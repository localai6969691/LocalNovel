package com.colablive.keeper.core

import android.content.Context
import android.content.Intent

/**
 * Mục 145 — lựa chọn ĐỒNG BỘ khi sao lưu/khôi phục hồ sơ.
 * Tra cứu: các trình chống phát hiện (Multilogin, GoLogin, Sendwin...) coi hồ sơ là MỘT GÓI gồm dấu vân tay + cookie/lưu trữ + proxy;
 * cookie nhập vào mà dấu vân tay hoặc IP lệch so với lúc đăng nhập thì dễ bị vô hiệu (Google/Meta gắn phiên với thiết bị).
 *  - [data]        = dữ liệu đăng nhập & trang web của hồ sơ (cookie, localStorage/IndexedDB, addon... = thư mục profile_data)
 *  - [fingerprint] = danh tính dấu vân tay (seed canvas/audio/WebGL, mẫu phần cứng, locale, múi giờ, công tắc `fp_*`)
 * Mặc định BẬT CẢ HAI (đồng bộ). Tắt một phần chỉ dành cho người hiểu hệ quả (UI có cảnh báo).
 */
data class BackupSyncOptions(val data: Boolean = true, val fingerprint: Boolean = true) {
    val synced: Boolean get() = data && fingerprint

    fun putInto(i: Intent) { i.putExtra(EXTRA_SYNC_DATA, data); i.putExtra(EXTRA_SYNC_FP, fingerprint) }

    fun remember(context: Context, forExport: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(key(forExport, "data"), data).putBoolean(key(forExport, "fp"), fingerprint).apply()
    }

    companion object {
        const val EXTRA_SYNC_DATA = "sync_data"
        const val EXTRA_SYNC_FP = "sync_fingerprint"
        private const val PREFS = "backup_sync_options"
        private fun key(forExport: Boolean, part: String) = (if (forExport) "export_" else "import_") + part

        fun from(i: Intent?): BackupSyncOptions =
            BackupSyncOptions(i?.getBooleanExtra(EXTRA_SYNC_DATA, true) ?: true, i?.getBooleanExtra(EXTRA_SYNC_FP, true) ?: true)

        fun last(context: Context, forExport: Boolean): BackupSyncOptions {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return BackupSyncOptions(p.getBoolean(key(forExport, "data"), true), p.getBoolean(key(forExport, "fp"), true))
        }
    }
}

/** Nguồn DUY NHẤT của công thức danh tính dấu vân tay mặc định theo TÊN hồ sơ (engine, export và import dùng chung). */
object FingerprintIdentity {
    fun isFingerprintKey(k: String) = k.startsWith("fp_")

    fun defaultSeedFor(profileName: String): Long {
        val d = java.security.MessageDigest.getInstance("SHA-256").digest(("lb-fp-noise-seed:$profileName").toByteArray())
        var v = 0L
        for (i in 0 until 7) v = (v shl 8) or (d[i].toLong() and 0xff)
        return if (v == 0L) 1L else v
    }

    fun seedHash(seed: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest(seed.toByteArray()).take(4).joinToString("") { "%02x".format(it) }
}

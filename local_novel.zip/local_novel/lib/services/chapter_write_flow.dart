import 'dart:async';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'authorship_service.dart';
import 'chapter_writer_service.dart';
import 'debug_log_service.dart';
import 'prefill_budget.dart';
import 'providers/local_provider.dart';
import 'rag_service.dart';
import 'settings_service.dart';
import 'style_service.dart';
import 'translation_service.dart';

// MỤC CV (2026-10-13) — LỚP DÍNH giữa ChapterWriterService (thuật toán viết theo ý, thuần Dart) và phần còn lại của app (cài đặt, dịch thuật trung gian, provider).
// Dùng chung cho "Tạo hàng loạt" (chapter_batch_service.dart) và "Đắp thịt" (chapter_editor_screen.dart) để 2 nơi không mỗi nơi một kiểu.
//
// Việc của lớp này:
//   1. Giải chế độ chia lượt ('auto' => local: two_part, API: beats, web chat: single) và số chữ mục tiêu từ cài đặt riêng của truyện.
//   2. Khi dịch thuật trung gian đang BẬT và chế độ là 'auto' => ép 'single': mỗi lượt phải dịch cả system+user sang ngôn ngữ trung gian rồi dịch ngược kết quả,
//      chia thành nhiều lượt sẽ nhân đôi/ba chi phí đó. (Người dùng chọn tay chế độ khác thì tôn trọng.)
//   3. Tạo hàm `generate` cho từng lượt: đi qua TranslationService.generateWithOptionalTranslation — nên VẪN tôn trọng dịch thuật trung gian, streaming chữ dần lên UI,
//      và huỷ giữa chừng (isCancelled) như mọi luồng sinh văn bản khác trong app. Không gọi provider trực tiếp ở đâu cả.
//   4. Lấy câu hướng dẫn văn phong (StyleService.styleInstructionFor) — dùng chung với các luồng khác.
class ChapterWriteFlow {
  // MỤC CV2: dựng (nội dung nền, điểm dừng) từ nội dung chương + cột điểm dừng + dàn ý hiện tại. Điểm dừng không khớp thì vẫn giữ phần đã viết và viết TIẾP
  // từ cuối nó (số ý đã xong là ước lượng) — xem WriterCheckpoint.reconcile. `legacyInContent`: true ở màn soạn (chữ nằm sẵn trong nội dung chương).
  static Future<({String base, WriterCheckpoint? resume})> prepareResume({
    required String novelId,
    required String outline,
    required String content,
    required String? rawCheckpoint,
    bool legacyInContent = false,
  }) async {
    final targetWords = await SettingsService().loadChapterTargetWords(novelId);
    return WriterCheckpoint.reconcile(
      content: content,
      rawCheckpoint: rawCheckpoint,
      beats: ChapterWriterService.parseBeats(outline),
      targetWords: targetWords,
      legacyInContent: legacyInContent,
    );
  }

  // MỤC CV3 (2026-10-15): 3 việc dùng chung cho mọi luồng viết (Tạo hàng loạt, Đắp thịt, Viết tiếp):
  //   (1) `modelKeyOf`: khoá model (cùng khoá với hệ số token/chữ) để lưu thứ đã học theo model;
  //   (2) `promptCharLimit`: trần độ dài prompt (ký tự) = tốc độ nạp đã đo × số giây tối đa (chỉ cho model local; null nếu chưa đo/đã tắt) — xem prefill_budget.dart;
  //   (3) `recordPrefill`: sau mỗi lượt sinh của model local, ghi mẫu tốc độ nạp (ký tự/giây) mà LocalLlamaProvider vừa đo.
  static String modelKeyOf(ModelTag tag) => '${tag.kind}|${tag.provider}|${tag.modelId}';

  static Future<int?> promptCharLimit(SettingsService settings, String modelKey, AIProvider provider) async {
    if (provider is! LocalLlamaProvider) return null;
    final target = await settings.loadPrefillTargetSec();
    if (target <= 0) return null;
    final speed = await settings.loadPrefillSpeed(PrefillBudget.speedKey(modelKey, provider.activeBackendName));
    return PrefillBudget.maxPromptChars(speed, target);
  }

  static Future<void> recordPrefill(SettingsService settings, String modelKey, AIProvider provider) async {
    if (provider is! LocalLlamaProvider) return;
    final ms = provider.lastPrefillMs;
    final chars = provider.lastPromptChars;
    if (!PrefillBudget.plausibleSample(chars, ms)) return;
    final cps = chars / (ms / 1000.0);
    final backend = provider.activeBackendName;
    await settings.recordPrefillSample(PrefillBudget.speedKey(modelKey, backend), cps);
    if (backend != null) await settings.recordPrefillSample(PrefillBudget.speedKey(modelKey, null), cps);
    final saved = await settings.loadPrefillSpeed(PrefillBudget.speedKey(modelKey, backend));
    unawaited(DebugLogService.instance.log('[CV3-PREFILL] $modelKey (backend ${backend ?? '?'}): prompt $chars ký tự, token đầu sau $ms ms => ${cps.toStringAsFixed(1)} ký tự/giây '
        '(trung bình đã lưu ${saved?.toStringAsFixed(1) ?? '?'}). Số đo gián tiếp: thời gian tới token đầu, không phải số token thật.'));
  }

  // Bọc 1 lần gọi model: gắn `shouldAbort` của bộ bắt chép-lại-prompt vào cờ huỷ của TranslationService (dừng stream sớm), CHẶN không cho chữ bị bắt lọt vào `onChunk`,
  // rồi ghi mẫu tốc độ nạp. Dùng chung cho `_runWriter` và nút "Viết tiếp" (màn soạn chương cũng dùng hàm này cho "Viết tiếp").
  static SegmentGenerator buildGenerator({
    required TranslationService translation,
    required AIProvider provider,
    required SettingsService settings,
    required String modelKey,
    required double temperature,
    required double topP,
    required int topK,
    required double repetitionPenalty,
    bool Function()? isCancelled,
    void Function(String stage)? onStage,
  }) {
    return ({required systemPrompt, required userPrompt, required maxTokens, onChunk, shouldAbort}) async {
      var aborted = false;
      try {
        return await translation.generateWithOptionalTranslation(
          mainProvider: provider,
          systemPrompt: systemPrompt,
          userPrompt: userPrompt,
          temperature: temperature,
          maxTokens: maxTokens,
          topP: topP,
          topK: topK,
          repetitionPenalty: repetitionPenalty,
          isCancelled: () => aborted || (isCancelled?.call() ?? false),
          onStage: onStage,
          onChunk: (soFar) {
            if (!aborted && shouldAbort != null && shouldAbort(soFar)) aborted = true;
            if (!aborted) onChunk?.call(soFar);
          },
        );
      } finally {
        await recordPrefill(settings, modelKey, provider);
      }
    };
  }

  static Future<ChapterWriteResult> run({
    required String novelId,
    required AIProvider provider,
    required String outline,
    required int chapterNumber,
    required StyleProfile? style,
    required RagService rag,
    String existingText = '',
    WriterCheckpoint? resume,
    double temperature = 0.95,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool Function()? isCancelled,
    void Function(String fullSoFar)? onChunk,
    void Function(String stage)? onStage,
    void Function(String textSoFar, int beatsDone, int beatsTotal)? onSegmentDone,
  }) async {
    final settings = SettingsService();
    final translation = TranslationService(settings, novelId: novelId);

    var mode = await settings.resolveChapterWriteMode(novelId);
    if (await settings.loadChapterWriteMode(novelId) == 'auto' && await translation.isEnabled) {
      mode = 'single';
    }
    final targetWords = await settings.loadChapterTargetWords(novelId);
    final styleInstruction = await StyleService().styleInstructionFor(
      style: style,
      rag: rag,
      currentChapterNumber: chapterNumber,
    );
    // Ngân sách "đoạn vừa viết": model local nạp prompt rất chậm (đo ~7-12 token/giây ở CPU) nên giữ ngắn; API có ngữ cảnh lớn nên cho dài hơn để nối mạch tốt hơn.
    final tag = await settings.currentModelTag(novelId);
    final tailChars = tag.kind == 'local' ? 1500 : 4000;
    // MỤC CV2: hệ số token/chữ HỌC ĐƯỢC theo model (xem ChapterWriterService.write) + log thống kê từng lượt ([CV2-SEG]) để đo thời gian/độ dài thật.
    final modelKey = modelKeyOf(tag);
    final learnedTpw = await settings.loadTokensPerWord(modelKey) ?? ChapterWriterService.kTokensPerWord;
    // MỤC CV3: bậc Bible đã học cho model này (model từng chép lại prompt ở bậc thấp hơn thì bắt đầu từ bậc đã học — khỏi tốn thêm một lần nạp prompt vô ích).
    final guardLevel = await settings.loadEchoGuardLevel(modelKey);

    // Model local: bọc CẢ chuỗi các lượt trong 1 phiên Foreground Service (đếm tham chiếu ở phía native — các begin/end lồng nhau của từng lượt
    // trong TranslationService không tắt dịch vụ giữa các lượt, xem MnnBridge.kt `pipelineDepth`) để tắt màn hình giữa các lượt không bị hệ thống treo.
    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) await LocalLlamaProvider.beginPipeline('Đang viết chương...');
    try {
      return await _runWriter(
        translation: translation,
        provider: provider,
        outline: outline,
        mode: mode,
        targetWords: targetWords,
        styleInstruction: styleInstruction,
        rag: rag,
        chapterNumber: chapterNumber,
        existingText: existingText,
        resume: resume,
        tailChars: tailChars,
        temperature: temperature,
        topP: topP,
        topK: topK,
        repetitionPenalty: repetitionPenalty,
        isCancelled: isCancelled,
        onChunk: onChunk,
        onStage: onStage,
        onSegmentDone: onSegmentDone,
        tokensPerWord: learnedTpw,
        onTokensPerWordLearned: (v) {
          unawaited(settings.saveTokensPerWord(modelKey, v));
          unawaited(DebugLogService.instance.log('[CV2-TPW] $modelKey: lượt bị cắt ở giới hạn token — hệ số token/chữ đo được ${v.toStringAsFixed(2)} (trước đó ${learnedTpw.toStringAsFixed(2)}), đã lưu'));
        },
        onSegmentStats: (info) => unawaited(DebugLogService.instance.log('[CV2-SEG] $modelKey: $info')),
        modelKey: modelKey,
        settings: settings,
        guardLevel: guardLevel,
        onGuardLevelChanged: (lv) {
          unawaited(settings.saveEchoGuardLevel(modelKey, lv));
          unawaited(DebugLogService.instance.log('[CV3-ECHO] $modelKey: đã lưu bậc Bible $lv (bậc thấp hơn bị model chép lại prompt, bậc này viết được) — lần viết sau bắt đầu từ bậc này'));
        },
        promptCharLimit: () => promptCharLimit(settings, modelKey, provider),
        onLog: (line) => unawaited(DebugLogService.instance.log('$line [$modelKey]')),
      );
    } finally {
      if (isLocal) await LocalLlamaProvider.endPipeline();
    }
  }

  static Future<ChapterWriteResult> _runWriter({
    required TranslationService translation,
    required AIProvider provider,
    required String outline,
    required String mode,
    required int targetWords,
    required String styleInstruction,
    required RagService rag,
    required int chapterNumber,
    required String existingText,
    required WriterCheckpoint? resume,
    required int tailChars,
    required double temperature,
    required double topP,
    required int topK,
    required double repetitionPenalty,
    required bool Function()? isCancelled,
    required void Function(String fullSoFar)? onChunk,
    required void Function(String stage)? onStage,
    required void Function(String textSoFar, int beatsDone, int beatsTotal)? onSegmentDone,
    required double tokensPerWord,
    required void Function(double learned)? onTokensPerWordLearned,
    required void Function(String info)? onSegmentStats,
    required String modelKey,
    required SettingsService settings,
    required int guardLevel,
    required void Function(int level)? onGuardLevelChanged,
    required Future<int?> Function()? promptCharLimit,
    required void Function(String line)? onLog,
  }) {
    // Trạng thái hiện tại do ChapterWriterService báo ("Đang viết phần 2/3...") — ghép với trạng thái nhỏ hơn của bước dịch/sinh để người dùng thấy cả hai.
    var segmentStage = '';

    return ChapterWriterService.write(
      outline: outline,
      mode: mode,
      targetWords: targetWords,
      styleInstruction: styleInstruction,
      rag: rag,
      chapterNumber: chapterNumber,
      existingText: existingText,
      resume: resume,
      tailChars: tailChars,
      isCancelled: isCancelled,
      onChunk: onChunk,
      onStage: (stage) {
        segmentStage = stage;
        onStage?.call(stage);
      },
      onSegmentDone: onSegmentDone,
      tokensPerWord: tokensPerWord,
      onTokensPerWordLearned: onTokensPerWordLearned,
      onSegmentStats: onSegmentStats,
      guardLevel: guardLevel,
      onGuardLevelChanged: onGuardLevelChanged,
      promptCharLimit: promptCharLimit,
      onLog: onLog,
      generate: buildGenerator(
        translation: translation,
        provider: provider,
        settings: settings,
        modelKey: modelKey,
        temperature: temperature,
        topP: topP,
        topK: topK,
        repetitionPenalty: repetitionPenalty,
        isCancelled: isCancelled,
        onStage: (inner) => onStage?.call(segmentStage.isEmpty ? inner : '$segmentStage · $inner'),
      ),
    );
  }
}

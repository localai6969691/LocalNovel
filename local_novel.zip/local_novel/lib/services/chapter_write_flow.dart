import 'dart:async';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'chapter_writer_service.dart';
import 'debug_log_service.dart';
import 'providers/local_provider.dart';
import 'rag_service.dart';
import 'settings_service.dart';
import 'style_service.dart';
import 'translation_service.dart';

// MỤC CV (2026-10-13) — LỚP DÍNH giữa ChapterWriterService (thuật toán viết theo ý, thuần Dart) và phần còn lại của app (cài đặt, dịch thuật trung gian, provider).
// Dùng chung cho "Tạo hàng loạt" (chapter_batch_service.dart) và "Đắp thịt" (chapter_editor_screen.dart) để 2 nơi không mỗi nơi một kiểu.
//
// Việc của lớp này:
//   1. Giải chế độ chia lượt ('auto' => local: two_part, API: beats, web chat: single) và số chữ mục tiêu từ cài đặt riêng của truyện.
//   2. Khi dịch thuật trung gian đang BẬT và chế độ là 'auto' => ép 'single': mỗi lượt phải dịch cả system+user sang ngôn ngữ trung gian rồi dịch ngược kết quả,
//      chia thành nhiều lượt sẽ nhân đôi/ba chi phí đó. (Người dùng chọn tay chế độ khác thì tôn trọng.)
//   3. Tạo hàm `generate` cho từng lượt: đi qua TranslationService.generateWithOptionalTranslation — nên VẪN tôn trọng dịch thuật trung gian, streaming chữ dần lên UI,
//      và huỷ giữa chừng (isCancelled) như mọi luồng sinh văn bản khác trong app. Không gọi provider trực tiếp ở đâu cả.
//   4. Lấy câu hướng dẫn văn phong (StyleService.styleInstructionFor) — dùng chung với các luồng khác.
class ChapterWriteFlow {
  // MỤC CV2: dựng (nội dung nền, điểm dừng) từ nội dung chương + cột điểm dừng + dàn ý hiện tại. Điểm dừng không khớp thì vẫn giữ phần đã viết và viết TIẾP
  // từ cuối nó (số ý đã xong là ước lượng) — xem WriterCheckpoint.reconcile. `legacyInContent`: true ở màn soạn (chữ nằm sẵn trong nội dung chương).
  static Future<({String base, WriterCheckpoint? resume})> prepareResume({
    required String novelId,
    required String outline,
    required String content,
    required String? rawCheckpoint,
    bool legacyInContent = false,
  }) async {
    final targetWords = await SettingsService().loadChapterTargetWords(novelId);
    return WriterCheckpoint.reconcile(
      content: content,
      rawCheckpoint: rawCheckpoint,
      beats: ChapterWriterService.parseBeats(outline),
      targetWords: targetWords,
      legacyInContent: legacyInContent,
    );
  }

  static Future<ChapterWriteResult> run({
    required String novelId,
    required AIProvider provider,
    required String outline,
    required int chapterNumber,
    required StyleProfile? style,
    required RagService rag,
    String existingText = '',
    WriterCheckpoint? resume,
    double temperature = 0.95,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool Function()? isCancelled,
    void Function(String fullSoFar)? onChunk,
    void Function(String stage)? onStage,
    void Function(String textSoFar, int beatsDone, int beatsTotal)? onSegmentDone,
  }) async {
    final settings = SettingsService();
    final translation = TranslationService(settings, novelId: novelId);

    var mode = await settings.resolveChapterWriteMode(novelId);
    if (await settings.loadChapterWriteMode(novelId) == 'auto' && await translation.isEnabled) {
      mode = 'single';
    }
    final targetWords = await settings.loadChapterTargetWords(novelId);
    final styleInstruction = await StyleService().styleInstructionFor(
      style: style,
      rag: rag,
      currentChapterNumber: chapterNumber,
    );
    // Ngân sách "đoạn vừa viết": model local nạp prompt rất chậm (đo ~7-12 token/giây ở CPU) nên giữ ngắn; API có ngữ cảnh lớn nên cho dài hơn để nối mạch tốt hơn.
    final tag = await settings.currentModelTag(novelId);
    final tailChars = tag.kind == 'local' ? 1500 : 4000;
    // MỤC CV2: hệ số token/chữ HỌC ĐƯỢC theo model (xem ChapterWriterService.write) + log thống kê từng lượt ([CV2-SEG]) để đo thời gian/độ dài thật.
    final modelKey = '${tag.kind}|${tag.provider}|${tag.modelId}';
    final learnedTpw = await settings.loadTokensPerWord(modelKey) ?? ChapterWriterService.kTokensPerWord;

    // Model local: bọc CẢ chuỗi các lượt trong 1 phiên Foreground Service (đếm tham chiếu ở phía native — các begin/end lồng nhau của từng lượt
    // trong TranslationService không tắt dịch vụ giữa các lượt, xem MnnBridge.kt `pipelineDepth`) để tắt màn hình giữa các lượt không bị hệ thống treo.
    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) await LocalLlamaProvider.beginPipeline('Đang viết chương...');
    try {
      return await _runWriter(
        translation: translation,
        provider: provider,
        outline: outline,
        mode: mode,
        targetWords: targetWords,
        styleInstruction: styleInstruction,
        rag: rag,
        chapterNumber: chapterNumber,
        existingText: existingText,
        resume: resume,
        tailChars: tailChars,
        temperature: temperature,
        topP: topP,
        topK: topK,
        repetitionPenalty: repetitionPenalty,
        isCancelled: isCancelled,
        onChunk: onChunk,
        onStage: onStage,
        onSegmentDone: onSegmentDone,
        tokensPerWord: learnedTpw,
        onTokensPerWordLearned: (v) {
          unawaited(settings.saveTokensPerWord(modelKey, v));
          unawaited(DebugLogService.instance.log('[CV2-TPW] $modelKey: lượt bị cắt ở giới hạn token — hệ số token/chữ đo được ${v.toStringAsFixed(2)} (trước đó ${learnedTpw.toStringAsFixed(2)}), đã lưu'));
        },
        onSegmentStats: (info) => unawaited(DebugLogService.instance.log('[CV2-SEG] $modelKey: $info')),
      );
    } finally {
      if (isLocal) await LocalLlamaProvider.endPipeline();
    }
  }

  static Future<ChapterWriteResult> _runWriter({
    required TranslationService translation,
    required AIProvider provider,
    required String outline,
    required String mode,
    required int targetWords,
    required String styleInstruction,
    required RagService rag,
    required int chapterNumber,
    required String existingText,
    required WriterCheckpoint? resume,
    required int tailChars,
    required double temperature,
    required double topP,
    required int topK,
    required double repetitionPenalty,
    required bool Function()? isCancelled,
    required void Function(String fullSoFar)? onChunk,
    required void Function(String stage)? onStage,
    required void Function(String textSoFar, int beatsDone, int beatsTotal)? onSegmentDone,
    required double tokensPerWord,
    required void Function(double learned)? onTokensPerWordLearned,
    required void Function(String info)? onSegmentStats,
  }) {
    // Trạng thái hiện tại do ChapterWriterService báo ("Đang viết phần 2/3...") — ghép với trạng thái nhỏ hơn của bước dịch/sinh để người dùng thấy cả hai.
    var segmentStage = '';

    return ChapterWriterService.write(
      outline: outline,
      mode: mode,
      targetWords: targetWords,
      styleInstruction: styleInstruction,
      rag: rag,
      chapterNumber: chapterNumber,
      existingText: existingText,
      resume: resume,
      tailChars: tailChars,
      isCancelled: isCancelled,
      onChunk: onChunk,
      onStage: (stage) {
        segmentStage = stage;
        onStage?.call(stage);
      },
      onSegmentDone: onSegmentDone,
      tokensPerWord: tokensPerWord,
      onTokensPerWordLearned: onTokensPerWordLearned,
      onSegmentStats: onSegmentStats,
      generate: ({required systemPrompt, required userPrompt, required maxTokens, onChunk}) {
        return translation.generateWithOptionalTranslation(
          mainProvider: provider,
          systemPrompt: systemPrompt,
          userPrompt: userPrompt,
          temperature: temperature,
          maxTokens: maxTokens,
          topP: topP,
          topK: topK,
          repetitionPenalty: repetitionPenalty,
          isCancelled: isCancelled,
          onStage: (inner) => onStage?.call(segmentStage.isEmpty ? inner : '$segmentStage · $inner'),
          onChunk: onChunk,
        );
      },
    );
  }
}

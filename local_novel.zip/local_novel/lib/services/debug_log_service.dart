import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

// Ghi log ra FILE THẬT (flush ngay lập tức, không đợi buffer hệ điều hành)
// — mục đích riêng: khi app bị crash native (SIGSEGV ở tầng C++, Kotlin
// try/catch không bắt được, toàn bộ tiến trình chết ngay lập tức không kịp
// hiện lỗi gì), dòng log CUỐI CÙNG trong file này vẫn còn nguyên trên đĩa,
// cho biết chính xác app đang làm gì (gọi lệnh native nào, slot mấy, model
// nào) ngay trước khi chết — thay thế tạm cho việc không lấy được logcat
// thật (cần máy tính + ADB, nhiều người dùng không có sẵn).
//
// QUAN TRỌNG: dùng `getApplicationSupportDirectory()` (KHÔNG phải
// `getApplicationDocumentsDirectory()`) — trên Android, ApplicationSupport
// mới tương ứng đúng `context.getFilesDir()`, còn ApplicationDocuments lại
// map sang 1 thư mục KHÁC (`.../app_flutter`). Tầng Kotlin/C++
// (MnnBridge.kt, mnn_bridge.cpp) ghi log native vào `appContext.filesDir`
// — phải dùng đúng hàm Dart này thì mới đọc được CÙNG thư mục, không thì
// sẽ không bao giờ thấy file log native dù nó ghi ra thành công.
//
// Đây KHÔNG thay thế được logcat/tombstone thật (không biết được lý do sâu
// ở tầng C++, chỉ biết được ĐANG LÀM GÌ lúc chết) nhưng đủ để khoanh vùng
// chính xác bước nào gây crash mà không cần máy tính.
class DebugLogService {
  static final DebugLogService instance = DebugLogService._();
  DebugLogService._();

  File? _file;
  static const int _maxBytesBeforeTrim = 512 * 1024; // 512KB — đủ nhiều dòng, không phình vô hạn
  // MỤC CW: khi xuất log chỉ đọc tối đa ngần này byte CUỐI của mỗi file (file native trước đây đọc không giới hạn).
  static const int _maxBytesOnRead = 3 * 1024 * 1024;

  // MỤC CW (2026-10-16): hàng đợi tuần tự cho MỌI lần ghi. Trước đây `log()` được gọi song song (hầu hết nơi gọi dùng `unawaited`) và mỗi lần
  // tự làm "ghi nối đuôi -> đo cỡ -> (nếu quá to) đọc cả file -> ghi đè nửa cuối": các bước đọc-rồi-ghi-đè đó KHÔNG nguyên tử nên (1) dòng log ghi
  // chen vào giữa lúc đọc và lúc ghi đè bị MẤT, (2) ghi đè (cắt rồi ghi lại) chạy chồng với 1 lần ghi nối khác có thể để lại byte UTF-8 dở dang giữa
  // file => `readAsString()` nghiêm ngặt ném FormatException — đúng triệu chứng log 2026-10-15: "Lỗi đọc log Dart: Failed to decode data using
  // encoding 'utf-8'" (toàn bộ log Dart của phiên mất, không thấy [CV3-ECHO]/[CV2-SEG]...). Nguyên nhân chính xác của TRƯỜNG HỢP ĐÓ chưa chứng minh
  // được (file đã mất), nhưng đây là lỗ hổng thật; sửa: ghi tuần tự + cắt theo BYTE ở ranh giới dòng + đọc bằng giải mã dung thứ (`allowMalformed`).
  Future<void> _queue = Future<void>.value();

  Future<File> _getFile() async {
    if (_file != null) return _file!;
    final dir = await getApplicationSupportDirectory();
    _file = File('${dir.path}/debug_log.txt');
    return _file!;
  }

  // File log ghi từ tầng Kotlin/C++ (MnnBridge.kt, mnn_bridge.cpp) — nằm
  // CÙNG thư mục (appContext.filesDir == getApplicationSupportDirectory
  // trên Android) nhưng tên file khác, đọc riêng để không lẫn 2 nguồn log.
  Future<File> _getNativeFile() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/native_debug.txt');
  }

  Future<void> log(String message) {
    // Mốc thời gian lấy NGAY lúc gọi (không phải lúc tới lượt ghi) để thứ tự/giờ giữ đúng khi hàng đợi có độ trễ.
    final line = '[${DateTime.now().toIso8601String()}] $message\n';
    final next = _queue.then((_) => _appendLine(line)).catchError((_) {
      // Không để lỗi ghi log làm hỏng luồng chính — đây chỉ là công cụ hỗ
      // trợ chẩn đoán, không được phép tự nó gây thêm lỗi.
    });
    _queue = next;
    return next;
  }

  Future<void> _appendLine(String line) async {
    final f = await _getFile();
    await f.writeAsString(line, mode: FileMode.append, flush: true);

    // Cắt bớt nếu file phình quá to (giữ lại phần cuối, gần crash nhất
    // vẫn quan trọng hơn phần đầu). Làm theo BYTE, bắt đầu ở đầu 1 dòng
    // nguyên vẹn — không bao giờ cắt giữa 1 ký tự UTF-8 nhiều byte.
    final size = await f.length();
    if (size > _maxBytesBeforeTrim) {
      final bytes = await f.readAsBytes();
      var cut = bytes.length - (_maxBytesBeforeTrim ~/ 2);
      if (cut < 0) cut = 0;
      var nl = cut;
      while (nl < bytes.length && bytes[nl] != 0x0A) {
        nl++;
      }
      final start = nl < bytes.length ? nl + 1 : cut;
      await f.writeAsBytes(bytes.sublist(start), flush: true);
    }
  }

  // Đọc tối đa `_maxBytesOnRead` byte CUỐI của file, giải mã UTF-8 dung thứ (byte hỏng thành U+FFFD thay vì ném lỗi làm mất cả log).
  Future<String> _readTailText(File f) async {
    final length = await f.length();
    final raf = await f.open();
    try {
      final from = length > _maxBytesOnRead ? length - _maxBytesOnRead : 0;
      await raf.setPosition(from);
      final bytes = await raf.read(length - from);
      var text = utf8.decode(bytes, allowMalformed: true);
      if (from > 0) {
        final nl = text.indexOf('\n');
        text = '(... log cũ hơn đã bị bỏ bớt khi xuất; chỉ hiện ${_maxBytesOnRead ~/ 1024}KB cuối ...)\n${nl >= 0 ? text.substring(nl + 1) : text}';
      }
      return text;
    } finally {
      await raf.close();
    }
  }

  // Đọc CẢ 2 nguồn (Dart + Kotlin/C++), gộp lại theo mốc thời gian ghi
  // (mỗi dòng đã tự có timestamp riêng, chỉ cần nối chuỗi là đủ dễ đọc —
  // không cần parse/sort phức tạp, người đọc tự so timestamp bằng mắt).
  Future<String> readAll() async {
    final buffer = StringBuffer();
    try {
      await _queue; // MỤC CW: đợi các dòng log đang xếp hàng ghi xong để bản xuất không thiếu dòng cuối
    } catch (_) {}
    try {
      final f = await _getFile();
      if (await f.exists()) {
        final c = await _readTailText(f);
        if (c.isNotEmpty) {
          buffer.writeln('===== Log tầng Dart (debug_log.txt) =====');
          buffer.writeln(c);
        }
      }
    } catch (e) {
      buffer.writeln('(Lỗi đọc log Dart: $e)');
    }

    try {
      final nf = await _getNativeFile();
      if (await nf.exists()) {
        final c = await _readTailText(nf);
        if (c.isNotEmpty) {
          buffer.writeln('===== Log tầng Kotlin/C++ (native_debug.txt) =====');
          buffer.writeln(c);
        }
      }
    } catch (e) {
      buffer.writeln('(Lỗi đọc log native: $e)');
    }

    final result = buffer.toString();
    return result.isEmpty
        ? '(Chưa có log nào — log sẽ tự ghi khi bạn dùng model local.)'
        : result;
  }

  Future<void> clear() async {
    try {
      await _queue;
    } catch (_) {}
    try {
      final f = await _getFile();
      if (await f.exists()) await f.writeAsString('', flush: true);
    } catch (_) {}
    try {
      final nf = await _getNativeFile();
      if (await nf.exists()) await nf.writeAsString('', flush: true);
    } catch (_) {}
  }

  Future<String> filePath() async => (await _getFile()).path;
}

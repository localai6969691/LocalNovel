import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../ai_provider.dart';
import 'web_chat_js.dart';

// MỤC CS (2026-10-07) — PHIÊN TRÌNH DUYỆT NHÚNG ĐỂ DÙNG WEB CHAT AI LÀM "MODEL VIẾT TRUYỆN".
//
// Ý TƯỞNG: mọi tính năng của app (viết chương, chat, trích Story Bible...) đã gọi `AIProvider.generate*()` với system prompt (Story Bible, văn phong)
// + user prompt. WebChatProvider nhận 2 chuỗi đó, nhờ phiên này dán vào ô chat của trang web (đã đăng nhập bằng tay trong WebView), bấm gửi, đợi trả lời
// xong, đọc lại chữ trả lời rồi trả về như 1 model bình thường — nên chương vẫn được lưu bằng đúng luồng hiện có, không sửa gì ở phía màn hình viết.
//
// KIẾN TRÚC:
//   - 1 WebViewController dùng chung cả app (cookie đăng nhập nằm trong kho cookie của WebView Android, còn sau khi tắt app).
//   - WebChatHost (lib/widgets/web_chat_host.dart) gắn WebView vào cây widget: khi đang dùng thì phủ kín màn hình nhưng NẰM DƯỚI giao diện app
//     (để trang có kích thước thật, các kiểm tra "phần tử có hiện không" mới đúng); khi người dùng mở để đăng nhập/dạy thì hiện lên trên.
//   - Mọi lệnh JS đi qua kênh `LNCh` (JS gửi kết quả về bằng postMessage kèm id) — không dựa vào runJavaScriptReturningResult (kiểu trả về khác nhau giữa
//     nền tảng). Việc "hỏi đáp" chạy TUẦN TỰ (1 trang chỉ nhận 1 cuộc trò chuyện 1 lúc).
//   - Việc poll tiến độ chạy ở phía Dart (không dùng setInterval trong trang) vì trang bị xem là "ẩn" khi app xuống nền sẽ bị trình duyệt giãn timer.
// GIỚI HẠN THẬT (không giấu):
//   1. Chưa chạy thử trên máy thật, chưa chạy thử trên trang thật nào (không có Flutter SDK và không mở được các trang đó từ môi trường soạn).
//      Phần JS đã chạy thử trong Chromium trên 2 trang chat giả do chính tôi dựng — chỉ chứng minh logic, KHÔNG chứng minh khớp giao diện thật.
//   2. Chưa biết khi tắt màn hình WebView có chạy tiếp được không (trình duyệt có thể ngưng vẽ/giãn timer; mạng và evaluateJavascript thì thường vẫn chạy).
//   3. Điều khoản của nhiều dịch vụ cấm tự động hoá giao diện web; tài khoản có thể bị hạn chế. Gói miễn phí có hạn mức tin nhắn — app chỉ phát hiện
//      được qua chữ báo lỗi, không đọc được bộ đếm.
//   4. Google thường chặn đăng nhập "Tiếp tục với Google" trong trình duyệt nhúng; popup đăng nhập cũng không được hỗ trợ. Dùng email/mật khẩu nếu trang cho.
//   5. Các tham số temperature/top_p/max tokens KHÔNG áp dụng được với web chat (trang không cho chỉnh qua giao diện này).
class WebChatSession {
  WebChatSession._();
  static final WebChatSession instance = WebChatSession._();

  WebViewController? _controller;
  final GlobalKey viewKey = GlobalKey();

  // Host chỉ dựng WebView sau khi cần lần đầu (tránh tốn tài nguyên khi không dùng tính năng này).
  final ValueNotifier<bool> everNeeded = ValueNotifier<bool>(false);
  // Đang hiện cho người dùng thao tác (đăng nhập/dạy app).
  final ValueNotifier<bool> expanded = ValueNotifier<bool>(false);
  // Số yêu cầu đang chạy (để host cho WebView kích thước thật + hiện thanh tiến độ).
  final ValueNotifier<int> activeUsers = ValueNotifier<int>(0);
  final ValueNotifier<String> status = ValueNotifier<String>('');

  String label = '';
  String profileKey = '';
  String startUrl = '';
  // MỤC CT: cách lấy "model thư ký" cho nút "AI tự dạy" (đặt khi mở trình duyệt từ Cài đặt). null = nút báo chưa có model.
  Future<AIProvider> Function()? helperFactory;

  int _seq = 0;
  final Map<int, Completer<dynamic>> _pending = <int, Completer<dynamic>>{};
  Completer<void>? _pageDone;
  Future<void> _queue = Future<void>.value();
  bool _cancelRequested = false;

  WebViewController get controller {
    final existing = _controller;
    if (existing != null) return existing;
    final c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('LNCh', onMessageReceived: (JavaScriptMessage m) => _onMessage(m.message))
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (String url) {
          final d = _pageDone;
          if (d != null && !d.isCompleted) d.complete();
          unawaited(_inject());
        },
        onWebResourceError: (WebResourceError e) {
          // Lỗi tài nguyên phụ (ảnh, tracker) rất phổ biến — chỉ ghi lại, không coi là thất bại.
          debugPrint('[WebChat] lỗi tài nguyên: ${e.description}');
        },
      ));
    _controller = c;
    return c;
  }

  // ---------- hồ sơ selector đã dạy (riêng từng provider) ----------
  static String _profKey(String key) => 'web_chat_profile_$key';

  Future<Map<String, dynamic>> loadProfile(String key) async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(_profKey(key));
      if (raw == null) return <String, dynamic>{};
      final d = jsonDecode(raw);
      return d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  Future<void> saveProfile(String key, Map<String, dynamic> p) async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString(_profKey(key), jsonEncode(p));
    } catch (_) {}
  }

  Future<void> clearProfile(String key) async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.remove(_profKey(key));
    } catch (_) {}
  }

  // ---------- cầu nối JS ----------
  void _onMessage(String raw) {
    try {
      final m = jsonDecode(raw);
      if (m is! Map) return;
      final id = m['id'];
      if (id is! int) return;
      final c = _pending.remove(id);
      if (c == null || c.isCompleted) return;
      if (m['ok'] == true) {
        c.complete(m['v']);
      } else {
        c.completeError(Exception('JS: ${m['e']}'));
      }
    } catch (_) {}
  }

  Future<void> _inject() async {
    try {
      await controller.runJavaScript(kWebChatJs);
    } catch (_) {}
  }

  // Chạy 1 biểu thức JS (có thể trả Promise) và đợi kết quả qua kênh LNCh.
  Future<dynamic> _call(String expr, {Duration timeout = const Duration(seconds: 25)}) async {
    final id = ++_seq;
    final c = Completer<dynamic>();
    _pending[id] = c;
    final js = '(function(){try{'
        'if(!window.__LN){LNCh.postMessage(JSON.stringify({id:$id,ok:false,e:"chua nap thu vien JS"}));return;}'
        'Promise.resolve($expr).then(function(v){LNCh.postMessage(JSON.stringify({id:$id,ok:true,v:(v===undefined?null:v)}))},'
        'function(e){LNCh.postMessage(JSON.stringify({id:$id,ok:false,e:String(e)}))})'
        '}catch(e){LNCh.postMessage(JSON.stringify({id:$id,ok:false,e:String(e)}))}})()';
    try {
      await controller.runJavaScript(js);
      return await c.future.timeout(timeout);
    } on TimeoutException {
      throw Exception('Trang web không phản hồi lệnh (quá ${timeout.inSeconds} giây).');
    } finally {
      _pending.remove(id);
    }
  }

  Future<void> _loadPage(String url) async {
    final done = Completer<void>();
    _pageDone = done;
    await controller.loadRequest(Uri.parse(url));
    await done.future.timeout(const Duration(seconds: 60), onTimeout: () {});
    await _inject();
  }

  // Cho host kịp dựng WebView trước khi nạp trang.
  Future<void> _waitForView() async {
    await WidgetsBinding.instance.endOfFrame;
    await Future<void>.delayed(const Duration(milliseconds: 700));
  }

  Future<T> _serial<T>(Future<T> Function() fn) {
    final completer = Completer<T>();
    _queue = _queue.catchError((Object _) {}).then((_) async {
      try {
        completer.complete(await fn());
      } catch (e, st) {
        completer.completeError(e, st);
      }
    });
    return completer.future;
  }

  void cancelCurrent() {
    _cancelRequested = true;
  }

  // ---------- thao tác cho người dùng (đăng nhập / dạy app) ----------
  Future<void> openForUser({
    required String startUrl,
    required String profileKey,
    required String label,
    Future<AIProvider> Function()? helper,
  }) async {
    this.startUrl = startUrl;
    this.profileKey = profileKey;
    this.label = label;
    helperFactory = helper;
    everNeeded.value = true;
    expanded.value = true;
    status.value = 'Đã mở $label — đăng nhập nếu cần.';
    await _waitForView();
    if (startUrl.isNotEmpty) {
      try {
        await _loadPage(startUrl);
      } catch (e) {
        status.value = 'Không nạp được trang: $e';
      }
    }
  }

  void closeForUser() {
    expanded.value = false;
  }

  Future<String?> currentUrl() async {
    try {
      return await controller.currentUrl();
    } catch (_) {
      return null;
    }
  }

  Future<void> reloadPage() async {
    try {
      await controller.reload();
    } catch (_) {}
  }

  Future<bool> goBackIfPossible() async {
    try {
      if (await controller.canGoBack()) {
        await controller.goBack();
        return true;
      }
    } catch (_) {}
    return false;
  }

  // Dạy app: kind = 'input' | 'send' | 'stop' | 'reply'. Chờ người dùng chạm vào trang, lưu selector.
  Future<Map<String, dynamic>> pick(String kind) async {
    await _inject();
    final prof = await loadProfile(profileKey);
    await _call('LN.setProfile(${jsonEncode(prof)})');
    final r = await _call('LN.pick(${jsonEncode(kind)})', timeout: const Duration(seconds: 130));
    if (r is Map && r['ok'] == true && r['selector'] is String) {
      prof[kind] = r['selector'];
      await saveProfile(profileKey, prof);
      return Map<String, dynamic>.from(r);
    }
    return r is Map ? Map<String, dynamic>.from(r) : <String, dynamic>{'ok': false};
  }

  Future<Map<String, dynamic>> diagnose() async {
    await _inject();
    final prof = await loadProfile(profileKey);
    await _call('LN.setProfile(${jsonEncode(prof)})');
    final r = await _call('LN.diagnose()');
    return r is Map ? Map<String, dynamic>.from(r) : <String, dynamic>{};
  }

  // ---------- MỤC CT (2026-10-07): "AI TỰ DẠY" — model thư ký (API) giúp chọn ô nhập / nút gửi; vùng trả lời tự định vị ----------
  // CÁCH LÀM (mỗi bước đều có kiểm chứng thật, KHÔNG tin mù vào AI):
  //   1. JS liệt kê các ô gõ chữ trên trang (mã i0, i1...) → model chọn MÃ ô soạn tin chính (chỉ có 1 ứng viên thì khỏi hỏi).
  //   2. App gõ thử chữ "ping" vào ô đó, JS liệt kê lại các nút sát ô nhập kèm cờ `fresh` (nút MỚI hiện/bật sau khi gõ) → model chọn MÃ nút gửi.
  //      Model chỉ chọn MÃ trong danh sách do JS lập — không tự viết selector, nên không thể bịa ra selector không tồn tại.
  //      Model lỗi/trả sai mã → quay về luật dò hình dạng (ứng viên đầu tiên / nút `fresh` đầu tiên).
  //   3. CHẠY THỬ THẬT: tải lại trang, dán 1 câu hỏi, gửi, đợi và đọc trả lời bằng đúng đường dùng khi viết truyện. Thất bại → HOÀN LẠI cấu hình cũ.
  //   4. Vùng trả lời: tìm trên trang đúng đoạn chữ vừa nhận rồi lấy khối bao quanh (không dùng AI). Không định vị được → vẫn dùng cách dò theo mã tham chiếu.
  // ĐÁNH ĐỔI/GIỚI HẠN: (a) tốn đúng 1 tin nhắn thật trên tài khoản web chat để chạy thử; (b) nhãn các nút sát ô nhập + placeholder của ô gõ được gửi cho
  // model thư ký (không gửi nội dung các cuộc trò chuyện, nhưng là chữ lấy từ trang); (c) chưa thử trên trang thật nào — chỉ trên 3 trang giả; (d) nút DỪNG
  // không được dạy tự động (nút này chỉ hiện khi đang sinh; thiếu nó app đợi lâu hơn để chắc đã xong — xem _askInner).
  Future<String> autoTeach(AIProvider helper) => _serial<String>(() => _autoTeachInner(helper));

  List<Map<String, dynamic>> _candList(dynamic digest) {
    if (digest is! Map || digest['cands'] is! List) return <Map<String, dynamic>>[];
    return (digest['cands'] as List).whereType<Map>().map((Map e) => Map<String, dynamic>.from(e)).toList();
  }

  // Hỏi model thư ký chọn 1 MÃ trong danh sách ứng viên. Trả null nếu model lỗi / trả mã không có trong danh sách / trả null.
  Future<String?> _helperPick(AIProvider helper, String kind, dynamic digest) async {
    final cands = _candList(digest);
    if (cands.isEmpty) return null;
    final ids = cands.map((Map<String, dynamic> c) => c['id']).whereType<String>().toSet();
    final String task;
    if (kind == 'input') {
      task = 'Đây là các phần tử gõ được chữ trên một trang web chat AI (đã đăng nhập). Hãy chọn Ô SOẠN TIN CHÍNH — nơi người dùng gõ câu hỏi gửi cho AI '
          '(thường nằm thấp nhất màn hình, rộng nhất, placeholder kiểu "Ask anything"/"Message"/"Nhập tin nhắn"). KHÔNG chọn ô tìm kiếm, ô tên, ô chỉnh sửa tin cũ.';
    } else {
      task = 'Người dùng vừa gõ chữ vào ô soạn tin của một trang web chat AI. Đây là các nút nằm sát ô soạn tin. Hãy chọn NÚT GỬI tin nhắn '
          '(thường là mũi tên/máy bay giấy, nằm bên phải ô nhập; cờ fresh=true nghĩa là nút đó mới hiện/bật lên SAU khi gõ chữ — rất đáng ngờ là nút gửi). '
          'KHÔNG chọn nút đính kèm/tải tệp, micro/giọng nói, chọn model, nút dừng, nút tìm kiếm web, nút bị disabled.';
    }
    final prompt = '$task\n'
        'Chỉ trả về ĐÚNG MỘT dòng JSON, không giải thích: {"id":"<mã trong danh sách>"} — hoặc {"id":null} nếu không phần tử nào phù hợp.\n'
        'DANH SÁCH (JSON):\n${jsonEncode(digest)}';
    try {
      final out = await helper.generate(
        systemPrompt: 'Bạn là bộ phân tích giao diện web. Chỉ trả về JSON đúng định dạng được yêu cầu.',
        userPrompt: prompt,
        temperature: 0.1,
        maxTokens: 300,
      );
      // Lấy khối JSON CUỐI CÙNG trong câu trả lời (model có "suy nghĩ" thường nói vài chữ trước rồi mới ra kết quả).
      final ms = RegExp(r'\{[^{}]*\}').allMatches(out).toList();
      for (var i = ms.length - 1; i >= 0; i--) {
        try {
          final j = jsonDecode(ms[i].group(0)!);
          if (j is Map && j.containsKey('id')) {
            final id = j['id'];
            if (id is String && ids.contains(id)) return id;
            if (id == null) return null;
          }
        } catch (_) {}
      }
    } catch (e) {
      debugPrint('[WebChat] model thư ký không chọn được ($kind): $e');
    }
    return null;
  }

  Future<String> _autoTeachInner(AIProvider helper) async {
    final key = profileKey;
    final url = startUrl;
    if (url.trim().isEmpty || key.isEmpty) return 'Chưa mở trang nào để dạy — vào Cài đặt AI và bấm biểu tượng trình duyệt cạnh provider Web chat AI.';
    final log = StringBuffer();
    final oldProf = await loadProfile(key);
    final prof = Map<String, dynamic>.from(oldProf)
      ..remove('input')
      ..remove('send')
      ..remove('reply');
    try {
      status.value = 'AI tự dạy: đang phân tích trang...';
      await _inject();
      await _call('LN.setProfile(${jsonEncode(prof)})');
      await _call('LN.snapshotButtons()');

      // 1) ô nhập
      final d1 = await _call('LN.digest("input")');
      final c1 = _candList(d1);
      if (c1.isEmpty) {
        return 'Không thấy ô gõ chữ nào trên trang. Hãy đăng nhập và mở màn hình chat (thấy ô soạn tin) rồi bấm lại.';
      }
      String? inputId = c1.length == 1 ? (c1.first['id'] as String?) : await _helperPick(helper, 'input', d1);
      final inputByModel = inputId != null && c1.length > 1;
      inputId ??= c1.first['id'] as String?; // dự phòng: ô thấp nhất/rộng nhất (đã được JS xếp đầu)
      final ci = await _call('LN.commit(${jsonEncode(inputId)}, "input")');
      if (ci is! Map || ci['ok'] != true) return 'Không lập được selector cho ô nhập: ${jsonEncode(ci)}';
      prof['input'] = ci['selector'];
      log.writeln('• Ô nhập: ${ci['selector']} (${c1.length == 1 ? "chỉ có 1 ứng viên" : (inputByModel ? "model thư ký chọn" : "model không chọn được → lấy ô thấp nhất")})');
      await _call('LN.setProfile(${jsonEncode(prof)})');

      // 2) nút gửi (chỉ lộ ra sau khi gõ chữ)
      status.value = 'AI tự dạy: gõ thử để tìm nút gửi...';
      await _call('LN.fill("ping", "")');
      await Future<void>.delayed(const Duration(milliseconds: 900));
      final d2 = await _call('LN.digest("send")');
      final c2 = _candList(d2);
      String? sendId;
      var sendByModel = false;
      if (c2.isNotEmpty) {
        sendId = await _helperPick(helper, 'send', d2);
        sendByModel = sendId != null;
        if (sendId == null) {
          for (final Map<String, dynamic> c in c2) {
            if (c['fresh'] == true && c['disabled'] != true) {
              sendId = c['id'] as String?;
              break;
            }
          }
        }
      }
      if (sendId != null) {
        final cs = await _call('LN.commit(${jsonEncode(sendId)}, "send")');
        if (cs is Map && cs['ok'] == true) {
          prof['send'] = cs['selector'];
          log.writeln('• Nút gửi: ${cs['selector']} (${sendByModel ? "model thư ký chọn" : "luật dự phòng: nút mới hiện sau khi gõ"})');
        } else {
          log.writeln('• Nút gửi: không lập được selector (${jsonEncode(cs)}) → để app tự dò / bấm Enter');
        }
      } else {
        log.writeln('• Nút gửi: không có ứng viên rõ ràng → để app tự dò theo nhãn / bấm Enter');
      }
      await _call('LN.fill("", "")'); // dọn chữ "ping"
      await saveProfile(key, prof);

      // 3) chạy thử thật (tải lại trang để chắc selector còn đúng sau khi trang dựng lại từ đầu)
      status.value = 'AI tự dạy: gửi 1 tin thử thật...';
      String reply;
      try {
        reply = await _askInner(url, key, 'Trả lời đúng 1 câu ngắn bằng tiếng Việt: hôm nay trời đẹp không?', const Duration(minutes: 3));
      } catch (e) {
        await saveProfile(key, oldProf);
        return 'Chạy thử THẤT BẠI — đã hoàn lại cấu hình cũ, KHÔNG lưu gì mới.\nLý do: $e\n\nĐã thử:\n$log'
            'Bạn có thể dùng "Chọn ô nhập / Chọn nút gửi" thủ công.';
      }
      log.writeln('• Chạy thử thật: nhận được ${reply.length} ký tự trả lời.');

      // 4) vùng trả lời (không dùng AI)
      final lr = await _call('LN.locateReply(${jsonEncode(reply)})');
      if (lr is Map && lr['ok'] == true && lr['selector'] is String) {
        prof['reply'] = lr['selector'];
        await saveProfile(key, prof);
        log.writeln('• Vùng trả lời: ${lr['selector']} (khớp ${lr['matches']} khối).');
      } else {
        log.writeln('• Vùng trả lời: không định vị được (${lr is Map ? lr['e'] : lr}) → vẫn dùng cách dò theo mã tham chiếu (đã chạy được ở bước thử).');
      }
      status.value = 'AI tự dạy: xong.';
      return 'ĐÃ DẠY XONG và lưu cho trang này.\n$log'
          'Trả lời thử: ${reply.length > 160 ? '${reply.substring(0, 160)}…' : reply}';
    } catch (e) {
      await saveProfile(key, oldProf);
      return 'Lỗi khi tự dạy: $e (đã hoàn lại cấu hình cũ).\n$log';
    }
  }

  // ---------- hỏi đáp ----------
  Future<String> ask({
    required String startUrl,
    required String profileKey,
    required String prompt,
    Duration maxWait = const Duration(minutes: 25),
  }) {
    return _serial<String>(() => _askInner(startUrl, profileKey, prompt, maxWait));
  }

  static final RegExp _limitText = RegExp(
    r"(reached (the|your|our) .{0,40}limit|usage limit|too many requests|try again later|rate limit|quota|đạt giới hạn|hết hạn mức|quá nhiều yêu cầu|vui lòng thử lại sau)",
    caseSensitive: false,
  );

  Future<String> _askInner(String startUrl, String profileKey, String prompt, Duration maxWait) async {
    if (startUrl.trim().isEmpty) {
      throw Exception('Web chat AI chưa có URL — vào Cài đặt AI, sửa provider và chọn trang (ChatGPT/Gemini/Claude...).');
    }
    _cancelRequested = false;
    this.startUrl = startUrl;
    this.profileKey = profileKey;
    everNeeded.value = true;
    activeUsers.value = activeUsers.value + 1;
    try {
      status.value = 'Web chat: đang mở trang...';
      await _waitForView();
      await _loadPage(startUrl);

      final prof = await loadProfile(profileKey);
      var ready = false;
      final readyDeadline = DateTime.now().add(const Duration(seconds: 35));
      while (DateTime.now().isBefore(readyDeadline)) {
        if (_cancelRequested) throw Exception('Đã huỷ.');
        try {
          await _inject();
          await _call('LN.setProfile(${jsonEncode(prof)})');
          ready = (await _call('LN.hasInput()')) == true;
        } catch (_) {
          ready = false;
        }
        if (ready) break;
        await Future<void>.delayed(const Duration(seconds: 1));
      }
      if (!ready) {
        throw Exception(
            'Không thấy ô nhập tin trên trang (có thể CHƯA ĐĂNG NHẬP, trang đang chặn, hoặc giao diện đã đổi). '
            'Vào Cài đặt AI → bấm biểu tượng trình duyệt cạnh provider "Web chat AI" để đăng nhập/dạy lại.');
      }

      final nonce = 'LN-${Random().nextInt(1 << 30).toRadixString(16).padLeft(8, '0')}';
      final full = '$prompt\n\n— ref $nonce';
      status.value = 'Web chat: đang dán prompt (${full.length} ký tự)...';
      final fill = await _call('LN.fill(${jsonEncode(full)}, ${jsonEncode(nonce)})', timeout: const Duration(seconds: 120));
      if (fill is! Map || fill['ok'] != true) {
        throw Exception('Không dán được prompt vào ô nhập (${jsonEncode(fill)}). Thử "Dạy app → Chọn ô nhập".');
      }
      await Future<void>.delayed(const Duration(milliseconds: 700));
      final sub = await _call('LN.submit()');
      if (sub is! Map || sub['ok'] != true) {
        throw Exception('Không gửi được tin (${jsonEncode(sub)}). Thử "Dạy app → Chọn nút gửi".');
      }
      status.value = 'Web chat: đã gửi, đang chờ trả lời...';

      final started = DateTime.now();
      var last = '';
      DateTime stableSince = DateTime.now();
      var sawBusy = false;
      var sawText = false;
      var misses = 0;
      while (true) {
        if (_cancelRequested) throw Exception('Đã huỷ.');
        final elapsed = DateTime.now().difference(started);
        if (elapsed > maxWait) {
          throw Exception('Hết thời gian chờ web chat (${maxWait.inMinutes} phút).');
        }
        if (!sawText && !sawBusy && elapsed > const Duration(seconds: 150)) {
          throw Exception('Gửi rồi nhưng 150 giây không thấy trả lời — kiểm tra trang (đăng nhập hết hạn? báo giới hạn?). Dùng "Dạy app → Chọn vùng trả lời".');
        }
        await Future<void>.delayed(const Duration(milliseconds: 1500));
        dynamic r;
        try {
          r = await _call('LN.read(${jsonEncode(nonce)})');
          misses = 0;
        } catch (_) {
          // Trang có thể đang chuyển hướng giữa chừng — thử lại vài lần trước khi bỏ cuộc.
          misses++;
          if (misses > 20) rethrow;
          continue;
        }
        if (r is! Map) continue;
        final busy = r['busy'] == true;
        final reply = r['reply'] is String ? r['reply'] as String : '';
        if (busy) sawBusy = true;
        if (reply.isNotEmpty) sawText = true;
        if (reply != last) {
          last = reply;
          stableSince = DateTime.now();
          if (reply.isNotEmpty) status.value = 'Web chat: đang nhận trả lời... ${reply.length} ký tự';
          continue;
        }
        if (busy || !sawText) {
          stableSince = DateTime.now();
          continue;
        }
        // Có tín hiệu "đang sinh" (nút dừng) thì chỉ cần ổn định ngắn; không dò được thì chờ lâu hơn để khỏi cắt giữa lúc model nghỉ.
        final need = sawBusy ? 3 : 9;
        if (DateTime.now().difference(stableSince).inSeconds >= need) break;
      }

      final text = last.replaceAll(nonce, '').trim();
      if (text.isEmpty) throw Exception('Trang trả về rỗng.');
      if (text.length < 400 && _limitText.hasMatch(text)) {
        throw Exception('Trang báo giới hạn/lỗi thay vì trả lời: "${text.replaceAll('\n', ' ')}"');
      }
      status.value = 'Web chat: xong (${text.length} ký tự).';
      return text;
    } finally {
      activeUsers.value = max(0, activeUsers.value - 1);
    }
  }
}

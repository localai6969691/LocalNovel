// MỤC CS (2026-10-07) — THƯ VIỆN JS NHÚNG VÀO TRANG WEB CHAT. FILE NÀY ĐƯỢC SINH TỪ ln_webchat.js (đã chạy thử trong Chromium thật trên 2 trang chat GIẢ:
// kiểu ChatGPT = ô contenteditable + nút gửi + khối tin nhắn; kiểu Gemini = textarea + Enter + <model-response>) — KHÔNG phải trên các trang thật,
// vì môi trường soạn không mở được ChatGPT/Gemini/Claude. Giao diện thật có thể khác; khi đó dùng chức năng "Dạy app" (chọn ô nhập/nút gửi/vùng trả lời).
// Nguyên tắc: KHÔNG gõ cứng selector của 1 trang. Mặc định dò theo hình dạng (ô soạn thấp nhất màn hình, nút gần ô đó có chữ send/gửi, cắt phần chữ sau MÃ
// tham chiếu của tin nhắn mình vừa gửi). Selector người dùng dạy được lưu RIÊNG từng trang (SharedPreferences) và ưu tiên hơn dò tự động.
// Cập nhật (mục CT): thêm LN.snapshotButtons/digest/commit/locateReply cho nút "AI tự dạy" — đã chạy thử trong Chromium trên 3 trang chat giả (thêm 1 trang
// có nút gửi chỉ hiện sau khi gõ, không nhãn, kèm ô tìm kiếm + nút chat cũ ở thanh bên làm mồi nhử).
const String kWebChatJs = r'''
(function () {
  if (window.__LN && window.__LN.v === 2) return;
  var LN = window.__LN = { v: 2, lastNonce: '' };
  var P = {}; // hồ sơ selector do Dart nạp: { input, send, stop, reply }
  LN.setProfile = function (p) { P = p || {}; return true; };

  // ---------- tiện ích ----------
  function $(sel) { try { return sel ? document.querySelector(sel) : null; } catch (e) { return null; } }
  function $$(sel) { try { return sel ? Array.prototype.slice.call(document.querySelectorAll(sel)) : []; } catch (e) { return []; } }
  function vis(el) {
    if (!el || !el.getBoundingClientRect) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var cs = window.getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  }
  function label(el) {
    return ((el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-testid') || '') + ' ' +
      (el.getAttribute('title') || '') + ' ' + (el.innerText || '') + ' ' + (typeof el.className === 'string' ? el.className : '')).toLowerCase();
  }
  function esc(s) { return String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"'); }
  function cssEsc(s) { return (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_-]/g, '\\$&'); }

  // ---------- ô nhập ----------
  var EDITABLE = 'textarea, [contenteditable=""], [contenteditable="true"], [role="textbox"]';
  function rankedInputs() {
    var cands = $$(EDITABLE).filter(vis);
    // ưu tiên ô nằm thấp nhất màn hình, rộng nhất (ô soạn tin nằm cuối trang)
    cands.sort(function (a, b) {
      var ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      return (rb.bottom + rb.width / 1000) - (ra.bottom + ra.width / 1000);
    });
    return cands;
  }
  function findInput() {
    var el = $(P.input);
    if (el && vis(el)) return el;
    return rankedInputs()[0] || null;
  }
  LN.hasInput = function () { return !!findInput(); };

  function setNativeValue(el, text) {
    var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
    var d = Object.getOwnPropertyDescriptor(proto, 'value');
    if (d && d.set) d.set.call(el, text); else el.value = text;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function textOfInput(el) { return (el.value !== undefined && el.tagName !== 'DIV') ? (el.value || '') : (el.innerText || el.textContent || ''); }

  LN.fill = function (text, nonce) {
    LN.lastNonce = nonce || '';
    var el = findInput();
    if (!el) return { ok: false, e: 'khong thay o nhap' };
    el.focus();
    if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
      setNativeValue(el, text);
    } else {
      var sel = window.getSelection();
      var range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);
      try { document.execCommand('delete'); } catch (e) {}
      var ok = false;
      try { ok = document.execCommand('insertText', false, text); } catch (e) { ok = false; }
      if (!ok || (nonce && textOfInput(el).indexOf(nonce) < 0)) {
        try {
          var dt = new DataTransfer();
          dt.setData('text/plain', text);
          el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
        } catch (e) {}
      }
      if (nonce && textOfInput(el).indexOf(nonce) < 0) {
        el.textContent = text;
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }
    var got = textOfInput(el);
    return { ok: nonce ? got.indexOf(nonce) >= 0 : got.length > 0, len: got.length };
  };

  // ---------- nút gửi ----------
  function findSend(input) {
    var b = $(P.send);
    if (b && vis(b)) return b;
    var ir = input.getBoundingClientRect();
    var cx = ir.left + ir.width / 2, cy = ir.top + ir.height / 2;
    var best = null, bestD = 1e9;
    var btns = $$('button, [role="button"], [type="submit"]');
    for (var i = 0; i < btns.length; i++) {
      var el = btns[i];
      if (!vis(el) || el.disabled || el.getAttribute('aria-disabled') === 'true') continue;
      var s = label(el);
      if (!/(send|submit|gửi|gui tin|enviar|envoyer|arrow-?up|paper-?plane)/.test(s)) continue;
      if (/(stop|dừng|attach|đính kèm|upload|voice|micro|mic\b|ghi âm|dictat)/.test(s)) continue;
      var r = el.getBoundingClientRect();
      var d = Math.abs(r.left + r.width / 2 - cx) + Math.abs(r.top + r.height / 2 - cy);
      if (d < bestD) { best = el; bestD = d; }
    }
    return best;
  }
  function pressEnter(el) {
    var o = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent('keydown', o));
    el.dispatchEvent(new KeyboardEvent('keypress', o));
    el.dispatchEvent(new KeyboardEvent('keyup', o));
  }
  LN.submit = function () {
    var input = findInput();
    if (!input) return { ok: false, e: 'khong thay o nhap' };
    var btn = findSend(input);
    if (btn) { btn.click(); return { ok: true, how: 'button' }; }
    pressEnter(input);
    return { ok: true, how: 'enter' };
  };

  // ---------- trạng thái đang sinh ----------
  function isBusy() {
    var s = $(P.stop);
    if (s && vis(s)) return true;
    if (P.stop) return false; // người dùng đã dạy nút dừng: chỉ tin selector này
    var btns = $$('button, [role="button"]');
    for (var i = 0; i < btns.length; i++) {
      var b = btns[i];
      if (!vis(b)) continue;
      var t = ((b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('data-testid') || '') + ' ' + (b.getAttribute('title') || '')).toLowerCase();
      if (/(^|[^a-z])(stop|dừng)([^a-z]|$)/.test(t) && !/(sharing|recording|voice|ghi âm|listening)/.test(t)) return true;
    }
    return false;
  }

  // ---------- đọc trả lời ----------
  var LEAD_UI = /^(edit( message)?|copy|copied|retry|share|show thinking|thinking|you said:?|[\w .-]{1,24} said:?|bạn đã nói:?|.{1,24} đã nói:?|chỉnh sửa|sao chép|thử lại|chia sẻ|hiện suy nghĩ|đang suy nghĩ…?|thinking…?)$/i;
  var TAIL_UI = /^(copy|copied|retry|regenerate|share|good response|bad response|read aloud|more|sao chép|thử lại|chia sẻ|phản hồi tốt|phản hồi không tốt|đọc to|thêm)$/i;
  var TAIL_NOTE = /(can make mistakes|check important info|double-check|có thể mắc lỗi|có thể sai sót|kiểm tra lại thông tin|may display inaccurate)/i;
  var SYMBOL_ONLY = /^[^A-Za-z0-9\u00C0-\u024F\u1E00-\u1EFF]{1,3}$/; // 1-3 ký tự toàn ký hiệu (vd mũi tên nút gửi)
  function cleanReply(t, nonce) {
    var lines = String(t || '').replace(/\r/g, '').split('\n');
    if (nonce) lines = lines.filter(function (l) { return l.indexOf(nonce) < 0; });
    var n = 0;
    while (lines.length && n < 8 && (lines[0].trim() === '' || LEAD_UI.test(lines[0].trim()))) { lines.shift(); n++; }
    n = 0;
    while (lines.length && n < 14) {
      var l = lines[lines.length - 1].trim();
      if (l === '' || TAIL_UI.test(l) || SYMBOL_ONLY.test(l) || (l.length < 200 && TAIL_NOTE.test(l))) { lines.pop(); n++; } else break;
    }
    return lines.join('\n').trim();
  }
  LN.read = function (nonce) {
    var busy = isBusy();
    var reply = '', mode = 'diff';
    if (P.reply) {
      var els = $$(P.reply).filter(function (e) { return (e.innerText || '').trim() !== ''; });
      if (els.length) {
        mode = 'profile';
        var t = els[els.length - 1].innerText || '';
        var k = t.indexOf(nonce);
        if (k >= 0) t = t.slice(k + nonce.length);
        reply = cleanReply(t, nonce);
      }
    }
    if (!reply && mode !== 'profile') {
      var full = document.body ? document.body.innerText : '';
      var i = full.indexOf(nonce);
      if (i >= 0) reply = cleanReply(full.slice(i + nonce.length), nonce);
    }
    return { busy: busy, reply: reply, mode: mode, len: reply.length };
  };

  // ---------- chọn phần tử (dạy app) ----------
  function segOf(n, many) {
    var tag = n.tagName.toLowerCase();
    var bad = /\d|:/;
    var a = n.getAttribute('data-testid');
    if (a && !(many && bad.test(a))) return tag + '[data-testid="' + esc(a) + '"]';
    a = n.getAttribute('data-message-author-role');
    if (a) return tag + '[data-message-author-role="' + esc(a) + '"]';
    a = n.getAttribute('aria-label');
    if (a && a.length < 60 && !(many && bad.test(a))) return tag + '[aria-label="' + esc(a) + '"]';
    if (n.id && !/\d{3,}|:/.test(n.id)) return tag + '#' + cssEsc(n.id);
    var cls = (typeof n.className === 'string' ? n.className : '').split(/\s+/).filter(function (c) {
      return c && /^[A-Za-z][A-Za-z-]{2,24}$/.test(c) && !/^(css|jsx|sc|svelte|ng|_)/i.test(c);
    }).slice(0, 2);
    var role = n.getAttribute('role');
    return tag + (cls.length ? '.' + cls.map(cssEsc).join('.') : '') + (role ? '[role="' + esc(role) + '"]' : '');
  }
  function cssFor(el, many) {
    var parts = [], n = el, sel = '';
    for (var d = 0; n && n.nodeType === 1 && n !== document.documentElement && d < 8; d++, n = n.parentElement) {
      parts.unshift(segOf(n, many));
      sel = parts.join(' > ');
      var found = $$(sel);
      if (many ? (found.indexOf(el) >= 0 && found.length <= 400) : (found.length === 1 && found[0] === el)) return sel;
    }
    if (!many) {
      var i = 1, sib = el;
      while ((sib = sib.previousElementSibling)) if (sib.tagName === el.tagName) i++;
      var withNth = sel + ':nth-of-type(' + i + ')';
      if ($$(withNth).indexOf(el) >= 0) return withNth;
    }
    return sel;
  }
  function replyBlockOf(el) {
    // khối LỚN NHẤT chứa câu trả lời nhưng KHÔNG chứa tin nhắn kiểm tra (có mã) của người dùng
    var nonce = LN.lastNonce;
    var n = el, best = el;
    if (nonce) {
      for (var d = 0; n && n !== document.body && d < 14; d++, n = n.parentElement) {
        if ((n.innerText || '').indexOf(nonce) >= 0) break;
        best = n;
      }
      return best;
    }
    // không có mã: leo khi cha vẫn gần bằng con (bao ngoài sát)
    n = el;
    for (var d2 = 0; n && n.parentElement && n.parentElement !== document.body && d2 < 6; d2++, n = n.parentElement) {
      var pl = (n.parentElement.innerText || '').length, cl = (n.innerText || '').length;
      if (pl > cl * 1.15 + 40) break;
      best = n.parentElement;
    }
    return best;
  }
  LN.pick = function (kind) {
    return new Promise(function (resolve) {
      var done = false;
      var EV = ['pointerdown', 'pointerup', 'mousedown', 'mouseup', 'touchstart', 'touchend'];
      function stopper(e) { e.stopPropagation(); if (e.stopImmediatePropagation) e.stopImmediatePropagation(); }
      function cleanup() {
        document.removeEventListener('click', onClick, true);
        EV.forEach(function (n) { document.removeEventListener(n, stopper, true); });
      }
      function finish(res) { if (done) return; done = true; cleanup(); resolve(res); }
      function onClick(e) {
        e.preventDefault(); e.stopPropagation(); if (e.stopImmediatePropagation) e.stopImmediatePropagation();
        var el = e.target;
        if (!el || el.nodeType !== 1) return;
        var target = el, many = false;
        if (kind === 'input') target = el.closest(EDITABLE) || el.querySelector(EDITABLE);
        else if (kind === 'send' || kind === 'stop') target = el.closest('button, [role="button"]') || el;
        else if (kind === 'reply') { target = replyBlockOf(el); many = true; }
        if (!target) return finish({ ok: false, e: 'cham vao cho khong phu hop voi "' + kind + '"' });
        var old = target.style.outline;
        target.style.outline = '3px solid #e53935';
        setTimeout(function () { target.style.outline = old; }, 1500);
        var selector = cssFor(target, many);
        var n = $$(selector).length;
        finish({ ok: true, kind: kind, selector: selector, matches: n, sample: String(target.innerText || target.getAttribute('aria-label') || target.tagName).slice(0, 80) });
      }
      document.addEventListener('click', onClick, true);
      EV.forEach(function (n) { document.addEventListener(n, stopper, true); });
      setTimeout(function () { finish({ ok: false, e: 'het thoi gian cho cham (120s)' }); }, 120000);
    });
  };

  // ---------- AI tự dạy (mục CT) ----------
  // Nguyên tắc: JS KHÔNG đoán "đâu là nút gửi" bằng AI — nó chỉ LIỆT KÊ ứng viên có mã (i0, b3...) kèm thuộc tính nhìn thấy được; Dart gửi bảng này cho
  // model thư ký chọn MÃ, rồi quay lại đây xin selector (LN.commit). Model không bao giờ tự viết selector => không thể bịa ra selector không tồn tại.
  // Vùng trả lời không cần AI: sau khi chạy thử thật, tìm đoạn chữ vừa nhận trên trang (LN.locateReply).
  var CAND = {}, BEFORE_EL = [], BEFORE_SIG = {};
  function clip(s, n) { return String(s || '').replace(/\s+/g, ' ').trim().slice(0, n); }
  // Chữ ký chỉ dựa vào nhãn/lớp CSS (KHÔNG dùng vị trí: khi nút gửi hiện ra, các nút khác trong hàng bị đẩy lệch và sẽ bị tính nhầm là "mới").
  function sig(el) { return clip(label(el), 60); }
  function btnList() { return $$('button, [role="button"], [type="submit"], a[role="button"]').filter(vis); }
  function isOff(b) { return !!b.disabled || b.getAttribute('aria-disabled') === 'true'; }
  // Gọi TRƯỚC khi gõ chữ vào ô: nhớ các nút đang bấm được, để sau khi gõ biết nút nào MỚI xuất hiện/bật lên (thường là nút gửi).
  LN.snapshotButtons = function () {
    BEFORE_EL = []; BEFORE_SIG = {};
    btnList().forEach(function (b) { if (!isOff(b)) { BEFORE_EL.push(b); BEFORE_SIG[sig(b)] = 1; } });
    return BEFORE_EL.length;
  };
  LN.digest = function (kind) {
    CAND = {};
    var out = [], vw = window.innerWidth, vh = window.innerHeight, i;
    if (kind === 'input') {
      var eds = rankedInputs().slice(0, 8);
      for (i = 0; i < eds.length; i++) {
        var e = eds[i], r = e.getBoundingClientRect(), id = 'i' + i;
        CAND[id] = e;
        out.push({
          id: id, tag: e.tagName.toLowerCase(), role: clip(e.getAttribute('role'), 20),
          aria: clip(e.getAttribute('aria-label'), 60),
          placeholder: clip(e.getAttribute('placeholder') || e.getAttribute('data-placeholder') || e.getAttribute('aria-placeholder'), 60),
          bottomY: Math.round(r.bottom), width: Math.round(r.width), height: Math.round(r.height),
          hasText: textOfInput(e).trim().length > 0
        });
      }
    } else if (kind === 'send') {
      var inp = findInput();
      if (!inp) return { vw: vw, vh: vh, cands: [] };
      var ir = inp.getBoundingClientRect(), cx = ir.left + ir.width / 2, cy = ir.top + ir.height / 2;
      var list = [];
      btnList().forEach(function (b) {
        if (b === inp || inp.contains(b)) return;
        var br = b.getBoundingClientRect(), bx = br.left + br.width / 2, by = br.top + br.height / 2;
        // Chỉ xét nút nằm sát ô nhập (cùng dải ngang/dọc) — tránh gửi nhãn của cả thanh bên (tiêu đề các cuộc trò chuyện cũ) cho model.
        if (Math.abs(by - cy) > 260 || bx < ir.left - 100 || bx > ir.right + 100) return;
        list.push({ el: b, d: Math.abs(bx - cx) + Math.abs(by - cy), dx: Math.round(bx - cx), dy: Math.round(by - cy) });
      });
      list.sort(function (a, b) { return a.d - b.d; });
      list = list.slice(0, 16);
      for (i = 0; i < list.length; i++) {
        var b = list[i].el, bid = 'b' + i;
        CAND[bid] = b;
        out.push({
          id: bid, tag: b.tagName.toLowerCase(), text: clip(b.innerText, 30), aria: clip(b.getAttribute('aria-label'), 50),
          title: clip(b.getAttribute('title'), 40), testid: clip(b.getAttribute('data-testid'), 40),
          hasIcon: !!b.querySelector('svg, img'), disabled: isOff(b), fresh: BEFORE_EL.indexOf(b) < 0 && !BEFORE_SIG[sig(b)], dx: list[i].dx, dy: list[i].dy
        });
      }
    }
    return { vw: vw, vh: vh, cands: out };
  };
  function flash(t) {
    var old = t.style.outline;
    t.style.outline = '3px solid #e53935';
    setTimeout(function () { t.style.outline = old; }, 1500);
  }
  LN.commit = function (id, kind) {
    var el = CAND[id];
    if (!el || !document.contains(el)) return { ok: false, e: 'ma ung vien khong con tren trang' };
    var target = el;
    if (kind === 'input') target = el.closest(EDITABLE) || el;
    else if (kind === 'send') target = el.closest('button, [role="button"]') || el;
    var selector = cssFor(target, false);
    var found = $$(selector);
    flash(target);
    return { ok: found.indexOf(target) >= 0, kind: kind, selector: selector, matches: found.length,
             sample: clip(target.innerText || target.getAttribute('aria-label') || target.tagName, 80) };
  };
  // Sau khi đã gửi tin thử và nhận trả lời `text`: tìm khối chứa đoạn cuối của trả lời đó trên trang (không dùng AI).
  LN.locateReply = function (text) {
    var nonce = LN.lastNonce;
    if (!nonce) return { ok: false, e: 'chua co ma tham chieu (chua gui tin thu)' };
    var lines = String(text || '').split('\n').map(function (l) { return l.trim(); }).filter(function (l) { return l.length >= 12; });
    if (!lines.length) return { ok: false, e: 'tra loi qua ngan de dinh vi' };
    var anchor = lines[lines.length - 1].slice(-60);
    var n = document.body;
    if (!n || (n.innerText || '').indexOf(anchor) < 0) return { ok: false, e: 'khong thay doan cuoi cua tra loi tren trang' };
    for (var g = 0; g < 80; g++) {
      var kids = n.children, next = null;
      for (var i = kids.length - 1; i >= 0; i--) {
        var k = kids[i];
        // Bỏ qua <script>/<style>/... (mã nguồn trang có thể chứa đúng đoạn chữ này) và phần tử bị ẩn.
        if (/^(script|style|noscript|template)$/i.test(k.tagName) || window.getComputedStyle(k).display === 'none') continue;
        if ((k.innerText || '').indexOf(anchor) >= 0) { next = k; break; }
      }
      if (!next) break;
      n = next;
    }
    var block = replyBlockOf(n);
    var selector = cssFor(block, true);
    var els = $$(selector).filter(function (e) { return (e.innerText || '').trim() !== ''; });
    var last = els.length ? els[els.length - 1] : null;
    var lt = last ? (last.innerText || '') : '';
    var okSel = !!last && vis(last) && lt.indexOf(anchor) >= 0 && lt.indexOf(nonce) < 0;
    if (okSel) flash(last);
    return { ok: okSel, selector: selector, matches: els.length, sample: clip(lt, 80) };
  };

  // ---------- chẩn đoán ----------
  LN.diagnose = function () {
    var input = findInput();
    var send = input ? findSend(input) : null;
    function d(el) { return el ? (el.tagName.toLowerCase() + ' | ' + label(el).replace(/\s+/g, ' ').slice(0, 60)) : null; }
    var replyEls = P.reply ? $$(P.reply) : [];
    return {
      url: location.href,
      profile: P,
      input: d(input),
      send: send ? d(send) : (input ? 'khong thay nut gui — se bam Enter' : null),
      busy: isBusy(),
      replyBlocks: replyEls.length,
      lastNonce: LN.lastNonce || null
    };
  };
})();
''';

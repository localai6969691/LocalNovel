import 'dart:math' as math;
import 'ai_provider.dart';
import 'prefill_budget.dart';
import 'prompt_echo_guard.dart';
import 'rag_service.dart';

// MỤC CV3 (2026-10-15) — hai việc đều nằm ở file này (xem chú thích ở prompt_echo_guard.dart và prefill_budget.dart):
//   (A) SỬA LỖI "model viết truyện chép/nhắc lại Bible thay vì viết chương" (người dùng báo 2026-10-14 22:46): (1) cấu trúc prompt mới — system chỉ còn vai trò + văn phong + dặn
//       "không chép lại"; Bible nằm trong lượt user, bọc trong thẻ <tham_khao> kèm lời dặn "không phải nội dung cần viết", viết dạng PLAIN (không `###`/gạch đầu dòng), và
//       DÒNG CUỐI CÙNG của prompt là yêu cầu viết ngay (model nhỏ bám phần cuối prompt nhất); (2) bộ bắt chép lại (PromptEchoGuard) chạy lúc stream (dừng sớm) và sau khi xong;
//       (3) khi bị bắt: bỏ kết quả, thử lại với Bible ÍT hơn (mức 1 = 35% ngân sách, mức 2 = không Bible) rồi mới báo lỗi; mức nào chạy được thì được NHỚ theo model (xem
//       ChapterWriteFlow) để lần sau khỏi tốn một lần nạp prompt vô ích.
//       NGUYÊN NHÂN GỐC CHƯA XÁC MINH: chưa có nhật ký của đúng lỗi này — cấu trúc prompt là GIẢ THUYẾT dựa trên mục BE; lớp bắt + thử lại là phần không phụ thuộc giả thuyết đó.
//   (B) TỰ HẠ NGÂN SÁCH PROMPT THEO TỐC ĐỘ NẠP của local: `promptCharLimit` (trần ký tự do tốc độ đo được) => hạ đoạn vừa viết rồi Bible trước mỗi lượt (PrefillBudget.fit).

// MỤC CV (2026-10-13) — VIẾT CHƯƠNG THEO KẾ HOẠCH TỪNG Ý, chống "đầu voi đuôi chuột" (đoạn đầu chi tiết, càng về sau càng cẩu thả/hụt, kết chương cụt).
//
// NGUYÊN NHÂN (đọc code cũ + tài liệu/nghiên cứu, xem mục CV tài liệu kiến trúc):
//   1. Trước đây "Đắp thịt"/"Tạo hàng loạt" gửi CẢ dàn ý trong 1 lần gọi, không nêu độ dài mục tiêu, và bị cắt cứng ở maxTokens (1024-1500) — model dồn chữ
//      vào các ý đầu, các ý sau lướt qua, và chương CỤT ở giữa câu khi hết token (không có "đoạn kết" nào được đảm bảo).
//   2. Model nhỏ khi thấy cả dàn ý thường vội "chạy" qua mọi ý (và có xu hướng kết truyện sớm). Cách các hệ thống nghiên cứu xử lý: Re3 (Yang 2022) viết
//      từng đoạn với prompt dựng lại từ [ý hiện tại + tóm tắt phần trước + đoạn vừa viết]; DOC (Yang 2023) mở rộng dàn ý chi tiết rồi bám từng ý;
//      LongWriter/AgentWrite (Bai 2024) lập kế hoạch từng đoạn kèm SỐ TỪ riêng rồi viết tuần tự, mỗi lượt nhận [yêu cầu + kế hoạch + phần đã viết];
//      phân tích "length volatility" (2026) chỉ ra model hay dừng sớm/bỏ ý giữa chừng khi không có ràng buộc cấu trúc từng phần.
//   3. Tiền tố prompt ổn định (vai trò, văn phong, Bible) đặt TRƯỚC, phần thay đổi (ý đang viết, đoạn vừa viết, nhiệm vụ) đặt SAU CÙNG vì model dùng tốt thông tin ở
//      ĐẦU/CUỐI ngữ cảnh hơn ở giữa (Liu 2023 "Lost in the Middle").
//
// CÁCH LÀM: tách dàn ý thành các Ý (mỗi dòng/gạch đầu dòng; dàn ý 1 đoạn thì tách theo câu), chia thành các ĐOẠN gọi model theo chế độ:
//   'single'   : 1 lượt cho tất cả các ý (giống cũ, nhưng prompt có kế hoạch đánh số + chỉ tiêu độ dài + chỉ dẫn kết chương) — rẻ nhất.
//   'two_part' : lượt 1 = các ý đầu; lượt 2 = ý CUỐI riêng (có ngân sách token riêng, đảm bảo có phần kết trọn vẹn). Thêm đúng 1 lần nạp prompt — hợp model local,
//                nơi mỗi lần nạp prompt tốn rất nhiều giây (đo: prefill CPU ~7-12 token/giây).
//   'beats'    : mỗi ý 1 lượt (đều tay nhất, mỗi yêu cầu nhỏ — hợp API; chi phí gọi nhiều hơn).
// Mỗi lượt: prompt = [vai trò + văn phong + Bible (theo ý + đoạn vừa viết)] ... [KẾ HOẠCH đánh dấu ý đã viết/đang viết/chưa tới] + [ĐOẠN VỪA VIẾT] + [nhiệm vụ với
// SỐ TỪ mục tiêu của lượt, và: lượt không phải cuối => "dừng giữa mạch, không kết chương/tóm tắt"; lượt cuối => "khép chương gọn, kết bằng hình ảnh/câu treo"].
// Sau mỗi lượt cắt về hết câu gần nhất (tránh cụt giữa câu) trước khi làm "đoạn vừa viết" cho lượt sau.
// GIỚI HẠN THẬT: (a) tốc độ/chi phí tăng khi chia nhiều lượt (đặc biệt local); (b) hệ số `kTokensPerWord` là số đo trên 1 model (UTENA-7B ~2,07 byte/token) — model khác có thể
// khác; (c) chất lượng thật CHƯA đo bằng chạy máy; (d) văn phong có thể "nối" thấy mối giữa các lượt dù đã đưa đoạn vừa viết.

// MỤC CV3: `shouldAbort` được gọi với chữ nhận được tới giờ; trả true => bên cài đặt phải DỪNG sinh sớm (huỷ stream) và trả về phần đã nhận, KHÔNG chuyển chữ đó cho `onChunk`.
typedef SegmentGenerator = Future<String> Function({
  required String systemPrompt,
  required String userPrompt,
  required int maxTokens,
  void Function(String textSoFar)? onChunk,
  bool Function(String textSoFar)? shouldAbort,
});

// Điểm dừng lưu tạm: các ý ĐÃ viết xong (tính theo SỐ Ý, không theo số lượt — đổi chế độ chia lượt giữa 2 lần chạy vẫn tiếp tục đúng chỗ) + văn bản đã có.
// Dạng lưu trong cột `generation_checkpoint` của chương: `⟦B3/8⟧` + văn bản (3 trong tổng 8 ý đã xong); thêm chữ `c` (`⟦B3/8c⟧`) nếu văn bản đó ĐÃ nằm ở cuối
// nội dung chương (màn soạn chương hiện chữ dần thẳng vào chương), không có `c` nếu nội dung chương còn nguyên (Tạo hàng loạt chỉ ghi vào chương khi xong hẳn).
class WriterCheckpoint {
  final int beatsDone;
  final int beatsTotal;
  final String text;
  final bool inContent;
  // true nếu số ý đã xong là ƯỚC LƯỢNG (điểm dừng định dạng cũ / dàn ý đã đổi số ý / văn bản đã bị sửa) chứ không phải số đã ghi lúc viết — xem `reconcile`.
  final bool estimated;
  const WriterCheckpoint({required this.beatsDone, required this.beatsTotal, required this.text, this.inContent = false, this.estimated = false});

  String encode() => '\u27E6B$beatsDone/$beatsTotal${inContent ? 'c' : ''}\u27E7$text';

  // null nếu không đúng định dạng (vd điểm dừng của phiên bản cũ — không có đánh dấu ý, không biết đã viết tới ý nào).
  static WriterCheckpoint? decode(String? raw) {
    if (raw == null) return null;
    final m = RegExp(r'^\u27E6B(\d+)/(\d+)(c?)\u27E7').firstMatch(raw);
    if (m == null) return null;
    final done = int.tryParse(m.group(1)!) ?? 0;
    final total = int.tryParse(m.group(2)!) ?? 0;
    final text = raw.substring(m.end);
    if (total <= 0 || text.trim().isEmpty) return null;
    return WriterCheckpoint(beatsDone: done, beatsTotal: total, text: text, inContent: m.group(3) == 'c');
  }

  // Tách nội dung chương hiện có thành (phần NỀN trước lần viết này, điểm dừng dùng được). Điểm dừng KHÔNG dùng được (null) khi: số ý trong dàn ý đã đổi, hoặc
  // điểm dừng loại `c` mà không còn thấy văn bản đó trong chương (người dùng đã xoá/sửa) — khi đó viết lại từ đầu và KHÔNG đụng vào nội dung chương hiện có.
  // Loại `c`: lấy lần xuất hiện CUỐI CÙNG của văn bản điểm dừng; phần nằm sau nó (đoạn dở của lượt bị gãy, có thể cụt giữa câu) bị bỏ vì sẽ được viết lại.
  static ({String base, WriterCheckpoint? resume}) split(String content, WriterCheckpoint? cp, int beatCount) {
    final text = content.trim();
    if (cp == null || cp.beatsTotal != beatCount) return (base: text, resume: null);
    if (!cp.inContent) return (base: text, resume: cp);
    final prior = cp.text.trim();
    final idx = text.lastIndexOf(prior);
    if (idx < 0) return (base: text, resume: null);
    return (base: text.substring(0, idx).trim(), resume: cp);
  }

  static String join(String a, String b) {
    final x = a.trim();
    final y = b.trim();
    if (x.isEmpty) return y;
    if (y.isEmpty) return x;
    return '$x\n\n$y';
  }

  // MỤC CV2 (2026-10-14): KHÔNG BAO GIỜ bỏ phần đã viết. Người dùng hỏi "sao không bắt đầu từ chỗ kết thúc" — bản trước (mục CV) khi điểm dừng không khớp
  // (định dạng cũ / dàn ý đổi số ý / văn bản bị sửa) thì viết lại từ ý 1 và điểm dừng bị xoá => phần đã viết ở Tạo hàng loạt mất, ở màn soạn thì bị lặp lại.
  // Nay: điểm dừng khớp tuyệt đối => dùng đúng (như cũ). Không khớp => coi văn bản đã có là "phần đã viết", ƯỚC LƯỢNG đã tới ý nào rồi viết TIẾP từ cuối
  // văn bản đó (cắt phần dở dang cuối cùng nếu cụt giữa câu). Ước lượng nghiêng về thận trọng (thà lặp nhẹ còn hơn bỏ sót ý) và prompt lượt đầu được dặn rõ.
  //   `legacyInContent`: điểm dừng định dạng cũ có nằm sẵn trong nội dung chương không (màn soạn: có; Tạo hàng loạt: không — chỉ nằm trong cột điểm dừng).
  static ({String base, WriterCheckpoint? resume}) reconcile({
    required String content,
    required String? rawCheckpoint,
    required List<String> beats,
    required int targetWords,
    bool legacyInContent = false,
  }) {
    final whole = content.trim();
    final raw = rawCheckpoint?.trim() ?? '';
    if (raw.isEmpty) return (base: whole, resume: null);
    final cp = decode(rawCheckpoint);
    final exact = split(content, cp, beats.length);
    if (exact.resume != null) return exact;
    if (cp == null && raw.startsWith('\u27E6')) return (base: whole, resume: null); // đánh dấu hỏng, không đoán
    final inContent = cp?.inContent ?? legacyInContent;
    var prior = (cp?.text ?? raw).trim();
    String base;
    if (inContent) {
      final idx = prior.isEmpty ? -1 : whole.lastIndexOf(prior);
      if (idx >= 0) {
        base = whole.substring(0, idx).trim();
      } else {
        base = ''; // người dùng đã sửa văn bản: coi TOÀN BỘ chương hiện có là phần đã viết (không đụng, không lặp)
        prior = whole;
      }
    } else {
      base = whole;
    }
    prior = ChapterWriterService.trimToSentenceEnd(prior);
    if (prior.trim().isEmpty) return (base: whole, resume: null);
    final done = ChapterWriterService.estimateBeatsDone(prior, beats, targetWords);
    return (
      base: base,
      resume: WriterCheckpoint(beatsDone: done, beatsTotal: beats.length, text: prior, inContent: inContent, estimated: true),
    );
  }
}

class ChapterWriteResult {
  final String text; // các đoạn hợp lệ đã viết xong, nối bằng dòng trống
  final int segmentsDone;
  final int segmentsTotal;
  final int beatsDone;
  final int beatsTotal;
  final bool cancelled;
  final String? failure; // lý do dừng (kết quả bất thường); null nếu không có lỗi
  final bool resumeIgnored; // true nếu điểm dừng cũ KHÔNG dùng được (dàn ý đã đổi số ý) nên viết lại từ đầu

  const ChapterWriteResult({
    required this.text,
    required this.segmentsDone,
    required this.segmentsTotal,
    required this.beatsDone,
    required this.beatsTotal,
    this.cancelled = false,
    this.failure,
    this.resumeIgnored = false,
  });

  bool get complete => failure == null && !cancelled && beatsDone >= beatsTotal;

  WriterCheckpoint? get checkpoint =>
      text.trim().isEmpty ? null : WriterCheckpoint(beatsDone: beatsDone, beatsTotal: beatsTotal, text: text);
}

class ChapterWriterService {
  // Số token ước lượng cho 1 "chữ" tiếng Việt (chữ = tách khoảng trắng, như bộ đếm của app). Đo trên UTENA-7B: ~2,07 byte/token, ~4,9 byte/chữ => ~2,4 token/chữ.
  static const double kTokensPerWord = 2.4;

  // MỤC CV2: `tokensPerWord` là hệ số HỌC ĐƯỢC theo từng model (xem `write` — khi một lượt bị cắt ở giới hạn token, đo lại hệ số thật); mặc định là số đo ban đầu.
  static int tokensForWords(int words, {double tokensPerWord = kTokensPerWord}) {
    final t = (words * tokensPerWord * 1.3).round(); // dư 30% để ý không bị cụt giữa câu khi model viết dài hơn chỉ tiêu một chút
    return math.min(math.max(t, 200), 3072);
  }

  // ---------- Tách dàn ý thành các ý ----------
  static List<String> parseBeats(String outline) {
    final beats = <String>[];
    final bullet = RegExp(r'^(?:[-–—•*·]+|\d+\s*[.):\-]|\(\d+\))\s*');
    for (final raw in outline.split(RegExp(r'[\r\n]+'))) {
      final line = raw.trim();
      if (line.isEmpty) continue;
      final cleaned = line.replaceFirst(bullet, '').trim();
      if (cleaned.isNotEmpty) beats.add(cleaned);
    }
    if (beats.length >= 2) return _groupEvenly(beats, 8);
    final single = beats.isEmpty ? outline.trim() : beats.first;
    if (single.isEmpty) return <String>[];
    final sentences = single.split(RegExp(r'(?<=[.!?…;])\s+')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    if (sentences.length >= 3) return _groupEvenly(sentences, 4);
    return [single];
  }

  static List<String> _groupEvenly(List<String> items, int maxGroups) {
    if (items.length <= maxGroups) return items;
    final out = <String>[];
    var start = 0;
    for (var g = 0; g < maxGroups; g++) {
      final end = ((g + 1) * items.length / maxGroups).round();
      if (end > start) {
        out.add(items.sublist(start, end).join(' '));
        start = end;
      }
    }
    return out;
  }

  // ---------- Chia các ý thành các lượt gọi ----------
  static List<List<int>> planSegments(int beatCount, String mode) {
    final all = <int>[for (var i = 0; i < beatCount; i++) i];
    if (beatCount <= 1 || mode == 'single') return [all];
    if (mode == 'two_part') {
      return [all.sublist(0, beatCount - 1), [beatCount - 1]];
    }
    return [for (var i = 0; i < beatCount; i++) [i]];
  }

  // ---------- Tiện ích văn bản ----------
  // Lấy khoảng `maxChars` ký tự CUỐI, bắt đầu từ ranh giới đoạn/câu để không mở đầu giữa chừng.
  static String tailOf(String text, int maxChars) {
    final t = text.trimRight();
    if (t.length <= maxChars) return t;
    var cut = t.substring(t.length - maxChars);
    final nl = cut.indexOf('\n');
    if (nl >= 0 && nl < cut.length ~/ 2) return cut.substring(nl + 1).trimLeft();
    final m = RegExp(r'[.!?…]["”)]?\s').firstMatch(cut);
    if (m != null && m.end < cut.length ~/ 2) {
      cut = cut.substring(m.end);
      return cut.trimLeft();
    }
    return '…$cut';
  }

  // Cắt về hết câu gần nhất nếu văn bản kết thúc giữa câu (hết token). Không có câu hoàn chỉnh nào ở gần cuối thì giữ nguyên.
  static String trimToSentenceEnd(String text) {
    final t = text.trimRight();
    if (t.isEmpty) return t;
    const closers = '"”’»)';
    const stops = '.!?…';
    final last = t[t.length - 1];
    if (stops.contains(last) || closers.contains(last)) return t;
    var i = t.length - 1;
    while (i > 0 && !stops.contains(t[i])) {
      i--;
    }
    if (i <= (t.length * 0.4)) return t;
    var end = i + 1;
    while (end < t.length && closers.contains(t[end])) {
      end++;
    }
    return t.substring(0, end);
  }

  // MỤC CV2: ước lượng văn bản đã có ứng với bao nhiêu ý đầu của dàn ý khi KHÔNG có số ghi sẵn. Hai thước đo, lấy cái THẤP hơn (thận trọng):
  //   (1) theo độ dài: mỗi ý chiếm ~ targetWords/số ý chữ;
  //   (2) theo từ khoá: một ý coi là "đã có" nếu ≥40% từ đặc trưng của nó (từ ≥3 ký tự, không xuất hiện ở quá nửa số ý) có trong văn bản; đếm các ý liền từ đầu tới ý đầu tiên chưa có.
  // Luôn chừa lại ít nhất ý CUỐI để chương có phần kết. Ước lượng thô — KHÔNG phải đo; chỉ để tiếp tục thay vì viết lại.
  static final RegExp _wordRe = RegExp(r'[\p{L}\p{N}]+', unicode: true);

  static Set<String> _contentTokens(String s) {
    final out = <String>{};
    for (final m in _wordRe.allMatches(s.toLowerCase())) {
      final w = m.group(0)!;
      if (w.length >= 3) out.add(w);
    }
    return out;
  }

  static int estimateBeatsDone(String text, List<String> beats, int targetWords) {
    final total = beats.length;
    if (total <= 1) return 0;
    final t = text.trim();
    final words = t.isEmpty ? 0 : t.split(RegExp(r'\s+')).length;
    final perBeat = math.max(40.0, targetWords / total);
    final byLen = (words / perBeat).floor();
    final textTokens = _contentTokens(t);
    final tokenSets = <Set<String>>[for (final b in beats) _contentTokens(b)];
    final df = <String, int>{};
    for (final set in tokenSets) {
      for (final tok in set) {
        df[tok] = (df[tok] ?? 0) + 1;
      }
    }
    var byLex = 0;
    for (var i = 0; i < total; i++) {
      final distinct = tokenSets[i].where((tok) => total < 3 || (df[tok] ?? 0) * 2 <= total).toList();
      if (distinct.length >= 2) {
        final hit = distinct.where((tok) => textTokens.contains(tok)).length;
        if (hit / distinct.length < 0.4) break;
      }
      byLex = i + 1;
    }
    return math.max(0, math.min(math.min(byLen, byLex), total - 1));
  }

  // MỤC CV2: văn bản kết thúc GIỮA CÂU (không có dấu kết câu/đóng ngoặc ở cuối) — dấu hiệu lượt sinh bị cắt ở giới hạn token (hoặc bị dừng sớm).
  static int _wordCount(String t) {
    final x = t.trim();
    return x.isEmpty ? 0 : x.split(RegExp(r'\s+')).length;
  }

  static bool endsMidSentence(String text) {
    final t = text.trimRight();
    if (t.isEmpty) return false;
    const enders = '.!?…"”’»)';
    return !enders.contains(t[t.length - 1]);
  }

  // Bỏ chữ cuối (có thể là nửa âm tiết do cắt token), để lượt "viết nốt" bắt đầu ở ranh giới chữ sạch.
  static String _dropLastWord(String text) {
    final t = text.trimRight();
    final i = t.lastIndexOf(RegExp(r'\s'));
    return i > 0 ? t.substring(0, i) : t;
  }

  static String _cleanSegment(String s) {
    var t = s.trim();
    t = t.replaceFirst(RegExp(r'^(?:\*\*)?(?:Ý|Phần)\s*\d+\s*[:.\-–]\s*(?:\*\*)?\s*', caseSensitive: false), '');
    return t.trim();
  }

  // ---------- Dựng prompt ----------
  // MỤC CV3: system CHỈ còn vai trò + văn phong + lời dặn "không chép lại". Bible KHÔNG còn nằm ở đây (trước đây nằm cuối system, ngay trước lượt user — model nhỏ coi đó là
  // tài liệu để viết tiếp/chép lại) mà nằm trong lượt user, xem `_referenceBlock`.
  static String _systemPrompt(String styleInstruction) {
    final b = StringBuffer();
    b.writeln('Bạn là người viết tiểu thuyết tiếng Việt. Chỉ viết phần văn xuôi của truyện (thoại, hành động, miêu tả, nội tâm). '
        'Không viết tiêu đề, không đánh số ý, không ghi chú, không tóm tắt, không bình luận ngoài truyện.');
    b.writeln(styleInstruction);
    b.write('Chỉ trả lời bằng phần truyện; không chép lại tài liệu tham khảo hay kế hoạch trong yêu cầu.');
    return b.toString();
  }

  // Khối tham khảo (Story Bible) — luôn nằm TRƯỚC phần việc cần làm trong lượt user, bọc thẻ + lời dặn rõ đây là thông tin nền, KHÔNG phải nội dung cần viết.
  static String _referenceBlock(String bible) {
    final t = bible.trim();
    if (t.isEmpty) return '';
    return '<tham_khao>\n'
        'STORY BIBLE — thông tin nền để đối chiếu, KHÔNG phải nội dung cần viết; đừng chép lại.\n'
        '$t\n'
        '</tham_khao>\n\n';
  }

  static String _userPrompt({
    required List<String> beats,
    required List<int> seg,
    required bool firstOfChapter,
    required bool lastSeg,
    required int segWords,
    required String tail,
    String bible = '',
    bool estimatedProgress = false,
    bool resumeCut = false,
    int remainingWords = 0,
  }) {
    final b = StringBuffer();
    b.write(_referenceBlock(bible));
    b.writeln('KẾ HOẠCH CHƯƠNG (${beats.length} ý, viết lần lượt):');
    for (var i = 0; i < beats.length; i++) {
      final String status;
      if (seg.contains(i)) {
        status = '  <- ĐANG VIẾT';
      } else if (i < seg.first) {
        status = '  [đã viết]';
      } else {
        status = '  [chưa tới, đừng viết trước]';
      }
      b.writeln('${i + 1}. ${beats[i]}$status');
    }
    if (estimatedProgress) {
      b.writeln('(Các ý ghi [đã viết] chỉ là ước lượng từ đoạn văn đã có. Nếu ĐOẠN VỪA VIẾT cho thấy ý đang viết đã có một phần thì chỉ viết phần CÒN THIẾU, không viết lại.)');
    }
    if (tail.isNotEmpty) {
      b.writeln();
      b.writeln('ĐOẠN VỪA VIẾT (viết nối liền ngay sau đoạn này, không lặp lại nội dung đã có):');
      b.writeln('"""');
      b.writeln(tail);
      b.writeln('"""');
    }
    b.writeln();
    final per = math.max(60, (segWords / seg.length).round());
    final which = seg.length == 1 ? 'ý ${seg.first + 1}' : 'các ý ${seg.first + 1}-${seg.last + 1}';
    if (resumeCut) {
      // MỤC CV2: lượt trước bị cắt ở giới hạn token (cụt giữa câu) — viết NỐT đúng chỗ dở rồi dừng.
      b.writeln('NHIỆM VỤ: đoạn cuối của ĐOẠN VỪA VIẾT đang dở dang (cụt giữa câu). Viết tiếp NGAY từ chỗ dở — không lặp lại chữ đã có — để hoàn tất $which, '
          'thêm khoảng $remainingWords từ nữa, rồi dừng. Triển khai bằng cảnh cụ thể: thoại, hành động, chi tiết giác quan.');
    } else {
      b.writeln('NHIỆM VỤ: viết $which thành văn xuôi hoàn chỉnh, khoảng $segWords từ'
          '${seg.length > 1 ? ' (mỗi ý khoảng $per từ — ý nào cũng phải có cảnh cụ thể, không lướt qua)' : ''}. '
          'Triển khai bằng cảnh cụ thể: thoại, hành động, chi tiết giác quan; không tóm lược kiểu "sau đó... rồi...".');
    }
    if (firstOfChapter && !resumeCut) {
      b.writeln('Mở đầu chương: vào cảnh ngay, không dẫn nhập chung chung.');
    }
    if (!lastSeg) {
      b.writeln('Dừng đúng khi phần đang viết hoàn tất, ở giữa mạch truyện: KHÔNG kết thúc chương, KHÔNG tóm tắt, KHÔNG rút bài học, '
          'KHÔNG viết câu tổng kết — các ý sau sẽ được viết ở lượt khác.');
    } else {
      b.writeln('Đây là phần CUỐI của chương: hoàn tất ý cuối rồi khép chương gọn gàng (không kéo dài), kết bằng một hình ảnh '
          'hoặc một câu treo gợi mở cho chương sau; không rút bài học, không bình luận.');
    }
    // MỤC CV3: dòng CUỐI CÙNG của prompt luôn là lệnh viết ngay (model nhỏ bám phần cuối prompt nhất; với khuôn "Trợ lý:" thô thì đây là thứ nằm sát chỗ model bắt đầu sinh).
    b.write('Viết ngay phần truyện (chỉ văn xuôi). Không chép lại tài liệu tham khảo, kế hoạch hay đoạn vừa viết.');
    return b.toString();
  }

  // Số chữ tương ứng với 1 giới hạn token (ngược của `tokensForWords`, đã trừ phần dư 30%) — làm tròn tới chục, tối thiểu 100.
  static int wordsForTokens(int tokens, {double tokensPerWord = kTokensPerWord}) {
    final w = (tokens / (tokensPerWord * 1.3)).round();
    return math.max(100, (w / 10).round() * 10);
  }

  // "Viết tiếp" (thêm vào cuối chương đang viết): trước đây gửi CẢ chương làm user prompt (tốn token API, nạp chậm trên local, và model chỉ "thấy" đoạn
  // cuối rõ — Liu 2023). Giờ chỉ gửi ĐOẠN CUỐI (cửa sổ `tail`) + định hướng (nếu có) + chỉ tiêu số chữ + chỉ dẫn "dừng giữa mạch, đừng kết chương".
  static ({String systemPrompt, String userPrompt}) continuePrompts({
    required String styleInstruction,
    required String bibleContext,
    required String tail,
    String guidance = '',
    required int words,
  }) {
    final b = StringBuffer();
    b.write(_referenceBlock(bibleContext));
    if (guidance.trim().isNotEmpty) {
      b.writeln('ĐỊNH HƯỚNG CHƯƠNG (chỉ để biết hướng đi; KHÔNG cố viết hết một lần — chỉ viết phần kế tiếp tự nhiên):');
      b.writeln(guidance.trim());
      b.writeln();
    }
    if (tail.isNotEmpty) {
      b.writeln('ĐOẠN CUỐI CHƯƠNG ĐANG VIẾT (viết nối liền ngay sau đoạn này, không lặp lại nội dung đã có):');
      b.writeln('"""');
      b.writeln(tail);
      b.writeln('"""');
    } else {
      b.writeln('Chương chưa có chữ nào — mở đầu bằng một cảnh cụ thể, vào việc ngay.');
    }
    b.writeln();
    b.writeln('NHIỆM VỤ: viết tiếp khoảng $words từ. Triển khai bằng cảnh cụ thể: thoại, hành động, chi tiết giác quan; không tóm lược kiểu "sau đó... rồi...". '
        'Giữ đúng giọng văn và ngôi kể của đoạn trên. Dừng ở một chỗ tự nhiên giữa mạch truyện (hết một ý/một cảnh nhỏ): '
        'KHÔNG kết thúc chương, KHÔNG tóm tắt, KHÔNG rút bài học.');
    b.write('Viết ngay phần truyện (chỉ văn xuôi), nối liền sau đoạn trên. Không chép lại tài liệu tham khảo, định hướng hay đoạn trên.');
    return (systemPrompt: _systemPrompt(styleInstruction), userPrompt: b.toString());
  }

  // Phần văn bản do LẦN CHẠY NÀY tạo ra (bỏ phần lấy từ điểm dừng cũ) — để ghi nhận "model nào viết" đúng phần mình viết.
  static String textAfterResume(String full, WriterCheckpoint? resume, bool resumeIgnored) {
    if (resume == null || resumeIgnored) return full;
    final prior = resume.text.trim();
    final t = full.trim();
    if (!t.startsWith(prior)) return full;
    return t.substring(prior.length).trim();
  }

  // ---------- Chạy ----------
  // MỤC CV3: bậc Bible của cơ chế chống chép lại — 0 = đầy đủ; 1 = 35% ngân sách (tối thiểu 500 ký tự); 2 = KHÔNG Bible (chỉ vai trò + văn phong + kế hoạch + đoạn vừa viết).
  static int _bibleBudgetForLevel(int level, int base) {
    if (level >= 2) return 0;
    if (level == 1) return math.min(base, math.max(PrefillBudget.kMinBibleChars, (base * 0.35).round()));
    return base;
  }

  // MỤC CV3: MỘT lần sinh có canh chừng chép lại prompt. Trong lúc stream, cứ ~100 ký tự mới kiểm tra `guard` (phần đầu kiểm ở ~40 ký tự) — bị bắt thì `shouldAbort` trả true để
  // bên cài đặt DỪNG sinh sớm (đỡ tốn hàng phút trên local); chữ bị bắt không được chuyển cho `onChunk`. Xong thì kiểm lần cuối trên toàn văn (bắt cả trường hợp nhà cung cấp
  // không stream). Trả về chữ nhận được + lý do (null = ổn).
  static Future<({String raw, String? echo})> _generateGuarded({
    required SegmentGenerator generate,
    required String systemPrompt,
    required String userPrompt,
    required int maxTokens,
    required PromptEchoGuard guard,
    void Function(String soFar)? onChunk,
  }) async {
    String? reason;
    var nextCheck = 40;
    final raw = await generate(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      maxTokens: maxTokens,
      shouldAbort: (soFar) {
        if (reason != null) return true;
        if (soFar.length < nextCheck) return false;
        nextCheck = soFar.length + 100;
        reason = guard.check(soFar, partial: true);
        return reason != null;
      },
      onChunk: (soFar) {
        if (reason == null) onChunk?.call(soFar);
      },
    );
    if (reason == null) {
      final t = raw.trim();
      if (t.isNotEmpty && !t.contains(kAiFailureMarker)) reason = guard.check(t);
    }
    return (raw: raw, echo: reason);
  }

  static String _sample(String s) {
    final t = s.trim().replaceAll(RegExp(r'\s+'), ' ');
    return t.length > 160 ? '${t.substring(0, 160)}…' : t;
  }

  // `existingText`: chữ ĐÃ CÓ trong chương (nối tiếp sau nó). `resume`: điểm dừng của lần chạy trước (các ý đã xong + văn bản) để tiếp tục thay vì viết lại.
  static Future<ChapterWriteResult> write({
    required String outline,
    required String mode,
    required int targetWords,
    required String styleInstruction,
    required RagService rag,
    required int chapterNumber,
    required SegmentGenerator generate,
    String existingText = '',
    WriterCheckpoint? resume,
    int tailChars = 1500,
    bool Function()? isCancelled,
    void Function(String fullSoFar)? onChunk,
    void Function(String stage)? onStage,
    void Function(String textSoFar, int beatsDone, int beatsTotal)? onSegmentDone,
    // MỤC CV2: hệ số token/chữ đã học của model này (null = mặc định); gọi `onTokensPerWordLearned` khi đo được hệ số CAO hơn (lượt bị cắt ở giới hạn token);
    // `onSegmentStats` nhận 1 dòng thống kê mỗi lượt (độ dài thực/chỉ tiêu, giới hạn token, có bị cắt/viết nốt không, kích thước prompt, thời gian) để ghi log.
    double tokensPerWord = kTokensPerWord,
    void Function(double learned)? onTokensPerWordLearned,
    void Function(String info)? onSegmentStats,
    // MỤC CV3: `guardLevel` = bậc Bible bắt đầu (0/1/2, xem `_bibleBudgetForLevel`; đã học theo model); `onGuardLevelChanged` báo khi phải nâng bậc vì model chép lại prompt;
    // `promptCharLimit` trả trần độ dài prompt (ký tự) theo tốc độ nạp đã đo (null = không giới hạn) — gọi LẠI trước mỗi lượt vì số đo cập nhật sau mỗi lượt; `onLog` nhận dòng log
    // có sẵn nhãn ([CV3-ECHO], [CV3-BUDGET]).
    int guardLevel = 0,
    void Function(int level)? onGuardLevelChanged,
    Future<int?> Function()? promptCharLimit,
    void Function(String line)? onLog,
  }) async {
    var tpw = tokensPerWord;
    var level = guardLevel.clamp(0, 2).toInt();
    var beats = parseBeats(outline);
    if (beats.isEmpty) {
      beats = [outline.trim().isEmpty ? 'Viết tiếp theo mạch truyện' : outline.trim()];
    }
    final beatsTotal = beats.length;
    var acc = '';
    var startBeat = 0;
    var resumeIgnored = false;
    if (resume != null) {
      if (resume.beatsTotal == beatsTotal && resume.text.trim().isNotEmpty) {
        acc = resume.text.trim();
        startBeat = math.min(resume.beatsDone, beatsTotal);
      } else {
        resumeIgnored = true; // dàn ý đã đổi số ý — không biết văn bản cũ ứng với ý nào, viết lại từ đầu
      }
    }
    var segments = planSegments(beatsTotal, mode);
    if (startBeat > 0) {
      final rest = <List<int>>[];
      for (final s in segments) {
        final r = s.where((i) => i >= startBeat).toList();
        if (r.isNotEmpty) rest.add(r);
      }
      segments = rest;
    }
    final totalSegs = segments.length;
    var beatsDone = startBeat;
    ChapterWriteResult stop({bool cancelled = false, String? failure, required int si}) => ChapterWriteResult(
          text: acc,
          segmentsDone: si,
          segmentsTotal: totalSegs,
          beatsDone: beatsDone,
          beatsTotal: beatsTotal,
          cancelled: cancelled,
          failure: failure,
          resumeIgnored: resumeIgnored,
        );

    for (var si = 0; si < totalSegs; si++) {
      if (isCancelled?.call() ?? false) return stop(cancelled: true, si: si);
      final seg = segments[si];
      final lastSeg = si == totalSegs - 1;
      final segWords = math.max(120, (targetWords * seg.length / beats.length).round());
      final tailSource = [existingText.trim(), acc].where((e) => e.isNotEmpty).join('\n\n');
      final segBeatText = seg.map((i) => beats[i]).join('\n');
      final estimated = si == 0 && (resume?.estimated ?? false);
      final prefix = acc;
      final maxTok = tokensForWords(segWords, tokensPerWord: tpw);
      final sw = Stopwatch()..start();

      // Vòng thử: mỗi lần bị bắt chép lại prompt thì nâng bậc (Bible ít hơn) và thử lại; hết bậc 2 vẫn chép thì báo lỗi.
      var echoRetries = 0;
      final levelAtSegStart = level;
      String system = '';
      String user = '';
      String context = '';
      int? limit;
      String raw = '';
      while (true) {
        // Lượt sau lượt đầu dùng ngân sách Bible nhỏ hơn: nhân vật/bối cảnh đã nằm trong "đoạn vừa viết" + kế hoạch, và mỗi lần nạp prompt (đặc biệt local) rất tốn.
        final baseBible = si == 0 ? rag.contextBudgetChars : math.max(1200, (rag.contextBudgetChars * 0.6).round());
        final wantBible = _bibleBudgetForLevel(level, baseBible);
        limit = await promptCharLimit?.call();
        system = _systemPrompt(styleInstruction);
        String userFor(String bible, String tailText) => _userPrompt(
              beats: beats,
              seg: seg,
              firstOfChapter: tailText.isEmpty,
              lastSeg: lastSeg,
              segWords: segWords,
              tail: tailText,
              bible: bible,
              estimatedProgress: estimated,
            );
        // MỤC CV3-B: khung prompt (không kể Bible và đoạn vừa viết) => còn bao nhiêu chỗ cho 2 phần đó theo trần do tốc độ nạp.
        final skeleton = system.length + userFor(wantBible > 0 ? 'x' : '', '').length;
        final fit = PrefillBudget.fit(limit: limit, skeleton: skeleton, wantBible: wantBible, wantTail: math.min(tailChars, tailSource.length));
        if (fit.reduced) {
          onLog?.call('[CV3-BUDGET] lượt ${si + 1}/$totalSegs: trần prompt ${limit ?? 0} ký tự (theo tốc độ nạp đã đo) — hạ Bible $wantBible→${fit.bible}, '
              'đoạn vừa viết ${math.min(tailChars, tailSource.length)}→${fit.tail}${fit.floored ? ' (chạm sàn Bible ${PrefillBudget.kMinBibleChars}: prompt vẫn vượt trần)' : ''}');
        }
        final tail = tailOf(tailSource, fit.tail);
        if (fit.bible <= 0) {
          context = '';
        } else {
          final ragForSeg = (si == 0 && fit.bible == rag.contextBudgetChars)
              ? rag
              : RagService(rag.db, rag.embedder, novelId: rag.novelId, contextBudgetChars: fit.bible);
          context = await ragForSeg.buildContext(currentText: '$segBeatText\n$tail', currentChapterNumber: chapterNumber, plain: true);
        }
        user = userFor(context, tail);
        final guard = PromptEchoGuard(reference: [system, userFor(context, '')], plan: beats, tail: tail);
        onStage?.call(totalSegs == 1 ? 'Đang viết chương...' : 'Đang viết phần ${si + 1}/$totalSegs...');
        final g = await _generateGuarded(
          generate: generate,
          systemPrompt: system,
          userPrompt: user,
          maxTokens: maxTok,
          guard: guard,
          onChunk: (soFar) => onChunk?.call(prefix.isEmpty ? soFar : '$prefix\n\n$soFar'),
        );
        // Bị huỷ giữa lượt: văn bản dở của lượt này BỎ (có thể cụt giữa câu) — chỉ giữ các lượt đã xong.
        if (isCancelled?.call() ?? false) return stop(cancelled: true, si: si);
        if (g.echo != null) {
          onChunk?.call(acc); // xoá chữ chép lại (nếu đã lỡ hiện) khỏi màn hình
          onLog?.call('[CV3-ECHO] lượt ${si + 1}/$totalSegs, bậc Bible $level: ${g.echo} — BỎ kết quả (${g.raw.trim().length} ký tự nhận được). Mẫu đầu: [${_sample(g.raw)}]');
          if (level >= 2) {
            return stop(
              failure: 'Model chép lại nội dung prompt thay vì viết truyện, kể cả khi đã bỏ hẳn Story Bible (${g.echo}). '
                  'Thử đổi model, hoặc tăng "Phạt lặp từ" trong Cài đặt sinh văn bản.',
              si: si,
            );
          }
          level++;
          echoRetries++;
          onStage?.call('Model chép lại prompt — thử lại với Story Bible ngắn hơn (bậc $level/2)...');
          continue;
        }
        raw = g.raw;
        break;
      }
      // Chỉ GHI NHỚ bậc mới khi bậc đó thật sự cho ra chữ (không ghi khi cả 3 bậc đều hỏng — lúc đó bậc không phải nguyên nhân).
      if (level > levelAtSegStart) onGuardLevelChanged?.call(level);
      final cleaned = raw.trim();
      if (cleaned.isEmpty || cleaned.contains(kAiFailureMarker)) {
        return stop(failure: cleaned.isEmpty ? 'Model không trả về chữ nào' : cleaned, si: si);
      }
      var text = cleaned;
      final w0 = _wordCount(text);
      // MỤC CV2: lượt bị CẮT giữa câu = (rất có thể) chạm giới hạn token. Khi đó số token sinh ra ≈ maxTok nên hệ số thật ≈ maxTok / số chữ — đo được mà KHÔNG cần
      // biết bộ tách token của model (mọi model/nhà cung cấp). Chỉ nhận khi lượt đã dài ≥ 50% chỉ tiêu (loại trường hợp model dừng sớm vì lý do khác) và chặn trong [1,5; 4,5].
      final cutMidSentence = endsMidSentence(text);
      if (cutMidSentence && w0 >= segWords * 0.5) {
        final measured = (maxTok / w0).clamp(1.5, 4.5).toDouble();
        if (measured > tpw * 1.03) {
          tpw = measured;
          onTokensPerWordLearned?.call(tpw);
        }
      }
      // Bị cắt mà chưa đủ chỉ tiêu chữ (hệ số trước đó thấp hơn thực tế): VIẾT NỐT 1 lần đúng chỗ dở — ý đang viết không bị bỏ dở rồi "nhảy" sang ý sau.
      var continued = false;
      if (cutMidSentence && w0 < segWords * 1.15) {
        continued = true;
        final head = _dropLastWord(text);
        final contTail = tailOf([tailSource, head].where((e) => e.isNotEmpty).join('\n\n'), tailChars);
        String contUserFor(String tailText) => _userPrompt(
              beats: beats,
              seg: seg,
              firstOfChapter: false,
              lastSeg: lastSeg,
              segWords: segWords,
              tail: tailText,
              bible: context,
              resumeCut: true,
              remainingWords: math.max(60, segWords - _wordCount(head)),
            );
        final more = await _generateGuarded(
          generate: generate,
          systemPrompt: system,
          userPrompt: contUserFor(contTail),
          maxTokens: tokensForWords(math.max(60, segWords - _wordCount(head)), tokensPerWord: tpw),
          guard: PromptEchoGuard(reference: [system, contUserFor('')], plan: beats, tail: contTail),
          onChunk: (soFar) {
            final shown = '$head $soFar';
            onChunk?.call(prefix.isEmpty ? shown : '$prefix\n\n$shown');
          },
        );
        if (isCancelled?.call() ?? false) return stop(cancelled: true, si: si);
        final m = more.raw.trim();
        if (more.echo != null) {
          onLog?.call('[CV3-ECHO] lượt viết nốt ${si + 1}/$totalSegs: ${more.echo} — bỏ phần viết nốt, giữ phần trước. Mẫu đầu: [${_sample(more.raw)}]');
          onChunk?.call(prefix.isEmpty ? head : '$prefix\n\n$head');
        }
        text = (more.echo != null || m.isEmpty || m.contains(kAiFailureMarker)) ? head : '$head $m';
      }
      final piece = _cleanSegment(trimToSentenceEnd(text));
      if (piece.isEmpty) return stop(failure: 'Kết quả rỗng sau khi dọn', si: si);
      sw.stop();
      onSegmentStats?.call('lượt ${si + 1}/$totalSegs ý ${seg.first + 1}-${seg.last + 1}: ${_wordCount(piece)}/$segWords chữ, trần $maxTok token, '
          'hệ số ${tpw.toStringAsFixed(2)}, cụt giữa câu=$cutMidSentence, viết nốt=$continued, prompt ${system.length + user.length} ký tự '
          '(Bible ${context.length}), bậc Bible=$level, thử lại vì chép prompt=$echoRetries, trần prompt=${limit ?? 'không'}, ${sw.elapsedMilliseconds} ms');
      acc = acc.isEmpty ? piece : '$acc\n\n$piece';
      beatsDone = seg.last + 1;
      onChunk?.call(acc);
      onSegmentDone?.call(acc, beatsDone, beatsTotal);
    }
    return stop(si: totalSegs);
  }

  // MỤC CV3: "Viết tiếp" (màn soạn chương) — cùng cấu trúc prompt mới, cùng bộ bắt chép lại + thử lại theo bậc Bible, cùng hạ ngân sách theo tốc độ nạp như `write`.
  // Trả về chữ nhận được (chưa cắt về hết câu — nơi gọi tự làm) và `failure` (khác null khi hết bậc mà model vẫn chép prompt). Huỷ giữa chừng: trả chữ nhận được tới đó.
  static Future<({String text, String? failure})> continueWriting({
    required String styleInstruction,
    required RagService rag,
    required int chapterNumber,
    required String baseText,
    String guidance = '',
    required int words,
    required int tailChars,
    required int maxTokens,
    required SegmentGenerator generate,
    int guardLevel = 0,
    void Function(int level)? onGuardLevelChanged,
    Future<int?> Function()? promptCharLimit,
    void Function(String line)? onLog,
    void Function(String textSoFar)? onChunk,
    bool Function()? isCancelled,
  }) async {
    var level = guardLevel.clamp(0, 2).toInt();
    final startLevel = level;
    final plain = baseText.trimRight();
    while (true) {
      final wantBible = _bibleBudgetForLevel(level, rag.contextBudgetChars);
      final limit = await promptCharLimit?.call();
      final skel = continuePrompts(styleInstruction: styleInstruction, bibleContext: wantBible > 0 ? 'x' : '', tail: '', guidance: guidance, words: words);
      final wantTail = math.min(tailChars, plain.length);
      final fit = PrefillBudget.fit(limit: limit, skeleton: skel.systemPrompt.length + skel.userPrompt.length, wantBible: wantBible, wantTail: wantTail);
      if (fit.reduced) {
        onLog?.call('[CV3-BUDGET] Viết tiếp: trần prompt ${limit ?? 0} ký tự (theo tốc độ nạp đã đo) — hạ Bible $wantBible→${fit.bible}, đoạn vừa viết $wantTail→${fit.tail}'
            '${fit.floored ? ' (chạm sàn Bible ${PrefillBudget.kMinBibleChars}: prompt vẫn vượt trần)' : ''}');
      }
      final tail = tailOf(baseText, fit.tail);
      String context = '';
      if (fit.bible > 0) {
        final ragFor = fit.bible == rag.contextBudgetChars
            ? rag
            : RagService(rag.db, rag.embedder, novelId: rag.novelId, contextBudgetChars: fit.bible);
        context = await ragFor.buildContext(currentText: '$guidance\n${tailOf(baseText, 6000)}', currentChapterNumber: chapterNumber, plain: true);
      }
      final prompts = continuePrompts(styleInstruction: styleInstruction, bibleContext: context, tail: tail, guidance: guidance, words: words);
      final noTail = continuePrompts(styleInstruction: styleInstruction, bibleContext: context, tail: '', guidance: guidance, words: words);
      final guard = PromptEchoGuard(reference: [prompts.systemPrompt, noTail.userPrompt], plan: [guidance], tail: tail);
      final g = await _generateGuarded(
        generate: generate,
        systemPrompt: prompts.systemPrompt,
        userPrompt: prompts.userPrompt,
        maxTokens: maxTokens,
        guard: guard,
        onChunk: onChunk,
      );
      if (isCancelled?.call() ?? false) return (text: g.raw, failure: null);
      if (g.echo == null) {
        if (level > startLevel) onGuardLevelChanged?.call(level); // chỉ ghi nhớ bậc khi bậc đó thật sự cho ra chữ
        return (text: g.raw, failure: null);
      }
      onChunk?.call('');
      onLog?.call('[CV3-ECHO] Viết tiếp, bậc Bible $level: ${g.echo} — BỎ kết quả (${g.raw.trim().length} ký tự nhận được). Mẫu đầu: [${_sample(g.raw)}]');
      if (level >= 2) {
        return (
          text: '',
          failure: 'Model chép lại nội dung prompt thay vì viết truyện, kể cả khi đã bỏ hẳn Story Bible (${g.echo}). '
              'Thử đổi model, hoặc tăng "Phạt lặp từ" trong Cài đặt sinh văn bản.',
        );
      }
      level++;
    }
  }
}

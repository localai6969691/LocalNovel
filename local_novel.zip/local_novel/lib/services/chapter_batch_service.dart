import 'dart:async';
import '../models/story_models.dart';
import 'ai_provider.dart';
import 'authorship_service.dart';
import 'background_task_manager.dart';
import 'chapter_write_flow.dart';
import 'chapter_writer_service.dart';
import 'database_service.dart';
import 'debug_log_service.dart';
import 'providers/local_provider.dart';
import 'rag_service.dart';
import 'settings_service.dart';
import 'summary_service.dart';
import 'translation_service.dart';

// ĐÃ THÊM (theo yêu cầu người dùng): tạo chương HÀNG LOẠT từ dàn ý/outline
// đã viết sẵn (không gọi AI lúc viết dàn ý) — người dùng lên kế hoạch
// nhiều chương ("chương mồi") TRƯỚC, rồi chọn chương nào cần AI viết.
//
// ĐÃ SỬA (theo yêu cầu người dùng: các nhiệm vụ AI đều nên chạy song song
// được với nhau, không riêng "tạo chương hàng loạt"): tách 2 đường hoàn
// toàn khác nhau theo loại provider —
//   - LOCAL: GIỮ NGUYÊN 100% hành vi cũ — chạy TUẦN TỰ, không đổi 1 dòng
//     logic nào so với bản gốc. Đây là cách né đúng nguyên nhân crash "2
//     lệnh generate chạy chồng chéo" đã tìm ra ở mục 5.67 kiến trúc —
//     Llm::response() của MNN không an toàn khi 2 luồng cùng ghi vào
//     chung 1 KV-cache của cùng 1 instance model LOCAL. Không có lý do
//     kỹ thuật nào để đổi nhánh này — model local vẫn bị giới hạn cứng ở
//     2 slot native (xem generateMutexes trong MnnBridge.kt), chạy "song
//     song" nhiều chương cùng lúc chỉ khiến chúng xếp hàng chờ nhau ở
//     cùng 1 khoá, không nhanh hơn, chỉ thêm phức tạp.
//   - REMOTE (Colab/API khác, qua HTTP): mỗi request độc lập hoàn toàn,
//     không có vùng nhớ chung nào bị 2 bên cùng ghi — an toàn để chạy
//     THẬT SỰ đồng thời. Thả từng chương vào BackgroundTaskManager dùng
//     chung toàn app, giới hạn số lượng đồng thời theo cấu hình người
//     dùng (SettingsService.loadMaxParallelRemoteTasks()).
class ChapterBatchService {
  final DatabaseService db;
  ChapterBatchService(this.db);

  // Điều phối: chọn đúng nhánh theo loại provider — xem giải thích đầy đủ
  // ở comment đầu class về lý do KHÔNG được đổi hành vi nhánh local.
  Future<void> generateBatch({
    required List<Chapter> chapters, // các chương ĐÃ CHỌN, có outline
    required AIProvider provider,
    AIProvider? memoryProvider, // MỤC CT: model thư ký cho tóm tắt/nén cốt truyện sau mỗi chương; null = dùng `provider`
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    // ĐÃ SỬA (theo yêu cầu người dùng: "thanh tiến trình không chỉ hiện số
    // chương đang chạy mà hiển thị luôn cả % của chương"): thêm tham số
    // đặt tên `currentPercent` (0-99, null = không áp dụng/chưa có dữ
    // liệu) — CHỈ nhánh REMOTE cung cấp giá trị thật (xem
    // _generateBatchParallel), nhánh LOCAL vẫn gọi callback y hệt bản gốc
    // (không có `currentPercent`, mặc định null) vì KHÔNG đổi nhánh đó.
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent, String? currentText, String? currentChapterId})? onProgress,
  }) async {
    final isLocal = provider is LocalLlamaProvider;
    if (isLocal) {
      await _generateBatchSequential(
        chapters: chapters,
        provider: provider,
        memoryProvider: memoryProvider,
        novelId: novelId,
        style: style,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    } else {
      await _generateBatchParallel(
        chapters: chapters,
        provider: provider,
        memoryProvider: memoryProvider,
        novelId: novelId,
        style: style,
        isCancelled: isCancelled,
        onProgress: onProgress,
      );
    }
  }

  // ===== Nhánh LOCAL — cấu trúc chạy TUẦN TỰ giữ NGUYÊN 100% (không đổi 1
  // dòng logic điều khiển luồng nào — vẫn `await` xong chương này mới sang
  // chương kế, không có 2 lệnh generate() nào chạy chồng lên nhau).
  //
  // ĐÃ SỬA (theo phản hồi người dùng — "tạo chương hàng loạt khi chữ chạy
  // thì liên quan gì đến crash khi yêu cầu 2 cái chạy cùng lúc": ĐÚNG, nhận
  // định trước đó của Claude nhầm lẫn 2 việc khác nhau): thêm `onChunk` để
  // hiện chữ dần lên UI — đây CHỈ là quan sát THỤ ĐỘNG lên đúng 1 lệnh
  // generate() vốn dĩ đã chạy tuần tự, không làm phát sinh thêm bất kỳ lệnh
  // gọi model song song nào, nên KHÔNG liên quan gì tới rủi ro crash "2 lệnh
  // generate chạy chồng chéo" (mục 5.67) — 2 việc độc lập, xem chi tiết ở
  // đúng chỗ gọi `onChunk` bên dưới.
  //
  // Kết quả trả về NGAY LẬP TỨC nếu 1 chương gặp lỗi/kết quả bất thường —
  // giống hệt cách DocumentProcessingAnomalyException đã làm cho tài liệu
  // (mục 64) — không lưu rác, dừng ngay, không chạy tiếp qua các chương
  // khác trong hàng đợi.
  //
  // GHI CHÚ (theo yêu cầu người dùng về resume/streaming khi GPU sập — xem
  // mục 5.93 tài liệu kiến trúc): tính năng CHECKPOINT + RESUME (khác với
  // hiện-chữ-dần vừa thêm ở trên — đây là việc LƯU TẠM xuống DB để phục hồi
  // sau khi crash) CHỈ áp dụng cho nhánh REMOTE bên dưới — model LOCAL khi
  // "sập" (crash app/OOM) thường kéo theo crash luôn tiến trình Dart đang
  // giữ state checkpoint trong RAM (khác hẳn remote: GPU chết nhưng app
  // Dart trên điện thoại vẫn sống, vẫn giữ được state), nên lợi ích thực tế
  // thấp hơn hẳn so với rủi ro đổi 1 vùng code đã ổn định. Có thể làm thêm
  // ở phiên sau nếu cần, không nằm trong yêu cầu lần này (người dùng hỏi cụ
  // thể về "quy trình chạy model GPU remote"). =====
  Future<void> _generateBatchSequential({
    required List<Chapter> chapters,
    required AIProvider provider,
    AIProvider? memoryProvider, // MỤC CT
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent, String? currentText, String? currentChapterId})? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(novelId),
    );
    final modelTag = await SettingsService().currentModelTag(novelId); // MỤC CV: ghi nhận model nào viết
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    await LocalLlamaProvider.beginPipeline('Đang tạo chương hàng loạt...');

    try {
      for (final chapter in chapters) {
        if (isCancelled?.call() ?? false) break;
        final outline = chapter.outline?.trim() ?? '';
        if (outline.isEmpty) {
          done++;
          continue; // bỏ qua chương không có outline, không tính là lỗi
        }
        await LocalLlamaProvider.updatePipelineStage('Đang viết: ${chapter.title} (${done + 1}/${chapters.length})...');
        onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);

        // MỤC CV (2026-10-13): thay vì 1 lần gọi cả dàn ý (dễ "đầu voi đuôi chuột": các ý đầu chi tiết, ý sau lướt, chương cụt giữa câu khi hết token),
        // viết theo KẾ HOẠCH TỪNG Ý — xem chapter_writer_service.dart / chapter_write_flow.dart. Vẫn đi qua TranslationService (dịch thuật trung gian, huỷ giữa chừng,
        // hiện chữ dần) nên các sửa lỗi cũ (mục AW: truyền `isCancelled` xuống tận lệnh sinh) vẫn giữ nguyên hiệu lực — `isCancelled` được truyền vào từng lượt.
        // Sau mỗi phần xong, LƯU ĐIỂM DỪNG xuống DB (cột generation_checkpoint — trước đây chỉ nhánh remote có): local mất rất nhiều phút cho 1 chương, nếu app bị
        // tắt/sập giữa chừng thì lần sau tiếp tục từ phần đã xong thay vì viết lại từ đầu. (Lập luận cũ "local sập thì mất state trong RAM" không áp dụng — điểm dừng
        // nằm trong DB, không nằm trong RAM.) Cấu trúc vòng lặp TUẦN TỰ giữ nguyên: vẫn `await` xong chương này mới sang chương kế.
        final rawCheckpoint = chapter.generationCheckpoint;
        // MỤC CV2: điểm dừng không khớp (định dạng cũ / dàn ý đổi số ý) thì VẪN giữ phần đã viết và viết tiếp từ cuối nó (số ý đã xong là ước lượng).
        final split = await ChapterWriteFlow.prepareResume(
          novelId: novelId,
          outline: outline,
          content: chapter.content,
          rawCheckpoint: rawCheckpoint,
        );
        final resume = split.resume;
        final baseContent = split.base;
        if (resume != null && resume.estimated) {
          unawaited(DebugLogService.instance.log(
              'ChapterBatch: điểm dừng của "${chapter.title}" không khớp dàn ý hiện tại — GIỮ ${AuthorshipService.countWords(resume.text)} chữ đã viết, ước lượng đã xong ${resume.beatsDone}/${resume.beatsTotal} ý, viết tiếp từ cuối'));
        } else if (resume == null && (rawCheckpoint?.trim().isNotEmpty ?? false)) {
          unawaited(DebugLogService.instance.log(
              'ChapterBatch: điểm dừng của "${chapter.title}" hỏng/rỗng — không có gì để tiếp tục, viết từ đầu'));
        }
        final writeResult = await ChapterWriteFlow.run(
          novelId: novelId,
          provider: provider,
          outline: outline,
          chapterNumber: chapter.number,
          style: style,
          rag: rag,
          existingText: baseContent,
          resume: resume,
          isCancelled: isCancelled,
          onStage: (stage) {
            LocalLlamaProvider.updatePipelineStage('${chapter.title}: $stage');
          },
          onChunk: (full) {
            onProgress?.call(done, chapters.length, chapter.title, currentText: full, currentChapterId: chapter.id);
          },
          onSegmentDone: (text, beatsDone, beatsTotal) {
            unawaited(db.updateChapterCheckpoint(
                chapter.id, WriterCheckpoint(beatsDone: beatsDone, beatsTotal: beatsTotal, text: text).encode()));
          },
        );
        // Bị huỷ GIỮA CHỪNG (khác với "model tự sinh xong nhưng kết quả tệ") — dừng sạch hàng đợi ngay tại đây, KHÔNG báo thành lỗi
        // (đúng nguyên tắc mục AW). Các phần ĐÃ xong của chương này nằm trong điểm dừng — chạy lại đúng chương này sẽ tiếp tục từ đó.
        if (writeResult.cancelled) {
          onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          break;
        }
        if (writeResult.failure != null) {
          // Model dừng giữa chừng / trả rác (kể cả chuỗi cảnh báo `kAiFailureMarker`) — dừng cả hàng đợi như trước (không chạy tiếp tạo thêm rác, nhất là khi chạy qua đêm).
          // Phần đã xong (nếu có) đã nằm trong điểm dừng nên không mất.
          onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          throw ChapterBatchAnomalyException(
            chapterTitle: chapter.title,
            rawResult: writeResult.failure!,
            resumable: writeResult.checkpoint != null,
          );
        }
        final resultTrimmed = writeResult.text.trim();
        // ĐÃ SỬA (2026-09-07, sau sự cố mục W): kiểm tra `kAiFailureMarker` TRƯỚC, độc lập với ngưỡng độ dài (chuỗi cảnh báo ~180 ký tự có thể không bị coi là "quá ngắn").
        final looksCorrupted = resultTrimmed.isEmpty ||
            resultTrimmed.contains(kAiFailureMarker) ||
            resultTrimmed.length < outline.length * 0.5;
        if (looksCorrupted) {
          await db.updateChapterCheckpoint(chapter.id, null); // đã sinh xong hẳn nhưng hỏng — không resume từ rác
          onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          throw ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
        }

        chapter.content = WriterCheckpoint.join(baseContent, resultTrimmed);
        chapter.generationCheckpoint = null; // xong hẳn — không còn "dở dang"
        await db.upsertChapter(chapter);
        // MỤC CV: ghi nhận model nào viết đoạn này (chỉ phần do lần chạy NÀY tạo; phần lấy lại từ điểm dừng cũ không rõ model nào nên không tính).
        await AuthorshipService.record(
          db: db,
          chapterId: chapter.id,
          novelId: novelId,
          action: 'tao_hang_loat',
          tag: modelTag,
          text: ChapterWriterService.textAfterResume(resultTrimmed, resume, false),
        );
        // ĐÃ THÊM (rà soát toàn hệ thống — cùng lỗi "chưa nối dây" đã sửa
        // ở chapter_editor_screen.dart _save(); xem giải thích đầy đủ ở
        // đó): tạo hàng loạt là 1 trong 2 CÁCH CHÍNH nội dung chương được
        // lưu, nếu không ghi log ở đây thì mục tiêu viết mỗi ngày chỉ tính
        // đúng phần viết tay/AI hỗ trợ đơn lẻ, bỏ sót toàn bộ phần tạo
        // hàng loạt — sai lệch nghiêm trọng với "số chữ đã viết hôm nay".
        await db.recordWordSnapshot(novelId);
        // ĐÃ THÊM (rà soát toàn hệ thống, phát hiện khi làm tính năng "đồng
        // bộ chương 1000 với chương 1"): trước đây batch KHÔNG hề gọi tóm
        // tắt/index embedding cho chương vừa tạo — nghĩa là phần LỚN NHẤT
        // của 1 truyện dài (chương do "Tạo hàng loạt" sinh ra, không phải
        // viết tay) hoàn toàn VÔ HÌNH với "Chương liên quan (truy xuất ngữ
        // nghĩa)" ở RagService — mục đó chỉ thấy được chương ĐÃ được
        // index qua editor. Giờ gọi y hệt _updateSummaryAndIndexInBackground()
        // bên chapter_editor_screen.dart: tóm tắt → index embedding → nén
        // vào "Cốt truyện đã diễn ra".
        await _finalizeChapterMemory(chapter: chapter, provider: memoryProvider ?? provider, rag: rag); // MỤC CT
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
      }
    } finally {
      await LocalLlamaProvider.endPipeline();
    }
  }

  // ===== Nhánh REMOTE. Thả từng chương vào BackgroundTaskManager, chạy
  // THẬT SỰ đồng thời (giới hạn theo cấu hình người dùng). Giữ đúng hợp
  // đồng cũ với nơi gọi: vẫn ném ChapterBatchAnomalyException nếu có
  // chương bất thường (nơi gọi ở chapters_batch_generate_screen.dart bắt
  // lỗi này y hệt như trước, không cần sửa gì ở đó), vẫn gọi onProgress
  // đúng số lượng — chỉ khác thứ tự hoàn thành giờ có thể không tuần tự
  // theo đúng thứ tự trong danh sách `chapters` nữa (vì chạy song song).
  //
  // ĐÃ SỬA (theo yêu cầu người dùng — mục 5.93 tài liệu kiến trúc): trước
  // đây gọi `generateWithOptionalTranslation()` (HTTP không streaming) —
  // nếu GPU remote sập giữa chừng, MẤT SẠCH phần đã sinh, không có cách
  // nào tiếp tục đúng chỗ gãy, lần chạy lại phải viết lại từ đầu chương.
  // Giờ dùng `generateResumableWithOptionalTranslation()` — streaming
  // từng đoạn NGAY KHI model sinh ra (giống hệt cách model LOCAL đã
  // streaming trong khung chat), lưu checkpoint định kỳ vào
  // `chapter.generationCheckpoint`. Nếu chương ĐÃ CÓ checkpoint từ lần
  // chạy trước (do lần đó bị lỗi giữa chừng, chưa kịp lưu `content` cuối
  // cùng) — TỰ ĐỘNG coi đây là resume, gửi kèm checkpoint để model viết
  // TIẾP thay vì viết lại từ đầu. `onProgress` giờ báo thêm `currentPercent`
  // ước lượng (dựa trên độ dài văn bản thô đã nhận / độ dài kỳ vọng theo
  // `maxTokens`) — CHỈ là ước lượng thô để có cảm giác tiến trình, không
  // phải số chính xác tuyệt đối (không có cách nào biết trước chính xác
  // model sẽ viết bao nhiêu chữ). =====
  Future<void> _generateBatchParallel({
    required List<Chapter> chapters,
    required AIProvider provider,
    AIProvider? memoryProvider, // MỤC CT
    required String novelId,
    StyleProfile? style,
    bool Function()? isCancelled,
    void Function(int done, int total, String currentChapterTitle, {int? currentPercent, String? currentText, String? currentChapterId})? onProgress,
  }) async {
    final rag = RagService(
      db,
      await SettingsService().currentEmbeddingService(),
      novelId: novelId,
      contextBudgetChars: await SettingsService().loadRagBudget(novelId),
    );
    final modelTag = await SettingsService().currentModelTag(novelId); // MỤC CV: ghi nhận model nào viết
    final targetWords = await SettingsService().loadChapterTargetWords(novelId); // MỤC CV: để ước lượng % tiến trình theo số chữ mục tiêu
    var done = 0;
    onProgress?.call(done, chapters.length, '');

    // Cờ dùng chung giữa các nhiệm vụ song song — 1 chương phát hiện bất
    // thường sẽ CHẶN việc thả THÊM chương mới vào hàng đợi (đúng tinh
    // thần "không tổ tốn thời gian nếu model đang gặp vấn đề" của bản
    // gốc), nhưng KHÔNG ép dừng cứng các chương ĐANG chạy dở song song —
    // Dart không có cách huỷ Future đang await HTTP giữa chừng 1 cách an
    // toàn, để chúng tự hoàn tất là lựa chọn ít rủi ro hơn.
    ChapterBatchAnomalyException? capturedAnomaly;
    final completers = <Completer<void>>[];
    // ĐÃ THÊM (theo yêu cầu người dùng — "hủy giữa chừng lúc đang batch tạo
    // chương, không phải đợi xong toàn bộ", xem giải thích đầy đủ ở
    // `TranslationService.generateResumableWithOptionalTranslation`): 1 cờ
    // huỷ RIÊNG cho MỖI chương (không phải 1 cờ chung cho cả lô) — khớp
    // đúng cách `BackgroundTaskManager` biểu diễn: MỖI chương là 1
    // `BackgroundTask` ĐỘC LẬP, người dùng có thể huỷ đúng 1 chương đang
    // chạy dở từ màn "Tác vụ nền" (sống độc lập với vòng đời màn hình tạo
    // hàng loạt — huỷ được NGAY CẢ SAU KHI đã rời màn đó) mà không ảnh
    // hưởng các chương khác đang chạy song song.
    final cancelledChapterIds = <String>{};

    for (final chapter in chapters) {
      if (isCancelled?.call() ?? false) break;
      if (capturedAnomaly != null) break;
      final outline = chapter.outline?.trim() ?? '';
      if (outline.isEmpty) {
        done++;
        onProgress?.call(done, chapters.length, chapter.title);
        continue;
      }

      final completer = Completer<void>();
      completers.add(completer);
      // Điểm dừng còn sót từ lần chạy trước bị lỗi/huỷ giữa chừng (nếu có) — đây chính là "chỗ gãy" cần tiếp tục từ đó, không phải viết lại từ đầu.
      // MỤC CV: định dạng điểm dừng `⟦B<số ý đã xong>/<tổng số ý>⟧` + văn bản (xem WriterCheckpoint). MỤC CV2: điểm dừng không khớp (định dạng cũ / dàn ý đổi số ý)
      // thì VẪN giữ phần đã viết và viết tiếp từ cuối nó (số ý đã xong là ước lượng) thay vì viết lại từ đầu.
      final rawCheckpoint = chapter.generationCheckpoint;
      final split = await ChapterWriteFlow.prepareResume(
        novelId: novelId,
        outline: outline,
        content: chapter.content,
        rawCheckpoint: rawCheckpoint,
      );
      final resume = split.resume;
      final baseContent = split.base;
      if (resume != null && resume.estimated) {
        unawaited(DebugLogService.instance.log(
            'ChapterBatch: điểm dừng của "${chapter.title}" không khớp dàn ý hiện tại — GIỮ ${AuthorshipService.countWords(resume.text)} chữ đã viết, ước lượng đã xong ${resume.beatsDone}/${resume.beatsTotal} ý, viết tiếp từ cuối'));
      } else if (resume == null && (rawCheckpoint?.trim().isNotEmpty ?? false)) {
        unawaited(DebugLogService.instance.log(
            'ChapterBatch: điểm dừng của "${chapter.title}" hỏng/rỗng — không có gì để tiếp tục, viết từ đầu'));
      }
      var checkpointSaved = resume != null;

      BackgroundTaskManager.instance.submit(
        label: 'Chương: ${chapter.title}',
        category: 'chapter_batch',
        isLocalProvider: provider is LocalLlamaProvider,
        onCancelRequested: () => cancelledChapterIds.add(chapter.id),
        run: () async {
          try {
            // MỤC CV: viết theo KẾ HOẠCH TỪNG Ý (chế độ 'beats' mặc định cho API: mỗi ý 1 lượt có số chữ riêng, lượt cuối khép chương) thay vì 1 lần gọi cả dàn ý
            // — xem chapter_writer_service.dart. Mỗi lượt vẫn đi qua TranslationService (dịch thuật trung gian, streaming, huỷ). Sau mỗi lượt xong, LƯU ĐIỂM DỪNG xuống DB
            // — lỗi giữa chừng (hết hạn mức, mất mạng...) chỉ mất tối đa 1 lượt (~vài trăm chữ), không mất cả chương.
            final writeResult = await ChapterWriteFlow.run(
              novelId: novelId,
              provider: provider,
              outline: outline,
              chapterNumber: chapter.number,
              style: style,
              rag: rag,
              existingText: baseContent,
              resume: resume,
              isCancelled: () => cancelledChapterIds.contains(chapter.id),
              onChunk: (full) {
                // Hiện chữ ĐANG sinh ngay (khi dịch thuật tắt đây chính là văn bản cuối; khi bật, bước dịch ngược của từng lượt ghi đè bằng tiếng Việt thật).
                onProgress?.call(done, chapters.length, chapter.title,
                    currentPercent: estimatePercentByWords(AuthorshipService.countWords(full), targetWords),
                    currentText: full,
                    currentChapterId: chapter.id);
              },
              onSegmentDone: (text, beatsDone, beatsTotal) {
                checkpointSaved = true;
                // Không `await` — ghi điểm dừng không được làm chậm việc nhận chunk kế tiếp.
                unawaited(db.updateChapterCheckpoint(
                    chapter.id, WriterCheckpoint(beatsDone: beatsDone, beatsTotal: beatsTotal, text: text).encode()));
              },
            );
            if (writeResult.cancelled) {
              // Bị huỷ THEO Ý MUỐN (nút Huỷ ở màn "Tác vụ nền") — KHÔNG phải bất thường (không set `capturedAnomaly`, sẽ chặn thả thêm chương mới).
              // Các lượt đã xong nằm trong điểm dừng; chạy lại đúng chương này sẽ tiếp tục từ đó. Không tăng `done`.
              onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
              return;
            }
            if (writeResult.failure != null) {
              capturedAnomaly ??= ChapterBatchAnomalyException(
                chapterTitle: chapter.title,
                rawResult: writeResult.failure!,
                resumable: writeResult.checkpoint != null,
              );
              onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
              return;
            }
            final resultTrimmed = writeResult.text.trim();
            // ĐÃ SỬA (2026-09-07, sau sự cố mục W): kiểm tra `kAiFailureMarker`, không chỉ độ dài.
            final looksCorrupted = resultTrimmed.isEmpty ||
                resultTrimmed.contains(kAiFailureMarker) ||
                resultTrimmed.length < outline.length * 0.5;
            if (looksCorrupted) {
              // Kết quả ĐÃ sinh xong nhưng hỏng — resume từ văn bản hỏng không có ý nghĩa, xoá điểm dừng để lần sau viết lại sạch từ đầu.
              await db.updateChapterCheckpoint(chapter.id, null);
              capturedAnomaly ??= ChapterBatchAnomalyException(chapterTitle: chapter.title, rawResult: resultTrimmed);
              onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
              return; // không lưu kết quả hỏng, không tăng done
            }
            chapter.content = WriterCheckpoint.join(baseContent, resultTrimmed);
            chapter.generationCheckpoint = null; // xong hẳn — xoá điểm dừng, không còn "dở dang" nữa
            await db.upsertChapter(chapter);
            // MỤC CV: ghi nhận model nào viết (chỉ phần do lần chạy NÀY tạo ra).
            await AuthorshipService.record(
              db: db,
              chapterId: chapter.id,
              novelId: novelId,
              action: 'tao_hang_loat',
              tag: modelTag,
              text: ChapterWriterService.textAfterResume(resultTrimmed, resume, false),
            );
            // ĐÃ THÊM (rà soát toàn hệ thống — cùng lỗi "chưa nối dây" ở nhánh local phía trên).
            await db.recordWordSnapshot(novelId);
            await _finalizeChapterMemory(chapter: chapter, provider: memoryProvider ?? provider, rag: rag); // MỤC CT
            done++;
            onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          } on GenerationCancelledException {
            // ĐÃ THÊM: bị huỷ THEO Ý MUỐN người dùng (nút Huỷ ở màn "Tác vụ
            // nền") — KHÔNG phải bất thường, KHÔNG set `capturedAnomaly`
            // (sẽ chặn thả thêm chương mới vào hàng đợi nếu set — đúng cho
            // lỗi thật, sai cho huỷ chủ động). Checkpoint đã được lưu tại
            // đúng điểm dừng (xem `runStream`) — chương này coi như "chưa
            // xong", user có thể tạo lại đúng chương này sau, sẽ tự resume
            // đúng chỗ gãy. Không tăng `done`.
            // Báo UI bỏ chương này khỏi danh sách "đang chạy" (không còn
            // text mới để hiện) — không đổi `done`/`total`.
            onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          } catch (e) {
            // Lỗi giữa chừng (mất kết nối/GPU sập...) — GIỮ NGUYÊN checkpoint
            // đã lưu qua onCheckpoint (không xoá) để lần chạy sau resume
            // đúng chỗ gãy thay vì viết lại từ đầu.
            capturedAnomaly ??= ChapterBatchAnomalyException(
              chapterTitle: chapter.title,
              rawResult: e.toString(),
              resumable: checkpointSaved,
            );
            onProgress?.call(done, chapters.length, chapter.title, currentChapterId: chapter.id);
          } finally {
            if (!completer.isCompleted) completer.complete();
          }
        },
      );
    }

    // Đợi TẤT CẢ nhiệm vụ ĐÃ THẢ vào hàng đợi chạy xong (dù thành/bại) —
    // generateBatch() chỉ coi là hoàn tất khi không còn gì đang chạy dở.
    await Future.wait(completers.map((c) => c.future));

    if (capturedAnomaly != null) throw capturedAnomaly!;
  }

  // Dùng chung cho cả 2 nhánh (local + remote) — tóm tắt chương + index
  // embedding + nén vào "Cốt truyện đã diễn ra". Best-effort: lỗi ở đây
  // KHÔNG được phép làm hỏng cả batch (chương đã lưu thành công rồi, đây
  // chỉ là bước bổ trợ cho lần viết SAU) — nuốt lỗi, không rethrow.
  Future<void> _finalizeChapterMemory({
    required Chapter chapter,
    required AIProvider provider,
    required RagService rag,
  }) async {
    try {
      final summary = await SummaryService().summarizeChapter(chapter, provider);
      // ĐÃ THÊM (2026-09-07, sau sự cố mục W): cùng lỗ hổng y hệt đã vá ở
      // `chapter_editor_screen.dart` (`_updateSummaryAndIndexInBackground`)
      // — hàm NÀY là bản riêng dùng cho batch, không tự động thừa hưởng
      // bản vá ở màn soạn 1 chương, phải vá lại đúng chỗ này mới thật sự
      // che được luồng "chạy hàng loạt qua đêm".
      if (summary.trim().isEmpty || summary.contains(kAiFailureMarker)) {
        return;
      }
      chapter.autoSummary = summary;
      await db.upsertChapter(chapter);
      await rag.indexChapter(chapter);
      await rag.updateCumulativeStorySummary(chapter, provider);
    } catch (_) {
      // im lặng bỏ qua — xem giải thích ở comment đầu hàm.
    }
  }

  // Ước lượng % tiến trình trong 1 chương từ độ dài văn bản thô đã nhận —
  // CHỈ là ước lượng (không có cách nào biết trước chính xác model sẽ viết
  // bao nhiêu chữ). 2.6 ký tự/token là ước lượng thô cho tiếng Việt có dấu;
  // nếu đang dịch thuật trung gian, văn bản thô nằm ở ngôn ngữ trung gian
  // (thường tiếng Anh, mật độ ký tự/token gần tương tự nên vẫn dùng chung
  // hệ số này, không tách riêng để đơn giản). Chặn trần ở 95% cho tới khi
  // thật sự xong hẳn (còn phải qua bước dịch ngược + kiểm tra hợp lý).
  // ĐÃ ĐỔI sang public + static (trước là private) — chapters_batch_
  // generate_screen.dart cũng cần đúng công thức này để hiện % ước lượng
  // ngay trong danh sách chọn chương (chương có checkpoint dở dang), tránh
  // chép lại công thức ở 2 nơi rồi lệch nhau khi có ai sửa 1 chỗ mà quên chỗ kia.
  static const maxTokensPerChapter = 1500;
  // MỤC CV: khi biết số chữ mục tiêu của chương (cài đặt "Viết chương" — mặc định local 600 / API 1200 chữ) thì ước lượng theo đó (~5 ký tự/chữ tiếng Việt kể cả khoảng trắng),
  // thay vì giả định cứng 1500 token như trước (sai hẳn khi chương mục tiêu 1200 chữ).
  static int estimatePercent(int rawChars, {int maxTokens = maxTokensPerChapter, int? targetWords}) {
    const charsPerTokenEstimate = 2.6;
    final estTargetChars = targetWords != null
        ? (targetWords * 5).clamp(500, 100000)
        : (maxTokens * charsPerTokenEstimate).clamp(500, 100000);
    return (rawChars / estTargetChars * 100).clamp(0, 95).round();
  }

  static int estimatePercentByWords(int words, int targetWords) {
    if (targetWords <= 0) return 0;
    return (words / targetWords * 100).clamp(0, 95).round();
  }
}

class ChapterBatchAnomalyException implements Exception {
  final String chapterTitle;
  final String rawResult;
  // ĐÃ THÊM: true nếu lỗi này có checkpoint đã lưu, resume được ở lần chạy
  // sau (lỗi kết nối/GPU sập giữa chừng) — false nếu là kết quả hỏng đã
  // sinh xong hẳn (không có checkpoint để resume, phải viết lại từ đầu).
  final bool resumable;
  ChapterBatchAnomalyException({required this.chapterTitle, required this.rawResult, this.resumable = false});

  // MỤC CV: thêm LÝ DO THẬT (thông báo lỗi của provider — vd hết hạn mức API, sai khoá) vào thông báo; trước đây chỉ nói chung chung "mất kết nối/GPU sập" nên người dùng
  // dùng API miễn phí bị chặn hạn mức không biết vì sao dừng.
  String get _detail {
    final d = rawResult.trim().replaceAll('\n', ' ');
    if (d.isEmpty) return '';
    return ' Chi tiết: ${d.length > 300 ? '${d.substring(0, 300)}…' : d}';
  }

  @override
  String toString() => resumable
      ? 'Chương "$chapterTitle": lỗi giữa chừng — '
          'ĐÃ DỪNG tạo các chương còn lại. Phần đã viết được cho chương này ĐÃ LƯU TẠM, '
          'chạy lại sẽ tiếp tục đúng chỗ gãy thay vì viết lại từ đầu.$_detail'
      : 'Chương "$chapterTitle": kết quả bất thường (${rawResult.length} ký tự) — '
          'có thể model bị lỗi giữa chừng, ĐÃ DỪNG tạo các chương còn lại trong hàng đợi.$_detail';
}

import '../ai_provider.dart';
import '../web_chat/web_chat_session.dart';

// MỤC CS (2026-10-07) — DÙNG 1 WEB CHAT AI (đăng nhập sẵn trong WebView của app) NHƯ MỘT MODEL VIẾT TRUYỆN.
// Xem web_chat_session.dart để biết cách hoạt động và GIỚI HẠN THẬT (chưa chạy thử trên trang thật, rủi ro điều khoản dịch vụ, hạn mức tin nhắn...).
//
// Hợp đồng với phần còn lại của app (không đổi gì ở màn hình viết chương/chat/Bible): nhận systemPrompt + userPrompt, trả về chữ trả lời.
//   - Web chat chỉ có MỘT ô nhập, nên system prompt (Story Bible, văn phong...) được ghép vào ĐẦU tin nhắn kèm nhãn, rồi tới yêu cầu cụ thể.
//   - Mỗi lần gọi mở 1 CUỘC TRÒ CHUYỆN MỚI (nạp lại URL "chat mới") — app vốn đã gửi lại toàn bộ ngữ cảnh mỗi lượt, nên không cần dựa vào lịch sử của trang
//     (và tránh ngữ cảnh phình dần làm trang từ chối).
//   - temperature/topP/topK/maxTokens/repetitionPenalty KHÔNG áp dụng được (giao diện web không cho chỉnh) — bị bỏ qua.
//   - Không có stream thật: trả 1 khối khi trả lời đã ổn định (đọc chữ từ trang dễ lệch nếu trang vẽ lại giữa chừng; 1 khối an toàn hơn ghép từng mẩu).
class WebChatProvider implements AIProvider {
  final String startUrl;
  final String profileKey;
  final String label;

  WebChatProvider({required this.startUrl, required this.profileKey, required this.label});

  @override
  String get name => 'Web chat AI ($label)';

  @override
  String get description =>
      'Dùng trang web chat AI bạn đã đăng nhập trong app như một model: app dán prompt + Story Bible vào ô chat, đợi trả lời rồi lưu thành chương. '
      'Chậm hơn API, có thể bị giới hạn bởi hạn mức của trang, và phụ thuộc giao diện web (có thể phải "Dạy app" lại khi trang đổi).';

  @override
  Future<bool> isReady() async => startUrl.trim().isNotEmpty;

  String _compose(String systemPrompt, String userPrompt) {
    final sys = systemPrompt.trim();
    if (sys.isEmpty) return userPrompt;
    return '[HƯỚNG DẪN HỆ THỐNG — hãy tuân thủ xuyên suốt]\n$sys\n\n[YÊU CẦU CỤ THỂ]\n$userPrompt';
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) {
    return WebChatSession.instance.ask(
      startUrl: startUrl,
      profileKey: profileKey,
      prompt: _compose(systemPrompt, userPrompt),
    );
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool reuseKv = false,
  }) async* {
    final text = await WebChatSession.instance.ask(
      startUrl: startUrl,
      profileKey: profileKey,
      prompt: _compose(systemPrompt, userPrompt),
    );
    yield text;
  }
}

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../ai_provider.dart';
import '../debug_log_service.dart';

// Provider dùng chung cho OpenAI và bất kỳ dịch vụ nào expose API theo
// chuẩn "OpenAI-compatible" (rất phổ biến, kể cả một số dịch vụ cho phép
// chọn model ít giới hạn hơn dành riêng cho viết truyện hư cấu).
// Người dùng tự nhập baseUrl + apiKey trong Cài đặt, app không hardcode
// một nhà cung cấp cụ thể nào.
//
// MỤC CV (2026-10-13) — VIẾT LẠI LỚP GỌI HTTP, sửa 4 lỗ hổng THẬT tìm thấy khi thêm API miễn phí (Groq...):
//   1. LUỒNG STREAM TRƯỚC ĐÂY KHÔNG KIỂM TRA MÃ HTTP. Gói miễn phí chắc chắn gặp 429/401/413 — thân lỗi (JSON) không bắt đầu bằng "data: " nên
//      bị bỏ qua, stream kết thúc rỗng, chương/đoạn rỗng hoặc cụt mà KHÔNG có thông báo lỗi nào. Giờ đọc status, thân lỗi, ném lỗi tiếng Việt rõ ràng.
//   2. TÁCH DÒNG SSE THEO TỪNG CHUNK MẠNG: 1 dòng "data: {...}" bị cắt đôi giữa 2 chunk thì cả 2 nửa đều bị bỏ (jsonDecode lỗi bị nuốt) => RƠI CHỮ
//      âm thầm giữa văn bản. Giờ ghép đệm theo dòng hoàn chỉnh (cùng cách GeminiProvider).
//   3. 429 (vượt hạn mức) KHÔNG ĐƯỢC XỬ LÝ: giờ đọc Retry-After / "try again in ..." trong thân lỗi, chờ rồi thử lại tối đa 3 lần nếu thời gian chờ
//      hợp lý (<= 75 giây, tức hạn mức theo PHÚT); nếu hết hạn mức NGÀY hoặc yêu cầu lớn hơn hẳn hạn mức token/phút (chờ cũng vô ích) thì báo rõ, không
//      chờ vô ích.
//   4. LỖI MID-STREAM (vd OpenRouter gửi {"error":...} giữa luồng): trước đây bị bỏ qua => văn bản cụt được coi như hoàn chỉnh. Giờ ném lỗi.
// THÍCH ỨNG THAM SỐ (cơ chế tổng quát, KHÔNG hardcode theo tên model/nhà cung cấp): `top_k`, `top_p`, `frequency_penalty`, `reasoning_effort` không phải
// nhà cung cấp nào cũng nhận (Groq: không liệt kê top_k; Mistral: 422 với trường lạ; gpt-oss không nhận reasoning_effort="none"...). Khi server trả
// 400/422, provider tìm tên tham số trong thân lỗi và BỎ tham số đó (hoặc hạ bậc `reasoning_effort` theo thang `reasoningEffortLadder`) rồi thử lại;
// kết quả học được lưu theo cặp (baseUrl, model) vào SharedPreferences nên các lần sau không phải thử-sai lại.
// Model "suy luận" có thể chèn <think>...</think> vào nội dung: bỏ phần này khỏi văn bản truyện (cả stream lẫn không stream).
// CHƯA build/test thật (không có Dart SDK ở môi trường soạn) — xem mục CV tài liệu kiến trúc.
// MỤC CV2: kết quả "Thử kết nối" (xem OpenAICompatibleProvider.probeEndpoint).
class ApiProbeResult {
  final bool ok;
  final int? status;
  final int latencyMs;
  final String summary;
  final Map<String, String> rateHeaders; // header hạn mức do server gửi (x-ratelimit-*, retry-after) — số của CHÍNH tài khoản này
  const ApiProbeResult({required this.ok, this.status, required this.latencyMs, required this.summary, this.rateHeaders = const {}});
}

class OpenAICompatibleProvider implements AIProvider {
  final String baseUrl; // ví dụ: https://api.openai.com/v1
  final String apiKey;
  final String modelId;

  // true = có gửi `top_k` (phần mở rộng ngoài chuẩn OpenAI, llama.cpp/vLLM/Ollama/Colab nhận). Nếu server từ chối, tự bỏ (xem THÍCH ỨNG THAM SỐ).
  final bool sendTopK;
  // Thang `reasoning_effort` thử lần lượt từ phần tử đầu; bị từ chối thì sang phần tử kế; hết thang thì không gửi nữa. Rỗng = không bao giờ gửi.
  final List<String> reasoningEffortLadder;
  // Nhãn ngắn dùng trong thông báo lỗi (vd "Groq"); rỗng => "API".
  final String label;

  // Timeout: xem giải thích gốc (GPU remote Colab có thể treo kiểu TCP không đóng). 10 phút cho cả lượt không stream; stream chỉ tính khoảng
  // cách giữa 2 chunk (2 phút không có chunk nào = server đã treo).
  static const _requestTimeout = Duration(minutes: 10);
  static const _streamIdleTimeout = Duration(minutes: 2);
  // Chờ tối đa bao nhiêu giây khi 429 có Retry-After: quá ngưỡng này coi là hạn mức NGÀY/giờ, không chờ.
  static const _maxAutoWaitSeconds = 75;
  static const _maxRateLimitRetries = 3;
  static const _maxAdaptRetries = 5;

  // Trạng thái đã học, dùng chung mọi instance (SettingsService dựng provider MỚI mỗi lần gọi).
  static final Map<String, _Learned> _learnedByKey = {};

  OpenAICompatibleProvider({
    required this.baseUrl,
    required this.apiKey,
    required this.modelId,
    this.sendTopK = true,
    this.reasoningEffortLadder = const [],
    this.label = '',
  });

  @override
  String get name => 'API tương thích OpenAI';

  @override
  String get description => 'Dùng cho OpenAI hoặc bất kỳ endpoint tương thích nào bạn tự cấu hình.';

  @override
  Future<bool> isReady() async => apiKey.isNotEmpty && baseUrl.isNotEmpty;

  // MỤC CV2: "Thử kết nối" — 1 yêu cầu NHỎ (max_tokens 8, không tham số phụ, không thử-lại) để biết key/URL/model có dùng được không, mất bao lâu, và (nếu server
  // gửi) hạn mức THẬT của tài khoản qua header x-ratelimit-* — thay cho số trong tài liệu (có thể mơ hồ/đã đổi). Dùng được cả khi bị chặn vùng: lỗi mạng/HTTP hiện nguyên văn.
  static Future<ApiProbeResult> probeEndpoint({
    required String baseUrl,
    required String apiKey,
    required String modelId,
    String label = '',
  }) async {
    final sw = Stopwatch()..start();
    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/chat/completions'),
            headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $apiKey'},
            body: jsonEncode({
              'model': modelId,
              'messages': [
                {'role': 'user', 'content': 'Trả lời đúng một từ: ok'},
              ],
              'max_tokens': 8,
            }),
          )
          .timeout(const Duration(seconds: 45));
      sw.stop();
      final rate = <String, String>{};
      res.headers.forEach((k, v) {
        final lk = k.toLowerCase();
        if (lk.startsWith('x-ratelimit') || lk.startsWith('ratelimit') || lk == 'retry-after') rate[lk] = v;
      });
      final bodyText = utf8.decode(res.bodyBytes, allowMalformed: true);
      if (res.statusCode == 200) {
        var reply = '';
        try {
          final d = jsonDecode(bodyText);
          final c = d is Map ? d['choices'] : null;
          if (c is List && c.isNotEmpty && c[0] is Map) {
            final m = (c[0] as Map)['message'];
            if (m is Map && m['content'] is String) reply = (m['content'] as String).trim();
          }
        } catch (_) {}
        return ApiProbeResult(
          ok: true,
          status: 200,
          latencyMs: sw.elapsedMilliseconds,
          summary: 'Kết nối được. Phản hồi mẫu: "${reply.isEmpty ? '(rỗng)' : reply}".',
          rateHeaders: rate,
        );
      }
      final msg = OpenAICompatibleProvider(baseUrl: baseUrl, apiKey: apiKey, modelId: modelId, label: label)
          ._explain(res.statusCode, bodyText)
          .toString()
          .replaceFirst('Exception: ', '');
      return ApiProbeResult(ok: false, status: res.statusCode, latencyMs: sw.elapsedMilliseconds, summary: msg, rateHeaders: rate);
    } on TimeoutException {
      return ApiProbeResult(ok: false, latencyMs: sw.elapsedMilliseconds, summary: 'Hết 45 giây không có phản hồi — mạng chậm, hoặc nhà cung cấp chặn/không tới được từ mạng này.');
    } catch (e) {
      return ApiProbeResult(
        ok: false,
        latencyMs: sw.elapsedMilliseconds,
        summary: 'Không kết nối được tới $baseUrl: $e. Kiểm tra mạng và Base URL; nếu nhà cung cấp chặn theo vùng IP thì app không vượt được.',
      );
    }
  }

  String get _who => label.isEmpty ? 'API' : label;
  String get _learnKey => '$baseUrl|$modelId';
  String get _prefsKey => 'api_learned::$_learnKey';

  Map<String, String> get _headers => {'Content-Type': 'application/json', 'Authorization': 'Bearer $apiKey'};

  // ---------- Trạng thái học được ----------
  Future<_Learned> _state() async {
    final cached = _learnedByKey[_learnKey];
    if (cached != null) return cached;
    final l = _Learned();
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(_prefsKey);
      if (raw != null && raw.isNotEmpty) {
        final m = jsonDecode(raw);
        if (m is Map) {
          final d = m['dropped'];
          if (d is List) l.dropped.addAll(d.whereType<String>());
          final e = m['effortIdx'];
          if (e is int) l.effortIdx = e;
        }
      }
    } catch (_) {}
    _learnedByKey[_learnKey] = l;
    return l;
  }

  Future<void> _persist(_Learned l) async {
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString(_prefsKey, jsonEncode({'dropped': l.dropped.toList(), 'effortIdx': l.effortIdx}));
    } catch (_) {}
  }

  Map<String, dynamic> _buildBody(
    _Learned l, {
    required String systemPrompt,
    required String userPrompt,
    required double temperature,
    required int maxTokens,
    required double topP,
    required int topK,
    required double repetitionPenalty,
    required bool stream,
  }) {
    final body = <String, dynamic>{
      'model': modelId,
      'messages': [
        {'role': 'system', 'content': systemPrompt},
        {'role': 'user', 'content': userPrompt},
      ],
      'temperature': temperature,
      'max_tokens': maxTokens,
    };
    if (stream) body['stream'] = true;
    if (!l.dropped.contains('top_p')) body['top_p'] = topP;
    if (sendTopK && !l.dropped.contains('top_k')) body['top_k'] = topK;
    // Chuẩn OpenAI không có repetition_penalty; frequency_penalty gần tương đương (thang khác nhau nên chỉ quy đổi thô).
    if (!l.dropped.contains('frequency_penalty')) {
      body['frequency_penalty'] = (repetitionPenalty - 1.0).clamp(-2.0, 2.0);
    }
    if (l.effortIdx < reasoningEffortLadder.length) {
      body['reasoning_effort'] = reasoningEffortLadder[l.effortIdx];
    }
    return body;
  }

  // Trả về true nếu đã chỉnh gì đó (nên thử lại ngay với body mới).
  bool _adaptToRejection(_Learned l, String bodyText) {
    final t = bodyText.toLowerCase();
    var changed = false;
    if (t.contains('reasoning_effort') || t.contains('reasoning effort')) {
      if (l.effortIdx < reasoningEffortLadder.length) {
        l.effortIdx++;
        changed = true;
      }
    }
    for (final k in const ['top_k', 'top_p', 'frequency_penalty']) {
      if (t.contains(k) && !l.dropped.contains(k)) {
        l.dropped.add(k);
        changed = true;
      }
    }
    // Lỗi 400 không nêu tên tham số nào nhưng ta đang gửi reasoning_effort: hạ bậc luôn (thang hữu hạn nên chắc chắn dừng).
    if (!changed && l.effortIdx < reasoningEffortLadder.length) {
      l.effortIdx++;
      changed = true;
    }
    return changed;
  }

  // ---------- Đọc lỗi ----------
  String _extractMessage(String bodyText) {
    try {
      final d = jsonDecode(bodyText);
      if (d is Map) {
        final e = d['error'];
        if (e is Map && e['message'] != null) return '${e['message']}';
        if (e is String) return e;
        final m = d['message'];
        if (m is String) return m;
        if (m != null) return jsonEncode(m);
        final detail = d['detail'];
        if (detail != null) return detail is String ? detail : jsonEncode(detail);
      }
    } catch (_) {}
    return bodyText.length > 400 ? '${bodyText.substring(0, 400)}...' : bodyText;
  }

  // Giây cần chờ theo header Retry-After hoặc câu "try again in 1m5.2s" trong thân lỗi; null nếu không biết.
  double? _waitSeconds(Map<String, String> headers, String bodyText) {
    final h = headers['retry-after'];
    if (h != null) {
      final v = double.tryParse(h.trim());
      if (v != null) return v;
    }
    final m = RegExp(r'try again in ([0-9hms.]+)', caseSensitive: false).firstMatch(bodyText);
    if (m == null) return null;
    final token = m.group(1) ?? '';
    var total = 0.0;
    var any = false;
    for (final p in RegExp(r'(\d+(?:\.\d+)?)(ms|h|m|s)').allMatches(token)) {
      final n = double.tryParse(p.group(1) ?? '');
      final unit = p.group(2);
      if (n == null || unit == null) continue;
      any = true;
      if (unit == 'ms') {
        total += n / 1000.0;
      } else if (unit == 'h') {
        total += n * 3600.0;
      } else if (unit == 'm') {
        total += n * 60.0;
      } else {
        total += n;
      }
    }
    return any ? total : null;
  }

  // "Limit 8000, Used 0, Requested 9000": yêu cầu lớn hơn hẳn hạn mức => chờ cũng không bao giờ qua được.
  ({int limit, int requested})? _tooLargeInfo(String bodyText) {
    final m = RegExp(r'Limit (\d+), Used (\d+), Requested (\d+)', caseSensitive: false).firstMatch(bodyText);
    if (m == null) return null;
    final limit = int.tryParse(m.group(1) ?? '');
    final requested = int.tryParse(m.group(3) ?? '');
    if (limit == null || requested == null) return null;
    return requested > limit ? (limit: limit, requested: requested) : null;
  }

  Exception _explain(int status, String bodyText) {
    final msg = _extractMessage(bodyText);
    final lower = bodyText.toLowerCase();
    if (status == 401 || status == 403) {
      return Exception('$_who từ chối quyền truy cập (HTTP $status): API key sai/hết hiệu lực hoặc tài khoản chưa được cấp quyền model này. Chi tiết: $msg');
    }
    if (status == 404) {
      return Exception('$_who báo không tìm thấy (HTTP 404): kiểm tra lại Model ID và Base URL. Chi tiết: $msg');
    }
    final tooLarge = _tooLargeInfo(bodyText);
    if (status == 413 || tooLarge != null) {
      final extra = tooLarge == null ? '' : ' (xin ${tooLarge.requested} token, hạn mức/phút của model chỉ ${tooLarge.limit})';
      return Exception('Yêu cầu quá lớn so với hạn mức của $_who$extra. Cách xử lý: giảm "ngân sách Bible cho API" và/hoặc "số token tối đa" '
          'trong Cài đặt sinh văn bản, hoặc chọn model có hạn mức token/phút cao hơn. Chi tiết: $msg');
    }
    if (status == 429) {
      final daily = lower.contains('per day') || lower.contains('tpd') || lower.contains('rpd') || lower.contains('daily');
      if (daily) {
        return Exception('Đã hết hạn mức NGÀY của $_who cho model này. Chờ hạn mức làm mới (tuỳ nhà cung cấp), hoặc đổi sang model/nhà cung cấp khác. Chi tiết: $msg');
      }
      final w = _waitSeconds(const <String, String>{}, bodyText);
      final when = w == null ? 'Chờ 1-2 phút' : (w > 90 ? 'Chờ khoảng ${(w / 60).ceil()} phút' : 'Chờ khoảng ${w.ceil()} giây');
      return Exception('$_who báo vượt hạn mức token/tần suất (HTTP 429) — app đã tự chờ-thử-lại khi thời gian chờ ngắn nhưng vẫn bị từ chối. $when rồi thử lại, hoặc đổi model. Chi tiết: $msg');
    }
    return Exception('Lỗi $_who (HTTP $status): $msg');
  }

  // Quyết định sau 1 phản hồi lỗi: trả về (đã chờ/đã chỉnh => thử lại) hoặc ném lỗi cuối cùng.
  Future<void> _handleHttpError(int status, String bodyText, Map<String, String> headers, _Learned l, _Attempt a) async {
    if ((status == 400 || status == 422) && a.adapts < _maxAdaptRetries && _adaptToRejection(l, bodyText)) {
      a.adapts++;
      await _persist(l);
      unawaited(DebugLogService.instance.log('$_who: HTTP $status — bỏ/hạ tham số bị từ chối (dropped=${l.dropped.toList()}, effortIdx=${l.effortIdx}) rồi thử lại'));
      return;
    }
    if ((status == 429 || status == 503) && a.waits < _maxRateLimitRetries && _tooLargeInfo(bodyText) == null) {
      final lower = bodyText.toLowerCase();
      final daily = lower.contains('per day') || lower.contains('tpd') || lower.contains('rpd') || lower.contains('daily');
      if (!daily) {
        var wait = _waitSeconds(headers, bodyText);
        wait ??= 6.0 * (a.waits + 1); // không có gợi ý: lùi dần 6s, 12s, 18s
        if (wait <= _maxAutoWaitSeconds) {
          a.waits++;
          unawaited(DebugLogService.instance.log('$_who: HTTP $status — chờ ${wait.toStringAsFixed(1)}s rồi thử lại (lần ${a.waits}/$_maxRateLimitRetries)'));
          await Future.delayed(Duration(milliseconds: (wait * 1000).ceil() + 400));
          return;
        }
      }
    }
    unawaited(DebugLogService.instance.log('$_who: HTTP $status — bỏ cuộc. Thân lỗi: ${bodyText.length > 300 ? bodyText.substring(0, 300) : bodyText}'));
    throw _explain(status, bodyText);
  }

  // ---------- Bỏ <think>...</think> ----------
  static String _stripThinkWhole(String s) {
    var t = s.replaceAll(RegExp(r'<think>[\s\S]*?</think>'), '');
    final open = t.indexOf('<think>');
    if (open >= 0) t = t.substring(0, open); // mở thẻ mà không đóng (cụt do hết token): chỉ có suy nghĩ, bỏ
    return t.trim().isEmpty ? '' : t;
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) async {
    final l = await _state();
    final attempt = _Attempt();
    while (true) {
      final http.Response res;
      try {
        res = await http
            .post(
              Uri.parse('$baseUrl/chat/completions'),
              headers: _headers,
              body: jsonEncode(_buildBody(l,
                  systemPrompt: systemPrompt,
                  userPrompt: userPrompt,
                  temperature: temperature,
                  maxTokens: maxTokens,
                  topP: topP,
                  topK: topK,
                  repetitionPenalty: repetitionPenalty,
                  stream: false)),
            )
            .timeout(_requestTimeout);
      } on TimeoutException {
        throw Exception(
            'Hết thời gian chờ (${_requestTimeout.inMinutes} phút) — server không phản hồi. '
            'Nếu đang dùng GPU từ xa (Colab): phiên có thể đã bị ngắt/GPU đã sập, '
            'thử chạy lại notebook Colab và cập nhật URL mới trong Cài đặt.');
      }
      final bodyText = utf8.decode(res.bodyBytes, allowMalformed: true);
      if (res.statusCode != 200) {
        await _handleHttpError(res.statusCode, bodyText, res.headers, l, attempt);
        continue; // _handleHttpError ném lỗi nếu bỏ cuộc; trả về bình thường = thử lại
      }
      dynamic data;
      try {
        data = jsonDecode(bodyText);
      } catch (_) {
        throw Exception('$_who trả về dữ liệu không phải JSON: ${bodyText.length > 200 ? bodyText.substring(0, 200) : bodyText}');
      }
      final choices = data is Map ? data['choices'] : null;
      if (choices is! List || choices.isEmpty || choices[0] is! Map) {
        throw Exception('$_who trả về phản hồi không có "choices": ${_extractMessage(bodyText)}');
      }
      final choice = choices[0] as Map;
      final message = choice['message'];
      final rawContent = (message is Map && message['content'] is String) ? message['content'] as String : '';
      final text = _stripThinkWhole(rawContent);
      if (text.isEmpty) {
        final fr = choice['finish_reason'];
        throw Exception('$_who không trả về chữ nào (finish_reason=$fr). Nếu là model suy luận: nó đã dùng hết ngân sách token cho phần suy nghĩ — '
            'tăng "số token tối đa" trong Cài đặt sinh văn bản.');
      }
      return text;
    }
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool reuseKv = false, // không dùng — chỉ có ý nghĩa với LocalLlamaProvider
  }) async* {
    final l = await _state();
    final attempt = _Attempt();
    late http.StreamedResponse streamed;
    while (true) {
      final req = http.Request('POST', Uri.parse('$baseUrl/chat/completions'));
      req.headers.addAll(_headers);
      req.body = jsonEncode(_buildBody(l,
          systemPrompt: systemPrompt,
          userPrompt: userPrompt,
          temperature: temperature,
          maxTokens: maxTokens,
          topP: topP,
          topK: topK,
          repetitionPenalty: repetitionPenalty,
          stream: true));
      final http.StreamedResponse got;
      try {
        got = await req.send().timeout(_requestTimeout);
      } on TimeoutException {
        throw Exception(
            'Hết thời gian chờ (${_requestTimeout.inMinutes} phút) — server không phản hồi kết nối ban đầu. '
            'Nếu đang dùng GPU từ xa (Colab): phiên có thể đã bị ngắt/GPU đã sập.');
      }
      if (got.statusCode == 200) {
        streamed = got;
        break;
      }
      final errBody = await got.stream.bytesToString();
      await _handleHttpError(got.statusCode, errBody, got.headers, l, attempt); // ném lỗi nếu bỏ cuộc; trả về bình thường = thử lại
    }
    // Timeout THEO TỪNG CHUNK (không phải tổng): 1 chương dài có thể stream hợp lệ nhiều phút, nhưng khoảng cách giữa 2 chunk quá dài = server treo.
    final byteStream = streamed.stream.timeout(
      _streamIdleTimeout,
      onTimeout: (sink) => sink.addError(TimeoutException(
          'Server ngừng phản hồi giữa chừng quá ${_streamIdleTimeout.inMinutes} phút — '
          'có thể GPU từ xa đã sập, kiểm tra lại notebook Colab.')),
    );
    final think = _ThinkStripper();
    var anyText = false;
    var finished = false;
    var pending = '';
    await for (final chunk in byteStream.transform(utf8.decoder)) {
      pending += chunk;
      final lines = pending.split('\n').toList(); // toList(): chắc chắn là danh sách mở rộng được (removeLast bên dưới)
      pending = lines.removeLast(); // dòng cuối có thể chưa đủ — giữ lại ghép với chunk sau
      for (final line in lines) {
        final r = _parseSseLine(line);
        if (r.error != null) {
          throw Exception('$_who báo lỗi giữa chừng khi đang sinh: ${r.error}');
        }
        if (r.text != null && r.text!.isNotEmpty) {
          final out = think.feed(r.text!);
          if (out.isNotEmpty) {
            anyText = true;
            yield out;
          }
        }
        if (r.done) {
          finished = true;
          break;
        }
      }
      if (finished) break;
    }
    if (!finished && pending.trim().isNotEmpty) {
      final r = _parseSseLine(pending);
      if (r.error != null) throw Exception('$_who báo lỗi giữa chừng khi đang sinh: ${r.error}');
      if (r.text != null && r.text!.isNotEmpty) {
        final out = think.feed(r.text!);
        if (out.isNotEmpty) {
          anyText = true;
          yield out;
        }
      }
    }
    final tail = think.flush();
    if (tail.isNotEmpty) {
      anyText = true;
      yield tail;
    }
    if (!anyText) {
      throw Exception('$_who trả về luồng rỗng (không có chữ nào). Nếu là model suy luận: tăng "số token tối đa" hoặc đổi model; '
          'nếu chỉ mới bị giới hạn tần suất: chờ 1-2 phút rồi thử lại.');
    }
  }

  ({String? text, bool done, String? error}) _parseSseLine(String raw) {
    final line = raw.trim();
    if (!line.startsWith('data:')) return (text: null, done: false, error: null);
    final payload = line.substring(5).trim();
    if (payload.isEmpty) return (text: null, done: false, error: null);
    if (payload == '[DONE]') return (text: null, done: true, error: null);
    try {
      final data = jsonDecode(payload);
      if (data is Map) {
        if (data['error'] != null) {
          return (text: null, done: true, error: _extractMessage(payload));
        }
        final choices = data['choices'];
        if (choices is List && choices.isNotEmpty && choices[0] is Map) {
          final delta = (choices[0] as Map)['delta'];
          if (delta is Map && delta['content'] is String) {
            return (text: delta['content'] as String, done: false, error: null);
          }
        }
      }
    } catch (_) {}
    return (text: null, done: false, error: null);
  }
}

class _Learned {
  final Set<String> dropped = <String>{};
  int effortIdx = 0;
}

class _Attempt {
  int adapts = 0;
  int waits = 0;
}

// Lọc <think>...</think> ở ĐẦU luồng (nơi model suy luận đặt phần suy nghĩ), xử lý được thẻ bị cắt đôi giữa 2 chunk.
// State 0: chưa quyết định (đang đệm tiền tố có thể là "<think>"); 1: đang trong khối suy nghĩ (bỏ); 2: chạy thẳng.
class _ThinkStripper {
  static const String _open = '<think>';
  static const String _close = '</think>';
  String _buf = '';
  int _state = 0;

  String feed(String s) {
    if (_state == 2) return s;
    _buf += s;
    if (_state == 0) {
      final t = _buf.trimLeft();
      if (t.length < _open.length && _open.startsWith(t)) return ''; // có thể là đầu thẻ — đợi thêm
      if (t.startsWith(_open)) {
        _state = 1;
        _buf = t.substring(_open.length);
      } else {
        _state = 2;
        final out = _buf;
        _buf = '';
        return out;
      }
    }
    // state 1: tìm thẻ đóng
    final end = _buf.indexOf(_close);
    if (end < 0) {
      // giữ lại đuôi đủ dài để thẻ đóng bị cắt đôi vẫn nhận ra được; phần còn lại là suy nghĩ, bỏ
      if (_buf.length > _close.length) _buf = _buf.substring(_buf.length - _close.length);
      return '';
    }
    final rest = _buf.substring(end + _close.length);
    _state = 2;
    _buf = '';
    return rest.trimLeft();
  }

  // Hết luồng: nếu còn đệm ở state 0 (văn bản ngắn giống đầu thẻ) thì trả ra; ở state 1 (suy nghĩ chưa đóng) thì bỏ.
  String flush() {
    if (_state == 0) {
      final out = _buf;
      _buf = '';
      return out;
    }
    _buf = '';
    return '';
  }
}

import '../ai_provider.dart';
import 'openai_compatible_provider.dart';

// MỤC CV (2026-10-13) — GROQ (groq.com): API miễn phí, không cần thẻ, tương thích OpenAI. Theo yêu cầu người dùng: "có API nào miễn phí nữa không, làm luôn".
//
// Số liệu hạn mức đối chiếu với TÀI LIỆU CHÍNH THỨC Groq (console.groq.com/docs/rate-limits, đọc 2026-10-13): gói miễn phí, MỖI MODEL riêng
// (không chung): 30 yêu cầu/phút, 1.000 yêu cầu/ngày, 8.000 token/phút, 200.000 token/ngày (gpt-oss-120b, gpt-oss-20b, qwen3.8-27b...).
// Giới hạn tính theo TỔ CHỨC, không theo người dùng. Số liệu có thể đổi — LUÔN xem lại trang đó, app không hardcode.
// HỆ QUẢ THIẾT KẾ (quan trọng): 8K token/phút nhỏ hơn nhiều so với context 131K của model => 1 yêu cầu quá lớn (prompt + max_tokens) sẽ bị từ chối
// VĨNH VIỄN (chờ cũng vô ích). Vì vậy app có "ngân sách Bible cho API" riêng (mặc định vừa phải) và cách viết chương theo từng ý (mỗi yêu cầu nhỏ).
//
// Về kỹ thuật: Groq là endpoint OpenAI-compatible nên TÁI DÙNG nguyên OpenAICompatibleProvider (đã có xử lý 429/Retry-After, SSE, thích ứng tham số),
// chỉ khác: base URL cố định; KHÔNG gửi `top_k` (tài liệu tương thích OpenAI của Groq không liệt kê; tham số lạ có thể bị từ chối);
// và thang `reasoning_effort` ["none","low"] — Qwen3.x trên Groq có chế độ "none" (không suy luận, nhanh và tiết kiệm token ngày), còn gpt-oss chỉ nhận
// low/medium/high nên "none" sẽ bị từ chối => provider tự hạ xuống "low" (cơ chế thích ứng, KHÔNG so sánh tên model nào). Model không nhận tham số này
// thì sau 2 bậc bị bỏ hẳn. Kết quả học được lưu lại nên chỉ tốn thử-sai lần đầu.
// Mọi giả định về lỗi cụ thể của Groq (nội dung thông báo 400/429) CHƯA kiểm thử thật — xem mục CV tài liệu kiến trúc.
class GroqProvider implements AIProvider {
  static const baseUrl = 'https://api.groq.com/openai/v1';

  final String apiKey;
  final String modelId;
  final OpenAICompatibleProvider _delegate;

  GroqProvider({required this.apiKey, required this.modelId})
      : _delegate = OpenAICompatibleProvider(
          baseUrl: baseUrl,
          apiKey: apiKey,
          modelId: modelId,
          sendTopK: false,
          reasoningEffortLadder: const ['none', 'low'],
          label: 'Groq',
        );

  @override
  String get name => 'Groq';

  @override
  String get description =>
      'Groq (console.groq.com) — gói miễn phí không cần thẻ, tốc độ rất cao. Nhập đúng Model ID (vd "openai/gpt-oss-120b"); danh sách và hạn mức hiện hành xem tại console.groq.com/docs/rate-limits.';

  @override
  Future<bool> isReady() => _delegate.isReady();

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
  }) {
    return _delegate.generate(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
    );
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool reuseKv = false,
  }) {
    return _delegate.generateStream(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      reuseKv: reuseKv,
    );
  }
}

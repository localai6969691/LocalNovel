import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../ai_provider.dart';

// MỤC CR (2026-10-07) — API GOOGLE GEMINI GỌI THẲNG (không qua lớp "tương thích OpenAI").
//
// VÌ SAO KHÔNG DÙNG LẠI OpenAICompatibleProvider: Google có endpoint tương thích OpenAI, nhưng tài liệu của họ liệt kê tham số được hỗ trợ
// rất hẹp ("mọi tham số khác sẽ bị bỏ qua âm thầm") và KHÔNG có cách nào đặt `safetySettings` qua lớp đó. Viết truyện hư cấu (bạo lực,
// kinh dị, người lớn) dễ bị bộ lọc mặc định của model cũ chặn. API gốc `generateContent` cho đặt ngưỡng từng nhóm — provider này
// gửi BLOCK_NONE cho cả 4 nhóm chỉnh được.
// GIỚI HẠN THẬT (không giấu), theo tài liệu Google (ai.google.dev/gemini-api/docs/safety-settings):
//   - Các bảo vệ lõi (ví dụ nội dung gây hại cho trẻ em) LUÔN bị chặn và KHÔNG chỉnh được, bất kể ngưỡng.
//   - Với model Gemini 2.5 và 3, ngưỡng mặc định đã là Off; gửi BLOCK_NONE ở đây chỉ có ý nghĩa với model cũ hơn.
//   - Model có "thinking" tính token suy nghĩ vào maxOutputTokens: nếu app đặt maxTokens nhỏ, model có thể dùng hết ngân sách cho suy nghĩ
//     và trả về RỖNG (finishReason=MAX_TOKENS). Provider báo lỗi rõ chứ không trả chuỗi rỗng im lặng.
//   - Gói miễn phí có giới hạn tần suất/ngày do Google đặt và có thể dùng nội dung để cải thiện sản phẩm (xem điều khoản Google) —
//     app không kiểm soát được.
// CHƯA build/test thật (môi trường soạn không có Flutter/Dart SDK — xem quy tắc mục 0 của tài liệu kiến trúc). Xác thực bằng header
// `x-goog-api-key` (đúng như ví dụ REST trong tài liệu Google), KHÔNG nhét khoá vào URL để khỏi lọt vào log.
class GeminiProvider implements AIProvider {
  static const _base = 'https://generativelanguage.googleapis.com/v1beta';
  static const _requestTimeout = Duration(minutes: 10);
  static const _streamIdleTimeout = Duration(minutes: 2);

  final String apiKey;
  final String modelId; // ví dụ "gemini-2.5-flash" — người dùng tự nhập, KHÔNG hardcode (danh sách model Google đổi liên tục)

  GeminiProvider({required this.apiKey, required this.modelId});

  @override
  String get name => 'Google Gemini';

  @override
  String get description =>
      'Gọi thẳng API Gemini của Google (khoá lấy tại aistudio.google.com). Nhập đúng tên model, ví dụ "gemini-2.5-flash" — xem danh sách hiện hành tại ai.google.dev/gemini-api/docs/models.';

  @override
  Future<bool> isReady() async => apiKey.isNotEmpty && modelId.isNotEmpty;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'x-goog-api-key': apiKey,
      };

  String _modelPath() {
    final id = modelId.trim();
    return id.startsWith('models/') ? id : 'models/$id';
  }

  Map<String, dynamic> _body({
    required String systemPrompt,
    required String userPrompt,
    required double temperature,
    required int maxTokens,
    required double topP,
    required int topK,
  }) {
    final body = <String, dynamic>{
      'contents': [
        {
          'role': 'user',
          'parts': [
            {'text': userPrompt}
          ],
        }
      ],
      'generationConfig': {
        'temperature': temperature,
        'topP': topP,
        'topK': topK,
        'maxOutputTokens': maxTokens,
      },
      'safetySettings': [
        for (final c in const [
          'HARM_CATEGORY_HARASSMENT',
          'HARM_CATEGORY_HATE_SPEECH',
          'HARM_CATEGORY_SEXUALLY_EXPLICIT',
          'HARM_CATEGORY_DANGEROUS_CONTENT',
        ])
          {'category': c, 'threshold': 'BLOCK_NONE'}
      ],
    };
    if (systemPrompt.trim().isNotEmpty) {
      body['systemInstruction'] = {
        'parts': [
          {'text': systemPrompt}
        ]
      };
    }
    return body;
  }

  // Gom text của 1 phản hồi (hoặc 1 chunk stream). Bỏ qua phần "thought" nếu server có gửi.
  String _textOf(dynamic data) {
    final cands = data is Map ? data['candidates'] : null;
    if (cands is! List || cands.isEmpty) return '';
    final content = cands[0] is Map ? cands[0]['content'] : null;
    final parts = content is Map ? content['parts'] : null;
    if (parts is! List) return '';
    final sb = StringBuffer();
    for (final p in parts) {
      if (p is Map && p['thought'] != true && p['text'] is String) sb.write(p['text'] as String);
    }
    return sb.toString();
  }

  // Trả về mô tả lý do nếu phản hồi bị chặn/cắt, null nếu bình thường.
  String? _problemOf(dynamic data, {required bool hasText}) {
    if (data is! Map) return null;
    final pf = data['promptFeedback'];
    if (pf is Map && pf['blockReason'] != null) {
      return 'Gemini chặn yêu cầu (blockReason=${pf['blockReason']}). Bảo vệ lõi của Google không chỉnh được; thử diễn đạt lại hoặc đổi model.';
    }
    final cands = data['candidates'];
    if (cands is List && cands.isNotEmpty && cands[0] is Map) {
      final fr = cands[0]['finishReason'];
      if (!hasText && fr != null && fr != 'STOP') {
        if (fr == 'MAX_TOKENS') {
          return 'Gemini hết ngân sách token trước khi ra chữ nào (finishReason=MAX_TOKENS) — model có thể đã dùng hết cho phần suy nghĩ. Tăng "số token tối đa" hoặc dùng model không suy nghĩ.';
        }
        return 'Gemini dừng không ra chữ (finishReason=$fr).';
      }
    }
    return null;
  }

  Never _fail(http.Response res) {
    String msg = res.body;
    try {
      final d = jsonDecode(utf8.decode(res.bodyBytes));
      if (d is Map && d['error'] is Map && d['error']['message'] != null) msg = '${d['error']['message']}';
    } catch (_) {}
    throw Exception('Lỗi Gemini API (${res.statusCode}): $msg');
  }

  @override
  Future<String> generate({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 1024,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05, // Gemini không có tham số tương đương — bỏ qua
  }) async {
    final http.Response res;
    try {
      res = await http
          .post(
            Uri.parse('$_base/${_modelPath()}:generateContent'),
            headers: _headers,
            body: jsonEncode(_body(
              systemPrompt: systemPrompt,
              userPrompt: userPrompt,
              temperature: temperature,
              maxTokens: maxTokens,
              topP: topP,
              topK: topK,
            )),
          )
          .timeout(_requestTimeout);
    } on TimeoutException {
      throw Exception('Hết thời gian chờ (${_requestTimeout.inMinutes} phút) — Gemini không phản hồi.');
    }
    if (res.statusCode != 200) _fail(res);
    final data = jsonDecode(utf8.decode(res.bodyBytes));
    final text = _textOf(data);
    final problem = _problemOf(data, hasText: text.isNotEmpty);
    if (problem != null) throw Exception(problem);
    return text;
  }

  @override
  Stream<String> generateStream({
    required String systemPrompt,
    required String userPrompt,
    double temperature = 0.9,
    int maxTokens = 2048,
    double topP = 0.9,
    int topK = 40,
    double repetitionPenalty = 1.05,
    bool reuseKv = false, // không dùng — chỉ có ý nghĩa với LocalLlamaProvider
  }) async* {
    final req = http.Request('POST', Uri.parse('$_base/${_modelPath()}:streamGenerateContent?alt=sse'));
    req.headers.addAll(_headers);
    req.body = jsonEncode(_body(
      systemPrompt: systemPrompt,
      userPrompt: userPrompt,
      temperature: temperature,
      maxTokens: maxTokens,
      topP: topP,
      topK: topK,
    ));
    final http.StreamedResponse streamed;
    try {
      streamed = await req.send().timeout(_requestTimeout);
    } on TimeoutException {
      throw Exception('Hết thời gian chờ (${_requestTimeout.inMinutes} phút) — Gemini không phản hồi kết nối ban đầu.');
    }
    if (streamed.statusCode != 200) {
      _fail(await http.Response.fromStream(streamed));
    }
    final byteStream = streamed.stream.timeout(
      _streamIdleTimeout,
      onTimeout: (sink) => sink.addError(TimeoutException('Gemini ngừng phản hồi giữa chừng quá ${_streamIdleTimeout.inMinutes} phút.')),
    );
    var anyText = false;
    String? problem;
    var pending = '';
    await for (final chunk in byteStream.transform(utf8.decoder)) {
      // Một sự kiện SSE có thể bị cắt giữa 2 chunk mạng — ghép lại theo từng dòng hoàn chỉnh.
      pending += chunk;
      final lines = pending.split('\n');
      pending = lines.removeLast();
      for (final line in lines) {
        if (!line.startsWith('data:')) continue;
        final payload = line.substring(5).trim();
        if (payload.isEmpty) continue;
        try {
          final data = jsonDecode(payload);
          final t = _textOf(data);
          if (t.isNotEmpty) {
            anyText = true;
            yield t;
          }
          problem ??= _problemOf(data, hasText: anyText);
        } catch (_) {}
      }
    }
    if (!anyText && problem != null) throw Exception(problem);
  }
}

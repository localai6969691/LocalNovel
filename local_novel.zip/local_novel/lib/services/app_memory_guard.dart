import 'dart:async';
import 'package:flutter/widgets.dart';
import 'background_task_manager.dart';
import 'debug_log_service.dart';
import 'providers/local_provider.dart';

/// MỤC DG (2026-10-17) — trả RAM/bộ nhớ đệm khi app KHÔNG còn được dùng.
///
/// Bằng chứng (log 2026-10-16): (1) trong cả `lib/` KHÔNG có chỗ nào phản ứng với vòng đời app (không `didChangeAppLifecycleState`), nên
/// model 7B nằm trong RAM (VmRSS ≈4,2GB, tiến trình ở trạng thái CACHED) suốt thời gian người dùng rời app; (2) cache GPU chỉ được dọn lúc khởi
/// động hoặc khi người dùng chủ động "Huỷ & thoát", không dọn khi chỉ để app ở nền / vuốt tắt. App local phổ biến nhất (PocketPal) tự giải phóng
/// model khi xuống nền để tiết kiệm RAM — đây là cách làm tương tự.
///
/// Quy tắc: app ở nền (paused/detached) liên tục [idleAfterBackground] mà KHÔNG có tác vụ nền nào đang chạy/xếp hàng và native không báo slot nào
/// đang sinh ⇒ xả model khỏi RAM (native đặt cờ "cần nạp lại" nên lần dùng kế tiếp tự nạp lại, tốn ~25–50 s) rồi dọn cache GPU xuống hạn mức.
/// Có tác vụ đang chạy ⇒ KHÔNG xả, hẹn kiểm lại sau [recheckInterval] (lượt viết chương chạy nền khi tắt màn hình không bị ngắt).
class AppMemoryGuard with WidgetsBindingObserver {
  AppMemoryGuard._();
  static final AppMemoryGuard instance = AppMemoryGuard._();

  static const Duration idleAfterBackground = Duration(minutes: 3);
  static const Duration recheckInterval = Duration(minutes: 1);
  static const List<int> _slots = [0, 1];

  bool _installed = false;
  bool _inBackground = false;
  Timer? _timer;

  /// Gọi 1 lần sau khi binding đã khởi tạo (vd trong `initState` của màn hình gốc). Gọi lại là no-op.
  void install() {
    if (_installed) return;
    _installed = true;
    WidgetsBinding.instance.addObserver(this);
    unawaited(DebugLogService.instance.log(
      '[DG] AppMemoryGuard da gan: o nen ${idleAfterBackground.inSeconds}s lien tuc va khong co tac vu se xa model khoi RAM + don cache GPU',
    ));
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _inBackground = false;
      _timer?.cancel();
      _timer = null;
      return;
    }
    if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
      if (_inBackground) return;
      _inBackground = true;
      _schedule(idleAfterBackground);
    }
  }

  void _schedule(Duration after) {
    _timer?.cancel();
    _timer = Timer(after, () => unawaited(_releaseIfIdle()));
  }

  bool _hasPendingTasks() {
    for (final t in BackgroundTaskManager.instance.tasks) {
      if (t.status == TaskStatus.running || t.status == TaskStatus.queued) return true;
    }
    return false;
  }

  Future<void> _releaseIfIdle() async {
    if (!_inBackground) return; // người dùng đã quay lại app
    try {
      if (_hasPendingTasks()) {
        unawaited(DebugLogService.instance.log('[DG] o nen nhung con tac vu dang chay/xep hang — chua xa model, kiem lai sau ${recheckInterval.inSeconds}s'));
        _schedule(recheckInterval);
        return;
      }
      for (final slot in _slots) {
        if (await LocalLlamaProvider.isSlotGenerating(slot)) {
          unawaited(DebugLogService.instance.log('[DG] o nen: native bao slot=$slot dang sinh — chua xa model, kiem lai sau ${recheckInterval.inSeconds}s'));
          _schedule(recheckInterval);
          return;
        }
      }
      var released = 0;
      for (final slot in _slots) {
        if (await LocalLlamaProvider.unloadSlotIfIdle(slot)) released++;
      }
      await LocalLlamaProvider.cleanupCacheOnExit();
      unawaited(DebugLogService.instance.log(
        '[DG] app o nen >=${idleAfterBackground.inSeconds}s, khong co tac vu: da yeu cau xa $released slot khoi RAM + don cache GPU xuong han muc (xem [DG]/[CM] trong native_debug.txt de biet RAM that giam bao nhieu)',
      ));
    } catch (e) {
      unawaited(DebugLogService.instance.log('[DG] _releaseIfIdle LOI (bo qua, khong anh huong dung app): $e'));
    }
  }
}

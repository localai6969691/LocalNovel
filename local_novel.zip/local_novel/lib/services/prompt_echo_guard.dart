// MỤC CV3 (2026-10-15) — BỘ BẮT "MODEL CHÉP LẠI PROMPT THAY VÌ VIẾT TRUYỆN".
//
// Người dùng báo (2026-10-14 22:46): dùng model viết truyện thì "thay vì viết truyện lại xuất ra cả Bible" — trước đó lỗi là ký tự rác, nay thành chép/nhắc lại Bible khi
// viết chương. Cùng họ lỗi với mục BE (model nhỏ/lượng tử hoá nặng coi khối chỉ dẫn + Bible dài là thứ cần PHẢN HỒI/chép lại — Llama 8B và Hunyuan 1.8B đều bị).
//
// Lớp này KHÔNG đoán nguyên nhân gốc, chỉ NHẬN RA kết quả hỏng bằng các dấu hiệu TỔNG QUÁT (không theo tên model/nhà cung cấp):
//   1. Trùng khớp cụm 5 âm tiết liên tiếp ("shingle") giữa văn bản model trả về và các văn bản ĐÃ GỬI vào prompt (vai trò, Bible, kế hoạch, nhiệm vụ). Văn xuôi thật
//      gần như không chứa cả chục cụm nguyên văn từ prompt; văn bản chép lại thì trùng hàng loạt.
//   2. Mở đầu bằng đúng cụm chữ trong prompt (2/3 cụm 5-chữ đầu tiên đều có trong prompt) — dấu hiệu sớm, bắt được khi mới có vài chục ký tự để DỪNG SỚM (đỡ tốn
//      hàng phút sinh chữ trên local).
//   3. Có NHÃN của chính prompt ("STORY BIBLE", "KẾ HOẠCH CHƯƠNG", "[đã viết]"...) — truyện không bao giờ chứa các nhãn này.
//   4. Ít nhất 3 dòng có dạng hồ sơ nhân vật "Tên (vai trò): mô tả" — khuôn của khối Bible, kể cả khi model không chép nguyên văn.
// Hai nhóm có ngưỡng RỘNG hơn, tách riêng khỏi "tham khảo" (vai trò + Bible + lời dặn): (a) KẾ HOẠCH (các ý của dàn ý) — model viết truyện rất hay mở đầu bằng đúng câu của ý đang viết
// ("Lâm Phong gặp Tô Mai ở quán trà..."), thử trên bản Python thấy dấu hiệu "mở đầu bằng cụm chép nguyên văn" bắt nhầm truyện thật nếu gộp kế hoạch vào nhóm tham khảo — nên chỉ coi là chép
// khi chép ≥50% cả cụm; (b) đoạn vừa viết (tail) — model được dặn viết NỐI TIẾP nên chút trùng ở câu đầu là bình thường; chỉ chép lại phần lớn mới là hỏng.
//
// GIỚI HẠN THẬT (chưa kiểm trên máy): (a) chỉ bắt chép NGUYÊN VĂN hoặc gần nguyên văn hoặc theo khuôn hồ sơ — model diễn giải lại bằng lời khác/ngôn ngữ khác
// (như Hunyuan dịch prompt sang tiếng Hoa ở mục BE) thì chỉ có thể bị bắt nếu rơi vào dấu hiệu 3-4; (b) khi dịch thuật trung gian BẬT, văn bản nhận được đã qua dịch ngược
// nên độ trùng thấp hơn thực tế — bộ bắt kém nhạy hơn; (c) ngưỡng là con số chọn bằng suy luận, KHÔNG phải đo trên nhật ký thật.
class PromptEchoGuard {
  static const int _k = 5;
  static final RegExp _tokRe = RegExp(r'[\p{L}\p{N}]+', unicode: true);
  static final RegExp _profileLine = RegExp(r'^\s*(?:[-•*]\s*)?[^:\n(]{1,40}\([^)\n]{1,40}\)\s*:', multiLine: true);

  // Nhãn do CHÍNH prompt viết truyện đặt ra (xem ChapterWriterService) — phân biệt hoa/thường để không nhầm với truyện (vd bảng "Nhiệm vụ:" trong truyện game).
  static const List<String> _metaMarkers = [
    'KẾ HOẠCH CHƯƠNG',
    'ĐOẠN VỪA VIẾT',
    'ĐOẠN CUỐI CHƯƠNG',
    '<- ĐANG VIẾT',
    '[đã viết]',
    '[chưa tới',
    '<tham_khao>',
    '</tham_khao>',
  ];

  final Set<String> _reference = <String>{};
  final Set<String> _plan = <String>{};
  final Set<String> _tail = <String>{};

  // `reference`: các văn bản KHÔNG được chép lại (vai trò, Bible, lời dặn nhiệm vụ — có thể là cả prompt user; cụm nào nằm trong `plan` thì không tính vào nhóm này).
  // `plan`: các ý của dàn ý/định hướng (được phép trích câu đầu). `tail`: đoạn vừa viết (được phép trùng nhẹ).
  PromptEchoGuard({required Iterable<String> reference, Iterable<String> plan = const <String>[], String tail = ''}) {
    for (final s in reference) {
      _addShingles(_reference, _tokens(s));
    }
    for (final s in plan) {
      _addShingles(_plan, _tokens(s));
    }
    _addShingles(_tail, _tokens(tail));
  }

  static List<String> _tokens(String s) => [for (final m in _tokRe.allMatches(s.toLowerCase())) m.group(0)!];

  static void _addShingles(Set<String> into, List<String> t) {
    for (var i = 0; i + _k <= t.length; i++) {
      into.add(t.sublist(i, i + _k).join(' '));
    }
  }

  // Trả về lý do (tiếng Việt, để ghi log) nếu `text` trông như chép lại prompt; null nếu ổn. `partial` = đang stream dở (chưa xong) — ngưỡng khắt khe hơn.
  String? check(String text, {bool partial = false}) {
    final t = text.trim();
    if (t.length < 20) return null;
    for (final m in _metaMarkers) {
      if (t.contains(m)) return 'có nhãn của prompt "$m"';
    }
    if (t.toLowerCase().contains('story bible')) return 'có nhãn của prompt "Story Bible"';
    if (_profileLine.allMatches(t).length >= 3) return 'có ≥3 dòng dạng hồ sơ "Tên (vai trò): mô tả" như khối Bible';

    final toks = _tokens(t);
    if (toks.length < _k + 5) return null;
    final total = toks.length - _k + 1;
    var hitRef = 0;
    var startHit = 0;
    var hitPlan = 0;
    var hitTail = 0;
    for (var i = 0; i < total; i++) {
      final key = toks.sublist(i, i + _k).join(' ');
      final inPlan = _plan.contains(key);
      if (inPlan) hitPlan++;
      if (_reference.contains(key) && !inPlan) {
        hitRef++;
        if (i < 3) startHit++;
      }
      if (_tail.contains(key)) hitTail++;
    }
    if (startHit >= 2) return 'mở đầu bằng cụm chữ chép nguyên văn từ prompt';
    final ratioRef = hitRef / total;
    if (partial) {
      if (total >= 20 && ratioRef >= 0.40) return 'trùng ${(ratioRef * 100).round()}% cụm chữ với prompt (đang stream)';
    } else {
      if (total >= 15 && ratioRef >= 0.30) return 'trùng ${(ratioRef * 100).round()}% cụm chữ với prompt';
      if (hitRef >= 12 && ratioRef >= 0.20) return 'trùng $hitRef cụm chữ (${(ratioRef * 100).round()}%) với prompt';
    }
    final ratioPlan = hitPlan / total;
    if (!partial && hitPlan >= 12 && ratioPlan >= 0.50) return 'chép lại ${(ratioPlan * 100).round()}% kế hoạch/dàn ý thay vì triển khai thành truyện';
    final ratioTail = hitTail / total;
    if (hitTail >= 15 && ratioTail >= 0.50) return 'chép lại ${(ratioTail * 100).round()}% đoạn vừa viết thay vì viết tiếp';
    return null;
  }
}

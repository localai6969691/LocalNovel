import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;

// MỤC DM (2026-10-24) — NGUỒN GỐC (provenance) của runtime MNN và của model, để biết chúng có lệch nhau không mà KHÔNG phải đoán qua nhãn phiên bản.
//
// Vì sao cần: nhãn "3.6.1" trong llm.mnn và MNN::getVersion() chỉ là chuỗi trong header; nhánh master vẫn mang nhãn đó sau khi tag 3.6.1 đã phát hành,
// nên nhãn KHÔNG phân biệt được "đúng tag" với "master mới hơn". Chuỗi mục BI → CE → DB → DH mất nhiều vòng vì app không biết commit MNN nào nằm trong nó.
//
// Hai nguồn, đều do CÔNG CỤ TẠO RA ghi lại (không ai gõ tay):
//   • runtime: CI ghi `assets/mnn_runtime.json` (commit/tag/version thật của cây MNN vừa build) vào APK;
//   • model:   notebook convert ghi `localnovel_export_info.json` (commit MNN thật dùng để xuất) cạnh model.
// Model cũ chưa có file này vẫn dùng được: chỉ có nhãn phiên bản đọc từ đuôi llm.mnn, và log nói rõ nhãn đó không đủ để kết luận.
//
// Chỉ dùng để GHI LOG chẩn đoán khi nạp model thất bại; không bao giờ ném lỗi, không đổi hành vi nạp.
class MnnProvenanceService {
  MnnProvenanceService._();

  static const String _runtimeAsset = 'assets/mnn_runtime.json';
  static const String _modelInfoName = 'localnovel_export_info.json';

  static Future<Map<String, dynamic>?> _readRuntime() async {
    try {
      final obj = jsonDecode(await rootBundle.loadString(_runtimeAsset));
      if (obj is Map<String, dynamic>) return obj;
    } catch (_) {}
    return null;
  }

  static Future<Map<String, dynamic>?> _readModelInfo(String modelDir) async {
    try {
      final f = File('$modelDir/$_modelInfoName');
      if (await f.exists()) {
        final obj = jsonDecode(await f.readAsString());
        if (obj is Map<String, dynamic>) return obj;
      }
    } catch (_) {}
    return null;
  }

  /// Nhãn "x.y.z" công cụ xuất ghi gần cuối llm.mnn (chuỗi FlatBuffers; mục CE đọc được "3.6.1" ở 32 byte cuối).
  static String? versionLabelFromTail(List<int> bytes) {
    final text = String.fromCharCodes(bytes.map((b) => (b >= 0x20 && b < 0x7f) ? b : 0x20));
    final all = RegExp(r'(?<![\d.])(\d+\.\d+\.\d+)(?![\d.])').allMatches(text).toList();
    return all.isEmpty ? null : all.last.group(1);
  }

  static Future<String?> _readVersionLabel(String modelDir) async {
    try {
      final f = File('$modelDir/llm.mnn');
      final len = await f.length();
      final raf = await f.open();
      try {
        final start = len > 128 ? len - 128 : 0;
        await raf.setPosition(start);
        final bytes = await raf.read(len - start);
        return versionLabelFromTail(bytes);
      } finally {
        await raf.close();
      }
    } catch (_) {}
    return null;
  }

  /// Kết luận bằng chữ từ dữ liệu đã đọc. Tách riêng để kiểm thử được mà không cần thiết bị.
  static String compare({Map<String, dynamic>? runtime, Map<String, dynamic>? model, String? versionLabel}) {
    final rc = (runtime?['commit'] is String) ? runtime!['commit'] as String : '';
    final mc = (model?['mnn_commit'] is String) ? model!['mnn_commit'] as String : '';
    final rt = runtime == null
        ? 'runtime: KHÔNG đọc được assets/mnn_runtime.json'
        : 'runtime: yêu_cầu=${runtime['requested_ref']} commit=${rc.isEmpty ? '(trống)' : rc} tag=${runtime['exact_tag']} version_header=${runtime['version_header']} nguồn=${runtime['source']}';
    final md = model == null
        ? 'model: không có $_modelInfoName (xuất bằng notebook cũ), nhãn trong llm.mnn=${versionLabel ?? 'không đọc được'}'
        : 'model: yêu_cầu=${model['mnn_requested_ref']} commit=${mc.isEmpty ? '(trống)' : mc} version_header=${model['mnn_version_header']}';
    String verdict;
    if (rc.isEmpty) {
      verdict = 'KHÔNG kết luận được: APK không mang commit của runtime (assets/mnn_runtime.json là bản mẫu — build ngoài CI?).';
    } else if (mc.isEmpty) {
      verdict = 'KHÔNG kết luận được về model: chưa biết commit xuất. Nhãn phiên bản không phân biệt tag với master. '
          'Cách chắc chắn: xuất lại model bằng notebook với mnn_git_ref = commit của runtime ($rc).';
    } else if (rc == mc) {
      verdict = 'KHỚP commit: công cụ xuất và runtime cùng một mã nguồn — nguyên nhân KHÔNG phải lệch phiên bản MNN.';
    } else {
      verdict = 'LỆCH commit: model xuất bằng $mc, runtime build từ $rc. Runtime phải CÙNG HOẶC MỚI HƠN công cụ xuất; '
          'app không tự biết thứ tự — xuất lại model bằng commit của runtime là cách chắc chắn.';
    }
    return '$rt | $md | $verdict';
  }

  /// Chuỗi mô tả để ghi log. Không bao giờ ném lỗi.
  static Future<String> describe(String modelDir) async {
    try {
      final runtime = await _readRuntime();
      final model = await _readModelInfo(modelDir);
      final label = model == null ? await _readVersionLabel(modelDir) : null;
      return compare(runtime: runtime, model: model, versionLabel: label);
    } catch (e) {
      return 'MnnProvenanceService.describe LỖI (bỏ qua): $e';
    }
  }
}

import 'dart:convert';
import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'debug_log_service.dart';

/// MỤC DJ (2026-10-18) — HỒ SƠ LẤY MẪU THEO MODEL (dữ liệu, không gõ cứng).
///
/// Vì sao: log + mã MNN thật cho thấy (mục DI) sampler chỉ đọc cấu hình lúc nạp và đang chạy bằng bộ mặc định CHUNG của `llmexport`
/// (temperature 0.8, top_k 40, top_p 0.9, min_p 0.05, typical 0.95 — cùng bộ số mặc định chung của Ollama) chứ không phải khuyến nghị của từng
/// model. Ngành làm thế nào: tác giả model công bố thông số trong model card và `generation_config.json`; Ollama giữ chúng trong Modelfile của từng
/// model; Qwen3 còn khuyến nghị riêng presence_penalty 1.5 cho model lượng tử hoá để chặn lặp.
///
/// TỰ ĐỘNG NHẬN DẠNG MODEL rồi cấu hình (mục DK): đọc tín hiệu từ chính thư mục model — tên thư mục (và tên nguồn trong `export_args.json`),
/// `model_type` + chat template trong `llm_config.json` — đối chiếu với bảng họ model `assets/sampling_presets.json` (mỗi họ có nguồn dẫn chính thức).
/// KHÔNG chỉ dựa model_type (bài học mục AP/BD: "llama" dùng chung nhiều họ). Độ tin cậy `exact` (tên khớp) hoặc `family` (bản tinh chỉnh/gộp của đúng
/// họ, chỉ khi họ cho phép); không khớp ⇒ KHÔNG áp số tự nghĩ.
///
/// Thứ tự áp (sau ghi đè trước): họ nhận dạng ← `generation_config.json` (model tự mô tả) ← `localnovel_sampling.json` (người dùng, trong thư mục model);
/// khoá còn thiếu được điền từ `_defaults` của bảng. Kết quả ghi vào `<filesDir>/sampling_profiles/<tên thư mục model>.json`; tầng C++ chỉ đọc file đó
/// và nạp qua set_config TRƯỚC load(). Không có nguồn nào ⇒ xoá file ⇒ giữ nguyên `config.json` mặc định của model.
class SamplingProfileService {
  SamplingProfileService._();

  static const String _presetsAsset = 'assets/sampling_presets.json';
  static Map<String, dynamic>? _presetsCache;

  // Khoá MNN được phép đi qua (khoá lạ bị loại, tránh gõ nhầm làm hỏng cấu hình) và miền giá trị hợp lệ.
  static const Map<String, List<num>> _numericKeys = {
    'temperature': [0.01, 5.0],
    'top_p': [0.01, 1.0],
    'min_p': [0.0, 1.0],
    'tfs_z': [0.0, 1.0],
    'typical': [0.0, 1.0],
    'repetition_penalty': [0.5, 5.0],
    'presence_penalty': [0.0, 5.0],
    'frequency_penalty': [0.0, 5.0],
    'ngram_factor': [1.0, 5.0],
    'max_penalty': [1.0, 100.0],
    'dry_multiplier': [0.0, 10.0],
    'dry_base': [1.0, 5.0],
    'xtc_probability': [0.0, 1.0],
    'xtc_threshold': [0.0, 0.5],
  };
  static const Map<String, List<num>> _intKeys = {
    'top_k': [0, 1000],
    'penalty_window': [0, 100000],
    'n_gram': [1, 64],
    'dry_allowed_length': [1, 64],
    'dry_penalty_last_n': [-1, 100000],
  };
  static const Set<String> _samplerNames = {
    'penalty', 'dry', 'topK', 'tfs', 'typical', 'topP', 'min_p', 'minP', 'xtc', 'temperature', 'greedy',
  };

  /// Tên file hồ sơ — PHẢI khớp `sanitizeModelFolderName` của mnn_bridge.cpp: lấy tên thư mục cuối, giữ [A-Za-z0-9._-], mọi BYTE UTF-8
  /// khác thành '_' (ký tự nhiều byte ⇒ nhiều dấu '_').
  static String sanitizeFolderName(String rawModelPath) {
    var p = rawModelPath;
    while (p.isNotEmpty && p.endsWith('/')) {
      p = p.substring(0, p.length - 1);
    }
    final slash = p.lastIndexOf('/');
    final folder = slash < 0 ? p : p.substring(slash + 1);
    final out = StringBuffer();
    for (final b in utf8.encode(folder)) {
      final isAlnum = (b >= 48 && b <= 57) || (b >= 65 && b <= 90) || (b >= 97 && b <= 122);
      if (isAlnum || b == 46 || b == 95 || b == 45) {
        out.writeCharCode(b);
      } else {
        out.write('_');
      }
    }
    final safe = out.toString();
    return safe.isEmpty ? 'unknown_model' : safe;
  }

  /// Dựng và ghi hồ sơ cho model ở [modelPath]. [applyAppOverride]=true CHỈ cho model chính (slot 0) — mục DL. Trả mô tả nguồn đã dùng (để log). KHÔNG BAO GIỜ ném lỗi ra ngoài.
  static Future<String> prepareFor(String modelPath, {bool applyAppOverride = false}) async {
    try {
      final folder = sanitizeFolderName(modelPath);
      final dir = Directory('${(await getApplicationSupportDirectory()).path}/sampling_profiles');
      await dir.create(recursive: true);
      final target = File('${dir.path}/$folder.json');

      final profile = <String, dynamic>{};
      final sources = <String>[];

      // A) tự nhận dạng họ model từ tín hiệu trong thư mục model
      final sig = await _readSignals(modelPath, folder);
      final hit = await _detectFamily(sig);
      await DebugLogService.instance.log(
        '[DJ] nhan dang model "$folder": ten=${sig.names} model_type=${sig.modelType ?? "?"} chat_template=${sig.template.isEmpty ? "khong co" : "${sig.template.length} ky tu"} => '
        '${hit == null ? "KHONG khop ho nao trong bang (khong ap so tu nghi)" : "ho ${hit.id} do tin cay ${hit.confidence} (${hit.reason})"}',
      );
      if (hit != null) {
        profile.addAll(hit.params);
        sources.add('ho:${hit.id}(${hit.confidence})');
      }

      // B) generation_config.json của chính model (model tự mô tả) ghi đè cùng khoá
      final gen = await _readJsonObject('$modelPath/generation_config.json');
      if (gen != null) {
        final mapped = _fromGenerationConfig(gen);
        if (mapped.isNotEmpty) {
          profile.addAll(mapped);
          sources.add('generation_config.json');
        }
      }

      // điền khoá còn thiếu từ _defaults của bảng (chỉ khi đã có nguồn)
      if (profile.isNotEmpty) await _fillDefaults(profile);

      // C) ghi đè của người dùng
      final user = await _readJsonObject('$modelPath/localnovel_sampling.json');
      if (user != null) {
        final cleaned = _sanitizeUserKeys(user);
        if (cleaned.isNotEmpty) {
          profile.addAll(cleaned);
          sources.add('localnovel_sampling.json');
        }
      }

      // D) MỤC DL (2026-10-23): ghi đè đặt TRONG APP (màn "Tham số sinh văn bản") — chỉ khi người dùng BẬT (mặc định tắt); ghi đè cuối cùng.
      // CHỈ áp cho model CHÍNH (slot 0 — [applyAppOverride]); model dịch thuật/tài liệu ở slot 1 dùng cấu hình riêng, ưu tiên chính xác hơn sáng tạo.
      if (applyAppOverride) {
        final ov = await loadAppOverride();
        if (ov.enabled && ov.params.isNotEmpty) {
          final cleaned = _sanitizeUserKeys(ov.params);
          if (cleaned.isNotEmpty) {
            profile.addAll(cleaned);
            sources.add('ghi_de_trong_app');
          }
        }
      }
      // Tham số bật mà danh sách mixed_samplers thiếu bước tương ứng thì MNN BỎ QUA êm (bài học mục AL) — bổ sung bước còn thiếu và ghi log.
      final addedSamplers = _ensureNeededSamplers(profile);
      if (addedSamplers.isNotEmpty) {
        await DebugLogService.instance.log(
          '[DL] mixed_samplers THIEU buoc cho tham so dang bat — da them $addedSamplers (neu khong MNN bo qua tham so am tham): ${jsonEncode(profile['mixed_samplers'])}',
        );
      }

      if (profile.isEmpty) {
        if (await target.exists()) await target.delete();
        await DebugLogService.instance.log(
          '[DJ] SamplingProfileService: model "$folder" KHONG co nguon (ho nhan dang / generation_config.json / localnovel_sampling.json) — dung config.json mac dinh cua model (bo mac dinh CHUNG cua llmexport, khong phai khuyen nghi cua model)',
        );
        return 'khong-co-nguon';
      }
      await target.writeAsString(jsonEncode(profile), flush: true);
      final desc = sources.join(' + ');
      await DebugLogService.instance.log('[DJ] SamplingProfileService: model "$folder" nguon=$desc => ${jsonEncode(profile)}');
      return desc;
    } catch (e) {
      await DebugLogService.instance.log('[DJ] SamplingProfileService.prepareFor LOI (bo qua, khong anh huong nap model): $e');
      return 'loi';
    }
  }

  // ---------------------------------------------------------------------------------------------------------------------------------------
  // MỤC DL BEGIN (2026-10-23) — GHI ĐÈ LẤY MẪU TRONG APP. Mục DJ §5 ghi "thanh trượt không tới được sampler; cần giao diện + quyết định mặc định hay ghi đè".
  // Quyết định: GHI ĐÈ, MẶC ĐỊNH TẮT ⇒ hành vi hiện tại không đổi (không chọn số mặc định nào thay người dùng). Bật thì các khoá người dùng ghi thay khoá cùng tên của
  // hồ sơ (họ model / generation_config.json / localnovel_sampling.json) và đi qua ĐÚNG đường đã có: file hồ sơ → set_config TRƯỚC load() (không đụng set_config lúc
  // sinh — bài học mục AM). Có hiệu lực khi model nạp lại; màn cài đặt xả model đang rảnh sau khi lưu để lần dùng tới nạp lại.
  static const String _overridePrefsKey = 'sampling_app_override_v1';

  /// Liệt kê khoá hợp lệ, dựng từ chính các bảng miền giá trị phía trên (không gõ riêng nên không thể lệch).
  static String get validKeysHelp {
    final nums = _numericKeys.entries.map((e) => '${e.key} (${e.value[0]}–${e.value[1]})');
    final ints = _intKeys.entries.map((e) => '${e.key} (${e.value[0]}–${e.value[1]})');
    return [...nums, ...ints, 'mixed_samplers (${_samplerNames.join(", ")})'].join(', ');
  }

  /// Ghi đè đã lưu: `enabled` + `params` (đã lọc khoá/miền lúc lưu). Chưa từng lưu / lỗi đọc ⇒ tắt.
  static Future<({bool enabled, Map<String, dynamic> params})> loadAppOverride() async {
    try {
      final sp = await SharedPreferences.getInstance();
      final raw = sp.getString(_overridePrefsKey);
      if (raw != null && raw.isNotEmpty) {
        final obj = jsonDecode(raw);
        if (obj is Map<String, dynamic>) {
          final p = obj['params'];
          return (enabled: obj['enabled'] == true, params: p is Map<String, dynamic> ? p : <String, dynamic>{});
        }
      }
    } catch (e) {
      await DebugLogService.instance.log('[DL] loadAppOverride LOI (coi nhu tat): $e');
    }
    return (enabled: false, params: <String, dynamic>{});
  }

  /// Kiểm tra JSON, lọc khoá lạ/ngoài miền (nêu rõ trong message), lưu. `changed` = hiệu lực THẬT có đổi không (tắt→tắt hoặc nội dung giống ⇒ false,
  /// để khỏi xả model vô ích). JSON hỏng ⇒ ok=false và KHÔNG ghi gì.
  static Future<({bool ok, bool changed, String message})> saveAppOverride({required bool enabled, required String jsonText}) async {
    final text = jsonText.trim();
    var cleaned = <String, dynamic>{};
    final dropped = <String>[];
    if (text.isNotEmpty) {
      dynamic obj;
      try {
        obj = jsonDecode(text);
      } catch (e) {
        return (ok: false, changed: false, message: 'JSON không hợp lệ: $e');
      }
      if (obj is! Map<String, dynamic>) {
        return (ok: false, changed: false, message: 'Phải là một đối tượng JSON dạng {"khoá": giá trị, ...}');
      }
      cleaned = _sanitizeUserKeys(obj);
      for (final k in obj.keys) {
        if (!cleaned.containsKey(k)) dropped.add(k);
      }
    }
    final before = await loadAppOverride();
    final effBefore = (before.enabled && before.params.isNotEmpty) ? jsonEncode(before.params) : '';
    final effAfter = (enabled && cleaned.isNotEmpty) ? jsonEncode(cleaned) : '';
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString(_overridePrefsKey, jsonEncode({'enabled': enabled, 'params': cleaned}));
    } catch (e) {
      return (ok: false, changed: false, message: 'Không lưu được: $e');
    }
    final changed = effBefore != effAfter;
    await DebugLogService.instance.log(
      '[DL] ghi de lay mau trong app: enabled=$enabled params=${jsonEncode(cleaned)} khoa_bi_bo=$dropped doi_hieu_luc_that=$changed',
    );
    return (ok: true, changed: changed, message: dropped.isEmpty ? '' : 'Đã bỏ khoá lạ/ngoài miền: ${dropped.join(", ")}');
  }

  /// Bảo đảm `mixed_samplers` có đủ bước cho tham số đang bật: penalty (khi repetition>1 hoặc presence/frequency>0), dry (dry_multiplier>0), xtc (xtc_probability>0).
  /// Thiếu bước ⇒ MNN bỏ qua tham số mà KHÔNG báo lỗi (mục AL). Chỉ chỉnh khi hồ sơ CÓ khai báo `mixed_samplers` (không khai báo ⇒ tầng C++ dùng danh sách dự phòng đã có
  /// penalty/dry/xtc). Vị trí theo mục DI: penalty đầu, dry ngay sau penalty, xtc ngay trước temperature. Trả tên các bước đã thêm.
  static List<String> _ensureNeededSamplers(Map<String, dynamic> profile) {
    final ms = profile['mixed_samplers'];
    if (ms is! List) return <String>[];
    final list = ms.whereType<String>().toList();
    double n(String k) {
      final v = profile[k];
      return v is num ? v.toDouble() : 0.0;
    }

    final added = <String>[];
    if ((n('repetition_penalty') > 1.0 || n('presence_penalty') > 0 || n('frequency_penalty') > 0) && !list.contains('penalty')) {
      list.insert(0, 'penalty');
      added.add('penalty');
    }
    if (n('dry_multiplier') > 0 && !list.contains('dry')) {
      final at = list.indexOf('penalty');
      list.insert(at < 0 ? 0 : at + 1, 'dry');
      added.add('dry');
    }
    if (n('xtc_probability') > 0 && !list.contains('xtc')) {
      final at = list.indexOf('temperature');
      if (at < 0) {
        list.add('xtc');
      } else {
        list.insert(at, 'xtc');
      }
      added.add('xtc');
    }
    if (added.isNotEmpty) profile['mixed_samplers'] = list;
    return added;
  }
  // MỤC DL END
  // ---------------------------------------------------------------------------------------------------------------------------------------

  static Future<_Signals> _readSignals(String modelPath, String folder) async {
    final names = <String>[folder];
    final ea = await _readJsonObject('$modelPath/export_args.json');
    if (ea != null) {
      for (final k in const ['path', 'model_path', 'src_path', 'name']) {
        final v = ea[k];
        if (v is String && v.isNotEmpty) {
          var s = v;
          while (s.endsWith('/')) {
            s = s.substring(0, s.length - 1);
          }
          final base = s.substring(s.lastIndexOf('/') + 1);
          if (base.isNotEmpty && !names.contains(base)) names.add(base);
        }
      }
    }
    String? modelType;
    var template = '';
    final lc = await _readJsonObject('$modelPath/llm_config.json');
    if (lc != null) {
      final mt = lc['model_type'];
      if (mt is String && mt.isNotEmpty) modelType = mt.toLowerCase();
      final pt = lc['prompt_template'];
      if (pt is String) template += pt;
      final j = lc['jinja'];
      if (j is Map && j['chat_template'] is String) template += j['chat_template'] as String;
    }
    return _Signals(names, modelType, template);
  }

  static RegExp? _rx(dynamic pattern) {
    if (pattern is! String || pattern.isEmpty) return null;
    try {
      return RegExp(pattern, caseSensitive: false);
    } catch (_) {
      return null;
    }
  }

  static List<String> _strList(dynamic v) => v is List ? v.whereType<String>().toList() : <String>[];

  /// Nhận dạng họ: lượt 1 tìm khớp `exact` (tên khớp, model_type không mâu thuẫn); lượt 2 tìm khớp `family` (chỉ họ cho phép).
  static Future<_FamilyHit?> _detectFamily(_Signals sig) async {
    final p = await _loadPresets();
    final list = p?['presets'];
    if (list is! List) return null;
    _FamilyHit? familyHit;
    for (final item in list) {
      if (item is! Map) continue;
      final det = item['detect'];
      if (det is! Map) continue;
      final nameRx = _rx(det['name']);
      final exRx = _rx(det['exclude']);
      final types = _strList(det['model_types']).map((e) => e.toLowerCase()).toList();
      final markers = _strList(det['template_markers']);
      if (exRx != null && sig.names.any(exRx.hasMatch)) continue;
      final nameHit = nameRx != null && sig.names.any(nameRx.hasMatch);
      // typeHit: null = không có/không biết để so; true/false = đã biết model_type
      final bool? typeHit = (types.isEmpty || sig.modelType == null) ? null : types.contains(sig.modelType);
      final id = item['id']?.toString() ?? 'khong-ten';
      if (nameHit) {
        if (typeHit == false) {
          await DebugLogService.instance.log('[DJ] ho $id: TEN khop nhung model_type="${sig.modelType}" khong nam trong $types — bo qua ho nay (tranh ap nham)');
          continue;
        }
        final params = _paramsOf(item);
        if (params.isEmpty) continue;
        return _FamilyHit(id, 'exact', params, 'ten khop${typeHit == true ? " + model_type khop" : ""}');
      }
      final allow = item['allow_family_match'] == true;
      if (allow && familyHit == null && typeHit == true && (markers.isEmpty || markers.any(sig.template.contains))) {
        final params = _paramsOf(item);
        if (params.isNotEmpty) {
          familyHit = _FamilyHit(id, 'family', params, 'model_type khop${markers.isEmpty ? "" : " + chat template khop"}, ten khong khop (ban tinh chinh/gop cua ho nay)');
        }
      }
    }
    return familyHit;
  }

  static Map<String, dynamic> _paramsOf(Map item) {
    final params = <String, dynamic>{};
    final mode = item['default_mode'];
    final modes = item['modes'];
    if (mode is String && modes is Map && modes[mode] is Map) {
      (modes[mode] as Map).forEach((k, v) {
        if (k is String && v is num) {
          final ok = _validate(k, v);
          if (ok != null) params[k] = ok;
        }
      });
    }
    final extras = item['extras_for_quantized']; // mọi model MNN của app đều là lượng tử hoá
    if (extras is Map) {
      extras.forEach((k, v) {
        if (k is String && v is num) {
          final ok = _validate(k, v);
          if (ok != null) params[k] = ok;
        }
      });
    }
    return params;
  }

  static Future<void> _fillDefaults(Map<String, dynamic> profile) async {
    final p = await _loadPresets();
    final d = p?['_defaults'];
    if (d is! Map) return;
    final params = d['params'];
    if (params is Map) {
      params.forEach((k, v) {
        if (k is String && v is num) {
          final ok = _validate(k, v);
          if (ok != null) profile.putIfAbsent(k, () => ok);
        }
      });
    }
    final ms = d['mixed_samplers'];
    if (ms is List) {
      final l = ms.whereType<String>().toList();
      if (l.isNotEmpty && l.every(_samplerNames.contains)) profile.putIfAbsent('mixed_samplers', () => l);
    }
  }

  static Future<Map<String, dynamic>?> _readJsonObject(String path) async {
    try {
      final f = File(path);
      if (!await f.exists()) return null;
      final len = await f.length();
      if (len > 262144) return null; // 256KB là quá lớn cho file cấu hình
      final obj = jsonDecode(await f.readAsString());
      return obj is Map<String, dynamic> ? obj : null;
    } catch (e) {
      await DebugLogService.instance.log('[DJ] khong doc duoc $path: $e');
      return null;
    }
  }

  // HF generation_config.json -> khoá MNN. do_sample=false/greedy KHÔNG được ánh xạ (Qwen3 cảnh báo greedy gây lặp vô tận).
  static Map<String, dynamic> _fromGenerationConfig(Map<String, dynamic> g) {
    final out = <String, dynamic>{};
    void put(String hfKey, String mnnKey) {
      final v = g[hfKey];
      if (v is num) {
        final ok = _validate(mnnKey, v);
        if (ok != null) out[mnnKey] = ok;
      }
    }

    put('temperature', 'temperature');
    put('top_k', 'top_k');
    put('top_p', 'top_p');
    put('min_p', 'min_p');
    put('repetition_penalty', 'repetition_penalty');
    return out;
  }

  static num? _validate(String key, num v) {
    final r = _numericKeys[key];
    if (r != null) return (v >= r[0] && v <= r[1]) ? v.toDouble() : null;
    final ri = _intKeys[key];
    if (ri != null) return (v >= ri[0] && v <= ri[1]) ? v.toInt() : null;
    return null;
  }

  static Map<String, dynamic> _sanitizeUserKeys(Map<String, dynamic> user) {
    final out = <String, dynamic>{};
    user.forEach((k, v) {
      if (k == 'mixed_samplers') {
        if (v is List && v.every((e) => e is String && _samplerNames.contains(e)) && v.isNotEmpty) {
          out[k] = v.cast<String>().toList();
        }
      } else if (k == 'dry_sequence_breakers') {
        if (v is List && v.every((e) => e is int)) out[k] = v;
      } else if (v is num) {
        final ok = _validate(k, v);
        if (ok != null) out[k] = ok;
      }
    });
    return out;
  }

  static Future<Map<String, dynamic>?> _loadPresets() async {
    if (_presetsCache != null) return _presetsCache;
    try {
      final obj = jsonDecode(await rootBundle.loadString(_presetsAsset));
      if (obj is Map<String, dynamic>) _presetsCache = obj;
    } catch (e) {
      await DebugLogService.instance.log('[DJ] khong doc duoc $_presetsAsset: $e');
    }
    return _presetsCache;
  }
}

class _Signals {
  final List<String> names;
  final String? modelType;
  final String template;
  const _Signals(this.names, this.modelType, this.template);
}

class _FamilyHit {
  final String id;
  final String confidence; // 'exact' | 'family'
  final Map<String, dynamic> params;
  final String reason;
  const _FamilyHit(this.id, this.confidence, this.params, this.reason);
}

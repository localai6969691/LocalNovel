import 'dart:math' as math;

// MỤC CV3 (2026-10-15) — TỰ HẠ NGÂN SÁCH PROMPT THEO TỐC ĐỘ NẠP PROMPT (prefill) CỦA MODEL LOCAL.
//
// Vấn đề (mục CV2 §5, đo cũ trên CPU: prefill ~7-12 token/giây): mỗi lượt viết nạp lại cả prompt (vai trò + văn phong + Bible + kế hoạch + đoạn vừa viết), prompt ~2400 token
// = vài phút CHỈ ĐỂ NẠP trước khi ra chữ đầu tiên — và chia lượt nhân số lần nạp đó. Ngân sách Bible/đoạn vừa viết trước giờ là số cố định, không quan tâm máy/backend nhanh hay chậm.
//
// CÁCH ĐO (chỉ Dart, KHÔNG đụng C++/Kotlin): `LocalLlamaProvider` bấm giờ từ lúc gửi lệnh generate xuống native tới TOKEN ĐẦU TIÊN về tới Dart (≈ thời gian nạp prompt + 1 bước sinh +
// độ trễ kênh) và ghi lại độ dài prompt thật đã gửi (ký tự). Tốc độ = ký tự/giây — đúng đơn vị ngân sách đang dùng (ký tự), nên KHÔNG cần biết bộ tách token hay số token thật của model.
// Lưu theo khoá `loại|nhà cung cấp|model|backend` (cùng model chạy CPU và GPU có tốc độ khác nhau), làm mượt bằng trung bình trượt; phản ứng nhanh hơn khi chậm đi (máy nóng, throttling).
// ÁP DỤNG: trần độ dài prompt = tốc độ × số giây tối đa cho phép (Cài đặt sinh văn bản, mặc định `kDefaultTargetSec`, 0 = tắt). Vượt trần thì hạ trước hết đoạn vừa viết rồi Bible,
// nhưng có SÀN (Bible ≥ 500 ký tự, đoạn vừa viết ≥ 300) để không bỏ mất luật thế giới/mạch văn — chạm sàn thì prompt vẫn vượt trần (có ghi log).
//
// GIỚI HẠN THẬT: (a) số đo là "thời gian tới token đầu", không phải thời gian nạp thuần như dòng `[CU-SPEED2]` của native — lượt ĐẦU sau khi nạp model có thể bị đo chậm hơn thực tế
// (khởi động/cấp phát), nên chỉ nhận mẫu khi prompt ≥ 800 ký tự và thời gian ≥ 800 ms, và mẫu quá chậm chỉ kéo trung bình từng phần; (b) chưa có số đo thì chưa hạ gì (lượt ĐẦU TIÊN
// của model/backend mới chạy với ngân sách đầy đủ, từ lượt sau mới áp dụng); (c) nạp prompt không tuyến tính tuyệt đối theo độ dài (chú ý dài hơn tốn hơn) nên trần chỉ là ước lượng;
// (d) mất chất lượng Bible là cái giá phải trả — hạ trần giây trong Cài đặt nếu muốn Bible đầy đủ hơn.
class PrefillBudget {
  // Mặc định 4 phút nạp prompt tối đa mỗi lượt (con số chọn theo đo cũ ~7-12 token/giây trên CPU, KHÔNG phải số đã thử trên máy). 0 = tắt tự hạ ngân sách.
  static const int kDefaultTargetSec = 240;
  static const int kMinBibleChars = 500;
  static const int kMinTailChars = 300;

  // Khoá lưu tốc độ: `modelKey` = 'loại|nhà cung cấp|model' (cùng khoá với hệ số token/chữ), thêm backend đang chạy ('cpu', 'opencl', 'vulkan', 'qnn'...). Backend null (model chưa nạp
  // nên chưa biết) => khoá '*' = mẫu gần nhất của model đó bất kể backend; mỗi mẫu đo được ghi vào CẢ khoá có backend lẫn khoá '*'.
  static String speedKey(String modelKey, String? backend) => '$modelKey|${(backend == null || backend.isEmpty) ? '*' : backend}';

  // Mẫu hợp lệ: prompt đủ dài và thời gian đủ lớn để không bị trội bởi độ trễ cố định.
  static bool plausibleSample(int promptChars, int firstTokenMs) => promptChars >= 800 && firstTokenMs >= 800;

  // Trộn mẫu mới vào trung bình: chậm đi => nghe theo nhanh (0,6), nhanh lên => nghe chậm (0,3). Kẹp [2, 5000] ký tự/giây.
  static double blend(double? old, double observed) {
    final obs = observed.clamp(2.0, 5000.0).toDouble();
    if (old == null || old <= 0) return obs;
    final w = obs < old ? 0.6 : 0.3;
    return (old * (1 - w) + obs * w).clamp(2.0, 5000.0).toDouble();
  }

  // Trần độ dài prompt (ký tự). null = không giới hạn (chưa có số đo hoặc người dùng tắt). Sàn 1500 để prompt luôn chứa được khung + chút Bible.
  static int? maxPromptChars(double? charsPerSec, int targetSec) {
    if (charsPerSec == null || targetSec <= 0) return null;
    return math.max(1500, (charsPerSec * targetSec).round());
  }

  // Chia chỗ cho đoạn vừa viết và Bible. `skeleton` = độ dài prompt KHÔNG kể Bible và đoạn vừa viết. Trả (Bible, đoạn vừa viết, có hạ không, chạm sàn không).
  static ({int bible, int tail, bool reduced, bool floored}) fit({
    required int? limit,
    required int skeleton,
    required int wantBible,
    required int wantTail,
  }) {
    if (limit == null || limit <= 0) return (bible: wantBible, tail: wantTail, reduced: false, floored: false);
    final room = limit - skeleton;
    if (room >= wantBible + wantTail) return (bible: wantBible, tail: wantTail, reduced: false, floored: false);
    var tail = wantTail;
    if (wantTail > 0) {
      tail = math.min(wantTail, math.max(kMinTailChars, (room * 0.45).round()));
    }
    var bible = wantBible;
    var floored = false;
    if (wantBible > 0) {
      bible = math.min(wantBible, room - tail);
      final floor = math.min(wantBible, kMinBibleChars);
      if (bible < floor) {
        bible = floor;
        floored = true;
      }
    }
    return (bible: bible, tail: tail, reduced: bible < wantBible || tail < wantTail, floored: floored);
  }
}

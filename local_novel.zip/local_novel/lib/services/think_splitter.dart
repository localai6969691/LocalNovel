import 'package:flutter/foundation.dart';
import 'ai_provider.dart' show kAiFailureMarker;

// MỤC DQ (2026-11-02) — TÁCH KHỐI SUY NGHĨ `<think>...</think>` của model (Qwen3 và các model "nghĩ trước khi trả lời") khỏi câu trả lời.
//
// Vì sao ở provider chứ không ở giao diện: mọi nơi dùng model local (chat, viết chương, Đắp thịt, dịch, tóm tắt, trích Bible...) đều nhận chữ qua
// `LocalLlamaProvider.generateStream()`. Lọc ở đây thì chương lưu vào DB, ngữ cảnh "Viết tiếp" và tóm tắt KHÔNG còn dính phần suy nghĩ. Phần suy nghĩ
// không bị vứt: đi riêng qua [ThinkingStore] (chỉ trong bộ nhớ, KHÔNG lưu DB) để giao diện có nút Hiện/Ẩn.
//
// Phạm vi: chỉ nhận ra khối suy nghĩ Ở ĐẦU đầu ra (đúng cách Qwen3 làm; cho phép khoảng trắng đứng trước). `<think>` xuất hiện giữa văn bản thì giữ nguyên.
// Chưa xử lý: khuôn chat tự mở sẵn `<think>` rồi model chỉ sinh nội dung + `</think>` (kiểu DeepSeek-R1 distill) — khi đó phần suy nghĩ vẫn hiện như chữ thường.
class ThinkPart {
  final String visible; // phần câu trả lời để hiện/lưu
  final String thinking; // phần suy nghĩ (không hiện mặc định)
  const ThinkPart(this.visible, this.thinking);
}

/// Bộ tách theo dòng chảy (streaming): đưa từng chunk vào [feed], hết luồng thì gọi [flush]. Chịu được thẻ bị cắt ngang giữa 2 chunk.
class ThinkSplitter {
  static const String _open = '<think>';
  static const String _close = '</think>';

  // 0 = chờ quyết định ở đầu đầu ra (đang giữ chữ có thể là đầu thẻ); 1 = đang trong khối suy nghĩ;
  // 2 = vừa đóng khối, nuốt khoảng trắng/xuống dòng đứng đầu câu trả lời; 3 = chuyển thẳng.
  int _state = 0;
  String _pending = '';
  bool _sawThink = false;

  /// Đã gặp thẻ mở `<think>` ở đầu đầu ra.
  bool get sawThink => _sawThink;

  /// Đang ở giữa khối suy nghĩ (chưa thấy `</think>`).
  bool get insideThink => _state == 1;

  // Độ dài đuôi dài nhất của [s] mà có thể là phần ĐẦU của [target] (để giữ lại chờ chunk sau, không làm rơi thẻ bị cắt đôi).
  static int _tailKeep(String s, String target) {
    final max = s.length < target.length - 1 ? s.length : target.length - 1;
    for (var k = max; k >= 1; k--) {
      if (s.endsWith(target.substring(0, k))) return k;
    }
    return 0;
  }

  ThinkPart feed(String chunk) {
    final vis = StringBuffer();
    final th = StringBuffer();
    var s = _pending + chunk;
    _pending = '';
    while (s.isNotEmpty) {
      if (_state == 0) {
        final t = s.trimLeft();
        if (t.isEmpty) {
          _pending = s; // mới chỉ có khoảng trắng: chưa quyết được
          s = '';
        } else if (t.startsWith(_open)) {
          _state = 1;
          _sawThink = true;
          s = t.substring(_open.length);
        } else if (_open.startsWith(t)) {
          _pending = s; // có thể là đầu của `<think>`: chờ thêm
          s = '';
        } else {
          _state = 3; // không phải khối suy nghĩ: giữ nguyên cả khoảng trắng đầu
        }
      } else if (_state == 1) {
        final ci = s.indexOf(_close);
        final mi = s.indexOf(kAiFailureMarker);
        if (ci >= 0 && (mi < 0 || ci < mi)) {
          th.write(s.substring(0, ci));
          s = s.substring(ci + _close.length);
          _state = 2;
        } else if (mi >= 0) {
          // Dòng cảnh báo lỗi nội bộ ("⚠️ [Đã tự dừng...", "⚠️ [Cần nạp lại model...") phải LUÔN hiện, không được nuốt vào phần suy nghĩ.
          th.write(s.substring(0, mi));
          s = s.substring(mi);
          _state = 3;
        } else {
          // Giữ lại đuôi có thể là phần đầu của `</think>` HOẶC của dòng cảnh báo lỗi (để cả hai không bị cắt đôi giữa 2 chunk).
          final keepClose = _tailKeep(s, _close);
          final keepMark = _tailKeep(s, kAiFailureMarker);
          final keep = keepClose > keepMark ? keepClose : keepMark;
          th.write(s.substring(0, s.length - keep));
          _pending = s.substring(s.length - keep);
          s = '';
        }
      } else if (_state == 2) {
        final t = s.trimLeft();
        if (t.isEmpty) {
          s = '';
        } else {
          s = t;
          _state = 3;
        }
      } else {
        vis.write(s);
        s = '';
      }
    }
    return ThinkPart(vis.toString(), th.toString());
  }

  /// Hết luồng: xả nốt phần đang giữ. Đang chờ quyết định ở đầu (vd chỉ có "<thi") thì coi là chữ thường; đang trong khối suy nghĩ chưa đóng thì phần giữ thuộc suy nghĩ.
  ThinkPart flush() {
    final p = _pending;
    _pending = '';
    if (_state == 0) {
      _state = 3;
      return ThinkPart(p, '');
    }
    if (_state == 1) return ThinkPart('', p);
    return const ThinkPart('', '');
  }
}

class ThinkingSnapshot {
  final int generation;
  final String text;
  final bool streaming;
  const ThinkingSnapshot(this.generation, this.text, this.streaming);
  static const ThinkingSnapshot empty = ThinkingSnapshot(0, '', false);
}

/// Kho TẠM (trong bộ nhớ, không lưu DB) giữ phần suy nghĩ của lượt sinh gần nhất trên model CHÍNH (slot 0). Giao diện nghe [notifier].
class ThinkingStore {
  ThinkingStore._();
  static final ThinkingStore instance = ThinkingStore._();

  static const int _maxChars = 20000;
  final ValueNotifier<ThinkingSnapshot> notifier = ValueNotifier<ThinkingSnapshot>(ThinkingSnapshot.empty);
  final StringBuffer _buf = StringBuffer();
  int _generation = 0;

  /// Số thứ tự lượt sinh hiện tại; nơi gọi lưu lại TRƯỚC khi sinh để biết sau đó có lượt mới hay không.
  int get generation => _generation;

  void begin() {
    _generation++;
    _buf.clear();
    notifier.value = ThinkingSnapshot(_generation, '', true);
  }

  void append(String t) {
    if (t.isEmpty) return;
    if (_buf.length < _maxChars) _buf.write(t);
    notifier.value = ThinkingSnapshot(_generation, _buf.toString(), true);
  }

  void finish() {
    notifier.value = ThinkingSnapshot(_generation, _buf.toString(), false);
  }
}

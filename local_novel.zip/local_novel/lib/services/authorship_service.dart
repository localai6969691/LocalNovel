import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import 'database_service.dart';

// MỤC CV (2026-10-13) — ghi nhận "AI NÀO ĐÃ VIẾT đoạn nào của chương nào" (xem ChapterAuthorship trong story_models.dart).
// Câu hỏi người dùng: "cùng cuốn truyện, dùng model local và API thì có đồng bộ được không, có phân biệt được chương nào model nào viết không".
// Dữ liệu truyện (chương, Bible, tóm tắt, embedding) gắn theo TRUYỆN nên dùng chung được cho mọi model; phần "ai viết" trước đây không được lưu ở đâu — nay lưu ở đây.

// Danh tính model đang viết: loại (local/api/web) + tên hiển thị + model ID.
class ModelTag {
  final String kind; // 'local' | 'api' | 'web' | 'manual' (người dùng tự khai báo "tôi tự viết")
  final String provider; // tên model local, hoặc tên người dùng đặt cho provider API (vd "Groq")
  final String modelId; // model ID của API; rỗng với local/web
  const ModelTag({required this.kind, required this.provider, this.modelId = ''});

  String get display => (kind == 'local' || modelId.isEmpty || modelId == provider) ? provider : '$provider · $modelId';
  String get icon => AuthorshipService.iconOfKind(kind);
}

class AuthorshipService {
  static String iconOfKind(String kind) => kind == 'local' ? '📱' : (kind == 'web' ? '🌐' : (kind == 'manual' ? '✍️' : '☁️'));

  // MỤC CV2: nguồn "tôi tự viết" — để gán cho phần chữ app không biết nguồn (gõ tay, hoặc chương viết trước khi có ghi nhận).
  static const ModelTag manualTag = ModelTag(kind: 'manual', provider: 'Tự viết');

  // MỤC CV2: số chữ CHƯA RÕ NGUỒN của 1 chương = số chữ hiện có − tổng chữ AI đã ghi (không âm). Không ghi gì vào DB — suy ra mỗi lần xem, nên chữ người dùng
  // tự gõ thêm/chương cũ viết trước khi có ghi nhận đều tự hiện ra mà không cần app "bắt" từng lần gõ (không làm được: app không biết ai gõ). Là ƯỚC LƯỢNG: nếu
  // người dùng xoá/sửa chữ AI đã viết thì con số lệch (xem `editedNote`).
  static int unknownWords(int chapterWords, List<ChapterAuthorship> list) {
    var sum = 0;
    for (final a in list) {
      sum += a.wordsAdded;
    }
    return chapterWords > sum ? chapterWords - sum : 0;
  }

  // Cảnh báo khi tổng chữ AI đã ghi vượt hẳn số chữ hiện có (>15%): chương đã bị xoá/sửa bớt sau khi AI viết => các con số theo model chỉ còn mang tính lịch sử.
  static String editedNote(int chapterWords, List<ChapterAuthorship> list) {
    var sum = 0;
    for (final a in list) {
      sum += a.wordsAdded;
    }
    if (sum > 0 && sum > chapterWords * 1.15) {
      return 'AI đã ghi nhận viết $sum chữ nhưng chương hiện chỉ có $chapterWords chữ — chương đã bị xoá/sửa bớt sau đó nên số chữ theo từng model chỉ là lịch sử, không còn khớp nội dung hiện tại.';
    }
    return '';
  }

  // Các nguồn có thể gán: "tự viết", model đang dùng, và mọi model đã từng ghi nhận trong truyện này (không trùng).
  static Future<List<ModelTag>> candidateTags(DatabaseService db, String novelId, ModelTag current) async {
    final out = <ModelTag>[manualTag, current];
    final seen = <String>{'${manualTag.kind}|${manualTag.provider}|', '${current.kind}|${current.provider}|${current.modelId}'};
    try {
      final byChapter = await db.authorshipForNovel(novelId);
      for (final list in byChapter.values) {
        for (final a in list) {
          if (seen.add('${a.providerKind}|${a.providerName}|${a.modelId}')) {
            out.add(ModelTag(kind: a.providerKind, provider: a.providerName, modelId: a.modelId));
          }
        }
      }
    } catch (_) {}
    return out;
  }

  static int countWords(String t) => t.trim().isEmpty ? 0 : t.trim().split(RegExp(r'\s+')).length;

  static String actionLabel(String action) {
    switch (action) {
      case 'viet_tiep':
        return 'Viết tiếp';
      case 'dap_thit':
        return 'Đắp thịt';
      case 'tao_hang_loat':
        return 'Tạo hàng loạt';
      case 'viet_lai_doan':
        return 'Viết lại đoạn';
      case 'gan_tay':
        return 'Gán thủ công';
      default:
        return action;
    }
  }

  static String displayOf(ChapterAuthorship a) {
    if (a.providerKind == 'local' || a.modelId.isEmpty || a.modelId == a.providerName) return a.providerName;
    return '${a.providerName} · ${a.modelId}';
  }

  // Ghi 1 dòng nhật ký sau khi AI ĐÃ ghi chữ thật vào chương. `text` = đúng đoạn chữ AI vừa sinh (để đếm chữ). Lỗi ghi nhật ký KHÔNG được làm hỏng việc lưu chương.
  static Future<void> record({
    required DatabaseService db,
    required String chapterId,
    required String novelId,
    required String action,
    required ModelTag tag,
    required String text,
  }) async {
    await recordWords(db: db, chapterId: chapterId, novelId: novelId, action: action, tag: tag, words: countWords(text));
  }

  // Như `record` nhưng nhận thẳng SỐ CHỮ (dùng khi gán thủ công cho phần chưa rõ nguồn).
  static Future<void> recordWords({
    required DatabaseService db,
    required String chapterId,
    required String novelId,
    required String action,
    required ModelTag tag,
    required int words,
  }) async {
    if (words <= 0) return;
    try {
      await db.addChapterAuthorship(ChapterAuthorship(
        id: const Uuid().v4(),
        chapterId: chapterId,
        novelId: novelId,
        action: action,
        providerKind: tag.kind,
        providerName: tag.provider,
        modelId: tag.modelId,
        wordsAdded: words,
      ));
    } catch (_) {}
  }

  // Dòng tóm tắt ngắn cho danh sách chương, vd "☁️ Groq · openai/gpt-oss-120b: 640 chữ · 📱 UTENA-7B: 320 chữ". Rỗng nếu chưa có dữ liệu.
  // MỤC CV2: truyền `chapterWords` để thêm "✍️ chưa rõ nguồn: N chữ" (chỉ khi chương đã có ghi nhận AI và phần chưa rõ ≥ 30 chữ — tránh nhiễu).
  static String summaryLine(List<ChapterAuthorship> list, {int? chapterWords}) {
    if (list.isEmpty) return '';
    final order = <String>[];
    final words = <String, int>{};
    final first = <String, ChapterAuthorship>{};
    for (final a in list) {
      final k = '${a.providerKind}|${a.providerName}|${a.modelId}';
      if (!words.containsKey(k)) {
        order.add(k);
        words[k] = 0;
        first[k] = a;
      }
      words[k] = (words[k] ?? 0) + a.wordsAdded;
    }
    final parts = <String>[];
    for (final k in order) {
      final a = first[k];
      if (a == null) continue;
      parts.add('${iconOfKind(a.providerKind)} ${displayOf(a)}: ${words[k] ?? 0} chữ');
    }
    if (chapterWords != null) {
      final unknown = unknownWords(chapterWords, list);
      if (unknown >= 30) parts.add('✍️ chưa rõ nguồn: $unknown chữ');
    }
    return parts.join(' · ');
  }
}

import 'package:flutter/material.dart';
import '../models/device_profile.dart';
import '../services/device_profile_service.dart';
import '../services/benchmark_service.dart';
import '../services/providers/local_provider.dart';
import '../services/settings_service.dart';
import '../services/translation_service.dart';

class LocalOptimizationScreen extends StatefulWidget {
  // ĐÃ THÊM (v14 — `currentProvider()` giờ cần `novelId`, xem
  // `SettingsService`): benchmark chạy đúng model của TRUYỆN đang mở khi
  // vào từ Cài đặt (xem `settings_screen.dart` truyền vào).
  final String novelId;
  const LocalOptimizationScreen({super.key, required this.novelId});
  @override
  State<LocalOptimizationScreen> createState() => _LocalOptimizationScreenState();
}

class _LocalOptimizationScreenState extends State<LocalOptimizationScreen> {
  DeviceProfile? profile;
  String deviceLabel = '';
  bool recognized = false;
  bool loading = true;
  bool benchmarking = false;
  bool applying = false;
  BenchmarkResult? result;

  final List<DeviceProfile> manualOverrides = knownChipsetProfiles.values.toList();
  DeviceProfile? overrideChoice;

  // Cho phép người dùng tinh chỉnh tay sau khi áp dụng gợi ý ban đầu.
  int threads = 4;
  int contextSize = 2048;
  int gpuLayers = 99;

  // Mục "Dịch thuật trung gian" đã hứa hẹn trong translation_settings_screen
  // ("xem Tối ưu AI local để biết máy có nên giữ cả 2 model trong RAM hay
  // không") — trước đây màn này chưa thực sự hiển thị phần đó, giờ thêm vào.
  int totalRamMb = 0;
  String keepResidentMode = 'auto'; // 'auto' | 'always' | 'never'
  int backendPreference = 0; // 0 = tự động (GPU tối ưu), 1 = ép GPU, 2 = ép CPU, 3 = thử QNN (thử nghiệm), 4 = ép GPU fp32 (thử nghiệm, mục CN)
  // ĐÃ THÊM: trạng thái loại trừ tối ưu hoá pin — lớp phòng vệ cuối cho
  // độ tin cậy chạy xuyên đêm (tạo chương hàng loạt/xử lý tài liệu dài).
  bool ignoringBatteryOptimizations = false;
  // MỤC CP: trạng thái chạy nền thật (dịch vụ foreground, thông báo) — để thấy ngay vì sao máy có thể ngủ khi tắt màn hình.
  Map<String, dynamic> bgStatus = <String, dynamic>{};
  // ĐÃ THÊM (theo yêu cầu người dùng: "mất công vào cài đặt cài thủ
  // công quá") — trạng thái quyền "Truy cập mọi tệp", cần cho việc duyệt
  // thư mục chọn model / import tài liệu từ bất kỳ đâu trên máy.
  bool hasStoragePermission = false;

  @override
  void initState() {
    super.initState();
    _detect();
  }

  Future<void> _checkBatteryOptimization() async {
    final ignoring = await LocalLlamaProvider.isIgnoringBatteryOptimizations();
    final status = await LocalLlamaProvider.getBackgroundStatus(); // MỤC CP
    if (mounted) {
      setState(() {
        ignoringBatteryOptimizations = ignoring;
        bgStatus = status;
      });
    }
  }

  // MỤC CP: 1 dòng trạng thái có biểu tượng xanh/cam.
  Widget _statusRow(bool ok, String okText, String badText) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(children: [
        Icon(ok ? Icons.check_circle : Icons.warning_amber_rounded, color: ok ? Colors.green : Colors.orange, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(ok ? okText : badText, style: const TextStyle(fontSize: 12.5))),
      ]),
    );
  }

  Future<void> _checkStoragePermission() async {
    final has = await LocalLlamaProvider.hasManageStoragePermission();
    if (mounted) setState(() => hasStoragePermission = has);
  }

  Future<void> _detect() async {
    setState(() => loading = true);
    final r = await DeviceProfileService().detect();
    final current = await SettingsService().loadLocalInferenceConfig(widget.novelId);
    final ramMb = await DeviceProfileService().readTotalRamMb();
    final mode = await SettingsService().loadTranslationKeepResidentMode(widget.novelId);
    final backend = await SettingsService().loadBackendPreference(widget.novelId);
    setState(() {
      profile = r.profile;
      deviceLabel = r.deviceLabel;
      recognized = r.recognized;
      threads = current.threads;
      contextSize = current.contextSize;
      gpuLayers = current.numGpuLayers;
      totalRamMb = ramMb;
      keepResidentMode = mode;
      backendPreference = backend;
      loading = false;
    });
    _checkBatteryOptimization();
    _checkStoragePermission();
  }

  void _fillFromProfile(DeviceProfile p) {
    setState(() {
      threads = p.recommendedThreads;
      contextSize = p.recommendedContext;
      gpuLayers = p.gpuOffloadLikely ? 99 : 0;
    });
  }

  // Áp dụng ngay lập tức — vì model chạy cùng tiến trình app (fllama),
  // không có bước "khởi động lại server" nào cả. Lần sinh văn bản tiếp
  // theo sẽ dùng ngay cấu hình mới.
  Future<void> _applyNow() async {
    setState(() => applying = true);
    try {
      await SettingsService().saveLocalInferenceConfig(
        widget.novelId,
        threads: threads,
        contextSize: contextSize,
        numGpuLayers: gpuLayers,
      );
      if (profile != null) {
        await SettingsService().saveRagBudget(widget.novelId, (overrideChoice ?? profile!).ragContextBudgetChars);
      }
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Đã áp dụng — có hiệu lực ngay từ lần sinh văn bản tiếp theo')));
      }
    } finally {
      if (mounted) setState(() => applying = false);
    }
  }

  Future<void> _setKeepResidentMode(String mode) async {
    setState(() => keepResidentMode = mode);
    await SettingsService().saveTranslationKeepResidentMode(widget.novelId, mode);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã lưu — có hiệu lực từ lượt dịch tiếp theo')));
    }
  }

  Future<void> _setBackendPreference(int value) async {
    setState(() => backendPreference = value);
    await SettingsService().saveBackendPreference(widget.novelId, value);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Đã lưu — có hiệu lực từ lần nạp model tiếp theo (đóng mở lại app để chắc chắn)'),
      ));
    }
  }

  Future<void> _runBenchmark() async {
    setState(() => benchmarking = true);
    try {
      final provider = await SettingsService().currentProvider(widget.novelId);
      final r = await BenchmarkService().run(provider);
      setState(() => result = r);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi đo tốc độ: $e')));
    } finally {
      setState(() => benchmarking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final active = overrideChoice ?? profile;
    return Scaffold(
      appBar: AppBar(title: const Text('Tối ưu AI local')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Thiết bị: $deviceLabel', style: const TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(
                        recognized
                            ? 'Đã nhận diện chipset: ${profile!.chipsetLabel}'
                            : 'Không nhận diện được chipset cụ thể — dùng ước lượng theo RAM (${profile!.chipsetLabel}).',
                        style: TextStyle(fontSize: 12, color: recognized ? Colors.green.shade700 : Colors.orange.shade700),
                      ),
                    ]),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<DeviceProfile?>(
                  value: overrideChoice,
                  decoration: const InputDecoration(labelText: 'Ghi đè hồ sơ thủ công (nếu tự nhận diện sai)', border: OutlineInputBorder()),
                  items: [
                    const DropdownMenuItem(value: null, child: Text('Dùng kết quả tự nhận diện')),
                    ...manualOverrides.map((p) => DropdownMenuItem(value: p, child: Text(p.tierName))),
                  ],
                  onChanged: (v) {
                    setState(() => overrideChoice = v);
                    _fillFromProfile(v ?? profile!);
                  },
                ),
                if (active != null) ...[
                  const SizedBox(height: 8),
                  TextButton.icon(
                    onPressed: () => _fillFromProfile(active),
                    icon: const Icon(Icons.auto_fix_high_outlined, size: 16),
                    label: const Text('Điền lại theo gợi ý cho hồ sơ này'),
                  ),
                  Text(active.note, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  const SizedBox(height: 8),
                  Text('Mức quantize khuyến nghị khi tải model: ${active.recommendedQuant}',
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
                ],
                const Divider(height: 32),
                Text('Tham số suy luận (có hiệu lực ngay khi áp dụng)', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                _slider('Số luồng CPU (threads)', threads, 1, 8, (v) => setState(() => threads = v)),
                _slider('Context size', contextSize, 512, 8192, (v) => setState(() => contextSize = v), step: 512),
                _slider('GPU layers (0 = tắt GPU offload)', gpuLayers, 0, 99, (v) => setState(() => gpuLayers = v)),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: applying ? null : _applyNow,
                  icon: applying
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.check_circle_outline),
                  label: const Text('Áp dụng ngay'),
                ),
                const Divider(height: 32),
                Text('Dịch thuật trung gian — giữ model trong RAM', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Khi bật "Dịch thuật trung gian" (Cài đặt → Dịch thuật trung gian), máy cần chạy '
                  'tuần tự 2 model (model dịch + model chính). Giữ model dịch trong RAM suốt phiên '
                  'làm việc giúp đỡ mất thời gian nạp lại nhiều lần, nhưng tốn thêm RAM có thể làm '
                  'chậm/crash model chính trên máy ít RAM.',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                Text(
                  totalRamMb > 0
                      ? 'RAM máy phát hiện được: ~${(totalRamMb / 1024).toStringAsFixed(1)} GB '
                          '(ngưỡng tự động giữ RAM: ${(TranslationService.ramKeepResidentThresholdMb / 1024).toStringAsFixed(1)} GB)'
                      : 'Không đọc được tổng RAM máy — chế độ "Tự động" sẽ luôn xả model dịch sau mỗi lần dùng để an toàn.',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 8),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'auto', label: Text('Tự động theo RAM')),
                    ButtonSegment(value: 'always', label: Text('Luôn giữ')),
                    ButtonSegment(value: 'never', label: Text('Luôn xả')),
                  ],
                  selected: {keepResidentMode},
                  onSelectionChanged: (s) => _setKeepResidentMode(s.first),
                ),
                const SizedBox(height: 4),
                Text(
                  keepResidentMode == 'auto'
                      ? (totalRamMb >= TranslationService.ramKeepResidentThresholdMb
                          ? '→ Quyết định hiện tại: GIỮ model dịch trong RAM suốt phiên (máy đủ RAM).'
                          : '→ Quyết định hiện tại: XẢ model dịch ngay sau mỗi lần dùng (máy ít RAM).')
                      : (keepResidentMode == 'always'
                          ? '→ Luôn giữ model dịch trong RAM suốt phiên, bất kể máy nhiều hay ít RAM.'
                          : '→ Luôn xả model dịch ngay sau mỗi lần dùng, bất kể máy nhiều hay ít RAM.'),
                  style: TextStyle(fontSize: 12, color: Colors.blue.shade700),
                ),
                const Divider(height: 32),
                Text('Backend ưu tiên cho model local', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Đổi được ngay ở đây, KHÔNG cần build lại app. Mặc định "Tự động" giờ đi '
                  'thẳng GPU đã tối ưu (precision/memory theo khuyến nghị MNN), KHÔNG còn tự '
                  'thử QNN/NPU trước nữa — máy Snapdragon 888 (Hexagon v68) đã xác nhận nằm '
                  'dưới mức Qualcomm chính thức hỗ trợ LLM-trên-NPU (yêu cầu v73 trở lên). '
                  'Chỉ chọn "Thử QNN" nếu đổi sang máy chip mới hơn (Snapdragon 8 Gen 2+).\n\n'
                  '⚠️ ĐÃ XÁC NHẬN THẬT (không phải nghi ngờ — người dùng tự kiểm tra trên máy '
                  'Adreno 660/Snapdragon 888): backend GPU (OpenCL) trên đúng dòng chip này sinh '
                  'ra ký tự lặp vô nghĩa (vd hàng loạt "F") khi viết đoạn dài, dù KHÔNG báo lỗi gì '
                  'cả — đây khớp với 1 lỗi tương thích OpenCL đã biết của chính engine MNN trên '
                  'nhiều dòng GPU khác nhau (xem alibaba/MNN issue #4836), không phải lỗi riêng '
                  'của app này. "Ép CPU" đã xác nhận vừa HẾT lặp vừa NHANH HƠN GPU trên máy này — '
                  'không nghịch lý: sinh từng chữ (decode) bị giới hạn bởi băng thông bộ nhớ chứ '
                  'không phải sức tính toán thuần, và CPU của MNN được tối ưu tay (assembly ARM) '
                  'rất kỹ, trong khi đường OpenCL đang có lỗi tương thích thật trên chip này. Nếu '
                  'thấy lặp ký tự khi dùng "Tự động"/"Ép GPU", hãy chuyển sang "Ép CPU".',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                // MỤC CN: đổi SegmentedButton -> Wrap + ChoiceChip để thêm lựa chọn thứ 5 mà không tràn ngang màn hình.
                Wrap(
                  spacing: 8,
                  runSpacing: 4,
                  children: [
                    ChoiceChip(
                      label: const Text('Tự động (hiện dùng CPU)'),
                      selected: backendPreference == 0,
                      onSelected: (_) => _setBackendPreference(0),
                    ),
                    ChoiceChip(
                      label: const Text('Ép GPU (thử nghiệm)'),
                      selected: backendPreference == 1,
                      onSelected: (_) => _setBackendPreference(1),
                    ),
                    ChoiceChip(
                      label: const Text('Ép GPU fp32 (thử nghiệm)'),
                      selected: backendPreference == 4,
                      onSelected: (_) => _setBackendPreference(4),
                    ),
                    // MỤC CU: phép thử Vulkan của MNN (cần bản build có Vulkan — build.yml mục CU).
                    ChoiceChip(
                      label: const Text('Thử Vulkan (fp16)'),
                      selected: backendPreference == 5,
                      onSelected: (_) => _setBackendPreference(5),
                    ),
                    ChoiceChip(
                      label: const Text('Thử Vulkan fp32'),
                      selected: backendPreference == 6,
                      onSelected: (_) => _setBackendPreference(6),
                    ),
                    ChoiceChip(
                      label: const Text('Ép CPU'),
                      selected: backendPreference == 2,
                      onSelected: (_) => _setBackendPreference(2),
                    ),
                    ChoiceChip(
                      label: const Text('Thử QNN (thử nghiệm)'),
                      selected: backendPreference == 3,
                      onSelected: (_) => _setBackendPreference(3),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'Mục CO: "Tự động" nay dùng CPU vì trên máy này GPU (OpenCL) ra chữ rác ở cả fp16 lẫn fp32 (thử nghiệm 05/10), '
                  'không nhanh hơn CPU khi đã làm nóng, và mỗi lần nạp giữ ~3,6GB bộ nhớ GPU không trả lại cho tới khi vuốt tắt hẳn app '
                  '(dùng GPU nhiều lần trong 1 phiên có thể làm hệ thống giết cả các app khác). Chỉ chọn GPU để thử nghiệm, và đóng hẳn app trước khi đổi chế độ.',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 6),
                Text(
                  'Mục CU — "Thử Vulkan": dùng backend Vulkan của chính MNN (đường GPU KHÁC với OpenCL đang ra chữ rác). '
                  'ĐÂY LÀ PHÉP THỬ, chưa có bằng chứng nào nó chạy đúng trên Adreno 660. Cách thử: chọn "Thử Vulkan fp32" trước (chậm hơn nhưng ít rủi ro sai số hơn), '
                  'nạp model, viết 1 đoạn NGẮN rồi 1 đoạn DÀI (prompt dài ~2.000 token trở lên — lỗi GPU của nhiều engine chỉ lộ ở prompt dài), '
                  'so với "Ép CPU". Nếu chữ sạch ở cả hai thì mới thử fp16 và đo tốc độ. Cẩn thận: nếu bản cài đặt này build KHÔNG có Vulkan, '
                  'MNN có thể âm thầm chạy bằng CPU mà app vẫn ghi "Vulkan" — app KHÔNG tự phát hiện được. Muốn chắc, xem native_debug.txt: các dòng [CU-VK] cho biết tên GPU, driver, extension Vulkan của máy; '
                  'và log build GitHub Actions có dòng "[CU] libMNN.so: ... shader attention Vulkan = N" (N = 0 nghĩa là build không có Vulkan LLM).',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const Divider(height: 32),
                // ĐÃ THÊM: lớp phòng vệ CUỐI CÙNG cho độ tin cậy chạy xuyên
                // đêm (tạo chương hàng loạt/xử lý tài liệu dài) — Foreground
                // Service + WakeLock tự làm mới đã đúng chuẩn Android, nhưng
                // 1 số OEM (đặc biệt ASUS ZenUI, xem mục 5.66 tài liệu kiến
                // trúc) có trình quản lý pin RIÊNG, có thể tự ý kill app nền
                // bất kể đúng chuẩn hay không, trừ khi được loại trừ thủ công.
                Text('Độ tin cậy khi để máy chạy lâu (qua đêm)', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Nếu máy tự kill app giữa chừng khi đang tạo chương hàng loạt/dịch tài liệu dài '
                  '(đặc biệt để qua đêm), 1 nguyên nhân thường gặp là trình quản lý pin riêng của '
                  'hãng máy — bấm nút dưới để loại trừ app khỏi tối ưu hoá pin.',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                Row(children: [
                  Icon(
                    ignoringBatteryOptimizations ? Icons.check_circle : Icons.warning_amber_rounded,
                    color: ignoringBatteryOptimizations ? Colors.green : Colors.orange,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      ignoringBatteryOptimizations
                          ? 'Đã loại trừ khỏi tối ưu hoá pin — an toàn để chạy lâu/qua đêm.'
                          : 'CHƯA loại trừ khỏi tối ưu hoá pin — rủi ro bị kill khi chạy lâu.',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: ignoringBatteryOptimizations ? Colors.green.shade700 : Colors.orange.shade800,
                      ),
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  if (!ignoringBatteryOptimizations)
                    FilledButton.icon(
                      onPressed: () async {
                        await LocalLlamaProvider.requestIgnoreBatteryOptimizations();
                        // Hộp thoại hệ thống của Android tự mở, người dùng tự
                        // xác nhận — không có cách nào biết CHÍNH XÁC lúc nào
                        // họ đóng hộp thoại đó, nên kiểm tra lại sau 1 khoảng
                        // ngắn khi họ (rất có thể) đã quay lại app.
                        await Future.delayed(const Duration(seconds: 2));
                        await _checkBatteryOptimization();
                      },
                      icon: const Icon(Icons.battery_alert_outlined, size: 18),
                      label: const Text('Loại trừ khỏi tối ưu hoá pin'),
                    ),
                  OutlinedButton.icon(
                    onPressed: _checkBatteryOptimization,
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('Kiểm tra lại'),
                  ),
                ]),
                // ===== MỤC CP (2026-10-05) → MỤC CQ (2026-10-07) — "Chạy nền khi tắt màn hình" =====
                // MỤC CQ: bỏ chữ ASUS gõ cứng. Tên hãng lấy từ chính máy (bgStatus['brand']); nút luôn mở được ít nhất trang Thông tin ứng dụng
                // của Android (mọi máy), và nếu hãng có mục riêng trong bảng (OemPowerSettings.kt) thì thử mở màn hình quản lý nguồn/tự khởi
                // động của hãng trước. Android KHÔNG có API chuẩn để app tự gạt các công tắc đó — chỉ mở màn hình để người dùng gạt.
                const SizedBox(height: 12),
                Text('Chạy nền khi tắt màn hình', style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 6),
                if (bgStatus.isEmpty)
                  Text('Chưa đọc được trạng thái — bấm "Kiểm tra lại".', style: TextStyle(fontSize: 12, color: Colors.grey.shade600))
                else ...[
                  _statusRow(bgStatus['notificationsEnabled'] == true,
                      'Thông báo của app đang BẬT.',
                      'Thông báo của app đang TẮT — thông báo dịch vụ nền bị ẩn, nên bật lại trong Cài đặt ứng dụng.'),
                  _statusRow(bgStatus['serviceRunning'] == true && bgStatus['serviceForeground'] == true,
                      'Dịch vụ nền đang chạy ở chế độ foreground (đang sinh chữ).',
                      'Dịch vụ nền chưa chạy foreground (bình thường nếu CHƯA đang sinh chữ — số liệu thật nằm ở dòng [PWR] trong nhật ký lúc sinh).'),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Text(
                      'Mức ưu tiên tiến trình theo hệ thống: ${bgStatus['procImportance'] ?? 'không đọc được'} '
                      '(125 = dịch vụ nền được công nhận; 400 = bị coi là đã cất — chỉ đáng quan tâm khi đọc lúc ĐANG sinh chữ).',
                      style: TextStyle(fontSize: 11.5, color: Colors.grey.shade600),
                    ),
                  ),
                ],
                const SizedBox(height: 6),
                Text(
                  'Nếu tắt màn hình mà máy vẫn tự ngủ giữa chừng (nhật ký ghi "MAY VUA NGU"), hãy đặt LocalNovel ở "không hạn chế" / "cho phép '
                  'chạy nền" trong phần Pin, và với 1 số hãng (Xiaomi, Oppo, Vivo, Huawei, Samsung, ASUS...) cả mục "tự khởi động"/quản lý nguồn của hãng. '
                  '${(bgStatus['hasOemEntry'] == true) ? 'App có gợi ý màn hình riêng cho máy ${bgStatus['brand']} — tên màn hình do cộng đồng ghi lại, chưa kiểm trên mọi đời máy; nếu không mở được, app tự mở trang cài đặt ứng dụng của Android (mục Pin).' : 'Máy ${bgStatus['brand'] ?? ''} chưa có màn hình riêng trong bảng của app — nút dưới mở trang cài đặt ứng dụng của Android (mục Pin).'}',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  FilledButton.tonalIcon(
                    onPressed: () async {
                      final opened = await LocalLlamaProvider.openOemPowerSettings();
                      if (!mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: Text(opened.isEmpty
                            ? 'Không mở được màn hình cài đặt nào.'
                            : (opened == 'android_app_details'
                                ? 'Đã mở trang cài đặt ứng dụng của Android (mục Pin).'
                                : 'Đã mở màn hình quản lý nguồn của hãng máy.')),
                      ));
                    },
                    icon: const Icon(Icons.settings_suggest_outlined, size: 18),
                    label: Text(bgStatus['hasOemEntry'] == true
                        ? 'Thử mở cài đặt nguồn của ${bgStatus['brand']}'
                        : 'Mở cài đặt pin của ứng dụng'),
                  ),
                ]),
                const Divider(height: 32),
                // ĐÃ THÊM (theo yêu cầu người dùng: "mất công vào cài đặt cài
                // thủ công quá") — quyền "Truy cập mọi tệp" cần cho duyệt thư
                // mục chọn model / import tài liệu. KHÔNG THỂ bật bằng 1 hộp
                // thoại Cho phép/Từ chối như quyền thông báo hay pin ở trên —
                // đây là chủ đích bảo mật của Android, mọi app đều bị vậy, kể
                // cả app trên Play Store. Cái làm được: đưa thẳng đến đúng
                // trang gạt quyền của app này, đỡ phải tự mò trong Cài đặt.
                Text('Quyền truy cập tệp', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                Text(
                  'Cần quyền "Truy cập mọi tệp" để duyệt thư mục chọn model AI và nhập tài liệu '
                  'từ bất kỳ đâu trên máy. Android bắt buộc phải xác nhận qua 1 màn Cài đặt (không '
                  'thể bật tự động như quyền thông báo) — bấm nút dưới để đi thẳng đến đúng trang, '
                  'chỉ cần gạt 1 công tắc.',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                Row(children: [
                  Icon(
                    hasStoragePermission ? Icons.check_circle : Icons.warning_amber_rounded,
                    color: hasStoragePermission ? Colors.green : Colors.orange,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      hasStoragePermission
                          ? 'Đã cấp quyền truy cập tệp.'
                          : 'CHƯA cấp quyền truy cập tệp — chọn model/tài liệu có thể bị hạn chế.',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: hasStoragePermission ? Colors.green.shade700 : Colors.orange.shade800,
                      ),
                    ),
                  ),
                ]),
                const SizedBox(height: 8),
                Wrap(spacing: 8, children: [
                  if (!hasStoragePermission)
                    FilledButton.icon(
                      onPressed: () async {
                        await LocalLlamaProvider.requestManageStoragePermission();
                        // Giống battery optimization — không biết chính xác lúc
                        // nào người dùng gạt xong công tắc và quay lại app, nên
                        // kiểm tra lại sau 1 khoảng ngắn.
                        await Future.delayed(const Duration(seconds: 2));
                        await _checkStoragePermission();
                      },
                      icon: const Icon(Icons.folder_open_outlined, size: 18),
                      label: const Text('Cấp quyền truy cập tệp'),
                    ),
                  OutlinedButton.icon(
                    onPressed: _checkStoragePermission,
                    icon: const Icon(Icons.refresh, size: 18),
                    label: const Text('Kiểm tra lại'),
                  ),
                ]),
                const Divider(height: 32),
                Text('Đo tốc độ thực tế', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 4),
                const Text(
                  'Chạy một đoạn sinh văn ngắn cố định với cấu hình đang áp dụng, đo tốc độ để biết đã ổn chưa.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: benchmarking ? null : _runBenchmark,
                  icon: benchmarking
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.speed_outlined),
                  label: Text(benchmarking ? 'Đang đo...' : 'Đo tốc độ ngay'),
                ),
                if (result != null) ...[
                  const SizedBox(height: 12),
                  Card(
                    color: Theme.of(context).colorScheme.primaryContainer,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('~${result!.tokensPerSecond.toStringAsFixed(1)} token/giây (ước lượng)',
                            style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text('${result!.wordCount} từ trong ${result!.elapsed.inMilliseconds}ms', style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 6),
                        Text(_advice(result!.tokensPerSecond), style: const TextStyle(fontSize: 12)),
                      ]),
                    ),
                  ),
                ],
              ],
            ),
    );
  }

  Widget _slider(String label, int value, int min, int max, ValueChanged<int> onChanged, {int step = 1}) {
    final divisions = ((max - min) / step).round();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('$label: $value', style: const TextStyle(fontSize: 13)),
      Slider(
        value: value.toDouble(),
        min: min.toDouble(),
        max: max.toDouble(),
        divisions: divisions,
        label: '$value',
        onChanged: (v) => onChanged(v.round()),
      ),
    ]);
  }

  String _advice(double tps) {
    if (tps >= 8) return 'Tốc độ tốt cho viết tương tác liên tục.';
    if (tps >= 3) {
      return 'Tốc độ chấp nhận được nhưng hơi chậm. Thử giảm context hoặc dùng model nhỏ hơn nếu cần mượt hơn.';
    }
    return 'Khá chậm. Kiểm tra: GPU layers có > 0 chưa? Model có đang ở Q4_K_M trở xuống không? '
        'Nếu vẫn chậm, cân nhắc đổi model nhỏ hơn (2-4B) hoặc dùng API cho các thao tác cần phản hồi nhanh.';
  }
}

import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/database_service.dart';
import '../services/ai_provider.dart';
import '../services/settings_service.dart';
import '../services/style_service.dart';
import '../services/rag_service.dart';
import '../services/translation_service.dart';

const List<String> kCharacterCategories = ['Nhân vật chính', 'Nhân vật phụ', 'Phản diện', 'Khác'];
const List<String> kWorldRuleCategories = ['Luật lệ', 'Địa điểm', 'Vũ khí', 'Tổ chức', 'Vật phẩm', 'Khác'];
const List<String> kGlossaryCategories = ['Địa danh', 'Thuật ngữ', 'Vật phẩm', 'Khác'];

class StoryBibleScreen extends StatefulWidget {
  final String novelId;
  const StoryBibleScreen({super.key, required this.novelId});
  @override
  State<StoryBibleScreen> createState() => _StoryBibleScreenState();
}

class _StoryBibleScreenState extends State<StoryBibleScreen> with SingleTickerProviderStateMixin {
  final db = DatabaseService.instance;
  List<Character> characters = [];
  List<WorldRule> rules = [];
  List<StyleProfile> styles = [];
  List<GlossaryTerm> glossaryTerms = [];
  // ĐÃ THÊM: 3 tab mới hỗ trợ quy trình viết tiểu thuyết — dàn ý toàn
  // truyện, tuyến truyện/subplot, mục tiêu viết mỗi ngày.
  List<PlotBeat> plotBeats = [];
  List<PlotThread> plotThreads = [];
  List<Volume> volumes = [];
  // ĐÃ THÊM (rà soát toàn hệ thống theo yêu cầu người dùng: "tính năng nào
  // chưa nối dây thì làm lại hết luôn") — `TimelineEvent` có đủ bảng/model/
  // CRUD từ trước (`database_service.dart`) nhưng KHÔNG có màn hình nào
  // dùng tới, và KHÔNG được RagService tham chiếu (đã sửa ở rag_service.dart)
  // — tính năng tồn tại 100% ở tầng dữ liệu nhưng vô hình với người dùng.
  List<TimelineEvent> timelineEvents = [];
  WritingGoal? writingGoal;
  List<Map<String, dynamic>> wordLog = []; // 30 ngày gần nhất, từ daily_word_log
  bool suggestingBeats = false; // đang gọi AI gợi ý dàn ý — chặn bấm 2 lần
  bool suggestingTimelineEvents = false; // đang gọi AI gợi ý sự kiện timeline — chặn bấm 2 lần
  // ĐÃ SỬA (màn hình trắng xoá — bug do lần sửa trước gây ra): trước đó
  // dùng `DefaultTabController` + gọi `DefaultTabController.of(context)`
  // ngay tại vị trí `animation:` của FAB — nhưng `context` ở đó là context
  // CỦA CHÍNH build() này (nằm TRÊN DefaultTabController trong cây widget
  // thật sự dựng ra), không phải context nằm DƯỚI nó — nên `.of(context)`
  // luôn thất bại ngay khi build, khiến toàn màn hình trắng xoá ở bản
  // release (Flutter ẩn traceback lỗi trong bản release). Giờ tự sở hữu
  // hẳn 1 TabController riêng (class đã có sẵn SingleTickerProviderStateMixin
  // để làm việc này) — không cần `.of(context)` ở đâu nữa, tránh hẳn lỗi
  // định phạm vi context (context scoping) này, đồng thời VẪN giữ đúng
  // hành vi rebuild khi đổi tab (TabController là ChangeNotifier, AnimatedBuilder
  // lắng nghe trực tiếp nó, không qua context nào cả).
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 8, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant StoryBibleScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  // ĐÃ THÊM: SỬA LỖI "đã tạo Quyển/Hồi ở tab Chương nhưng tab Bách khoa vẫn
  // báo chưa có quyển nào". Nguyên nhân: RootScreen (main.dart) dùng
  // IndexedStack giữ tab này sống xuyên suốt, `_load()` trong initState()
  // chỉ chạy 1 LẦN lúc mở truyện — lúc đó `volumes` gần như luôn RỖNG (mới
  // mở truyện, chưa kịp tạo Quyển/Hồi ở tab Chương). Sau đó chuyển tab
  // (IndexedStack không dispose/tạo lại State) nên `_load()` không bao giờ
  // chạy lại, `volumes` đứng yên mãi ở trạng thái rỗng ban đầu dù đã tạo
  // Quyển/Hồi thật ở tab Chương. Public method này để RootScreen gọi lại
  // mỗi khi người dùng CHUYỂN SANG tab Bách khoa, đảm bảo `volumes` (và
  // toàn bộ Bible) luôn khớp với dữ liệu DB mới nhất.
  Future<void> refreshData() => _load();

  Future<void> _load() async {
    final c = await db.allCharacters(widget.novelId);
    final r = await db.allWorldRules(widget.novelId);
    final s = await db.allStyleProfiles(widget.novelId);
    final g = await db.allGlossaryTerms(widget.novelId);
    final beats = await db.allPlotBeats(widget.novelId);
    final threads = await db.allPlotThreads(widget.novelId);
    final goal = await db.loadWritingGoal(widget.novelId);
    final log = await db.recentWordLog(widget.novelId, days: 30);
    // ĐÃ THÊM: nạp danh sách Quyển/Hồi — cần cho hộp thoại chọn "phạm vi
    // hiệu lực theo Quyển/Hồi" ở Nhân vật/Luật thế giới/Văn phong/Thuật
    // ngữ/Tuyến truyện.
    final vols = await db.allVolumes(widget.novelId);
    final timeline = await db.allTimelineEvents(widget.novelId);
    if (!mounted) return;
    setState(() {
      characters = c;
      rules = r;
      styles = s;
      glossaryTerms = g;
      plotBeats = beats;
      plotThreads = threads;
      writingGoal = goal;
      wordLog = log;
      volumes = vols;
      timelineEvents = timeline;
    });
  }

  // ĐÃ THÊM: hộp thoại nhỏ dùng CHUNG cho cả 5 loại (Nhân vật/Luật thế
  // giới/Văn phong/Thuật ngữ/Tuyến truyện) — chọn phạm vi hiệu lực theo
  // 1 trong 3 kiểu: Luôn có hiệu lực (mặc định, không giới hạn) / Theo số
  // chương cụ thể / Theo Quyển-Hồi (không đóng băng, tự dò lại khoảng
  // chương thật của quyển mỗi lần dùng — xem RagService._resolveScope).
  // Trả về record (fromChapter, toChapter, fromVolumeId, toVolumeId) —
  // null cả 4 nghĩa là "Luôn có hiệu lực". Trả về null (khác với record
  // toàn null) nghĩa là người dùng bấm Hủy, giữ nguyên giá trị cũ.
  Future<(int?, int?, String?, String?)?> _pickScope({
    required int? initialFromChapter,
    required int? initialToChapter,
    required String? initialFromVolumeId,
    required String? initialToVolumeId,
  }) async {
    String mode = 'always';
    if (initialFromVolumeId != null || initialToVolumeId != null) {
      mode = 'volume';
    } else if (initialFromChapter != null || initialToChapter != null) {
      mode = 'chapter';
    }
    final fromChapterCtrl = TextEditingController(text: initialFromChapter?.toString() ?? '');
    final toChapterCtrl = TextEditingController(text: initialToChapter?.toString() ?? '');
    String? fromVolumeId = initialFromVolumeId;
    String? toVolumeId = initialToVolumeId;

    return showDialog<(int?, int?, String?, String?)>(
      context: context,
      builder: (dialogCtx) => StatefulBuilder(builder: (dialogCtx, setDialogState) {
        return AlertDialog(
          title: const Text('Phạm vi hiệu lực'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text(
                'Áp dụng khi nào? Mặc định LUÔN có hiệu lực xuyên suốt truyện — chỉ giới hạn nếu thông tin '
                'này thay đổi/không còn đúng ở 1 đoạn nào đó (vd nhân vật chết ở Quyển 2, luật bị lật lại...).',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const SizedBox(height: 8),
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: const Text('Luôn có hiệu lực (mặc định)'),
                value: 'always',
                groupValue: mode,
                onChanged: (v) => setDialogState(() => mode = v!),
              ),
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: const Text('Theo số chương cụ thể'),
                value: 'chapter',
                groupValue: mode,
                onChanged: (v) => setDialogState(() => mode = v!),
              ),
              if (mode == 'chapter')
                Padding(
                  padding: const EdgeInsets.only(left: 16, bottom: 8),
                  child: Row(children: [
                    Expanded(
                      child: TextField(
                        controller: fromChapterCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Từ chương', hintText: 'để trống = từ đầu'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: toChapterCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Đến chương', hintText: 'để trống = tới cuối'),
                      ),
                    ),
                  ]),
                ),
              RadioListTile<String>(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(volumes.isEmpty ? 'Theo Quyển/Hồi (chưa có quyển nào)' : 'Theo Quyển/Hồi'),
                subtitle: volumes.isEmpty
                    ? const Text('Vào màn Chương → biểu tượng sách để tạo quyển trước', style: TextStyle(fontSize: 11))
                    : const Text(
                        'Không cần biết trước quyển dài bao nhiêu chương — viết thêm chương vào quyển sau này, '
                        'phạm vi tự mở rộng theo.',
                        style: TextStyle(fontSize: 11),
                      ),
                value: 'volume',
                groupValue: mode,
                onChanged: volumes.isEmpty ? null : (v) => setDialogState(() => mode = v!),
              ),
              if (mode == 'volume' && volumes.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(left: 16, bottom: 8),
                  child: Row(children: [
                    Expanded(
                      child: DropdownButtonFormField<String?>(
                        value: fromVolumeId,
                        decoration: const InputDecoration(labelText: 'Từ quyển'),
                        items: [
                          const DropdownMenuItem<String?>(value: null, child: Text('(từ đầu)')),
                          ...volumes.map((v) => DropdownMenuItem<String?>(value: v.id, child: Text(v.title, overflow: TextOverflow.ellipsis))),
                        ],
                        onChanged: (v) => setDialogState(() => fromVolumeId = v),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: DropdownButtonFormField<String?>(
                        value: toVolumeId,
                        decoration: const InputDecoration(labelText: 'Đến quyển'),
                        items: [
                          const DropdownMenuItem<String?>(value: null, child: Text('(tới cuối)')),
                          ...volumes.map((v) => DropdownMenuItem<String?>(value: v.id, child: Text(v.title, overflow: TextOverflow.ellipsis))),
                        ],
                        onChanged: (v) => setDialogState(() => toVolumeId = v),
                      ),
                    ),
                  ]),
                ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogCtx), child: const Text('Hủy')),
            FilledButton(
              onPressed: () {
                switch (mode) {
                  case 'chapter':
                    Navigator.pop(dialogCtx, (
                      int.tryParse(fromChapterCtrl.text.trim()),
                      int.tryParse(toChapterCtrl.text.trim()),
                      null,
                      null,
                    ));
                    break;
                  case 'volume':
                    Navigator.pop(dialogCtx, (null, null, fromVolumeId, toVolumeId));
                    break;
                  default:
                    Navigator.pop(dialogCtx, (null, null, null, null));
                }
              },
              child: const Text('Chọn'),
            ),
          ],
        );
      }),
    );
  }

  // Tóm tắt ngắn gọn hiển thị trong danh sách/nút "Chỉnh phạm vi".
  String _scopeSummary(int? fc, int? tc, String? fv, String? tv) {
    if (fv != null || tv != null) {
      final fromName = fv == null ? '' : (volumes.where((v) => v.id == fv).isEmpty ? '?' : volumes.firstWhere((v) => v.id == fv).title);
      final toName = tv == null ? '' : (volumes.where((v) => v.id == tv).isEmpty ? '?' : volumes.firstWhere((v) => v.id == tv).title);
      if (fv != null && tv != null) return 'Từ $fromName đến $toName';
      if (fv != null) return 'Từ $fromName';
      return 'Đến $toName';
    }
    if (fc != null || tc != null) {
      if (fc != null && tc != null) return 'Chương $fc-$tc';
      if (fc != null) return 'Từ chương $fc';
      return 'Đến chương $tc';
    }
    return 'Luôn có hiệu lực';
  }

  // ĐÃ THÊM (theo yêu cầu người dùng: "nhân vật A tính cách 1 theo số
  // chương, tính cách 2 theo hồi, tính cách 3 cho toàn truyện... tương tự
  // đối với bible khác" — không chỉ Nhân vật mà cả Luật thế giới, Văn
  // phong, Thuật ngữ, Tuyến truyện) — hộp thoại quản lý "chi tiết theo
  // giai đoạn" (BibleFact) DÙNG CHUNG cho cả 5 loại, mở khi CHẠM vào 1
  // entry trong danh sách. Mô tả/nội dung CHUNG của entry (hiện ở đầu, chỉ
  // đọc) luôn đúng bất kể chương nào; các "chi tiết" bên dưới mỗi cái có
  // phạm vi RIÊNG — cho phép cùng 1 nhân vật/luật có nhiều chi tiết mâu
  // thuẫn nhau ở các giai đoạn khác nhau của truyện mà AI vẫn chọn đúng.
  Future<void> _manageFactsSheet({
    required String parentType,
    required String parentId,
    required String entryLabel,
    required String generalDescription,
  }) async {
    List<BibleFact> facts = await db.factsFor(parentType, parentId);

    Future<void> addOrEditFact(StateSetter setSheetState, {BibleFact? existing}) async {
      final textCtrl = TextEditingController(text: existing?.factText ?? '');
      int? scopeFromChapter = existing?.effectiveFromChapter;
      int? scopeToChapter = existing?.effectiveToChapter;
      String? scopeFromVolumeId = existing?.effectiveFromVolumeId;
      String? scopeToVolumeId = existing?.effectiveToVolumeId;

      final ok = await showDialog<bool>(
        context: context,
        builder: (dialogCtx) => StatefulBuilder(builder: (dialogCtx, setDialogState) {
          return AlertDialog(
            title: Text(existing == null ? 'Thêm chi tiết' : 'Sửa chi tiết'),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                TextField(
                  controller: textCtrl,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Chi tiết (vd: Tính tình lạnh lùng, tàn nhẫn)'),
                ),
                const SizedBox(height: 8),
                Row(children: [
                  Expanded(
                    child: Text('Phạm vi: ${_scopeSummary(scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId)}',
                        style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ),
                  TextButton(
                    onPressed: () async {
                      final result = await _pickScope(
                        initialFromChapter: scopeFromChapter,
                        initialToChapter: scopeToChapter,
                        initialFromVolumeId: scopeFromVolumeId,
                        initialToVolumeId: scopeToVolumeId,
                      );
                      if (result != null) {
                        setDialogState(() {
                          (scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId) = result;
                        });
                      }
                    },
                    child: const Text('Chỉnh phạm vi'),
                  ),
                ]),
              ]),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dialogCtx, false), child: const Text('Hủy')),
              FilledButton(onPressed: () => Navigator.pop(dialogCtx, true), child: const Text('Lưu')),
            ],
          );
        }),
      );
      if (ok != true) return;
      final text = textCtrl.text.trim();
      if (text.isEmpty) return;
      await db.upsertBibleFact(BibleFact(
        id: existing?.id ?? const Uuid().v4(),
        novelId: widget.novelId,
        parentType: parentType,
        parentId: parentId,
        factText: text,
        orderIndex: existing?.orderIndex ?? facts.length,
        effectiveFromChapter: scopeFromChapter,
        effectiveToChapter: scopeToChapter,
        effectiveFromVolumeId: scopeFromVolumeId,
        effectiveToVolumeId: scopeToVolumeId,
      ));
      facts = await db.factsFor(parentType, parentId);
      setSheetState(() {});
    }

    if (!mounted) return;
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (sheetCtx) => StatefulBuilder(builder: (sheetCtx, setSheetState) {
        return SafeArea(
          child: Padding(
            padding: EdgeInsets.only(
              left: 16,
              right: 16,
              top: 16,
              bottom: MediaQuery.of(sheetCtx).viewInsets.bottom + 16,
            ),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(entryLabel, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 4),
              Text(
                generalDescription,
                style: const TextStyle(fontSize: 12, color: Colors.grey),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              const Divider(height: 20),
              Row(children: [
                const Expanded(
                  child: Text('Chi tiết theo giai đoạn', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                ),
                TextButton.icon(
                  onPressed: () => addOrEditFact(setSheetState),
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Thêm'),
                ),
              ]),
              const Text(
                'Nội dung chỉ đúng trong 1 giai đoạn cụ thể (khác mô tả chung ở trên, vốn luôn đúng). '
                'Vd: tính cách thay đổi sau 1 biến cố, luật bị lật lại ở hồi sau...',
                style: TextStyle(fontSize: 11, color: Colors.grey),
              ),
              const SizedBox(height: 8),
              if (facts.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Text('Chưa có chi tiết nào riêng theo giai đoạn.', style: TextStyle(color: Colors.grey, fontSize: 12)),
                )
              else
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    children: facts
                        .map((f) => ListTile(
                              dense: true,
                              title: Text(f.factText),
                              subtitle: Text(
                                _scopeSummary(f.effectiveFromChapter, f.effectiveToChapter, f.effectiveFromVolumeId, f.effectiveToVolumeId),
                                style: const TextStyle(fontSize: 11),
                              ),
                              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                                IconButton(
                                  icon: const Icon(Icons.edit_outlined, size: 18),
                                  onPressed: () => addOrEditFact(setSheetState, existing: f),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline, size: 18),
                                  onPressed: () async {
                                    await db.deleteBibleFact(f.id);
                                    facts = await db.factsFor(parentType, parentId);
                                    setSheetState(() {});
                                  },
                                ),
                              ]),
                            ))
                        .toList(),
                  ),
                ),
            ]),
          ),
        );
      }),
    );
    _load();
  }

  Future<void> _addStyleFromDescription() async {
    final result = await _editDialog(
      title: 'Mô tả văn phong bằng lời',
      fields: {'name': 'Tên hồ sơ (vd: Cổ trang trầm lắng)', 'profile_description': 'Mô tả văn phong'},
    );
    if (result == null) return;
    // ĐÃ THÊM: bước chọn phạm vi hiệu lực (tuỳ chọn) — tách riêng thành
    // bước tiếp theo thay vì nhét vào _editDialog() (hàm dùng chung nhiều
    // nơi khác, không muốn sửa cấu trúc chung chỉ vì 1 trường hợp). LƯU Ý:
    // StyleProfile hiện CHƯA được RagService tự động tham chiếu (người
    // dùng tự chọn văn phong mỗi lần viết) — phạm vi ở đây chỉ có giá trị
    // hiển thị/nhất quán dữ liệu, xem chú thích ở model.
    final scope = await _pickScope(
      initialFromChapter: null,
      initialToChapter: null,
      initialFromVolumeId: null,
      initialToVolumeId: null,
    );
    await db.upsertStyleProfile(StyleProfile(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      name: result['name'] ?? '',
      profileDescription: result['profile_description'] ?? '',
      effectiveFromChapter: scope?.$1,
      effectiveToChapter: scope?.$2,
      effectiveFromVolumeId: scope?.$3,
      effectiveToVolumeId: scope?.$4,
    ));
    _load();
  }

  // Dán một đoạn văn CỦA CHÍNH NGƯỜI DÙNG (chương cũ họ tự viết) để AI
  // phân tích ra mô tả văn phong, thay vì lưu lại nguyên văn tác phẩm.
  Future<void> _addStyleFromSample() async {
    final result = await _editDialog(
      title: 'Học văn phong từ mẫu văn của bạn',
      fields: {'name': 'Tên hồ sơ', 'sample': 'Dán một đoạn văn bạn đã viết (không phải của người khác)'},
    );
    if (result == null || (result['sample'] ?? '').trim().isEmpty) return;
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const AlertDialog(content: Row(children: [
        CircularProgressIndicator(),
        SizedBox(width: 16),
        Text('Đang phân tích văn phong...'),
      ])),
    );
    try {
      final provider = await SettingsService().secretaryProvider(widget.novelId);
      final description =
          await StyleService().analyzeStyleFromSample(result['sample']!, provider, novelId: widget.novelId);
      // ĐÃ THÊM (mục AB tài liệu kiến trúc, 2026-09-09 — rà soát toàn bộ
      // codebase theo yêu cầu người dùng, không chờ log mới): trước đây
      // ghi THẲNG `description` vào `StyleProfile.profileDescription`
      // không qua bất kỳ kiểm tra nào — NGHIÊM TRỌNG hơn hẳn 1 lần ghi rác
      // thường, vì `profileDescription` bị `_fleshOutOutline()` nhúng vào
      // system prompt của MỌI LẦN "Đắp thịt" sau này dùng đúng văn phong
      // này (xem `StyleService.buildFleshOutPrompt()`: "Viết đúng theo văn
      // phong sau: $styleDescription") — 1 lần nhiễm rác ở đây âm thầm
      // làm hỏng MỌI chương viết sau đó cho tới khi có người phát hiện,
      // giống hệt lớp nguy hiểm đã ghi ở mục Y/rag_service.dart cho
      // `plotProgressSummary`. Cùng logic `kAiFailureMarker`.
      final cleanedDescription = description.trim();
      if (cleanedDescription.isEmpty || cleanedDescription.contains(kAiFailureMarker)) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text(
              'Model AI dừng giữa chừng khi phân tích văn phong (lặp vô tận hoặc cần nạp lại model) — '
              'chưa tạo hồ sơ văn phong. Thử lại.',
            ),
            duration: Duration(seconds: 8),
          ));
        }
        return;
      }
      await db.upsertStyleProfile(StyleProfile(
        id: const Uuid().v4(),
        novelId: widget.novelId,
        name: result['name'] ?? 'Văn phong của tôi',
        profileDescription: cleanedDescription,
      ));
      _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) Navigator.pop(context);
    }
  }

  // ĐÃ SỬA (2026-09-05, theo phản hồi người dùng: "phần tạo nhân vật không
  // có chỗ chỉnh sửa nếu nhập thông tin sai"): trước đây hàm này CHỈ tạo
  // MỚI — bấm vào 1 nhân vật đã có chỉ mở được `_manageFactsSheet` (quản
  // lý dữ kiện rời gắn thêm), KHÔNG sửa được tên/vai trò/mô tả/phân loại
  // gốc đã nhập — nhập sai phải xoá tạo lại từ đầu (mất luôn facts/lịch sử
  // đã gắn). Giờ nhận thêm `existing` (null = tạo mới, khác null = sửa) —
  // điền sẵn mọi giá trị hiện tại vào form, giữ nguyên `id`/`voiceStyle`
  // (chưa có ô riêng trong form này) khi lưu đè.
  Future<void> _addOrEditCharacter({Character? existing}) async {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final roleCtrl = TextEditingController(text: existing?.role ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    final keywordsCtrl = TextEditingController(text: existing?.keywords.join(', ') ?? '');
    String category = existing?.category ?? kCharacterCategories.first;
    int? scopeFromChapter = existing?.effectiveFromChapter;
    int? scopeToChapter = existing?.effectiveToChapter;
    String? scopeFromVolumeId = existing?.effectiveFromVolumeId;
    String? scopeToVolumeId = existing?.effectiveToVolumeId;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: Text(existing == null ? 'Nhân vật mới' : 'Sửa nhân vật'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên')),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Phân loại'),
                items: kCharacterCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => category = v ?? category),
              ),
              TextField(controller: roleCtrl, decoration: const InputDecoration(labelText: 'Vai trò (mô tả tự do, vd: Đội trưởng)')),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả'), maxLines: 5),
              TextField(
                controller: keywordsCtrl,
                decoration: const InputDecoration(labelText: 'Từ khóa kích hoạt (cách nhau bởi dấu phẩy)'),
              ),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: Text('Phạm vi: ${_scopeSummary(scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId)}',
                      style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ),
                TextButton(
                  onPressed: () async {
                    final result = await _pickScope(
                      initialFromChapter: scopeFromChapter,
                      initialToChapter: scopeToChapter,
                      initialFromVolumeId: scopeFromVolumeId,
                      initialToVolumeId: scopeToVolumeId,
                    );
                    if (result != null) {
                      setDialogState(() {
                        (scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId) = result;
                      });
                    }
                  },
                  child: const Text('Chỉnh phạm vi'),
                ),
              ]),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(existing == null ? 'Lưu' : 'Lưu thay đổi')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final name = nameCtrl.text.trim();
    if (name.isEmpty) return;
    final kw = keywordsCtrl.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final character = Character(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      name: name,
      role: roleCtrl.text.trim(),
      category: category,
      description: descCtrl.text.trim(),
      voiceStyle: existing?.voiceStyle ?? '',
      keywords: kw.isEmpty ? [name] : kw,
      effectiveFromChapter: scopeFromChapter,
      effectiveToChapter: scopeToChapter,
      effectiveFromVolumeId: scopeFromVolumeId,
      effectiveToVolumeId: scopeToVolumeId,
    );
    await db.upsertCharacter(character);
    await (await _rag()).indexCharacter(character);
    _load();
  }

  // ĐÃ SỬA (2026-09-05): cùng lỗi/cùng cách sửa như `_addOrEditCharacter`
  // ở trên — trước đây chỉ tạo mới được, không sửa lại được luật đã lỡ
  // nhập sai.
  Future<void> _addOrEditRule({WorldRule? existing}) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final contentCtrl = TextEditingController(text: existing?.content ?? '');
    final keywordsCtrl = TextEditingController(text: existing?.keywords.join(', ') ?? '');
    String category = existing?.category ?? kWorldRuleCategories.first;
    bool isHardRule = existing?.isHardRule ?? true;
    int? scopeFromChapter = existing?.effectiveFromChapter;
    int? scopeToChapter = existing?.effectiveToChapter;
    String? scopeFromVolumeId = existing?.effectiveFromVolumeId;
    String? scopeToVolumeId = existing?.effectiveToVolumeId;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: Text(existing == null ? 'Luật thế giới mới' : 'Sửa luật thế giới'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tiêu đề')),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Phân loại'),
                items: kWorldRuleCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => category = v ?? category),
              ),
              TextField(controller: contentCtrl, decoration: const InputDecoration(labelText: 'Nội dung'), maxLines: 5),
              TextField(
                controller: keywordsCtrl,
                decoration: const InputDecoration(labelText: 'Từ khóa kích hoạt (nếu không phải luật cứng)'),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Luật cứng (không bao giờ được vi phạm)'),
                value: isHardRule,
                onChanged: (v) => setDialogState(() => isHardRule = v),
              ),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: Text('Phạm vi: ${_scopeSummary(scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId)}',
                      style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ),
                TextButton(
                  onPressed: () async {
                    final result = await _pickScope(
                      initialFromChapter: scopeFromChapter,
                      initialToChapter: scopeToChapter,
                      initialFromVolumeId: scopeFromVolumeId,
                      initialToVolumeId: scopeToVolumeId,
                    );
                    if (result != null) {
                      setDialogState(() {
                        (scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId) = result;
                      });
                    }
                  },
                  child: const Text('Chỉnh phạm vi'),
                ),
              ]),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(existing == null ? 'Lưu' : 'Lưu thay đổi')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;
    final rule = WorldRule(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      title: title,
      content: contentCtrl.text.trim(),
      isHardRule: isHardRule,
      category: category,
      keywords: keywordsCtrl.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
      effectiveFromChapter: scopeFromChapter,
      effectiveToChapter: scopeToChapter,
      effectiveFromVolumeId: scopeFromVolumeId,
      effectiveToVolumeId: scopeToVolumeId,
    );
    await db.upsertWorldRule(rule);
    await (await _rag()).indexWorldRule(rule);
    _load();
  }

  // ---------- Glossary (bảng thuật ngữ) ----------
  Future<void> _addGlossaryTerm() async {
    final termCtrl = TextEditingController();
    final defCtrl = TextEditingController();
    String category = kGlossaryCategories.first;
    int? scopeFromChapter;
    int? scopeToChapter;
    String? scopeFromVolumeId;
    String? scopeToVolumeId;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: const Text('Thuật ngữ mới'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: termCtrl, decoration: const InputDecoration(labelText: 'Thuật ngữ')),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'Phân loại'),
                items: kGlossaryCategories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => category = v ?? category),
              ),
              TextField(controller: defCtrl, decoration: const InputDecoration(labelText: 'Định nghĩa / giải thích'), maxLines: 4),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: Text('Phạm vi: ${_scopeSummary(scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId)}',
                      style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ),
                TextButton(
                  onPressed: () async {
                    final result = await _pickScope(
                      initialFromChapter: scopeFromChapter,
                      initialToChapter: scopeToChapter,
                      initialFromVolumeId: scopeFromVolumeId,
                      initialToVolumeId: scopeToVolumeId,
                    );
                    if (result != null) {
                      setDialogState(() {
                        (scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId) = result;
                      });
                    }
                  },
                  child: const Text('Chỉnh phạm vi'),
                ),
              ]),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final term = termCtrl.text.trim();
    if (term.isEmpty) return;
    await db.upsertGlossaryTerm(GlossaryTerm(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      term: term,
      definition: defCtrl.text.trim(),
      category: category,
      effectiveFromChapter: scopeFromChapter,
      effectiveToChapter: scopeToChapter,
      effectiveFromVolumeId: scopeFromVolumeId,
      effectiveToVolumeId: scopeToVolumeId,
    ));
    _load();
  }

  Future<void> _deleteGlossaryTerm(GlossaryTerm t) async {
    await db.deleteGlossaryTerm(t.id);
    _load();
  }

  Future<RagService> _rag() async => RagService(
        db,
        await SettingsService().currentEmbeddingService(),
        novelId: widget.novelId,
        contextBudgetChars: await SettingsService().loadRagBudget(widget.novelId),
      );

  Future<Map<String, String>?> _editDialog({
    required String title,
    required Map<String, String> fields,
  }) async {
    final controllers = {for (final k in fields.keys) k: TextEditingController()};
    return showDialog<Map<String, String>>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: fields.entries
              .map((e) => TextField(
                    controller: controllers[e.key],
                    decoration: InputDecoration(labelText: e.value),
                    maxLines: (e.key == 'description' || e.key == 'content' || e.key == 'profile_description' || e.key == 'sample') ? 5 : 1,
                  ))
              .toList(),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Hủy')),
          FilledButton(
            onPressed: () => Navigator.pop(
              context,
              {for (final k in controllers.keys) k: controllers[k]!.text},
            ),
            child: const Text('Lưu'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteCharacter(Character c) async {
    await db.deleteCharacter(c.id);
    _load();
  }

  Future<void> _deleteRule(WorldRule r) async {
    await db.deleteWorldRule(r.id);
    _load();
  }

  // ---------- Dàn ý toàn truyện (PlotBeat) ----------
  static const kBeatTypes = ['Mở đầu', 'Điểm nút', 'Cao trào', 'Kết thúc', 'Khác'];

  Future<void> _addOrEditBeat({PlotBeat? existing}) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    String beatType = existing?.beatType ?? kBeatTypes.first;
    String status = existing?.status ?? 'planned';
    // ĐÃ THÊM (theo báo cáo người dùng: "cái dàn ý thì không thấy chỗ
    // điều chỉnh phạm vi"): trước đây dialog này KHÔNG có field nào cho
    // `linkedChapterNumber` lẫn phạm vi rộng hơn (theo quyển/khoảng
    // chương) — dù `linkedChapterNumber` đã tồn tại sẵn trong model và
    // ĐƯỢC RagService dùng để khớp điểm nút với chương đang viết, nó chưa
    // bao giờ có chỗ để người dùng thật sự nhập vào. Giờ dùng lại đúng
    // `_pickScope()` (cùng UI với Nhân vật/Luật thế giới/Văn phong/Thuật
    // ngữ/Tuyến truyện) để nhất quán toàn app — CỘNG THÊM 1 ô số riêng
    // "Chương chính xác" cho trường hợp biết chắc điểm nút rơi đúng 1
    // chương (linkedChapterNumber, dùng để AI ưu tiên cao nhất khi viết
    // đúng chương đó — xem RagService.buildContext).
    final linkedChapterCtrl = TextEditingController(text: existing?.linkedChapterNumber?.toString() ?? '');
    int? scopeFromChapter = existing?.effectiveFromChapter;
    int? scopeToChapter = existing?.effectiveToChapter;
    String? scopeFromVolumeId = existing?.effectiveFromVolumeId;
    String? scopeToVolumeId = existing?.effectiveToVolumeId;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: Text(existing == null ? 'Điểm nút mới' : 'Sửa điểm nút'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên (vd: Nhân vật chính rời làng)')),
              DropdownButtonFormField<String>(
                value: beatType,
                decoration: const InputDecoration(labelText: 'Loại'),
                items: kBeatTypes.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (v) => setDialogState(() => beatType = v ?? beatType),
              ),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả'), maxLines: 4),
              DropdownButtonFormField<String>(
                value: status,
                decoration: const InputDecoration(labelText: 'Trạng thái'),
                items: const [
                  DropdownMenuItem(value: 'planned', child: Text('Mới lên kế hoạch')),
                  DropdownMenuItem(value: 'drafted', child: Text('Đang viết')),
                  DropdownMenuItem(value: 'done', child: Text('Đã xong')),
                ],
                onChanged: (v) => setDialogState(() => status = v ?? status),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: linkedChapterCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Chương chính xác (tùy chọn)',
                  hintText: 'để trống nếu chưa biết đúng chương nào',
                ),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerLeft,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Expanded(
                    child: Text('Phạm vi: ${_scopeSummary(scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId)}',
                        style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ),
                  TextButton(
                    onPressed: () async {
                      final result = await _pickScope(
                        initialFromChapter: scopeFromChapter,
                        initialToChapter: scopeToChapter,
                        initialFromVolumeId: scopeFromVolumeId,
                        initialToVolumeId: scopeToVolumeId,
                      );
                      if (result != null) {
                        setDialogState(() {
                          (scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId) = result;
                        });
                      }
                    },
                    child: const Text('Chỉnh phạm vi'),
                  ),
                ]),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;
    await db.upsertPlotBeat(PlotBeat(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      title: title,
      description: descCtrl.text.trim(),
      beatType: beatType,
      orderIndex: existing?.orderIndex ?? plotBeats.length,
      linkedChapterNumber: int.tryParse(linkedChapterCtrl.text.trim()),
      status: status,
      effectiveFromChapter: scopeFromChapter,
      effectiveToChapter: scopeToChapter,
      effectiveFromVolumeId: scopeFromVolumeId,
      effectiveToVolumeId: scopeToVolumeId,
    ));
    _load();
  }

  Future<void> _deleteBeat(PlotBeat b) async {
    await db.deletePlotBeat(b.id);
    _load();
  }

  Future<void> _reorderBeats(int oldIndex, int newIndex) async {
    if (newIndex > oldIndex) newIndex -= 1;
    final list = List<PlotBeat>.from(plotBeats);
    final item = list.removeAt(oldIndex);
    list.insert(newIndex, item);
    setState(() => plotBeats = list);
    await db.reorderPlotBeats(list);
  }

  // AI gợi ý beat sheet dựa trên mô tả truyện (Novel.description) + văn
  // phong/nhân vật hiện có (nếu có) — chạy qua TranslationService để tôn
  // trọng cài đặt dịch thuật trung gian VÀ được bảo vệ Foreground Service
  // tự động (đã sửa gốc, xem translation_service.dart). Model local có
  // thể không tuân JSON nghiêm ngặt, nên dùng định dạng dòng đơn giản dễ
  // parse: "Loại | Tên | Mô tả" — bỏ qua dòng nào không đúng định dạng
  // thay vì crash cả phần gợi ý.
  // Mã loại điểm nút bằng tiếng Anh viết hoa (KHÔNG phải nhãn tiếng Việt
  // hiển thị) — lý do: khi dịch thuật trung gian BẬT, câu trả lời của AI
  // phải đi qua 1 vòng dịch Việt->ngôn ngữ trung gian->Việt; nhãn tiếng
  // Việt tự nhiên ("Mở đầu", "Điểm nút"...) KHÔNG đảm bảo dịch đi dịch lại
  // ra ĐÚNG Y HỆT chữ gốc (dịch không phải phép biến đổi 2 chiều hoàn hảo)
  // — khiến logic so khớp loại dễ sai, rơi hết vào "Khác". Mã tiếng Anh
  // viết hoa dạng token (OPENING/TURN/CLIMAX/ENDING) ít bị dịch thuật biến
  // dạng hơn nhiều so với cụm từ tiếng Việt tự nhiên, nên dùng làm định
  // dạng trung gian, rồi tự ánh xạ sang nhãn tiếng Việt hiển thị ở tầng
  // Dart — không phụ thuộc vào việc dịch có khớp chính xác hay không.
  static const Map<String, String> _beatTypeCodeToLabel = {
    'OPENING': 'Mở đầu',
    'TURN': 'Điểm nút',
    'CLIMAX': 'Cao trào',
    'ENDING': 'Kết thúc',
  };

  Future<void> _suggestBeatsWithAI() async {
    final novel = await db.novelById(widget.novelId);
    if (novel == null || !mounted) return;
    // ĐÃ SỬA — LỖI THẬT xác nhận qua phản hồi người dùng + rà soát code:
    // trước đây chặn cứng ở đây nếu `novel.description` rỗng, báo "vào Cài
    // đặt truyện để thêm mô tả trước" — NHƯNG rà soát TOÀN BỘ app xác nhận
    // `Novel.description` KHÔNG CÓ Ô NHẬP LIỆU NÀO CẢ (khác hẳn
    // `Volume.description` — mô tả của TỪNG QUYỂN/HỒI, có ô nhập ở
    // `chapters_screen.dart._addOrEditVolume` — dễ nhầm vì cùng tên
    // field). Thông báo cũ trỏ người dùng tới 1 nơi KHÔNG TỒN TẠI — chặn
    // đứng tính năng vĩnh viễn, không có cách nào tự gỡ.
    //
    // Xét lại: `novel.description` chỉ dùng làm (1) câu neo tìm kiếm ngữ
    // nghĩa cho `buildContext` và (2) 1 dòng ngữ cảnh trong prompt — KHÔNG
    // phải dữ liệu bắt buộc để tính năng chạy được, vì hàm này ĐÃ ghép sẵn
    // toàn bộ Bible (nhân vật/luật thế giới/tuyến truyện) làm ngữ cảnh
    // chính. Bỏ hẳn việc chặn — để trống thì AI tự suy luận dàn ý từ Bible
    // hiện có, đúng bản chất "Bách khoa truyện" là nơi lưu dữ kiện, không
    // bắt buộc phải có tóm tắt truyện riêng mới dùng được.
    setState(() => suggestingBeats = true);
    try {
      final provider = await SettingsService().currentProvider(widget.novelId);
      // ĐÃ SỬA (rà soát theo yêu cầu người dùng: "gợi ý dàn ý có thật sự
      // dùng Bible không hay chỉ đọc mỗi mô tả truyện"): trước đây hàm này
      // KHÔNG hề gọi RagService — input duy nhất gửi cho AI là
      // `novel.description`, bỏ qua toàn bộ nhân vật/luật thế giới/tuyến
      // truyện đã nhập ở Bách khoa, dù đây chính là màn "Bách khoa truyện"
      // — lẽ ra phải tham chiếu Bible nhiều nhất. Hệ quả: AI gợi ý dàn ý
      // hoàn toàn không biết truyện đã có nhân vật nào, luật thế giới gì,
      // dễ gợi ý lệch hẳn khỏi Bible đã xây. Giờ ghép thêm ngữ cảnh Bible
      // (không giới hạn theo chương/quyển — dùng currentChapterNumber:
      // null vì đây là dàn ý CHO TOÀN TRUYỆN, chưa gắn vào 1 chương cụ
      // thể nào) và liệt kê tên các điểm nút ĐÃ CÓ để AI không gợi ý
      // trùng lặp với những gì người dùng đã tự thêm/đã chốt trước đó.
      //
      // ĐÃ SỬA THÊM — mục BK, 2026-09-20: neo tìm kiếm ngữ nghĩa
      // (`currentText`) giờ dùng `description` NẾU CÓ, không thì lùi về
      // tên truyện (`novel.title`) — vẫn có 1 câu neo hợp lý thay vì chuỗi
      // rỗng (chuỗi rỗng có thể khiến bước tìm "chương liên quan" theo
      // ngữ nghĩa trả về kết quả không ổn định/ngẫu nhiên).
      final rag = await _rag();
      final bibleContext = await rag.buildContext(currentText: novel.description.trim().isEmpty ? novel.title : novel.description);
      final existingTitles = plotBeats.map((b) => b.title).where((t) => t.trim().isNotEmpty).toList();
      final avoidDuplicateNote =
          existingTitles.isEmpty ? '' : '\n\nCác điểm nút ĐÃ CÓ (đừng gợi ý trùng lặp): ${existingTitles.join('; ')}';
      // ĐÃ SỬA: nếu chưa có mô tả, đổi hẳn câu dẫn trong userPrompt — nói
      // rõ với model "tự suy luận từ Bible" thay vì để dòng "Mô tả
      // truyện: " trống trơn (dễ khiến model hiểu nhầm/bịa mô tả không có
      // thật để lấp chỗ trống).
      final descriptionLine = novel.description.trim().isEmpty
          ? 'Truyện chưa có mô tả tổng quan — hãy tự suy luận bối cảnh/cốt truyện dựa HOÀN TOÀN vào dữ liệu Story Bible bên dưới (nhân vật, luật thế giới, tuyến truyện).'
          : 'Mô tả truyện: ${novel.description}';
      final raw = await TranslationService(SettingsService(), novelId: widget.novelId).generateWithOptionalTranslation(
        mainProvider: provider,
        systemPrompt: 'Bạn là biên tập viên tiểu thuyết. Chỉ trả lời đúng định dạng yêu cầu, '
            'mỗi điểm nút 1 dòng, không đánh số, không giải thích thêm. '
            'GIỮ NGUYÊN mã loại viết hoa (OPENING/TURN/CLIMAX/ENDING) — KHÔNG dịch mã này sang tiếng Việt hay ngôn ngữ khác.'
            '${bibleContext.trim().isEmpty ? '' : '\n\nDữ liệu Story Bible của truyện (nhân vật, luật thế giới, tuyến truyện đã có) — '
                'gợi ý dàn ý PHẢI khớp với dữ liệu này, không bịa nhân vật/luật mới mâu thuẫn với nó:\n$bibleContext'}',
        userPrompt: 'Dựa trên thông tin truyện sau, gợi ý 6-10 điểm nút cốt truyện chính (beat sheet) '
            'theo cấu trúc 3 hồi (mở đầu, điểm nút, cao trào, kết thúc). '
            'Mỗi dòng theo đúng định dạng: MÃ_LOẠI | Tên ngắn gọn | Mô tả 1 câu\n'
            'MÃ_LOẠI chỉ được là 1 trong 4 mã sau, viết hoa y hệt, không dịch: OPENING, TURN, CLIMAX, ENDING.\n\n'
            '$descriptionLine$avoidDuplicateNote',
        temperature: 0.8,
        maxTokens: 800,
      );
      final lines = raw.split('\n').map((l) => l.trim()).where((l) => l.contains('|'));
      // ĐÃ THÊM (mục AB, 2026-09-09): vòng lặp bên dưới lọc theo ký tự "|"
      // nên tự nhiên đã loại được đúng nguyên văn chuỗi cảnh báo
      // `kAiFailureMarker` (không chứa "|") — NHƯNG nếu model lặp vô tận
      // ĐÚNG 1 dòng gợi ý (có "|", vd model kẹt lặp "OPENING | ... | ..."),
      // dòng đó vẫn lọt qua bộ lọc và bị thêm trùng lặp nhiều lần vào Bách
      // khoa (không nghiêm trọng bằng rác lẫn vào văn xuôi chương, nhưng
      // vẫn là rác) — chặn sớm bằng kiểm tra trực tiếp trên toàn bộ `raw`.
      if (raw.contains(kAiFailureMarker)) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Model AI dừng giữa chừng (lặp vô tận hoặc cần nạp lại model) — chưa gợi ý được điểm nút nào. Thử lại.'),
            duration: Duration(seconds: 8),
          ));
        }
        return;
      }
      var order = plotBeats.length;
      var added = 0;
      for (final line in lines) {
        final parts = line.split('|').map((p) => p.trim()).toList();
        if (parts.length < 2) continue; // dòng không đúng định dạng, bỏ qua thay vì crash
        // Tìm mã loại (không phân biệt hoa/thường, bỏ qua ký tự thừa AI có
        // thể chèn quanh mã) trong TOÀN BỘ dòng thay vì chỉ đúng parts[0] —
        // AI đôi khi trả về "Loại: OPENING" thay vì "OPENING" trần trụi.
        final codeMatch = _beatTypeCodeToLabel.keys.firstWhere(
          (code) => line.toUpperCase().contains(code),
          orElse: () => '',
        );
        final type = codeMatch.isEmpty ? 'Khác' : _beatTypeCodeToLabel[codeMatch]!;
        final title = parts[1];
        final desc = parts.length >= 3 ? parts[2] : '';
        if (title.isEmpty) continue;
        await db.upsertPlotBeat(PlotBeat(
          id: const Uuid().v4(),
          novelId: widget.novelId,
          title: title,
          description: desc,
          beatType: type,
          orderIndex: order++,
          status: 'planned',
        ));
        added++;
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(added > 0 ? 'Đã thêm $added điểm nút gợi ý — sửa lại tùy ý.' : 'AI không trả về gợi ý hợp lệ, thử lại.'),
        ));
      }
      _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi: $e')));
    } finally {
      if (mounted) setState(() => suggestingBeats = false);
    }
  }

  // ---------- Tuyến truyện / subplot (PlotThread) ----------
  static const kThreadColors = [0xFF6750A4, 0xFFD32F2F, 0xFF388E3C, 0xFF1976D2, 0xFFF57C00, 0xFF7B1FA2, 0xFF00796B];

  Future<void> _addOrEditThread({PlotThread? existing}) async {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    int colorValue = existing?.colorValue ?? kThreadColors.first;
    String status = existing?.status ?? 'active';
    int? scopeFromChapter = existing?.effectiveFromChapter;
    int? scopeToChapter = existing?.effectiveToChapter;
    String? scopeFromVolumeId = existing?.effectiveFromVolumeId;
    String? scopeToVolumeId = existing?.effectiveToVolumeId;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: Text(existing == null ? 'Tuyến truyện mới' : 'Sửa tuyến truyện'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Tên tuyến (vd: Tuyến chính, Tình cảm phụ)')),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả'), maxLines: 3),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: kThreadColors
                    .map((c) => GestureDetector(
                          onTap: () => setDialogState(() => colorValue = c),
                          child: CircleAvatar(
                            backgroundColor: Color(c),
                            radius: 14,
                            child: colorValue == c ? const Icon(Icons.check, size: 16, color: Colors.white) : null,
                          ),
                        ))
                    .toList(),
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: status,
                decoration: const InputDecoration(labelText: 'Trạng thái'),
                items: const [
                  DropdownMenuItem(value: 'active', child: Text('Đang chạy')),
                  DropdownMenuItem(value: 'paused', child: Text('Tạm gác')),
                  DropdownMenuItem(value: 'resolved', child: Text('Đã khép lại')),
                ],
                onChanged: (v) => setDialogState(() => status = v ?? status),
              ),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: Text('Phạm vi: ${_scopeSummary(scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId)}',
                      style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ),
                TextButton(
                  onPressed: () async {
                    final result = await _pickScope(
                      initialFromChapter: scopeFromChapter,
                      initialToChapter: scopeToChapter,
                      initialFromVolumeId: scopeFromVolumeId,
                      initialToVolumeId: scopeToVolumeId,
                    );
                    if (result != null) {
                      setDialogState(() {
                        (scopeFromChapter, scopeToChapter, scopeFromVolumeId, scopeToVolumeId) = result;
                      });
                    }
                  },
                  child: const Text('Chỉnh phạm vi'),
                ),
              ]),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final name = nameCtrl.text.trim();
    if (name.isEmpty) return;
    await db.upsertPlotThread(PlotThread(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      name: name,
      description: descCtrl.text.trim(),
      colorValue: colorValue,
      status: status,
      effectiveFromChapter: scopeFromChapter,
      effectiveToChapter: scopeToChapter,
      effectiveFromVolumeId: scopeFromVolumeId,
      effectiveToVolumeId: scopeToVolumeId,
    ));
    _load();
  }

  Future<void> _deleteThread(PlotThread t) async {
    await db.deletePlotThread(t.id);
    _load();
  }

  // ĐÃ THÊM (rà soát toàn hệ thống theo yêu cầu người dùng: "tính năng nào
  // chưa nối dây thì làm lại") — UI đầu tiên cho `TimelineEvent`, trước đó
  // chỉ có DB/model/CRUD ở tầng dữ liệu, không có màn hình nào gọi tới.
  Future<void> _addOrEditTimelineEvent({TimelineEvent? existing}) async {
    final chapterCtrl = TextEditingController(text: existing?.chapterNumber.toString() ?? '');
    final summaryCtrl = TextEditingController(text: existing?.summary ?? '');
    DateTime? inStoryDate = existing?.inStoryDate;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
        return AlertDialog(
          title: Text(existing == null ? 'Sự kiện mới' : 'Sửa sự kiện'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(
                controller: chapterCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Xảy ra ở chương số'),
              ),
              TextField(
                controller: summaryCtrl,
                decoration: const InputDecoration(labelText: 'Tóm tắt sự kiện', hintText: 'vd: Nhân vật chính rời làng lên kinh thành'),
                maxLines: 3,
              ),
              const SizedBox(height: 8),
              // Ngày trong truyện — TUỲ CHỌN, chỉ hữu ích với truyện có
              // lịch riêng/dòng thời gian được theo dõi chặt (vd tiên hiệp
              // tính theo năm tu luyện). Không bắt buộc vì đa số truyện
              // không cần mốc ngày cụ thể, chỉ cần thứ tự theo chương.
              Row(children: [
                Expanded(
                  child: Text(
                    inStoryDate == null ? 'Chưa đặt ngày trong truyện (tuỳ chọn)' : 'Ngày: ${inStoryDate!.toIso8601String().split('T').first}',
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
                TextButton(
                  onPressed: () async {
                    final picked = await showDatePicker(
                      context: context,
                      initialDate: inStoryDate ?? DateTime.now(),
                      firstDate: DateTime(1, 1, 1),
                      lastDate: DateTime(9999, 12, 31),
                    );
                    if (picked != null) setDialogState(() => inStoryDate = picked);
                  },
                  child: const Text('Chọn ngày'),
                ),
                if (inStoryDate != null)
                  IconButton(
                    icon: const Icon(Icons.clear, size: 18),
                    onPressed: () => setDialogState(() => inStoryDate = null),
                  ),
              ]),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
          ],
        );
      }),
    );
    if (ok != true) return;
    final chapterNumber = int.tryParse(chapterCtrl.text.trim());
    final summary = summaryCtrl.text.trim();
    if (chapterNumber == null || summary.isEmpty) return;
    await db.upsertTimelineEvent(TimelineEvent(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      chapterNumber: chapterNumber,
      summary: summary,
      inStoryDate: inStoryDate,
    ));
    _load();
  }

  Future<void> _deleteTimelineEvent(TimelineEvent e) async {
    await db.deleteTimelineEvent(e.id);
    _load();
  }

  // ĐÃ THÊM (theo yêu cầu người dùng): trích 1-3 sự kiện đáng ghi làm mốc
  // thời gian từ NỘI DUNG chương gần nhất ĐÃ VIẾT (không phải soạn cả beat
  // sheet từ mô tả như bên Dàn ý). Người dùng vẫn phải BẤM DUYỆT từng gợi
  // ý trước khi lưu — không tự động thêm, tránh rác nếu AI trích sai.
  Future<void> _suggestTimelineEventsWithAI() async {
    final allChapters = await db.allChapters(widget.novelId); // đã sort DESC theo number
    Chapter? target;
    for (final c in allChapters) {
      if (c.content.trim().isNotEmpty) {
        target = c;
        break;
      }
    }
    if (target == null) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('Chưa có chương nào có nội dung để trích sự kiện.')));
      }
      return;
    }
    setState(() => suggestingTimelineEvents = true);
    try {
      final provider = await SettingsService().secretaryProvider(widget.novelId); // MỤC CT: việc phụ → thư ký
      final rag = await _rag();
      // Bible liên quan tới chương này — để AI dùng đúng tên riêng đã
      // chuẩn hoá khi tóm tắt sự kiện, không tự bịa cách gọi khác.
      final bibleContext =
          await rag.buildContext(currentText: target.content, currentChapterNumber: target.number, recentChapterCount: 0);
      final raw = await TranslationService(SettingsService(), novelId: widget.novelId).generateWithOptionalTranslation(
        mainProvider: provider,
        systemPrompt: 'Bạn là biên tập viên tiểu thuyết. Chỉ trả lời đúng định dạng yêu cầu, mỗi sự kiện 1 dòng, '
            'không đánh số, không giải thích thêm.'
            '${bibleContext.trim().isEmpty ? '' : '\n\nStory Bible liên quan:\n$bibleContext'}',
        userPrompt: 'Đọc nội dung chương ${target.number} sau, liệt kê 1-3 sự kiện QUAN TRỌNG đáng ghi làm mốc '
            'thời gian (thay đổi lớn: nhân vật chết/xuất hiện lần đầu, địa điểm mới, quyết định lớn, bí mật lộ '
            'ra...). Nếu chương không có sự kiện nào đáng ghi, trả lời đúng 1 dòng: KHÔNG CÓ.\n'
            'Mỗi dòng đúng 1 câu tóm tắt ngắn gọn, không tiêu đề, không đánh số.\n\n'
            'Nội dung chương ${target.number}: ${target.title}\n${target.content}',
        temperature: 0.5,
        maxTokens: 400,
      );
      final lines = raw
          .split('\n')
          .map((l) => l.trim().replaceFirst(RegExp(r'^[-•\d.)\s]+'), '').trim())
          .where((l) => l.isNotEmpty && l.toUpperCase() != 'KHÔNG CÓ')
          .toList();
      if (!mounted) return;
      // ĐÃ THÊM (mục AB, 2026-09-09): khác với gợi ý điểm nút (lọc theo "|"
      // nên tự loại được `kAiFailureMarker`), bộ lọc ở đây KHÔNG loại được
      // — chuỗi cảnh báo sẽ lọt qua và hiện ra như 1 "sự kiện gợi ý" trong
      // hộp thoại xác nhận bên dưới, gây hiểu lầm (dù người dùng vẫn có cơ
      // hội bỏ chọn trước khi lưu — mức độ nhẹ hơn hẳn ghi thẳng vào
      // chương). Chặn sớm, báo lỗi rõ ràng thay vì để lẫn vào danh sách gợi ý.
      if (raw.contains(kAiFailureMarker)) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Model AI dừng giữa chừng (lặp vô tận hoặc cần nạp lại model) — chưa gợi ý được sự kiện nào. Thử lại.'),
          duration: Duration(seconds: 8),
        ));
        return;
      }
      if (lines.isEmpty) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('AI không thấy sự kiện nào đáng ghi ở chương ${target.number}.')));
        return;
      }
      final selected = List<bool>.filled(lines.length, true);
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => StatefulBuilder(builder: (context, setDialogState) {
          return AlertDialog(
            title: Text('Gợi ý từ chương ${target!.number}'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: List.generate(
                  lines.length,
                  (i) => CheckboxListTile(
                    value: selected[i],
                    onChanged: (v) => setDialogState(() => selected[i] = v ?? false),
                    title: Text(lines[i], style: const TextStyle(fontSize: 14)),
                    controlAffinity: ListTileControlAffinity.leading,
                    dense: true,
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
              FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Thêm mục đã chọn')),
            ],
          );
        }),
      );
      if (confirmed != true) return;
      for (var i = 0; i < lines.length; i++) {
        if (!selected[i]) continue;
        await db.upsertTimelineEvent(TimelineEvent(
          id: const Uuid().v4(),
          novelId: widget.novelId,
          chapterNumber: target.number,
          summary: lines[i],
        ));
      }
      _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi gợi ý: $e')));
      }
    } finally {
      if (mounted) setState(() => suggestingTimelineEvents = false);
    }
  }

  // Hiện danh sách chương thuộc tuyến này — giúp phát hiện tuyến bị "bỏ
  // quên" quá lâu (không chương nào thúc đẩy tuyến này trong 1 khoảng dài).
  Future<void> _showChaptersInThread(PlotThread t) async {
    final allChapters = await db.allChapters(widget.novelId);
    final inThread = allChapters.where((c) => c.threadIds.contains(t.id)).toList()..sort((a, b) => a.number.compareTo(b.number));
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: inThread.isEmpty
            ? const Padding(
                padding: EdgeInsets.all(24),
                child: Text('Chưa chương nào gắn tuyến này. Vào màn soạn chương để gắn.'),
              )
            : ListView(
                shrinkWrap: true,
                children: inThread
                    .map((c) => ListTile(
                          leading: Text('#${c.number}'),
                          title: Text(c.title.isEmpty ? '(Chưa đặt tên)' : c.title),
                        ))
                    .toList(),
              ),
      ),
    );
  }

  // ---------- Mục tiêu viết mỗi ngày ----------
  Future<void> _editGoal() async {
    final ctrl = TextEditingController(text: (writingGoal?.dailyTargetWords ?? 500).toString());
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Mục tiêu viết mỗi ngày'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'Số chữ / ngày', suffixText: 'chữ'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
        ],
      ),
    );
    if (ok != true) return;
    final target = int.tryParse(ctrl.text.trim()) ?? 500;
    await db.saveWritingGoal(WritingGoal(novelId: widget.novelId, dailyTargetWords: target));
    _load();
  }

  // Tính (ngày -> số chữ viết TRONG ngày đó) từ dãy snapshot tổng số chữ
  // — hiệu số giữa 2 snapshot liền kề. Ngày đầu tiên trong dãy không có
  // ngày trước để so sánh nên bỏ qua (không tính vào streak).
  List<MapEntry<String, int>> _dailyDeltas() {
    final result = <MapEntry<String, int>>[];
    for (var i = 1; i < wordLog.length; i++) {
      final prev = wordLog[i - 1]['total_words'] as int;
      final cur = wordLog[i]['total_words'] as int;
      result.add(MapEntry(wordLog[i]['date'] as String, (cur - prev).clamp(0, 1 << 30)));
    }
    return result;
  }

  int _currentStreak(int target) {
    final deltas = _dailyDeltas();
    var streak = 0;
    for (var i = deltas.length - 1; i >= 0; i--) {
      if (deltas[i].value >= target) {
        streak++;
      } else {
        break;
      }
    }
    return streak;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Bách khoa truyện'),
          bottom: TabBar(
            controller: _tabController,
            isScrollable: true,
            tabs: const [
              Tab(text: 'Nhân vật'),
              Tab(text: 'Luật thế giới'),
              Tab(text: 'Văn phong'),
              Tab(text: 'Thuật ngữ'),
              Tab(text: 'Dàn ý'),
              Tab(text: 'Tuyến truyện'),
              Tab(text: 'Mục tiêu'),
              Tab(text: 'Dòng thời gian'),
            ],
          ),
        ),
        body: TabBarView(controller: _tabController, children: [
          characters.isEmpty
              ? const Center(child: Text('Chưa có nhân vật nào. Bấm + để thêm.'))
              : ListView(
                  children: characters
                      .map((c) => ListTile(
                            leading: CircleAvatar(child: Text(c.name.isNotEmpty ? c.name[0] : '?')),
                            title: Row(children: [
                              Flexible(child: Text(c.name)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(c.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text('${c.role} · ${c.description}'),
                            onTap: () => _manageFactsSheet(
                              parentType: 'character',
                              parentId: c.id,
                              entryLabel: c.name,
                              generalDescription: c.description,
                            ),
                            trailing: PopupMenuButton<String>(
                              icon: const Icon(Icons.more_vert, size: 18),
                              onSelected: (v) {
                                if (v == 'edit') _addOrEditCharacter(existing: c);
                                if (v == 'delete') _deleteCharacter(c);
                              },
                              itemBuilder: (context) => const [
                                PopupMenuItem(value: 'edit', child: Text('Sửa')),
                                PopupMenuItem(value: 'delete', child: Text('Xóa')),
                              ],
                            ),
                          ))
                      .toList(),
                ),
          rules.isEmpty
              ? const Center(child: Text('Chưa có luật thế giới nào. Bấm + để thêm.'))
              : ListView(
                  children: rules
                      .map((r) => ListTile(
                            leading: Icon(r.isHardRule ? Icons.gavel : Icons.info_outline),
                            title: Row(children: [
                              Flexible(child: Text(r.title)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(r.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text(r.content),
                            onTap: () => _manageFactsSheet(
                              parentType: 'world_rule',
                              parentId: r.id,
                              entryLabel: r.title,
                              generalDescription: r.content,
                            ),
                            trailing: PopupMenuButton<String>(
                              icon: const Icon(Icons.more_vert, size: 18),
                              onSelected: (v) {
                                if (v == 'edit') _addOrEditRule(existing: r);
                                if (v == 'delete') _deleteRule(r);
                              },
                              itemBuilder: (context) => const [
                                PopupMenuItem(value: 'edit', child: Text('Sửa')),
                                PopupMenuItem(value: 'delete', child: Text('Xóa')),
                              ],
                            ),
                          ))
                      .toList(),
                ),
          ListView(
            children: [
              const Padding(
                padding: EdgeInsets.all(12),
                child: Text(
                  'Mỗi hồ sơ là một mô tả văn phong (không lưu nguyên văn tác phẩm ai khác). '
                  'Có thể chọn hồ sơ này khi viết tiếp chương hoặc đắp thịt outline.',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ),
              ...styles.map((s) => ListTile(
                    leading: const Icon(Icons.edit_note_outlined),
                    title: Text(s.name),
                    subtitle: Text(s.profileDescription, maxLines: 2, overflow: TextOverflow.ellipsis),
                    onTap: () => _manageFactsSheet(
                      parentType: 'style_profile',
                      parentId: s.id,
                      entryLabel: s.name,
                      generalDescription: s.profileDescription,
                    ),
                    onLongPress: () async {
                      await db.deleteStyleProfile(s.id);
                      _load();
                    },
                  )),
            ],
          ),
          glossaryTerms.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Chưa có thuật ngữ nào. Dùng để tra cứu nhanh tên địa danh/thuật ngữ riêng của '
                      'truyện — khác Story Bible ở chỗ KHÔNG tự động nạp vào prompt AI.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView(
                  children: glossaryTerms
                      .map((t) => ListTile(
                            leading: const Icon(Icons.menu_book_outlined),
                            title: Row(children: [
                              Flexible(child: Text(t.term)),
                              const SizedBox(width: 6),
                              Chip(
                                label: Text(t.category, style: const TextStyle(fontSize: 10)),
                                visualDensity: VisualDensity.compact,
                                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                padding: EdgeInsets.zero,
                              ),
                            ]),
                            subtitle: Text(t.definition),
                            onTap: () => _manageFactsSheet(
                              parentType: 'glossary_term',
                              parentId: t.id,
                              entryLabel: t.term,
                              generalDescription: t.definition,
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline, size: 18),
                              onPressed: () => _deleteGlossaryTerm(t),
                            ),
                          ))
                      .toList(),
                ),
          // ── Tab "Dàn ý": beat sheet toàn truyện, kéo-thả sắp xếp ──
          Column(children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                const Expanded(
                  child: Text(
                    'Điểm nút cốt truyện toàn truyện — kéo-thả để sắp xếp lại thứ tự.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
                FilledButton.icon(
                  onPressed: suggestingBeats ? null : _suggestBeatsWithAI,
                  icon: suggestingBeats
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.auto_awesome_outlined, size: 16),
                  label: Text(suggestingBeats ? 'Đang gợi ý...' : 'AI gợi ý'),
                ),
              ]),
            ),
            Expanded(
              child: plotBeats.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Chưa có điểm nút nào. Bấm + để tự thêm, hoặc "AI gợi ý" để có bản nháp ban đầu.',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    )
                  : ReorderableListView(
                      onReorder: _reorderBeats,
                      children: plotBeats
                          .map((b) => ListTile(
                                key: ValueKey(b.id),
                                leading: CircleAvatar(
                                  radius: 14,
                                  child: Icon(
                                    b.status == 'done'
                                        ? Icons.check_circle_outline
                                        : b.status == 'drafted'
                                            ? Icons.edit_outlined
                                            : Icons.circle_outlined,
                                    size: 16,
                                  ),
                                ),
                                title: Row(children: [
                                  Flexible(child: Text(b.title)),
                                  const SizedBox(width: 6),
                                  Chip(
                                    label: Text(b.beatType, style: const TextStyle(fontSize: 10)),
                                    visualDensity: VisualDensity.compact,
                                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                                    padding: EdgeInsets.zero,
                                  ),
                                ]),
                                subtitle: Text(b.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                                onTap: () => _addOrEditBeat(existing: b),
                                trailing: IconButton(
                                  icon: const Icon(Icons.delete_outline, size: 18),
                                  onPressed: () => _deleteBeat(b),
                                ),
                              ))
                          .toList(),
                    ),
            ),
          ]),
          // ── Tab "Tuyến truyện": subplot, chấm màu nhận diện ──
          plotThreads.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'Chưa có tuyến truyện nào. Bấm + để thêm (vd "Tuyến chính", "Tình cảm phụ").',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                )
              : ListView(
                  children: plotThreads
                      .map((t) => ListTile(
                            leading: CircleAvatar(backgroundColor: Color(t.colorValue), radius: 10),
                            title: Text(t.name),
                            subtitle: Text(
                              t.description.isEmpty
                                  ? (t.status == 'active' ? 'Đang chạy' : t.status == 'paused' ? 'Tạm gác' : 'Đã khép lại')
                                  : t.description,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onTap: () => _showChaptersInThread(t),
                            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                              IconButton(
                                icon: const Icon(Icons.timeline_outlined, size: 18),
                                tooltip: 'Chi tiết theo giai đoạn',
                                onPressed: () => _manageFactsSheet(
                                  parentType: 'plot_thread',
                                  parentId: t.id,
                                  entryLabel: t.name,
                                  generalDescription: t.description,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.edit_outlined, size: 18),
                                onPressed: () => _addOrEditThread(existing: t),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline, size: 18),
                                onPressed: () => _deleteThread(t),
                              ),
                            ]),
                          ))
                      .toList(),
                ),
          // ── Tab "Mục tiêu": số chữ/ngày, streak, 14 ngày gần nhất ──
          Builder(builder: (context) {
            final target = writingGoal?.dailyTargetWords ?? 500;
            final deltas = _dailyDeltas();
            final todayKey = () {
              final now = DateTime.now();
              return '${now.year.toString().padLeft(4, '0')}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
            }();
            final todayEntry = deltas.where((e) => e.key == todayKey);
            final todayWords = todayEntry.isEmpty ? 0 : todayEntry.first.value;
            final streak = _currentStreak(target);
            final recentDeltas = deltas.reversed.take(14).toList().reversed.toList();
            return ListView(padding: const EdgeInsets.all(16), children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Text('Mục tiêu hôm nay', style: TextStyle(fontWeight: FontWeight.bold)),
                      const Spacer(),
                      TextButton(onPressed: _editGoal, child: const Text('Sửa mục tiêu')),
                    ]),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(value: target == 0 ? 0 : (todayWords / target).clamp(0, 1)),
                    const SizedBox(height: 8),
                    Text('$todayWords / $target chữ'),
                    if (streak > 0) ...[
                      const SizedBox(height: 4),
                      Text('🔥 $streak ngày liên tiếp đạt mục tiêu', style: const TextStyle(color: Colors.orange)),
                    ],
                  ]),
                ),
              ),
              const SizedBox(height: 16),
              const Text('14 ngày gần nhất', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (recentDeltas.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16),
                  child: Text('Chưa có dữ liệu — lưu 1 chương để bắt đầu theo dõi.', style: TextStyle(color: Colors.grey)),
                )
              else
                ...recentDeltas.map((e) => ListTile(
                      dense: true,
                      leading: Icon(
                        e.value >= target ? Icons.check_circle : Icons.circle_outlined,
                        color: e.value >= target ? Colors.green : Colors.grey,
                        size: 18,
                      ),
                      title: Text(e.key),
                      trailing: Text('${e.value} chữ'),
                    )),
            ]);
          }),
          // ── Tab "Dòng thời gian" (trước đây có đủ DB/model nhưng KHÔNG
          // hề có UI, xem ghi chú ở field `timelineEvents` phía trên):
          // liệt kê sự kiện chính theo đúng thứ tự chương xảy ra, giúp AI
          // (qua RagService) và người viết không tự mâu thuẫn dòng thời
          // gian khi truyện dài hàng trăm chương.
          //
          // ĐÃ THÊM nút "AI gợi ý" (theo yêu cầu người dùng): khác hẳn "AI
          // gợi ý" bên tab Dàn ý (soạn TOÀN BỘ beat sheet từ MÔ TẢ truyện,
          // cho những gì CHƯA xảy ra) — nút này trích sự kiện ĐÃ XẢY RA từ
          // NỘI DUNG 1 chương đã viết xong, người dùng vẫn phải BẤM DUYỆT
          // từng gợi ý trước khi lưu (không tự động thêm) để tránh rác nếu
          // AI trích sai. Đây KHÔNG phải cơ chế tự cập nhật liên tục như
          // "Cốt truyện đã diễn ra" (tab đó auto 100%, không cần duyệt) —
          // Timeline vẫn giữ đúng bản chất "người dùng kiểm soát từng mốc". ──
          Column(children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                const Expanded(
                  child: Text(
                    'Mốc thời gian theo chương — dùng để AI không viết mâu thuẫn với chuyện đã xảy ra.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
                FilledButton.icon(
                  onPressed: suggestingTimelineEvents ? null : _suggestTimelineEventsWithAI,
                  icon: suggestingTimelineEvents
                      ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.auto_awesome_outlined, size: 16),
                  label: Text(suggestingTimelineEvents ? 'Đang gợi ý...' : 'AI gợi ý'),
                ),
              ]),
            ),
            Expanded(
              child: timelineEvents.isEmpty
                  ? const Center(
                      child: Padding(
                        padding: EdgeInsets.all(24),
                        child: Text(
                          'Chưa có sự kiện nào. Bấm + để tự thêm, hoặc "AI gợi ý" để trích '
                          'từ chương gần nhất đã viết (vd "Chương 12: nhân vật chính rời làng").',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Colors.grey),
                        ),
                      ),
                    )
                  : ListView(
                      children: (List<TimelineEvent>.from(timelineEvents)..sort((a, b) => a.chapterNumber.compareTo(b.chapterNumber)))
                          .map((e) => ListTile(
                                leading: CircleAvatar(child: Text('${e.chapterNumber}', style: const TextStyle(fontSize: 12))),
                                title: Text(e.summary, maxLines: 2, overflow: TextOverflow.ellipsis),
                                subtitle: e.inStoryDate != null
                                    ? Text('Chương ${e.chapterNumber} · ${e.inStoryDate!.toIso8601String().split('T').first}')
                                    : Text('Chương ${e.chapterNumber}'),
                                onTap: () => _addOrEditTimelineEvent(existing: e),
                                trailing: IconButton(
                                  icon: const Icon(Icons.delete_outline, size: 18),
                                  onPressed: () => _deleteTimelineEvent(e),
                                ),
                              ))
                          .toList(),
                    ),
            ),
          ]),
        ]),
        floatingActionButton: AnimatedBuilder(
          // ĐÃ SỬA (bug nút + luôn mở "Nhân vật mới" bất kể đang ở tab
          // nào): `Builder` thường KHÔNG lắng nghe TabController — đọc
          // `DefaultTabController.of(context).index` bên trong nó chỉ
          // lấy đúng giá trị tại lần build ĐẦU TIÊN của toàn màn hình,
          // sau đó vuốt/chạm đổi tab KHÔNG kích hoạt build lại nút FAB
          // (vì TabController.index thay đổi qua notifyListeners(),
          // không phải qua cơ chế InheritedWidget rebuild thông thường).
          // TabController là 1 ChangeNotifier — phải dùng AnimatedBuilder
          // (hoặc addListener thủ công) để thực sự lắng nghe và rebuild
          // đúng lúc tab đổi. Đây là lý do cả 4 tab đều hiện "Nhân vật
          // mới" giống hệt nhau trong ảnh chụp màn hình.
          animation: _tabController,
          builder: (context, _) {
            final tabIndex = _tabController.index;
            if (tabIndex == 0) {
              return FloatingActionButton(onPressed: () => _addOrEditCharacter(), child: const Icon(Icons.add));
            } else if (tabIndex == 1) {
              return FloatingActionButton(onPressed: () => _addOrEditRule(), child: const Icon(Icons.add));
            } else if (tabIndex == 3) {
              return FloatingActionButton(onPressed: _addGlossaryTerm, child: const Icon(Icons.add));
            } else if (tabIndex == 4) {
              return FloatingActionButton(onPressed: () => _addOrEditBeat(), child: const Icon(Icons.add));
            } else if (tabIndex == 5) {
              return FloatingActionButton(onPressed: () => _addOrEditThread(), child: const Icon(Icons.add));
            } else if (tabIndex == 6) {
              // Tab "Mục tiêu" không có danh sách để "thêm mới" — sửa mục
              // tiêu đã có nút riêng ngay trong nội dung tab, không cần FAB.
              return const SizedBox.shrink();
            } else if (tabIndex == 7) {
              return FloatingActionButton(onPressed: () => _addOrEditTimelineEvent(), child: const Icon(Icons.add));
            } else if (tabIndex != 2) {
              return const SizedBox.shrink();
            }
            return FloatingActionButton.extended(
            onPressed: () => showModalBottomSheet(
              context: context,
              builder: (_) => SafeArea(
                child: Wrap(children: [
                  ListTile(
                    leading: const Icon(Icons.description_outlined),
                    title: const Text('Mô tả bằng lời'),
                    onTap: () {
                      Navigator.pop(context);
                      _addStyleFromDescription();
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.content_paste_outlined),
                    title: const Text('Học từ mẫu văn của tôi'),
                    onTap: () {
                      Navigator.pop(context);
                      _addStyleFromSample();
                    },
                  ),
                ]),
              ),
            ),
            icon: const Icon(Icons.add),
            label: const Text('Thêm văn phong'),
          );
          },
        ),
    );
  }
}

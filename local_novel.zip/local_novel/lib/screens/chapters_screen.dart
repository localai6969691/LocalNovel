import 'dart:async';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:uuid/uuid.dart';
import '../models/story_models.dart';
import '../services/authorship_service.dart';
import '../services/database_service.dart';
import '../services/export_service.dart';
import '../services/settings_service.dart';
import 'chapter_editor_screen.dart';
import 'chapters_batch_generate_screen.dart';
import 'data_integrity_screen.dart';
import 'search_screen.dart';

class ChaptersScreen extends StatefulWidget {
  final String novelId;
  final String novelTitle;
  const ChaptersScreen({super.key, required this.novelId, required this.novelTitle});
  @override
  State<ChaptersScreen> createState() => _ChaptersScreenState();
}

class _ChaptersScreenState extends State<ChaptersScreen> {
  final db = DatabaseService.instance;
  List<Chapter> chapters = [];
  // ĐÃ THÊM: tầng "Quyển/Hồi" nhóm nhiều chương — rỗng = không dùng tính
  // năng này, danh sách chương hiển thị y hệt như trước (không đổi gì).
  List<Volume> volumes = [];
  // MỤC CV: nhật ký "model nào đã viết đoạn nào" của cả truyện, gom theo chương — để hiện 1 dòng tóm tắt dưới tên mỗi chương.
  Map<String, List<ChapterAuthorship>> authorship = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant ChaptersScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.novelId != widget.novelId) _load();
  }

  // ĐÃ THÊM: RootScreen (main.dart) dùng IndexedStack để giữ 5 tab (Chương/
  // Bách khoa/Trợ lý AI/Tài liệu/Cài đặt) sống cùng lúc, đổi tab KHÔNG dispose/
  // tạo lại State — nghĩa là `_load()` gọi trong initState() chỉ chạy ĐÚNG 1
  // LẦN DUY NHẤT khi mở truyện, các dữ liệu (chương, Quyển/Hồi...) sau đó KHÔNG
  // tự cập nhật khi có thay đổi từ tab khác. Public method này để RootScreen
  // gọi lại mỗi khi người dùng CHUYỂN SANG tab này, đảm bảo danh sách chương/
  // Quyển-Hồi luôn mới (vd nếu vừa xóa Quyển ở màn khác — dù hiện tại chỉ có
  // đúng tab này tạo/sửa Quyển).
  Future<void> refreshData() => _load();

  Future<void> _load() async {
    try {
      final list = await db.allChapters(widget.novelId);
      final v = await db.allVolumes(widget.novelId);
      // Tách riêng: lỗi đọc nhật ký (phụ trợ) không được làm hỏng việc hiện danh sách chương.
      Map<String, List<ChapterAuthorship>> auth = {};
      try {
        auth = await db.authorshipForNovel(widget.novelId);
      } catch (_) {}
      if (!mounted) return;
      setState(() {
        chapters = list;
        volumes = v;
        authorship = auth;
      });
    } catch (e) {
      // ĐÃ THÊM: trước đây lỗi ở đây (vd bảng "volumes" chưa có do máy
      // chưa qua migration v6, hoặc bất kỳ lỗi DB nào khác) văng ra KHÔNG
      // AI BẮT — người dùng bấm nút mà "không thấy gì xảy ra" vì Future
      // lỗi âm thầm rớt, không có SnackBar/thông báo nào cả (10 nơi gọi
      // _load() trong file này đều không bọc try/catch). Giờ luôn hiện rõ
      // lỗi thật cho người dùng thấy, thay vì im lặng thất bại.
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi tải danh sách chương: $e')));
      }
    }
  }

  Future<void> _newChapter() async {
    final nextNumber = chapters.isEmpty ? 1 : chapters.first.number + 1;
    // ĐÃ SỬA (theo báo cáo người dùng: "có quyển hồi, có chương, nhưng
    // chương không nằm trong quyển hồi, cả 2 nằm riêng lẻ"): trước đây
    // chương mới LUÔN tạo ra với volumeId = null ("Chưa gom quyển"), bất
    // kể truyện đã có quyển/hồi hay chương gần nhất đang thuộc quyển nào —
    // người dùng phải tự gán tay cho TỪNG chương một (và cách gán duy
    // nhất là chạm-giữ ẩn, xem sửa ở _chapterTile bên dưới). Giờ chương
    // mới TỰ NỐI TIẾP đúng quyển của chương có số lớn nhất hiện có (chính
    // là `chapters.first`, danh sách đã sắp DESC) — khớp với cách viết
    // truyện thật: chương mới luôn tiếp nối quyển đang viết dở, CHỈ đổi
    // quyển khi tác giả chủ động bắt đầu quyển mới (lúc đó tự đổi bằng nút
    // gán quyển). Truyện chưa có chương nào hoặc chương gần nhất chưa gán
    // quyển → vẫn null như cũ, không đổi hành vi.
    final inheritedVolumeId = chapters.isEmpty ? null : chapters.first.volumeId;
    final chapter = Chapter(
      id: const Uuid().v4(),
      novelId: widget.novelId,
      number: nextNumber,
      title: 'Chương mới',
      content: '',
      volumeId: inheritedVolumeId,
    );
    // ĐÃ SỬA: tách rõ 2 bước — LƯU chương (quan trọng, phải xong) và LÀM
    // MỚI danh sách hiển thị (phụ, không nên chặn điều hướng nếu lỗi).
    // Trước đây `await _load()` nằm CHẮN NGANG giữa lưu chương và điều
    // hướng — nếu _load() lỗi (xem sửa ở trên), người dùng mất luôn cả
    // chương vừa tạo (đã lưu DB thật, nhưng không bao giờ thấy màn soạn
    // chương để biết nó tồn tại). Giờ dù _load() có trục trặc, chương vẫn
    // đã lưu an toàn VÀ vẫn điều hướng sang màn soạn để người dùng thấy
    // ngay, viết luôn — danh sách nền sẽ tự đúng lại lần tải kế tiếp.
    //
    // ĐÃ THÊM try/catch: đây chính là nơi lỗi "bảng chapters thiếu cột
    // thread_ids/volume_id" (xem ghi chú trong database_service.dart,
    // onCreate) từng rớt ÂM THẦM — bấm "+" nhưng không có chương nào được
    // tạo và cũng không có thông báo lỗi nào. Giờ mọi lỗi khi lưu chương
    // đều hiện rõ cho người dùng, không còn "bấm mà không thấy gì".
    try {
      await db.upsertChapter(chapter);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi tạo chương: $e')));
      }
      return;
    }
    unawaited(_load());
    if (mounted) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: chapter)))
          .then((_) => _load());
    }
  }

  // ---------- Quyển/Hồi ----------
  Future<void> _addOrEditVolume({Volume? existing}) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(existing == null ? 'Quyển/Hồi mới' : 'Sửa Quyển/Hồi'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Tên (vd: Quyển 1 - Khởi đầu)')),
          TextField(controller: descCtrl, decoration: const InputDecoration(labelText: 'Mô tả (tùy chọn)'), maxLines: 3),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Lưu')),
        ],
      ),
    );
    if (ok != true) return;
    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;
    await db.upsertVolume(Volume(
      id: existing?.id ?? const Uuid().v4(),
      novelId: widget.novelId,
      title: title,
      description: descCtrl.text.trim(),
      orderIndex: existing?.orderIndex ?? volumes.length,
    ));
    _load();
  }

  Future<void> _deleteVolume(Volume v) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Xóa Quyển/Hồi?'),
        content: Text('"${v.title}" sẽ bị xóa. Các chương đang thuộc quyển này KHÔNG bị xóa, chỉ gỡ khỏi quyển.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Hủy')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Xóa')),
        ],
      ),
    );
    if (confirm != true) return;
    await db.deleteVolume(v.id);
    _load();
  }

  // Màn quản lý Quyển/Hồi — mở từ menu AppBar, CRUD đầy đủ, kéo-thả sắp
  // xếp lại thứ tự quyển (không phải thứ tự chương — chương vẫn đánh số
  // liên tục xuyên suốt truyện như cũ).
  Future<void> _manageVolumes() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => StatefulBuilder(builder: (sheetContext, setSheetState) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                const Text('Quản lý Quyển/Hồi', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const Spacer(),
                TextButton.icon(
                  onPressed: () async {
                    await _addOrEditVolume();
                    setSheetState(() {});
                  },
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Thêm'),
                ),
              ]),
              const SizedBox(height: 8),
              if (volumes.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 24),
                  child: Text('Chưa có quyển/hồi nào. Bấm "Thêm" để tạo.', style: TextStyle(color: Colors.grey)),
                )
              else
                Flexible(
                  child: ReorderableListView(
                    shrinkWrap: true,
                    onReorder: (oldIndex, newIndex) async {
                      if (newIndex > oldIndex) newIndex -= 1;
                      final list = List<Volume>.from(volumes);
                      final item = list.removeAt(oldIndex);
                      list.insert(newIndex, item);
                      setState(() => volumes = list);
                      setSheetState(() {});
                      await db.reorderVolumes(list);
                    },
                    children: volumes
                        .map((v) => ListTile(
                              key: ValueKey(v.id),
                              leading: const Icon(Icons.menu_book_outlined),
                              title: Text(v.title),
                              subtitle: v.description.isEmpty ? null : Text(v.description, maxLines: 1, overflow: TextOverflow.ellipsis),
                              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                                IconButton(
                                  icon: const Icon(Icons.edit_outlined, size: 18),
                                  onPressed: () async {
                                    await _addOrEditVolume(existing: v);
                                    setSheetState(() {});
                                  },
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline, size: 18),
                                  onPressed: () async {
                                    await _deleteVolume(v);
                                    setSheetState(() {});
                                  },
                                ),
                              ]),
                            ))
                        .toList(),
                  ),
                ),
            ]),
          ),
        );
      }),
    );
    _load();
  }

  // Gán 1 chương vào quyển nào — bottom sheet chọn nhanh, có tùy chọn
  // "Không thuộc quyển nào" để gỡ khỏi quyển hiện tại.
  Future<void> _assignChapterVolume(Chapter c) async {
    if (volumes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Chưa có quyển/hồi nào — bấm biểu tượng sách ở thanh trên để tạo trước.'),
      ));
      return;
    }
    final chosen = await showModalBottomSheet<String?>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            ListTile(
              leading: const Icon(Icons.remove_circle_outline),
              title: const Text('Không thuộc quyển nào'),
              selected: c.volumeId == null,
              onTap: () => Navigator.pop(context, ''),
            ),
            ...volumes.map((v) => ListTile(
                  leading: const Icon(Icons.menu_book_outlined),
                  title: Text(v.title),
                  selected: c.volumeId == v.id,
                  onTap: () => Navigator.pop(context, v.id),
                )),
          ],
        ),
      ),
    );
    if (chosen == null) return; // bấm ra ngoài, không đổi gì
    c.volumeId = chosen.isEmpty ? null : chosen;
    c.updatedAt = DateTime.now();
    await db.upsertChapter(c);
    _load();
  }

  Future<void> _export(String format) async {
    final all = await db.allChaptersAscending(widget.novelId);
    if (all.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Chưa có chương nào để xuất')));
      return;
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đang tạo file xuất bản...')));
    }
    try {
      final novel = await db.novelById(widget.novelId);
      final exporter = ExportService();
      final file = switch (format) {
        'epub' => await exporter.exportEpub(
            title: widget.novelTitle,
            author: (novel?.author.trim().isNotEmpty ?? false) ? novel!.author : 'Chưa rõ tác giả',
            chapters: all,
          ),
        'docx' => await exporter.exportDocx(title: widget.novelTitle, chapters: all),
        _ => await exporter.exportTxt(title: widget.novelTitle, chapters: all),
      };
      await Share.shareXFiles([XFile(file.path)]);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Lỗi xuất bản: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Chương (${chapters.length})'),
        actions: [
          IconButton(
            icon: const Icon(Icons.menu_book_outlined),
            tooltip: 'Quản lý Quyển/Hồi',
            onPressed: _manageVolumes,
          ),
          IconButton(
            icon: const Icon(Icons.playlist_add_check_outlined),
            tooltip: 'Tạo chương hàng loạt từ outline',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => ChaptersBatchGenerateScreen(novelId: widget.novelId)),
            ).then((_) => _load()),
          ),
          IconButton(
            icon: const Icon(Icons.history_edu_outlined),
            tooltip: 'Gán nguồn (ai viết) cho chương cũ / chữ tự gõ',
            onPressed: _bulkAssignAuthorship,
          ),
          IconButton(
            icon: const Icon(Icons.search_outlined),
            tooltip: 'Tìm kiếm toàn văn',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => SearchScreen(novelId: widget.novelId)),
            ).then((_) => _load()),
          ),
          // ĐÃ THÊM (2026-09-05): công cụ tự quét toàn bộ chương tìm đoạn bị
          // ghi đè bởi thông báo lỗi nội bộ (⚠️ [...]) — xem
          // DataIntegrityService để biết vì sao lỗi này có thể xảy ra
          // (bug ở _applyAllPendingRewrites đã sửa cùng đợt này).
          IconButton(
            icon: const Icon(Icons.health_and_safety_outlined),
            tooltip: 'Kiểm tra dữ liệu bị lỗi',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => DataIntegrityScreen(novelId: widget.novelId)),
            ).then((_) => _load()),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.ios_share_outlined),
            onSelected: _export,
            itemBuilder: (context) => const [
              PopupMenuItem(value: 'epub', child: Text('Xuất EPUB')),
              PopupMenuItem(value: 'docx', child: Text('Xuất DOCX')),
              PopupMenuItem(value: 'txt', child: Text('Xuất TXT')),
            ],
          ),
        ],
      ),
      body: chapters.isEmpty
          ? const Center(child: Text('Chưa có chương nào. Bấm + để bắt đầu.'))
          // ĐÃ THÊM: khi truyện CÓ ít nhất 1 quyển/hồi, danh sách chương
          // hiển thị NHÓM theo quyển (thứ tự quyển đã sắp, chương ascending
          // trong từng nhóm — đúng thứ tự đọc) thay vì danh sách phẳng DESC
          // như trước. Truyện CHƯA dùng tính năng này (volumes rỗng) giữ
          // NGUYÊN 100% hành vi cũ, không đổi gì.
          : (volumes.isEmpty ? _buildFlatList() : _buildGroupedByVolume()),
      floatingActionButton: FloatingActionButton(onPressed: _newChapter, child: const Icon(Icons.add)),
    );
  }

  String authorshipLine(Chapter c) =>
      AuthorshipService.summaryLine(authorship[c.id] ?? const <ChapterAuthorship>[], chapterWords: c.wordCount);

  // MỤC CV2: gán nguồn cho phần chữ "chưa rõ nguồn" của NHIỀU chương cùng lúc — dành cho chương viết trước khi app có ghi nhận hoặc chữ tự gõ. App không tự biết
  // ai viết các chương đó: đây là KHAI BÁO của người dùng (ghi nhận kiểu "Gán thủ công"), gán cho phần chữ chưa có nguồn = chữ hiện có − chữ AI đã ghi.
  Future<void> _bulkAssignAuthorship() async {
    if (chapters.isEmpty) return;
    final current = await SettingsService().currentModelTag(widget.novelId);
    final candidates = await AuthorshipService.candidateTags(db, widget.novelId, current);
    if (!mounted) return;
    final numbers = chapters.map((c) => c.number).toList()..sort();
    final fromCtrl = TextEditingController(text: '${numbers.first}');
    final toCtrl = TextEditingController(text: '${numbers.last}');
    var picked = 0;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Gán nguồn cho chữ chưa rõ nguồn'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Dành cho chương viết trước khi app có ghi nhận, hoặc chữ bạn tự gõ. Phần chữ CHƯA CÓ NGUỒN của các chương trong khoảng dưới đây sẽ được ghi là do '
                  'lựa chọn bên dưới viết. Đây là khai báo của bạn — app không tự biết ai đã viết.',
                  style: TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: fromCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Từ chương'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextField(
                        controller: toCtrl,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'Đến chương'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                for (var i = 0; i < candidates.length; i++)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(picked == i ? Icons.radio_button_checked : Icons.radio_button_unchecked),
                    title: Text('${candidates[i].icon} ${candidates[i].display}${i == 1 ? ' (đang dùng)' : ''}'),
                    onTap: () => setLocal(() => picked = i),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Huỷ')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Gán')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final from = int.tryParse(fromCtrl.text.trim()) ?? numbers.first;
    final to = int.tryParse(toCtrl.text.trim()) ?? numbers.last;
    final tag = candidates[picked];
    var count = 0;
    var totalWords = 0;
    for (final c in chapters) {
      if (c.number < from || c.number > to) continue;
      final unknown = AuthorshipService.unknownWords(c.wordCount, authorship[c.id] ?? const <ChapterAuthorship>[]);
      if (unknown < 1) continue;
      await AuthorshipService.recordWords(
        db: db,
        chapterId: c.id,
        novelId: widget.novelId,
        action: 'gan_tay',
        tag: tag,
        words: unknown,
      );
      count++;
      totalWords += unknown;
    }
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(count == 0
          ? 'Không có chương nào trong khoảng $from–$to còn chữ chưa rõ nguồn.'
          : 'Đã gán $totalWords chữ của $count chương cho ${tag.display}.'),
    ));
  }

  Widget _chapterTile(Chapter c) {
    // ĐÃ SỬA (theo báo cáo người dùng): trước đây cách DUY NHẤT để gán/đổi
    // quyển của 1 chương là chạm-giữ (long-press) — không icon, không gợi
    // ý, gần như không ai tìm ra được, khiến quyển và chương trong thực tế
    // luôn "nằm riêng lẻ" dù tính năng gán đã có sẵn trong code. Giờ thêm
    // hẳn 1 nút bấm rõ ràng ở cuối dòng (icon sách + tên quyển hiện tại,
    // hoặc "Gán quyển" nếu chưa có) — vẫn giữ long-press song song để
    // không đổi hành vi cũ. Nút chỉ hiện khi truyện ĐÃ có ít nhất 1 quyển
    // (volumes.isEmpty thì không tốn chỗ hiển thị 1 nút vô dụng).
    // Không dùng `firstOrNull` (thuộc package `collection`, chưa có trong
    // pubspec.yaml của project) — viết tay bằng try/catch trên
    // `firstWhere` để không phải thêm dependency mới chỉ cho 1 chỗ.
    String? currentVolumeTitle;
    if (c.volumeId != null) {
      try {
        currentVolumeTitle = volumes.firstWhere((v) => v.id == c.volumeId).title;
      } catch (_) {
        currentVolumeTitle = null; // quyển đã bị xoá nhưng chương còn giữ id cũ
      }
    }
    return ListTile(
      title: Text('Chương ${c.number}: ${c.title}'),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${c.wordCount} chữ'
            '${c.consistencyWarning != null ? ' · có cảnh báo nhất quán' : ''}'
            // ĐÃ THÊM: hiện rõ chương nào có outline nhưng chưa
            // viết ("chương mồi" đang chờ) — để biết còn gì cần
            // xử lý qua "Tạo chương hàng loạt" mà không cần mở
            // từng chương ra xem.
            '${(c.outline?.trim().isNotEmpty ?? false) && c.content.trim().isEmpty ? ' · có outline, chưa viết' : ''}',
          ),
          // MỤC CV: dòng "model nào viết" (chỉ phần AI thêm; chữ gõ tay không ghi). Rỗng nếu chưa có dữ liệu.
          if (authorshipLine(c).isNotEmpty)
            Text(
              authorshipLine(c),
              style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
        ],
      ),
      leading: Icon(
        c.consistencyWarning != null
            ? Icons.warning_amber_rounded
            : (c.consistencyChecked ? Icons.check_circle_outline : Icons.circle_outlined),
        color: c.consistencyWarning != null ? Colors.orange : null,
      ),
      trailing: volumes.isEmpty
          ? null
          : ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 110),
              child: TextButton.icon(
                onPressed: () => _assignChapterVolume(c),
                icon: const Icon(Icons.menu_book_outlined, size: 18),
                label: Text(
                  currentVolumeTitle ?? 'Gán quyển',
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
      // Giữ chạm giữ song song cho ai đã quen thao tác cũ.
      onLongPress: () => _assignChapterVolume(c),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ChapterEditorScreen(chapter: c)),
      ).then((_) => _load()),
    );
  }

  Widget _buildFlatList() {
    return ListView.builder(
      itemCount: chapters.length,
      itemBuilder: (context, i) => _chapterTile(chapters[i]),
    );
  }

  Widget _buildGroupedByVolume() {
    final byVolume = <String?, List<Chapter>>{};
    for (final c in chapters) {
      byVolume.putIfAbsent(c.volumeId, () => []).add(c);
    }
    for (final list in byVolume.values) {
      list.sort((a, b) => a.number.compareTo(b.number));
    }
    final sections = <Widget>[];
    for (final v in volumes) {
      final inVolume = byVolume[v.id] ?? [];
      // ĐÃ SỬA (theo báo cáo người dùng: "tạo nhiều quyển mà thấy có 1
      // quyển"): trước đây quyển CHƯA có chương nào bị ẨN HẲN khỏi danh
      // sách này (chỉ còn thấy trong "Quản lý Quyển/Hồi" bên dưới) — kết
      // hợp với việc chương mới giờ TỰ NỐI TIẾP quyển của chương gần nhất
      // (xem sửa ở _newChapter), các quyển tạo sau gần như CHẮC CHẮN sẽ
      // trống mãi cho tới khi người dùng chủ động dùng nút "Gán quyển" —
      // khiến người dùng tạo 3 quyển nhưng chỉ thấy 1 quyển hiện ra, tưởng
      // 2 quyển kia biến mất/lỗi. Giờ LUÔN hiện đủ mọi quyển đã tạo, quyển
      // trống có ghi chú "(chưa có chương)" thay vì ẩn đi — để cấu trúc
      // quyển/hồi luôn khớp với "Quản lý Quyển/Hồi", không gây hiểu lầm.
      sections.add(Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        child: Text(
          inVolume.isEmpty ? '${v.title} (chưa có chương)' : v.title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: inVolume.isEmpty ? Theme.of(context).colorScheme.outline : null,
          ),
        ),
      ));
      sections.addAll(inVolume.map(_chapterTile));
    }
    final unassigned = (byVolume[null] ?? [])..sort((a, b) => a.number.compareTo(b.number));
    if (unassigned.isNotEmpty) {
      sections.add(Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        color: Theme.of(context).colorScheme.surfaceContainerHighest,
        child: const Text('Chưa gom quyển', style: TextStyle(fontWeight: FontWeight.bold)),
      ));
      sections.addAll(unassigned.map(_chapterTile));
    }
    return ListView(children: sections);
  }
}

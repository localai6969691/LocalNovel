import 'dart:convert';
import 'package:flutter/material.dart';
import '../services/settings_service.dart';
import '../services/sampling_profile_service.dart';
import '../services/providers/local_provider.dart';
import '../services/database_service.dart';
import '../services/prefill_budget.dart';

class GenerationSettingsScreen extends StatefulWidget {
  // ĐÃ SỬA (v13 — theo câu hỏi người dùng: "cài đặt riêng từng truyện hay
  // chung cả app?"): 4 cài đặt "Tự tóm tắt cốt truyện luỹ kế" bên dưới giờ
  // RIÊNG CHO TỪNG TRUYỆN (đọc/ghi cột trong bảng `novels`), bắt buộc phải
  // biết đang ở truyện nào.
  // ĐÃ SỬA THÊM (v14 — người dùng phản đối trực tiếp giả định "model không
  // phải nội dung truyện nên dùng chung" ở mục 2.1 tài liệu kiến trúc):
  // 5 tham số sinh văn bản (temperature...) ở TRÊN giờ CŨNG RIÊNG TỪNG
  // TRUYỆN — không còn "vẫn chung toàn app" như comment cũ ở đây từng ghi.
  final String novelId;
  const GenerationSettingsScreen({super.key, required this.novelId});
  @override
  State<GenerationSettingsScreen> createState() => _GenerationSettingsScreenState();
}

class _GenerationSettingsScreenState extends State<GenerationSettingsScreen> {
  final settings = SettingsService();
  final db = DatabaseService.instance;
  double temperature = 0.8;
  double topP = 0.9;
  int topK = 40;
  double repetitionPenalty = 1.15; // ĐÃ SỬA: đồng bộ mặc định mới với settings_service.dart (xem giải thích ở đó)
  int maxNewTokens = 1024;
  bool loading = true;
  // ĐÃ THÊM (theo câu hỏi người dùng: "có làm ai local chậm hơn không nếu
  // chương phình to") — xem giải thích chi phí đầy đủ ở
  // RagService.updateCumulativeStorySummary().
  bool plotSummaryEnabled = true;
  int plotSummaryInterval = 1;
  // ĐÃ THÊM (theo đề xuất người dùng — nguồn rẻ hơn thay vì luôn đọc lại
  // toàn bộ nội dung chương): xem giải thích đầy đủ ở story_models.dart
  // (Novel.plotSummaryPreferTimeline/PreferOutline) và RagService.
  bool plotSummaryPreferTimeline = true;
  bool plotSummaryPreferOutline = true;
  // MỤC CV (2026-10-13): cài đặt "Viết chương" (cách chia lượt, số chữ mục tiêu) và ngân sách Story Bible khi dùng API — RIÊNG TỪNG TRUYỆN (SharedPreferences).
  String writeMode = 'auto';
  bool customTarget = false;
  int targetWords = 600;
  int apiBudget = 4000;
  String modelKind = 'local'; // 'local' | 'api' | 'web' — model chính đang chọn của truyện
  // MỤC CV3 (2026-10-15): trần giây nạp prompt (toàn app), số đo tốc độ nạp của model chính, bậc Bible đã học (chống model chép lại prompt).
  int prefillTargetSec = PrefillBudget.kDefaultTargetSec;
  double? prefillSpeed;
  int echoLevel = 0;
  String modelKey = '';
  // MỤC DL (2026-10-23): ghi đè lấy mẫu cho model local (áp cho MỌI truyện dùng model local trên máy này; mặc định TẮT ⇒ hành vi không đổi).
  bool samplerOverrideOn = false;
  final TextEditingController samplerJsonCtl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    samplerJsonCtl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final cfg = await settings.loadGenerationConfig(widget.novelId);
    final novel = await db.novelById(widget.novelId);
    final wMode = await settings.loadChapterWriteMode(widget.novelId);
    final wCustom = await settings.hasCustomChapterTargetWords(widget.novelId);
    final wTarget = await settings.loadChapterTargetWords(widget.novelId);
    final wBudget = await settings.loadApiRagBudget(widget.novelId);
    final tag = await settings.currentModelTag(widget.novelId);
    final mKey = '${tag.kind}|${tag.provider}|${tag.modelId}';
    final pTarget = await settings.loadPrefillTargetSec();
    final pSpeed = await settings.loadPrefillSpeed(PrefillBudget.speedKey(mKey, null));
    final eLevel = await settings.loadEchoGuardLevel(mKey);
    final samplerOv = await SamplingProfileService.loadAppOverride();
    if (!mounted) return;
    setState(() {
      samplerOverrideOn = samplerOv.enabled;
      samplerJsonCtl.text = samplerOv.params.isEmpty ? '' : const JsonEncoder.withIndent('  ').convert(samplerOv.params);
      modelKey = mKey;
      prefillTargetSec = pTarget;
      prefillSpeed = pSpeed;
      echoLevel = eLevel;
      writeMode = wMode;
      customTarget = wCustom;
      targetWords = wTarget;
      apiBudget = wBudget;
      modelKind = tag.kind;
      temperature = cfg.temperature;
      topP = cfg.topP;
      topK = cfg.topK;
      repetitionPenalty = cfg.repetitionPenalty;
      maxNewTokens = cfg.maxNewTokens;
      // novel == null không nên xảy ra (novelId truyền vào luôn là truyện
      // đang active) — nếu có, giữ mặc định an toàn thay vì crash màn hình.
      plotSummaryEnabled = novel?.plotSummaryEnabled ?? true;
      plotSummaryInterval = novel?.plotSummaryInterval ?? 1;
      plotSummaryPreferTimeline = novel?.plotSummaryPreferTimeline ?? true;
      plotSummaryPreferOutline = novel?.plotSummaryPreferOutline ?? true;
      loading = false;
    });
  }

  Future<void> _save() async {
    await settings.saveGenerationConfig(
      widget.novelId,
      temperature: temperature,
      topP: topP,
      topK: topK,
      repetitionPenalty: repetitionPenalty,
      maxNewTokens: maxNewTokens,
    );
    await db.updateNovelPlotSummarySettings(
      widget.novelId,
      enabled: plotSummaryEnabled,
      interval: plotSummaryInterval,
      preferTimeline: plotSummaryPreferTimeline,
      preferOutline: plotSummaryPreferOutline,
    );
    await settings.saveChapterWriteMode(widget.novelId, writeMode);
    if (customTarget) {
      await settings.saveChapterTargetWords(widget.novelId, targetWords);
    } else {
      await settings.clearChapterTargetWords(widget.novelId);
    }
    await settings.saveApiRagBudget(widget.novelId, apiBudget);
    await settings.savePrefillTargetSec(prefillTargetSec);
    // MỤC DL: ghi đè lấy mẫu của model local. Sampler của MNN chỉ đọc cấu hình lúc NẠP (mục DI) nên sau khi đổi hiệu lực phải xả model ĐANG RẢNH
    // (native đặt cờ "cần nạp lại" ⇒ lần dùng kế tiếp tự nạp lại và dựng hồ sơ mới). Slot đang bận thì KHÔNG xả (tránh cắt lệnh sinh đang chạy).
    var overrideNote = '';
    if (modelKind == 'local') {
      final r = await SamplingProfileService.saveAppOverride(enabled: samplerOverrideOn, jsonText: samplerJsonCtl.text);
      if (!r.ok) {
        overrideNote = ' ⚠️ Ghi đè lấy mẫu CHƯA lưu: ${r.message}';
      } else {
        if (r.message.isNotEmpty) overrideNote = ' ${r.message}.';
        if (r.changed) {
          var released = 0;
          // Ghi đè chỉ áp cho model CHÍNH (slot 0) — không xả slot 1 (dịch thuật/tài liệu) vì nó không bị ảnh hưởng.
          if (await LocalLlamaProvider.unloadSlotIfIdle(0)) released++;
          overrideNote += released > 0
              ? ' Đã xả model đang rảnh — lần dùng tới sẽ nạp lại với cách lấy mẫu mới (mất ~25–50 giây).'
              : ' Chưa xả được model (đang bận) — cách lấy mẫu mới có hiệu lực ở lần nạp model kế tiếp.';
        }
      }
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        duration: const Duration(seconds: 8),
        content: Text(modelKind == 'local'
            ? 'Đã lưu. Với model local, 4 thanh trượt lấy mẫu (temperature/top_p/top_k/repetition_penalty) chưa đổi được sampler lúc sinh — xem mục "Lấy mẫu của model local".$overrideNote'
            : 'Đã lưu — áp dụng ngay từ lần sinh văn bản tiếp theo, không cần nạp lại model'),
      ));
    }
  }

  // MỤC DL (2026-10-23) — nối "tham số lấy mẫu" vào hồ sơ của model local. Chỉ hiện khi model chính là LOCAL.
  List<Widget> _samplerOverrideSection(BuildContext context) {
    return [
      const Divider(height: 32),
      Text('Lấy mẫu của model local (nâng cao)', style: Theme.of(context).textTheme.titleSmall),
      const SizedBox(height: 4),
      const Text(
        'Theo mã MNN 3.6.1 đã đọc (tài liệu kiến trúc, mục DI), sampler chỉ đọc cấu hình lúc NẠP model: 4 thanh trượt ở trên vẫn được gửi lúc sinh nhưng KHÔNG đổi được cách lấy mẫu '
        'của model local. Cách lấy mẫu local hiện lấy từ hồ sơ tự động theo model (generation_config.json của model hoặc bảng họ model có nguồn dẫn, mục DJ/DK); không nhận dạng được '
        'thì dùng bộ mặc định chung trong config.json của model. Muốn tự thử, bật ghi đè bên dưới: các khoá trong JSON thay khoá cùng tên của hồ sơ (áp cho MỌI truyện dùng model '
        'local trên máy này) và có hiệu lực khi model nạp lại — nút Lưu sẽ xả model đang rảnh để lần dùng tới nạp lại. Chỉ áp cho model chính (không áp cho model dịch thuật trung gian / tài liệu). Mặc định TẮT.',
        style: TextStyle(fontSize: 12, color: Colors.grey),
      ),
      SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('Ghi đè hồ sơ lấy mẫu của model local'),
        value: samplerOverrideOn,
        onChanged: (v) => setState(() => samplerOverrideOn = v),
      ),
      if (samplerOverrideOn) ...[
        TextField(
          controller: samplerJsonCtl,
          minLines: 4,
          maxLines: 12,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 13),
          decoration: const InputDecoration(
            border: OutlineInputBorder(),
            labelText: 'JSON ghi đè (chỉ ghi các khoá muốn đổi)',
            hintText: '{"repetition_penalty": 1.0, "dry_multiplier": 0.8, "dry_allowed_length": 8}',
          ),
        ),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 4, children: [
          OutlinedButton(
            onPressed: () => setState(() {
              samplerJsonCtl.text = const JsonEncoder.withIndent('  ').convert({
                'temperature': double.parse(temperature.toStringAsFixed(2)),
                'top_p': double.parse(topP.toStringAsFixed(2)),
                'top_k': topK,
                'repetition_penalty': double.parse(repetitionPenalty.toStringAsFixed(2)),
              });
            }),
            child: const Text('Điền từ 4 thanh trượt'),
          ),
          OutlinedButton(
            onPressed: () => setState(() => samplerJsonCtl.clear()),
            child: const Text('Xoá nội dung'),
          ),
        ]),
        const SizedBox(height: 8),
        Text(
          'Khoá hợp lệ (khoá lạ hoặc ngoài miền bị bỏ khi lưu): ${SamplingProfileService.validKeysHelp}. '
          'dry_* và xtc_* chỉ có tác dụng với MNN đã được vá trong CI (mục DI). '
          'Lưu ý: repetition_penalty > 1.0 mà không đặt penalty_window sẽ phạt trên TOÀN BỘ lịch sử gồm cả prompt dài (mặc định của MNN = 0); hồ sơ Qwen3 dùng cửa sổ 64.',
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ],
    ];
  }

  Widget _sliderRow({
    required String label,
    required String helpText,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required void Function(double) onChanged,
    String Function(double)? displayFormat,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
          Text(displayFormat?.call(value) ?? value.toStringAsFixed(2)),
        ]),
        Text(helpText, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        Slider(value: value, min: min, max: max, divisions: divisions, onChanged: onChanged),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Tham số sinh văn bản'), actions: [
        TextButton(onPressed: _save, child: const Text('Lưu', style: TextStyle(color: Colors.white))),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text(
          'Áp dụng cho model chính (viết chương + chat) — model dịch thuật trung '
          'gian (nếu bật) dùng cấu hình cố định riêng, ưu tiên chính xác hơn sáng tạo.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const Divider(height: 24),
        _sliderRow(
          label: 'Temperature',
          helpText: 'Độ sáng tạo/ngẫu nhiên. Thấp → văn chắc chắn, dễ lặp khuôn mẫu. Cao → đa dạng hơn nhưng dễ lạc đề nếu quá cao.',
          value: temperature,
          min: 0.1,
          max: 1.5,
          divisions: 28,
          onChanged: (v) => setState(() => temperature = v),
        ),
        _sliderRow(
          label: 'top_p (nucleus sampling)',
          helpText: 'Chỉ chọn trong nhóm từ có tổng xác suất cộng dồn đạt tới p. Giá trị phổ biến: 0.9.',
          value: topP,
          min: 0.1,
          max: 1.0,
          divisions: 18,
          onChanged: (v) => setState(() => topP = v),
        ),
        _sliderRow(
          label: 'top_k',
          helpText: 'Chỉ chọn trong đúng k từ có xác suất cao nhất tại mỗi bước. Giá trị phổ biến: 40.',
          value: topK.toDouble(),
          min: 1,
          max: 100,
          divisions: 99,
          displayFormat: (v) => v.round().toString(),
          onChanged: (v) => setState(() => topK = v.round()),
        ),
        _sliderRow(
          label: 'repetition_penalty',
          helpText: 'Phạt các từ/cụm đã xuất hiện trước đó — tăng lên nếu thấy AI lặp từ vô nghĩa.',
          value: repetitionPenalty,
          min: 1.0,
          max: 2.0,
          divisions: 20,
          onChanged: (v) => setState(() => repetitionPenalty = v),
        ),
        _sliderRow(
          label: 'max_new_tokens (độ dài tối đa mỗi lần sinh)',
          helpText: 'Giới hạn độ dài đoạn văn AI sinh ra mỗi lần — không phải giới hạn tổng ngữ cảnh (context_length quản lý riêng ở RAG, xem "Tối ưu AI local").',
          value: maxNewTokens.toDouble(),
          min: 128,
          max: 4096,
          divisions: 31,
          displayFormat: (v) => v.round().toString(),
          onChanged: (v) => setState(() => maxNewTokens = v.round()),
        ),
        if (modelKind == 'local') ..._samplerOverrideSection(context),
        const Divider(height: 32),
        Text('Viết chương theo từng ý', style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 4),
        const Text(
          // Giải thích thật, kể cả đánh đổi — không hứa chất lượng chưa đo.
          'Áp dụng cho "Đắp thịt" và "Tạo chương hàng loạt". Thay vì gửi cả dàn ý trong 1 lần (dễ viết kỹ các ý đầu rồi lướt qua các ý sau, và cụt giữa câu khi hết '
          'token), app tách dàn ý thành từng ý, đặt số chữ cho từng phần, và phần cuối được dặn khép chương gọn. Chia càng nhiều lượt thì càng đều tay nhưng càng tốn thời gian '
          '(model local nạp lại prompt mỗi lượt) hoặc số yêu cầu API. Chất lượng thực tế chưa được đo trên máy — hãy thử và chọn chế độ hợp với bạn.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: writeMode,
          decoration: const InputDecoration(labelText: 'Cách chia lượt', border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'auto', child: Text('Tự động (local: 2 phần · API: từng ý · web chat: 1 lượt)')),
            DropdownMenuItem(value: 'single', child: Text('1 lượt (nhanh nhất, dễ đầu voi đuôi chuột nhất)')),
            DropdownMenuItem(value: 'two_part', child: Text('2 phần: thân + phần kết riêng')),
            DropdownMenuItem(value: 'beats', child: Text('Từng ý 1 lượt (đều tay nhất, tốn lượt nhất)')),
          ],
          onChanged: (v) => setState(() => writeMode = v ?? 'auto'),
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: Text('Tự đặt số chữ mục tiêu mỗi chương', style: Theme.of(context).textTheme.bodyMedium)),
          Switch(value: customTarget, onChanged: (v) => setState(() => customTarget = v)),
        ]),
        if (customTarget)
          _sliderRow(
            label: 'Số chữ mục tiêu mỗi chương',
            helpText: 'Chia đều cho các ý. Tính theo "chữ" (tách khoảng trắng, như bộ đếm của app). Thay cho max_new_tokens ở trên khi viết theo từng ý. '
                'Model nhỏ thường viết ngắn hơn chỉ tiêu.',
            value: targetWords.toDouble().clamp(150.0, 3000.0).toDouble(),
            min: 150,
            max: 3000,
            divisions: 57,
            displayFormat: (v) => '${v.round()} chữ',
            onChanged: (v) => setState(() => targetWords = (v / 50).round() * 50),
          )
        else
          Text(
            'Đang dùng mặc định theo loại model: $targetWords chữ (local 600, API 1200).',
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
        const SizedBox(height: 8),
        _sliderRow(
          label: 'Ngân sách Story Bible khi dùng API (ký tự)',
          helpText: modelKind == 'local'
              ? 'Model chính hiện là model LOCAL nên số này CHƯA dùng (local dùng ngân sách ở "Tối ưu AI local"); áp dụng khi truyện chuyển sang API. '
                  'Giữ nhỏ để tiết kiệm token: gói miễn phí như Groq giới hạn ~8.000 token/phút, 1 yêu cầu lớn hơn mức đó sẽ bị từ chối.'
              : 'Lượng chữ Story Bible + chương liên quan được đưa vào MỖI lần gọi (≈ 1 token mỗi 2,5-3 ký tự tiếng Việt). Nhỏ hơn = rẻ và nhanh hơn, ít ngữ cảnh hơn; '
                  'gói miễn phí giới hạn token/phút nên đừng đặt quá lớn.',
          value: apiBudget.toDouble().clamp(800.0, 16000.0).toDouble(),
          min: 800,
          max: 16000,
          divisions: 76,
          displayFormat: (v) => '${v.round()}',
          onChanged: (v) => setState(() => apiBudget = (v / 200).round() * 200),
        ),
        const Divider(height: 32),
        Text('Tự hạ ngân sách prompt theo tốc độ nạp (model local)', style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 4),
        const Text(
          'Model local phải nạp lại cả prompt (vai trò + văn phong + Story Bible + kế hoạch + đoạn vừa viết) ở MỖI lượt viết — trên CPU có thể mất vài phút chỉ để nạp. '
          'App đo thời gian từ lúc gửi prompt tới chữ đầu tiên (số đo gián tiếp, không phải số token thật) để biết máy/backend này nạp được bao nhiêu ký tự mỗi giây, rồi '
          'tự thu ngắn đoạn vừa viết và Story Bible sao cho thời gian nạp không vượt số giây dưới đây. Đổi lại Bible ít chi tiết hơn (luôn giữ tối thiểu ~500 ký tự Bible '
          'và ~300 ký tự đoạn vừa viết). Lượt viết local ĐẦU TIÊN chưa có số đo nên chạy đủ ngân sách; từ lượt sau mới áp dụng. Đặt 0 để tắt.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        _sliderRow(
          label: 'Thời gian nạp prompt tối đa mỗi lượt',
          helpText: prefillSpeed == null
              ? 'Chưa có số đo tốc độ nạp cho model này (sẽ đo sau lượt viết local đầu tiên).'
              : 'Đã đo: ~${prefillSpeed!.toStringAsFixed(1)} ký tự/giây => trần prompt ≈ ${PrefillBudget.maxPromptChars(prefillSpeed, prefillTargetSec) ?? 0} ký tự'
                  '${prefillTargetSec <= 0 ? ' (đang tắt nên không áp dụng)' : ''}. Số đo có thể lệch khi máy nóng.',
          value: prefillTargetSec.toDouble().clamp(0.0, 600.0).toDouble(),
          min: 0,
          max: 600,
          divisions: 20,
          displayFormat: (v) => v.round() <= 0 ? 'Tắt' : '${v.round()} giây',
          onChanged: (v) => setState(() => prefillTargetSec = (v / 30).round() * 30),
        ),
        Row(children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () async {
                await settings.clearPrefillSpeed(PrefillBudget.speedKey(modelKey, null));
                if (mounted) setState(() => prefillSpeed = null);
              },
              child: const Text('Xoá số đo tốc độ'),
            ),
          ),
        ]),
        const SizedBox(height: 12),
        Text(
          echoLevel == 0
              ? 'Chống "chép lại prompt": model này chưa từng chép lại Story Bible/kế hoạch khi viết — dùng Bible đầy đủ.'
              : 'Chống "chép lại prompt": model này từng chép lại prompt thay vì viết truyện nên đang bắt đầu từ bậc Bible ${echoLevel == 1 ? '"ngắn" (35% ngân sách)' : '"không Bible"'}. '
                  'Bấm nút dưới để thử lại với Bible đầy đủ.',
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        ),
        if (echoLevel > 0)
          OutlinedButton(
            onPressed: () async {
              await settings.clearEchoGuardLevel(modelKey);
              if (mounted) setState(() => echoLevel = 0);
            },
            child: const Text('Đặt lại bậc Bible về đầy đủ'),
          ),
        const Divider(height: 32),
        Row(children: [
          Expanded(
            child: Text('Tự tóm tắt cốt truyện luỹ kế', style: Theme.of(context).textTheme.titleSmall),
          ),
          Switch(value: plotSummaryEnabled, onChanged: (v) => setState(() => plotSummaryEnabled = v)),
        ]),
        const Text(
          // ĐÃ SỬA (v13): ghi rõ đây là cài đặt RIÊNG CHO TRUYỆN ĐANG MỞ,
          // không còn dùng chung cho mọi truyện — trước đây gây hiểu lầm
          // hợp lý (đổi ở đây tưởng ảnh hưởng truyện khác đang viết cùng
          // lúc, thực ra không).
          'Riêng cho truyện đang mở. Sau mỗi chương hoàn thành, AI nén thêm vào 1 bản tóm tắt '
          'cốt truyện luỹ kế, LUÔN được đưa vào ngữ cảnh ở mọi chương sau — kể cả chương cách xa '
          'hàng trăm chương — để tránh viết mâu thuẫn với chuyện đã xảy ra từ lâu.\n'
          'Đánh đổi: tốn THÊM 1 lượt gọi AI riêng sau mỗi chương (dùng model chính, có thể '
          'nặng nếu đang chạy model local), và mọi chương viết SAU đó đều cõng thêm ngữ cảnh '
          'này vào prompt — máy yếu chạy model local sẽ thấy rõ chậm hơn. Tắt hẳn nếu ưu tiên '
          'tốc độ hơn độ đồng bộ xuyên suốt truyện dài.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
        if (plotSummaryEnabled) ...[
          const SizedBox(height: 8),
          _sliderRow(
            label: 'Giãn cách cập nhật (số chương)',
            helpText: '1 = cập nhật sau MỖI chương (đồng bộ chặt nhất, tốn AI nhiều nhất). '
                'Tăng lên để gộp nhiều chương mới gọi AI 1 lần — giảm số lượt gọi phụ trội đúng '
                'theo hệ số này, đổi lại tóm tắt "cũ" hơn tối đa (N-1) chương tại bất kỳ lúc nào '
                '(không mất dữ liệu, chỉ gộp trễ hơn).',
            value: plotSummaryInterval.toDouble(),
            min: 1,
            max: 20,
            divisions: 19,
            displayFormat: (v) => v.round().toString(),
            onChanged: (v) => setState(() => plotSummaryInterval = v.round()),
          ),
          const SizedBox(height: 8),
          // ĐÃ THÊM (theo đề xuất người dùng — ưu tiên nguồn RẺ HƠN thay vì
          // luôn đọc lại toàn bộ nội dung chương): xem giải thích đầy đủ ở
          // story_models.dart và RagService._doUpdateCumulativeStorySummary.
          Row(children: [
            Expanded(
              child: Text('Ưu tiên Dòng thời gian (nếu chương đã có)', style: Theme.of(context).textTheme.bodyMedium),
            ),
            Switch(value: plotSummaryPreferTimeline, onChanged: (v) => setState(() => plotSummaryPreferTimeline = v)),
          ]),
          const Text(
            'Nếu chương vừa xong đã có sẵn sự kiện Dòng thời gian (tự nhập tay hoặc bấm "AI gợi ý"), '
            'dùng đúng các sự kiện đó làm nguyên liệu nén tóm tắt — ngắn gọn hơn, đã lọc qua Bách '
            'khoa, KHÔNG tốn thêm lượt gọi AI nào để lấy. Không tự tạo sự kiện mới ở đây; chương nào '
            'chưa có Dòng thời gian thì rơi xuống nguồn tiếp theo bên dưới.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: Text('Ưu tiên dàn ý/outline (nếu chương đã có)', style: Theme.of(context).textTheme.bodyMedium),
            ),
            Switch(value: plotSummaryPreferOutline, onChanged: (v) => setState(() => plotSummaryPreferOutline = v)),
          ]),
          const Text(
            'Dùng dàn ý đã viết sẵn của chương (thường có với "Tạo chương hàng loạt") thay vì đọc '
            'lại nội dung — rẻ nhất vì có TRƯỚC khi chương tồn tại. Xếp SAU Dòng thời gian ở trên: '
            'dàn ý là KẾ HOẠCH, có thể lệch so với nội dung THỰC SỰ đã viết ra nếu AI đắp thịt khác '
            'outline. Chương không có cả 2 nguồn trên vẫn dùng cách cũ (đọc autoSummary/nội dung).',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ]),
    );
  }
}

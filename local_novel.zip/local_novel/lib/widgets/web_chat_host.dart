import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../services/ai_provider.dart';
import '../services/web_chat/web_chat_session.dart';

// MỤC CS (2026-10-07) — GẮN WEBVIEW CỦA "WEB CHAT AI" VÀO CÂY WIDGET (đặt ở MaterialApp.builder, bọc ngoài Navigator).
//
// 3 TRẠNG THÁI của WebView (luôn cùng 1 widget + GlobalKey để KHÔNG bị tạo lại — tạo lại sẽ nạp lại trang):
//   - chưa cần          : không dựng gì.
//   - rảnh (đã từng dùng): thu còn 1x1 điểm ảnh ở góc, không nhận chạm.
//   - đang chạy yêu cầu : phủ kín màn hình nhưng NẰM DƯỚI giao diện app — trang có kích thước thật nên các kiểm tra "phần tử đang hiện" đúng,
//                         người dùng không thấy gì (giao diện app che lên). Hiện thanh trạng thái nhỏ có nút Xem/Dừng.
//   - mở cho người dùng : hiện trên cùng, có thanh công cụ (Xong/Tải lại/Dạy app); giao diện app tạm ẩn bằng Offstage (state vẫn giữ nguyên).
// LƯU Ý: lớp này nằm TRÊN Navigator nên KHÔNG dùng được widget cần Navigator/Overlay (PopupMenu, Dialog, Tooltip, SnackBar) — dùng nút thường + vùng chữ.
class WebChatHost extends StatelessWidget {
  final Widget child;
  const WebChatHost({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final s = WebChatSession.instance;
    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[s.everNeeded, s.expanded, s.activeUsers, s.status]),
      builder: (context, _) {
        final mq = MediaQuery.of(context);
        final expanded = s.expanded.value;
        final active = s.activeUsers.value > 0;
        final full = expanded || active;
        final toolbarH = mq.padding.top + 52;
        return Stack(
          textDirection: TextDirection.ltr,
          children: <Widget>[
            if (s.everNeeded.value)
              Positioned(
                key: const ValueKey<String>('ln_webchat_view'),
                left: 0,
                right: full ? 0 : null,
                width: full ? null : 1,
                bottom: 0,
                top: expanded ? toolbarH : (active ? 0 : null),
                height: full ? null : 1,
                child: IgnorePointer(
                  ignoring: !expanded,
                  child: WebViewWidget(key: s.viewKey, controller: s.controller),
                ),
              ),
            Positioned.fill(
              key: const ValueKey<String>('ln_webchat_app'),
              child: Offstage(offstage: expanded, child: child),
            ),
            if (expanded)
              Positioned(
                key: const ValueKey<String>('ln_webchat_toolbar'),
                top: 0,
                left: 0,
                right: 0,
                child: _Toolbar(session: s, height: toolbarH, topInset: mq.padding.top),
              ),
            if (expanded)
              Positioned(
                key: const ValueKey<String>('ln_webchat_teach'),
                left: 0,
                right: 0,
                top: toolbarH,
                child: _TeachPanel(session: s),
              ),
            if (active && !expanded)
              Positioned(
                key: const ValueKey<String>('ln_webchat_pill'),
                left: 12,
                right: 12,
                bottom: 12 + mq.padding.bottom,
                child: Material(
                  elevation: 6,
                  borderRadius: BorderRadius.circular(24),
                  color: Theme.of(context).colorScheme.secondaryContainer,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                    child: Row(children: <Widget>[
                      const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                      const SizedBox(width: 10),
                      Expanded(child: Text(s.status.value, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12))),
                      TextButton(onPressed: () => s.expanded.value = true, child: const Text('Xem')),
                      TextButton(onPressed: s.cancelCurrent, child: const Text('Dừng')),
                    ]),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _Toolbar extends StatelessWidget {
  final WebChatSession session;
  final double height;
  final double topInset;
  const _Toolbar({required this.session, required this.height, required this.topInset});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      elevation: 4,
      color: cs.surface,
      child: SizedBox(
        height: height,
        child: Padding(
          padding: EdgeInsets.only(top: topInset, left: 4, right: 4),
          child: Row(children: <Widget>[
            TextButton.icon(
              onPressed: session.closeForUser,
              icon: const Icon(Icons.check, size: 18),
              label: const Text('Xong'),
            ),
            IconButton(
              onPressed: () async {
                await session.goBackIfPossible();
              },
              icon: const Icon(Icons.arrow_back, size: 20),
            ),
            IconButton(onPressed: session.reloadPage, icon: const Icon(Icons.refresh, size: 20)),
            const SizedBox(width: 4),
            Expanded(
              child: ValueListenableBuilder<String>(
                valueListenable: session.status,
                builder: (_, v, __) => Text(
                  v.isEmpty ? session.label : v,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11.5),
                ),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

// Bảng "Dạy app": chọn ô nhập / nút gửi / vùng trả lời bằng cách chạm vào trang; gửi tin thử; chẩn đoán.
class _TeachPanel extends StatefulWidget {
  final WebChatSession session;
  const _TeachPanel({required this.session});

  @override
  State<_TeachPanel> createState() => _TeachPanelState();
}

class _TeachPanelState extends State<_TeachPanel> {
  bool open = false;
  bool busy = false;
  String info = '';

  Future<void> _run(Future<String> Function() action) async {
    if (busy) return;
    // Thu bảng lại để KHÔNG che trang trong lúc bạn cần chạm vào phần tử cần chọn.
    setState(() {
      busy = true;
      info = '';
      open = false;
    });
    String result;
    try {
      result = await action();
    } catch (e) {
      result = 'Lỗi: $e';
    }
    if (!mounted) return;
    setState(() {
      busy = false;
      info = result;
    });
  }

  Future<String> _pick(String kind, String hint) async {
    widget.session.status.value = hint;
    final r = await widget.session.pick(kind);
    if (r['ok'] == true) {
      return 'Đã lưu "$kind": ${r['selector']}  (khớp ${r['matches']} phần tử). Mẫu: ${r['sample']}';
    }
    return 'Không chọn được: ${r['e'] ?? r}';
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.session;
    return Material(
      elevation: 8,
      color: Theme.of(context).colorScheme.surfaceContainerHigh,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 2, 8, 4),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
          Row(children: <Widget>[
            TextButton.icon(
              onPressed: () => setState(() => open = !open),
              icon: Icon(open ? Icons.expand_more : Icons.school_outlined, size: 18),
              label: Text(open ? 'Ẩn bảng dạy app' : 'Dạy app / kiểm tra'),
            ),
            if (busy) const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
          ]),
          if (open) ...<Widget>[
            const Text(
              'Chỉ cần khi app không tự nhận ra trang. Mỗi nút "Chọn..." bảo bạn CHẠM vào đúng phần tử trên trang; app nhớ riêng cho từng trang.',
              style: TextStyle(fontSize: 11),
            ),
            const Text(
              'AI tự dạy: model thư ký (API) chọn ô nhập/nút gửi giúp bạn, rồi app gửi 1 tin thử THẬT (tốn 1 tin nhắn của tài khoản) để kiểm chứng; '
              'sai thì tự hoàn lại. Nhãn các nút sát ô nhập sẽ được gửi cho model thư ký. Cần chọn "Model thư ký" ở Cài đặt (không dùng được với chính Web chat AI).',
              style: TextStyle(fontSize: 11),
            ),
            Wrap(spacing: 6, runSpacing: 0, children: <Widget>[
              ActionChip(
                avatar: const Icon(Icons.auto_fix_high, size: 16),
                label: const Text('AI tự dạy'),
                onPressed: () => _run(() async {
                  final f = s.helperFactory;
                  if (f == null) {
                    return 'Chưa có model thư ký cho nút này — đóng trình duyệt rồi mở lại bằng biểu tượng trình duyệt cạnh provider trong Cài đặt AI.';
                  }
                  AIProvider helper;
                  try {
                    helper = await f();
                  } catch (e) {
                    return '$e';
                  }
                  s.status.value = 'AI tự dạy: đang chạy...';
                  return s.autoTeach(helper);
                }),
              ),
              ActionChip(label: const Text('Chọn ô nhập'), onPressed: () => _run(() => _pick('input', 'Chạm vào Ô SOẠN TIN trên trang...'))),
              ActionChip(label: const Text('Chọn nút gửi'), onPressed: () => _run(() => _pick('send', 'Gõ sẵn 1 chữ vào ô, rồi chạm NÚT GỬI (nút sẽ không gửi thật)...'))),
              ActionChip(label: const Text('Chọn nút dừng'), onPressed: () => _run(() => _pick('stop', 'Khi trang đang trả lời, chạm NÚT DỪNG...'))),
              ActionChip(
                  label: const Text('Chọn vùng trả lời'),
                  onPressed: () => _run(() => _pick('reply', 'Chạm vào CÂU TRẢ LỜI của AI (sau khi bấm "Gửi tin thử")...'))),
              ActionChip(
                label: const Text('Gửi tin thử'),
                onPressed: () => _run(() async {
                  final t = await s.ask(
                    startUrl: s.startUrl,
                    profileKey: s.profileKey,
                    prompt: 'Trả lời đúng 2 câu ngắn bằng tiếng Việt: chào bạn, và cho biết hôm nay bạn khoẻ không.',
                  );
                  return 'Đọc được trả lời (${t.length} ký tự): ${t.length > 300 ? '${t.substring(0, 300)}…' : t}';
                }),
              ),
              ActionChip(
                label: const Text('Chẩn đoán'),
                onPressed: () => _run(() async {
                  final d = await s.diagnose();
                  return d.entries.map((e) => '${e.key}: ${e.value}').join('\n');
                }),
              ),
              ActionChip(
                label: const Text('Xoá cấu hình đã dạy'),
                onPressed: () => _run(() async {
                  await s.clearProfile(s.profileKey);
                  return 'Đã xoá cấu hình đã dạy — quay lại tự dò.';
                }),
              ),
            ]),
          ],
          if (info.isNotEmpty)
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
              Expanded(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 110),
                  child: SingleChildScrollView(child: Text(info, style: const TextStyle(fontSize: 11))),
                ),
              ),
              IconButton(onPressed: () => setState(() => info = ''), icon: const Icon(Icons.close, size: 16)),
            ]),
        ]),
      ),
    );
  }
}

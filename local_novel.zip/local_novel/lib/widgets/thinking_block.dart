import 'package:flutter/material.dart';
import '../services/think_splitter.dart';

// MỤC DQ (2026-11-02) — nút Hiện/Ẩn phần suy nghĩ của model (xem `think_splitter.dart`). Mặc định ẨN.

/// Nút + khung suy nghĩ cho MỘT đoạn chữ đã có sẵn (vd gắn với 1 tin nhắn chat).
class ThinkingBlock extends StatefulWidget {
  final String text;
  final bool streaming;
  const ThinkingBlock({super.key, required this.text, this.streaming = false});

  @override
  State<ThinkingBlock> createState() => _ThinkingBlockState();
}

class _ThinkingBlockState extends State<ThinkingBlock> {
  bool open = false;

  @override
  Widget build(BuildContext context) {
    final body = widget.text.trim();
    if (body.isEmpty) return const SizedBox.shrink();
    final label = open
        ? 'Ẩn suy nghĩ'
        : (widget.streaming ? 'Hiện suy nghĩ (model đang suy nghĩ...)' : 'Hiện suy nghĩ (${body.length} ký tự)');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        TextButton.icon(
          onPressed: () => setState(() => open = !open),
          icon: Icon(open ? Icons.expand_less : Icons.psychology_outlined, size: 16),
          label: Text(label, style: const TextStyle(fontSize: 12)),
          style: TextButton.styleFrom(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            minimumSize: Size.zero,
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
        ),
        if (open)
          Container(
            width: double.infinity,
            constraints: const BoxConstraints(maxHeight: 220),
            padding: const EdgeInsets.all(10),
            margin: const EdgeInsets.only(bottom: 6),
            decoration: BoxDecoration(color: Colors.blueGrey.shade50, borderRadius: BorderRadius.circular(8)),
            child: SingleChildScrollView(
              child: SelectableText(
                body,
                style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: Colors.black54),
              ),
            ),
          ),
      ],
    );
  }
}

/// Giống [ThinkingBlock] nhưng tự theo dõi phần suy nghĩ của lượt sinh GẦN NHẤT trên model chính (cập nhật khi model còn đang nghĩ). Rỗng thì không hiện gì.
class LiveThinkingBlock extends StatelessWidget {
  // Chỉ hiện suy nghĩ của lượt sinh MỚI HƠN mốc này — để màn hình không hiện nhầm suy nghĩ còn sót từ lượt/màn khác (vd mở màn soạn chương sau khi chat).
  final int minGeneration;
  const LiveThinkingBlock({super.key, this.minGeneration = 0});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThinkingSnapshot>(
      valueListenable: ThinkingStore.instance.notifier,
      builder: (context, snap, _) => snap.generation > minGeneration
          ? ThinkingBlock(text: snap.text, streaming: snap.streaming)
          : const SizedBox.shrink(),
    );
  }
}

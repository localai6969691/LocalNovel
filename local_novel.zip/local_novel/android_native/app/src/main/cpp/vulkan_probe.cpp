// MỤC CU (2026-10-10) — đo KHẢ NĂNG VULKAN THẬT của máy, chỉ để GHI LOG chẩn đoán.
//
// Vì sao có file này: phép thử "MNN chạy LLM bằng backend Vulkan" (backendPreference = 5/6)
// chỉ có ý nghĩa nếu biết máy này THỰC SỰ có gì: tên GPU, phiên bản Vulkan, phiên bản driver,
// có 16-bit storage / shaderFloat16 / subgroup arithmetic / cooperative matrix hay không.
// Đây chính là loại dữ kiện còn THIẾU khi đoán "GPU Adreno 660 rác là do driver hay do code".
//
// Nguyên tắc an toàn:
//   - KHÔNG liên kết libvulkan lúc build (chỉ dlopen lúc chạy) => không thêm phụ thuộc nào.
//   - Nếu NDK không có <vulkan/vulkan.h> thì cả file này biên dịch thành 1 hàm trả chuỗi
//     "bo qua" (không làm hỏng build).
//   - Không ném exception, không đụng JNI, chỉ trả về chuỗi nhiều dòng để nativeLog() ghi.
//   - Chỉ ĐỌC thông tin (tạo instance tạm rồi huỷ) — không chạy compute, không ảnh hưởng MNN.
//
// Giới hạn thật (đã biết trước, không giấu): hàm này chỉ cho biết máy "khai báo" gì; việc khai
// báo đủ KHÔNG chứng minh kernel MNN chạy đúng trên driver đó. Chỉ log sinh chữ thật mới chứng minh.

#include <string>
#include <vector>
#include <cstring>
#include <cstdio>
#include <cstdint>
#include <dlfcn.h>

#if defined(__has_include)
#  if __has_include(<vulkan/vulkan.h>)
#    define LN_HAVE_VULKAN_HEADER 1
#  endif
#endif

#ifdef LN_HAVE_VULKAN_HEADER
#include <vulkan/vulkan.h>
#endif

std::string lnProbeVulkanReport() {
#ifndef LN_HAVE_VULKAN_HEADER
  return "[CU-VK] build nay KHONG co <vulkan/vulkan.h> trong NDK — bo qua buoc do Vulkan (khong anh huong MNN).";
#else
  std::string out;
  auto add = [&out](const std::string& s) { out += s; out += "\n"; };

  void* lib = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
  if (!lib) {
    const char* e = dlerror();
    return std::string("[CU-VK] dlopen(libvulkan.so) THAT BAI: ") + (e ? e : "(khong ro)") +
           " — may nay khong co Vulkan loader, MNN backend vulkan chac chan khong chay duoc.";
  }

  auto gipa = reinterpret_cast<PFN_vkGetInstanceProcAddr>(dlsym(lib, "vkGetInstanceProcAddr"));
  if (!gipa) return "[CU-VK] libvulkan.so khong co vkGetInstanceProcAddr";

  auto fnEnumInstVer = reinterpret_cast<PFN_vkEnumerateInstanceVersion>(gipa(nullptr, "vkEnumerateInstanceVersion"));
  uint32_t instVer = VK_API_VERSION_1_0;
  if (fnEnumInstVer) {
    uint32_t v = 0;
    if (fnEnumInstVer(&v) == VK_SUCCESS) instVer = v;
  }
  char verBuf[96];
  snprintf(verBuf, sizeof(verBuf), "[CU-VK] instance Vulkan = %u.%u.%u", VK_API_VERSION_MAJOR(instVer),
           VK_API_VERSION_MINOR(instVer), VK_API_VERSION_PATCH(instVer));
  add(verBuf);

  auto fnCreateInstance = reinterpret_cast<PFN_vkCreateInstance>(gipa(nullptr, "vkCreateInstance"));
  if (!fnCreateInstance) return out + "[CU-VK] khong lay duoc vkCreateInstance";

  VkApplicationInfo app = {};
  app.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
  app.pApplicationName = "LocalNovelProbe";
  app.apiVersion = (instVer >= VK_API_VERSION_1_1) ? VK_API_VERSION_1_1 : VK_API_VERSION_1_0;
  VkInstanceCreateInfo ici = {};
  ici.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
  ici.pApplicationInfo = &app;
  VkInstance inst = VK_NULL_HANDLE;
  VkResult r = fnCreateInstance(&ici, nullptr, &inst);
  if (r != VK_SUCCESS || inst == VK_NULL_HANDLE) {
    char b[96];
    snprintf(b, sizeof(b), "[CU-VK] vkCreateInstance THAT BAI, VkResult=%d", (int)r);
    return out + b;
  }

  auto fnDestroyInstance = reinterpret_cast<PFN_vkDestroyInstance>(gipa(inst, "vkDestroyInstance"));
  auto fnEnumPd = reinterpret_cast<PFN_vkEnumeratePhysicalDevices>(gipa(inst, "vkEnumeratePhysicalDevices"));
  auto fnGetProps = reinterpret_cast<PFN_vkGetPhysicalDeviceProperties>(gipa(inst, "vkGetPhysicalDeviceProperties"));
  auto fnEnumExt =
      reinterpret_cast<PFN_vkEnumerateDeviceExtensionProperties>(gipa(inst, "vkEnumerateDeviceExtensionProperties"));
  auto fnProps2 = reinterpret_cast<PFN_vkGetPhysicalDeviceProperties2>(gipa(inst, "vkGetPhysicalDeviceProperties2"));
  auto fnFeat2 = reinterpret_cast<PFN_vkGetPhysicalDeviceFeatures2>(gipa(inst, "vkGetPhysicalDeviceFeatures2"));

  if (!fnEnumPd || !fnGetProps || !fnEnumExt) {
    if (fnDestroyInstance) fnDestroyInstance(inst, nullptr);
    return out + "[CU-VK] thieu ham co ban (EnumeratePhysicalDevices/GetProperties/EnumerateExtensions)";
  }

  uint32_t n = 0;
  fnEnumPd(inst, &n, nullptr);
  add("[CU-VK] so GPU Vulkan = " + std::to_string(n));
  std::vector<VkPhysicalDevice> devs(n);
  if (n > 0) fnEnumPd(inst, &n, devs.data());

  for (uint32_t i = 0; i < n && i < 4; ++i) {
    VkPhysicalDeviceProperties p = {};
    fnGetProps(devs[i], &p);
    char b[512];
    snprintf(b, sizeof(b),
             "[CU-VK] GPU#%u: name=\"%s\" vendorID=0x%04x deviceID=0x%x apiVersion=%u.%u.%u driverVersion=0x%x type=%d", i,
             p.deviceName, p.vendorID, p.deviceID, VK_API_VERSION_MAJOR(p.apiVersion),
             VK_API_VERSION_MINOR(p.apiVersion), VK_API_VERSION_PATCH(p.apiVersion), p.driverVersion,
             (int)p.deviceType);
    add(b);

    uint32_t en = 0;
    fnEnumExt(devs[i], nullptr, &en, nullptr);
    std::vector<VkExtensionProperties> exts(en);
    if (en > 0) fnEnumExt(devs[i], nullptr, &en, exts.data());
    auto has = [&exts](const char* name) {
      for (const auto& e : exts)
        if (strcmp(e.extensionName, name) == 0) return true;
      return false;
    };
    const char* wanted[] = {"VK_KHR_16bit_storage",
                            "VK_KHR_8bit_storage",
                            "VK_KHR_shader_float16_int8",
                            "VK_KHR_shader_integer_dot_product",
                            "VK_KHR_shader_subgroup_extended_types",
                            "VK_KHR_driver_properties",
                            "VK_KHR_cooperative_matrix",
                            "VK_QCOM_cooperative_matrix_conversion",
                            "VK_EXT_subgroup_size_control"};
    std::string line = "[CU-VK] GPU#" + std::to_string(i) + " extension (CO/khong): ";
    for (const char* w : wanted) {
      line += std::string(w) + "=" + (has(w) ? "co" : "khong") + "; ";
    }
    line += "tong so extension=" + std::to_string(en);
    add(line);

    if (fnProps2 && p.apiVersion >= VK_API_VERSION_1_1) {
      VkPhysicalDeviceSubgroupProperties sg = {};
      sg.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SUBGROUP_PROPERTIES;
      VkPhysicalDeviceDriverProperties drv = {};
      drv.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES;
      const bool haveDrv = has("VK_KHR_driver_properties") || p.apiVersion >= VK_API_VERSION_1_2;
      if (haveDrv) sg.pNext = &drv;
      VkPhysicalDeviceProperties2 p2 = {};
      p2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2;
      p2.pNext = &sg;
      fnProps2(devs[i], &p2);
      char sb[320];
      snprintf(sb, sizeof(sb),
               "[CU-VK] GPU#%u subgroupSize=%u supportedOperations=0x%x (ARITHMETIC=0x%x, BASIC=0x%x) computeStage=%d", i,
               sg.subgroupSize, (unsigned)sg.supportedOperations, (unsigned)VK_SUBGROUP_FEATURE_ARITHMETIC_BIT,
               (unsigned)VK_SUBGROUP_FEATURE_BASIC_BIT, (int)((sg.supportedStages & VK_SHADER_STAGE_COMPUTE_BIT) != 0));
      add(sb);
      if (haveDrv) {
        add(std::string("[CU-VK] GPU#") + std::to_string(i) + " driverName=\"" + drv.driverName + "\" driverInfo=\"" +
            drv.driverInfo + "\" driverID=" + std::to_string((int)drv.driverID));
      }
    } else {
      add("[CU-VK] GPU#" + std::to_string(i) + " khong doc duoc subgroup/driver (thieu Vulkan 1.1 hoac thieu ham properties2)");
    }

    if (fnFeat2 && p.apiVersion >= VK_API_VERSION_1_1) {
      VkPhysicalDevice16BitStorageFeatures st16 = {};
      st16.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_16BIT_STORAGE_FEATURES;
      VkPhysicalDeviceShaderFloat16Int8Features f16 = {};
      f16.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_SHADER_FLOAT16_INT8_FEATURES;
      st16.pNext = has("VK_KHR_shader_float16_int8") ? static_cast<void*>(&f16) : nullptr;
      VkPhysicalDeviceFeatures2 f2 = {};
      f2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;
      f2.pNext = &st16;
      fnFeat2(devs[i], &f2);
      char fb[320];
      snprintf(fb, sizeof(fb),
               "[CU-VK] GPU#%u storageBuffer16BitAccess=%d uniformAndStorageBuffer16BitAccess=%d shaderFloat16=%d shaderInt8=%d "
               "shaderInt16=%d (feature float16/int8 chi hop le neu extension tuong ung = co)",
               i, (int)st16.storageBuffer16BitAccess, (int)st16.uniformAndStorageBuffer16BitAccess, (int)f16.shaderFloat16,
               (int)f16.shaderInt8, (int)f2.features.shaderInt16);
      add(fb);
    }

    char lb[256];
    snprintf(lb, sizeof(lb),
             "[CU-VK] GPU#%u limits: maxStorageBufferRange=%u maxComputeSharedMemorySize=%u maxComputeWorkGroupInvocations=%u "
             "maxMemoryAllocationCount=%u",
             i, p.limits.maxStorageBufferRange, p.limits.maxComputeSharedMemorySize,
             p.limits.maxComputeWorkGroupInvocations, p.limits.maxMemoryAllocationCount);
    add(lb);
  }

  if (fnDestroyInstance) fnDestroyInstance(inst, nullptr);
  return out;
#endif
}

package com.localnovel.mnnbridge

import android.content.Context
import android.os.Build
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.ZipFile

// MỤC CB (2026-10-01) — Chụp NGUYÊN NHÂN THẬT khi `nativeLoadModel()` trả về false.
//
// VÌ SAO FILE NÀY TỒN TẠI: khi `Llm::load()` của MNN thất bại, LÝ DO THẬT do
// chính MNN in ra logcat (MNN_ERROR, tag "MNNJNI" vì build với
// MNN_USE_LOGCAT=true). App không có adb/PC nên toàn bộ lịch sử debug (mục
// BX→BZ) chưa từng thấy dòng lý do đó, chỉ thấy "load() TRA VE = FALSE".
//
// QUY TẮC THIẾT KẾ (rút ra từ build #2/#4 tự làm hỏng ở mục BY/CA):
//  - CHỈ ĐỌC, không đổi bất kỳ luồng nạp model nào.
//  - MỌI phần bọc try/catch riêng — 1 phần lỗi không làm mất các phần còn lại,
//    và KHÔNG BAO GIỜ ném exception ra ngoài (không thể làm hỏng loadModel).
//  - Chỉ chạy khi load() THẤT BẠI — lúc nạp thành công không tốn gì.
//  - Toàn bộ kết quả ghi vào native_debug.txt qua kLog() như mọi log khác.
internal object LoadDiagnostics {

    private const val TAG = "LocalNovelDiag"
    private const val PREFIX = "[CHAN DOAN LOAD FAIL] "

    // Gọi TRƯỚC nativeLoadModel(): ghi 1 dòng mốc DUY NHẤT vào logcat để sau
    // đó cắt đúng phần logcat thuộc lần nạp này.
    fun markBegin(slot: Int): String {
        val marker = "LOAD_BEGIN slot=$slot t=${System.nanoTime()}"
        try {
            android.util.Log.i(TAG, marker)
        } catch (_: Throwable) {
        }
        return marker
    }

    // Gọi khi nativeLoadModel() trả false. Không bao giờ ném lỗi.
    fun dumpOnFailure(context: Context, slot: Int, configPath: String, marker: String) {
        try {
            kLog(context, PREFIX + "===== BAT DAU (slot=$slot) — ly do THAT do chinh MNN in ra logcat, truoc nay chua tung duoc thu =====")
            dumpEnvironment(context)
            dumpRuntimeLibs(context)
            dumpModelFileReadCheck(context, configPath)
            dumpLogcatAfter(context, marker)
            kLog(context, PREFIX + "===== KET THUC =====")
        } catch (t: Throwable) {
            kLog(context, PREFIX + "chinh phan chan doan bi loi: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    // --- 1) Môi trường + "dấu vân tay" APK đang chạy -----------------------
    private fun dumpEnvironment(context: Context) {
        try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            val installed = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(Date(info.lastUpdateTime))
            kLog(context, PREFIX + "APK: lastUpdateTime=$installed, Android=${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), " +
                "ABI=${Build.SUPPORTED_ABIS.joinToString(",")}, may=${Build.MANUFACTURER} ${Build.MODEL}")
        } catch (t: Throwable) {
            kLog(context, PREFIX + "khong doc duoc thong tin APK: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    // --- 2) Thư viện MNN thật trong APK: kích thước + trình biên dịch đã build ra nó ---
    // MỤC CD (người dùng yêu cầu bỏ chẩn đoán xoay quanh model): chỉ quan sát phía BUILD/runtime.
    // Chuỗi "clang version ..." nằm trong mục .comment của ELF cho biết NDK/trình biên dịch
    // thật của libMNN.so và libmnn_bridge.so trong APK đang chạy (không cần đoán từ build.yml).
    private fun dumpRuntimeLibs(context: Context) {
        for (libName in listOf("libMNN.so", "libmnn_bridge.so")) {
            try {
                val desc = withLibStream(context, libName) { input, size, origin ->
                    val bytes = input.readBytes()
                    val compiler = extractAround(bytes, "clang version", 120, 220) ?: "(khong thay chuoi 'clang version')"
                    val linker = extractAround(bytes, "Linker: ", 10, 80) ?: "(khong thay chuoi 'Linker:')"
                    origin + " | size=" + size + " byte | CRC32=" + crc32Hex(bytes) + " | compiler=[" + compiler + "] | linker=[" + linker + "]"
                }
                kLog(context, PREFIX + "lib $libName: " + (desc ?: "KHONG TIM THAY (khong co file roi, khong co trong APK)"))
            } catch (t: Throwable) {
                kLog(context, PREFIX + "quet lib $libName loi: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
    }

    private fun crc32Hex(bytes: ByteArray): String {
        val c = CRC32()
        c.update(bytes, 0, bytes.size)
        return "%08x".format(c.value)
    }

    // Lấy 1 đoạn chuỗi ASCII quanh lần xuất hiện ĐẦU TIÊN của `needle` (đoạn nằm giữa 2 byte NUL).
    private fun extractAround(bytes: ByteArray, needle: String, maxBack: Int, maxFwd: Int): String? {
        val nb = needle.toByteArray(Charsets.US_ASCII)
        val idx = indexOfBytes(bytes, bytes.size, nb)
        if (idx < 0) return null
        var start = idx
        var back = 0
        while (start > 0 && back < maxBack && bytes[start - 1].toInt() != 0) {
            start--
            back++
        }
        var end = idx + nb.size
        var fwd = 0
        while (end < bytes.size && fwd < maxFwd && bytes[end].toInt() != 0) {
            end++
            fwd++
        }
        val sb = StringBuilder()
        for (i in start until end) {
            val c = bytes[i].toInt() and 0xff
            sb.append(if (c in 32..126) c.toChar() else '?')
        }
        return sb.toString()
    }

    // Mở thư viện .so: ưu tiên file đã giải nén ở nativeLibraryDir; nếu không có
    // (minSdk 28 → AGP mặc định KHÔNG giải nén .so, chúng nằm thẳng trong APK)
    // thì đọc trực tiếp entry trong APK.
    private fun <T> withLibStream(context: Context, libName: String, block: (InputStream, Long, String) -> T): T? {
        val direct = File(context.applicationInfo.nativeLibraryDir, libName)
        if (direct.isFile) {
            return direct.inputStream().use { block(it, direct.length(), "file: " + direct.absolutePath) }
        }
        val apkPaths = ArrayList<String>()
        val src = context.applicationInfo.sourceDir
        if (src != null) apkPaths.add(src)
        val splits = context.applicationInfo.splitSourceDirs
        if (splits != null) {
            for (s in splits) apkPaths.add(s)
        }
        for (apk in apkPaths) {
            try {
                ZipFile(apk).use { zf ->
                    for (abi in Build.SUPPORTED_ABIS) {
                        val entry = zf.getEntry("lib/$abi/$libName")
                        if (entry != null) {
                            return zf.getInputStream(entry).use { block(it, entry.size, "apk: $apk!/lib/$abi/$libName") }
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun indexOfBytes(hay: ByteArray, len: Int, needle: ByteArray): Int {
        if (needle.isEmpty() || len < needle.size) return -1
        val last = len - needle.size
        var i = 0
        while (i <= last) {
            if (hay[i] == needle[0]) {
                var j = 1
                while (j < needle.size && hay[i + j] == needle[j]) j++
                if (j == needle.size) return i
            }
            i++
        }
        return -1
    }

    // --- 3) CÁCH ĐỌC file llm.mnn (không phải nội dung model) ---------------------
    // Chỉ để đối chiếu: Java đọc llm.mnn ra bao nhiêu byte + CRC32, so với CRC32 do code
    // C++ (self-test mục CD) tính ở dòng "[CD] (B)". Khác nhau => đường đọc native bị lỗi
    // (quyền/FUSE); giống nhau => native thấy ĐÚNG các byte Java thấy.
    private fun dumpModelFileReadCheck(context: Context, configPath: String) {
        val given = File(configPath)
        val dir: File? = if (given.isDirectory) given else given.parentFile
        if (dir == null) {
            kLog(context, PREFIX + "khong xac dinh duoc thu muc tu configPath=$configPath")
            return
        }
        try {
            val f = File(dir, "llm.mnn")
            if (!f.isFile) {
                kLog(context, PREFIX + "llm.mnn: KHONG TON TAI trong ${dir.absolutePath}")
                return
            }
            val crc = CRC32()
            var total = 0L
            f.inputStream().use { input ->
                val buf = ByteArray(1 shl 16)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    crc.update(buf, 0, n)
                    total += n
                }
            }
            kLog(context, PREFIX + "llm.mnn doc bang JAVA: length()=" + f.length() + " byte, doc duoc=" + total + " byte, CRC32(java)=" + "%08x".format(crc.value))
        } catch (t: Throwable) {
            kLog(context, PREFIX + "doc llm.mnn bang Java loi: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    // --- 4) Logcat của CHÍNH app này, từ mốc LOAD_BEGIN tới giờ -----------------
    // Từ Android 4.1, `logcat` chạy từ app chỉ thấy log của chính UID app —
    // không cần quyền READ_LOGS, không lộ dữ liệu app khác.
    private fun dumpLogcatAfter(context: Context, marker: String) {
        try {
            Thread.sleep(300) // chờ logd kịp nhận nốt các dòng MNN vừa in
            val lines = ArrayList<String>()
            val proc = ProcessBuilder(listOf("logcat", "-d", "-v", "threadtime", "-t", "3000"))
                .redirectErrorStream(true)
                .start()
            val reader = Thread {
                try {
                    proc.inputStream.bufferedReader().useLines { seq ->
                        seq.forEach { line -> synchronized(lines) { lines.add(line) } }
                    }
                } catch (_: Throwable) {
                }
            }
            reader.start()
            reader.join(5000)
            if (reader.isAlive) {
                proc.destroy()
                kLog(context, PREFIX + "logcat doc qua 5 giay — da dung, dung phan doc duoc")
            }
            val snapshot: List<String> = synchronized(lines) { ArrayList(lines) }
            val idx = snapshot.indexOfLast { it.contains(marker) }
            val after: List<String>
            if (idx >= 0) {
                after = snapshot.subList(idx + 1, snapshot.size)
            } else {
                kLog(context, PREFIX + "KHONG thay dong moc trong logcat (buffer da tran hoac logcat bi chan) — lay 150 dong cuoi thay the")
                after = snapshot.takeLast(150)
            }
            if (after.isEmpty()) {
                kLog(context, PREFIX + "logcat: 0 dong sau moc (tong doc duoc " + snapshot.size + " dong) — logcat co the bi chan tren may nay")
                return
            }
            val shown: List<String> = if (after.size > 160) {
                after.take(110) + listOf("... (bo qua " + (after.size - 160) + " dong giua) ...") + after.takeLast(50)
            } else {
                after
            }
            kLog(context, PREFIX + "logcat sau moc: " + after.size + " dong (hien " + shown.size + ")")
            for (l in shown) {
                kLog(context, "[LOGCAT] " + (if (l.length > 500) l.substring(0, 500) + "..." else l))
            }
        } catch (t: Throwable) {
            kLog(context, PREFIX + "khong chup duoc logcat: ${t.javaClass.simpleName}: ${t.message}")
        }
    }
}

package com.localnovel.mnnbridge

import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock

// MỤC CN (2026-10-04) — NHẬT KÝ XÁC MINH TRẠNG THÁI NGUỒN KHI SINH CHỮ.
//
// VÌ SAO: log 04/10 cho thấy máy vẫn ngủ giữa chừng (STEADY 348s vs WALL 453s; 115s vs 197s) dù người dùng báo ĐÃ BẬT
// miễn tối ưu pin trong app. Trước đây chỉ SUY ĐOÁN (mục V/W) chứ chưa từng GHI trạng thái thật. Lớp này ghi lại, tại các thời điểm
// thay đổi, đúng những thứ quyết định việc Android có tôn trọng PARTIAL_WAKE_LOCK hay không:
//   - ignoreBatteryOpt : app có thật sự nằm trong danh sách miễn tối ưu pin không (nút xanh trong app có thể không khớp hệ thống)
//   - screenOn         : màn hình có sáng không (PowerManager.isInteractive)
//   - doze             : máy có đang ở chế độ Doze sâu không (isDeviceIdleMode) — Doze bỏ qua wake lock của app không được miễn
//   - powerSave        : chế độ tiết kiệm pin hệ thống
//   - standbyBucket    : nhóm chờ của ứng dụng (10 ACTIVE, 20 WORKING_SET, 30 FREQUENT, 40 RARE, 45 RESTRICTED)
//   - thermal          : trạng thái nhiệt (0 = bình thường ... 3 = nghiêm trọng+)
//   - directWakeLock   : wake lock trực tiếp của MnnBridge có đang được giữ không
//   - slept            : tổng thời gian máy NGỦ kể từ lúc bắt đầu = (elapsedRealtime - uptimeMillis) tăng thêm. elapsedRealtime
//                        tính cả lúc ngủ sâu, uptimeMillis thì không => hiệu số chính là thời gian CPU bị đóng băng.
// CHỈ ĐỌC — không đổi bất kỳ hành vi giữ máy thức nào. Mọi lời gọi hệ thống bọc try/catch.
internal object PowerDiagnostics {

    fun snapshot(context: Context, extra: String): String {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val parts = ArrayList<String>()
            parts.add("ignoreBatteryOpt=" + pm.isIgnoringBatteryOptimizations(context.packageName))
            parts.add("screenOn=" + pm.isInteractive)
            parts.add("doze=" + pm.isDeviceIdleMode)
            parts.add("powerSave=" + pm.isPowerSaveMode)
            try {
                val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                if (usm != null) parts.add("standbyBucket=" + usm.appStandbyBucket)
            } catch (t: Throwable) {
                parts.add("standbyBucket=loi:" + t.javaClass.simpleName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                parts.add("thermal=" + pm.currentThermalStatus)
            }
            if (extra.isNotEmpty()) parts.add(extra)
            parts.joinToString(", ")
        } catch (t: Throwable) {
            "snapshot loi: " + t.javaClass.simpleName + ": " + t.message
        }
    }
}

// Theo dõi trong lúc 1 lệnh sinh chữ chạy: ghi 1 dòng khi BẮT ĐẦU và KẾT THÚC, và mỗi ~15 giây CHỈ ghi khi trạng thái đổi
// hoặc máy vừa ngủ thêm > 3 giây. Luồng giám sát cũng bị đóng băng khi máy ngủ, nên dòng đầu tiên sau khi thức báo ngay phần ngủ.
internal class PowerWatcher(
    private val context: Context,
    private val tag: String,
    private val extraProvider: () -> String
) {
    @Volatile
    private var running = false
    private var thread: Thread? = null
    private val elapsed0 = SystemClock.elapsedRealtime()
    private val uptime0 = SystemClock.uptimeMillis()

    private fun sleptSoFarMs(): Long {
        val elapsed = SystemClock.elapsedRealtime() - elapsed0
        val uptime = SystemClock.uptimeMillis() - uptime0
        return elapsed - uptime
    }

    fun start() {
        kLog(context, "[PWR] " + tag + " BAT DAU: " + PowerDiagnostics.snapshot(context, extraProvider()))
        running = true
        val t = Thread {
            var lastSnap = PowerDiagnostics.snapshot(context, extraProvider())
            var lastSlept = 0L
            while (running) {
                try {
                    Thread.sleep(15000)
                } catch (_: InterruptedException) {
                    break
                }
                if (!running) break
                val slept = sleptSoFarMs()
                val snap = PowerDiagnostics.snapshot(context, extraProvider())
                val newlySlept = slept - lastSlept
                if (snap != lastSnap || newlySlept > 3000) {
                    val sleepNote = if (newlySlept > 3000) "MAY VUA NGU THEM " + newlySlept + "ms (tong " + slept + "ms) — " else ""
                    kLog(context, "[PWR] " + tag + ": " + sleepNote + snap)
                    lastSnap = snap
                    lastSlept = slept
                }
            }
        }
        t.isDaemon = true
        t.name = "PowerWatcher"
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        try {
            thread?.interrupt()
        } catch (_: Throwable) {
        }
        kLog(context, "[PWR] " + tag + " KET THUC: tong thoi gian may NGU = " + sleptSoFarMs() + "ms. " +
            PowerDiagnostics.snapshot(context, extraProvider()))
    }
}

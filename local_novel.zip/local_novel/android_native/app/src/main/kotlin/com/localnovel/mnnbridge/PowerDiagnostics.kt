package com.localnovel.mnnbridge

import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock

// MỤC CN (2026-10-04) — NHẬT KÝ XÁC MINH TRẠNG THÁI NGUỒN KHI SINH CHỮ.
//
// VÌ SAO: log 04/10 cho thấy máy vẫn ngủ giữa chừng (STEADY 348s vs WALL 453s; 115s vs 197s) dù người dùng báo ĐÃ BẬT
// miễn tối ưu pin trong app. Trước đây chỉ SUY ĐOÁN (mục V/W) chứ chưa từng GHI trạng thái thật. Lớp này ghi lại, tại các thời điểm
// thay đổi, đúng những thứ quyết định việc Android có tôn trọng PARTIAL_WAKE_LOCK hay không:
//   - ignoreBatteryOpt : app có thật sự nằm trong danh sách miễn tối ưu pin không (nút xanh trong app có thể không khớp hệ thống)
//   - screenOn         : màn hình có sáng không (PowerManager.isInteractive)
//   - doze             : máy có đang ở chế độ Doze sâu không (isDeviceIdleMode) — Doze bỏ qua wake lock của app không được miễn
//   - powerSave        : chế độ tiết kiệm pin hệ thống
//   - standbyBucket    : nhóm chờ của ứng dụng (10 ACTIVE, 20 WORKING_SET, 30 FREQUENT, 40 RARE, 45 RESTRICTED)
//   - thermal          : trạng thái nhiệt (0 = bình thường ... 3 = nghiêm trọng+)
//   - directWakeLock   : wake lock trực tiếp của MnnBridge có đang được giữ không
//   - slept            : tổng thời gian máy NGỦ kể từ lúc bắt đầu = (elapsedRealtime - uptimeMillis) tăng thêm. elapsedRealtime
//                        tính cả lúc ngủ sâu, uptimeMillis thì không => hiệu số chính là thời gian CPU bị đóng băng.
// CHỈ ĐỌC — không đổi bất kỳ hành vi giữ máy thức nào. Mọi lời gọi hệ thống bọc try/catch.
internal object PowerDiagnostics {

    // MỤC CQ (2026-10-07): MỨC ƯU TIÊN THẬT CỦA CHÍNH TIẾN TRÌNH NÀY theo hệ thống (ActivityManager.getMyMemoryState — API chuẩn cho tiến trình
    // của mình, không cần quyền). Đây là số đo QUYẾT ĐỊNH giả thuyết "dịch vụ nền chỉ đang báo chạy chứ hệ thống chưa coi là foreground":
    //   100 FOREGROUND / 125 FOREGROUND_SERVICE  => dịch vụ nền được hệ thống công nhận, wake lock được tôn trọng
    //   150 TOP_SLEEPING / 200 VISIBLE / 230 PERCEPTIBLE / 300 SERVICE => thấp hơn foreground-service, bất thường khi đang sinh chữ
    //   400 CACHED => tiến trình bị coi là "đã cất" — AOSP vô hiệu hoá wake lock của tiến trình cached (PowerManagerService)
    // Lưu ý ĐO: cần đọc lúc ĐANG sinh chữ; đọc lúc rảnh ra 400 là bình thường.
    fun ownImportanceText(): String {
        return try {
            val st = android.app.ActivityManager.RunningAppProcessInfo()
            android.app.ActivityManager.getMyMemoryState(st)
            val name = when (st.importance) {
                android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND -> "FOREGROUND"
                android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND_SERVICE -> "FOREGROUND_SERVICE"
                android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_TOP_SLEEPING -> "TOP_SLEEPING"
                android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_VISIBLE -> "VISIBLE"
                android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_PERCEPTIBLE -> "PERCEPTIBLE"
                android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_SERVICE -> "SERVICE"
                android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED -> "CACHED"
                else -> "khac"
            }
            st.importance.toString() + "(" + name + ")"
        } catch (t: Throwable) {
            "loi:" + t.javaClass.simpleName
        }
    }

    // MỤC CU4: pin + có cắm sạc không (intent dính ACTION_BATTERY_CHANGED, không cần quyền). Chỉ để ĐỐI CHỨNG khi đọc log (máy cắm sạc
    // có thể bị đối xử khác về Doze) — KHÔNG phải cách "né" lỗi.
    fun batteryText(context: Context): String {
        return try {
            val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i == null) {
                "battery=khong_doc_duoc, plugged=khong_doc_duoc"
            } else {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val pct = if (level >= 0 && scale > 0) (level * 100 / scale).toString() + "%" else "?"
                val plugged = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
                    0 -> "none"
                    BatteryManager.BATTERY_PLUGGED_AC -> "ac"
                    BatteryManager.BATTERY_PLUGGED_USB -> "usb"
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "wireless"
                    else -> "khac"
                }
                "battery=" + pct + ", plugged=" + plugged
            }
        } catch (t: Throwable) {
            "battery=loi:" + t.javaClass.simpleName
        }
    }

    // MỤC CU4: tách "khoá=giá trị, khoá=giá trị" của snapshot() thành bảng để so sánh/đối chiếu. Giá trị tự nó có ", " (hiếm) thì phần sau bị bỏ qua.
    fun parseSnapshot(s: String): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        for (p in s.split(", ")) {
            val i = p.indexOf('=')
            if (i > 0) m[p.substring(0, i).trim()] = p.substring(i + 1).trim()
        }
        return m
    }

    // MỤC CU4: đọc file nhỏ trong /sys nếu SELinux cho phép (thường KHÔNG cho app thường — khi đó trả null và log ghi "khong_doc_duoc").
    fun readSmallFile(path: String): String? {
        return try {
            val f = java.io.File(path)
            if (!f.canRead()) null else f.readText().trim().take(200)
        } catch (t: Throwable) {
            null
        }
    }

    // Số lần máy THẬT SỰ vào suspend từ lúc khởi động (nếu đọc được). Hiệu hai lần đọc = số lần suspend trong khoảng đó.
    fun suspendSuccessCount(): Long? = readSmallFile("/sys/power/suspend_stats/success")?.toLongOrNull()
    fun suspendFailCount(): Long? = readSmallFile("/sys/power/suspend_stats/fail")?.toLongOrNull()

    // Lý do thức dậy gần nhất (vd tên IRQ/alarm) nếu hệ thống cho đọc — cho biết CÁI GÌ đánh thức máy mỗi chu kỳ.
    fun lastResumeReason(): String? = readSmallFile("/sys/kernel/wakeup_reasons/last_resume_reason")

    // MỤC CU4: môi trường tĩnh, ghi 1 lần mỗi tiến trình. Chỉ ĐỌC các thiết lập hệ thống công khai (Settings.Global đọc được bởi mọi app) để thấy hãng
    // có chỉnh hằng số Doze/standby không (giá trị null = mặc định AOSP). Thông tin hãng/model chỉ để người đọc log biết, KHÔNG dùng để rẽ nhánh logic.
    fun envText(context: Context): String {
        val parts = ArrayList<String>()
        parts.add("sdk=" + Build.VERSION.SDK_INT)
        parts.add("maycua=" + Build.MANUFACTURER + "/" + Build.MODEL)
        parts.add("rom=" + Build.DISPLAY)
        for (key in arrayOf("device_idle_constants", "app_standby_enabled", "adaptive_battery_management_enabled", "forced_app_standby_enabled",
            "low_power_standby_enabled", "battery_saver_constants")) {
            val v = try {
                android.provider.Settings.Global.getString(context.contentResolver, key) ?: "null(mac_dinh)"
            } catch (t: Throwable) {
                "khong_doc_duoc"
            }
            parts.add("Global." + key + "=" + v)
        }
        // MỤC CU5: dung lượng trống của bộ nhớ trong (nơi đặt cache GPU ~4GB). Log 2026-10-12: lượt GPU crash SIGBUS, nghi hết chỗ ghi file cache.
        try {
            val fs = android.os.StatFs(context.filesDir.path)
            parts.add("luu_tru_trong_con_trong=" + (fs.availableBytes / (1024L * 1024L)) + "MB/" + (fs.totalBytes / (1024L * 1024L)) + "MB")
        } catch (t: Throwable) {
            parts.add("luu_tru_trong_con_trong=khong_doc_duoc")
        }
        parts.add("sysfs.suspend_success=" + (suspendSuccessCount()?.toString() ?: "khong_doc_duoc"))
        parts.add("sysfs.suspend_fail=" + (suspendFailCount()?.toString() ?: "khong_doc_duoc"))
        parts.add("sysfs.last_resume_reason=" + (lastResumeReason() ?: "khong_doc_duoc"))
        return parts.joinToString(", ")
    }

    // Pha hiện tại (cho bảng "ngủ bao nhiêu % ở mỗi pha"). Máy thức trong cửa sổ bảo trì của Doze sẽ rơi vào TAT_MAN_HINH_KHONG_DOZE.
    fun currentPhase(context: Context): String {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isInteractive) "MAN_HINH_SANG"
            else if (pm.isDeviceIdleMode) "DOZE_SAU"
            else if (Build.VERSION.SDK_INT >= 33 && pm.isDeviceLightIdleMode) "DOZE_NHE"
            else "TAT_MAN_HINH_KHONG_DOZE"
        } catch (t: Throwable) {
            "KHONG_RO"
        }
    }

    fun snapshot(context: Context, extra: String): String {
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            val parts = ArrayList<String>()
            parts.add("ignoreBatteryOpt=" + pm.isIgnoringBatteryOptimizations(context.packageName))
            parts.add("screenOn=" + pm.isInteractive)
            parts.add("doze=" + pm.isDeviceIdleMode)
            // MỤC CU4: Doze NHẸ (light idle) — bắt đầu khoảng vài phút sau khi tắt màn hình, TRƯỚC Doze sâu. Log 2026-10-11 cho thấy máy ngủ chủ yếu
            // ở pha này mà chỉ số `doze` (Doze sâu) vẫn false => phải ghi riêng. API 33+.
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    parts.add("lightDoze=" + pm.isDeviceLightIdleMode)
                } catch (t: Throwable) {
                    parts.add("lightDoze=khong_doc_duoc")
                }
            }
            parts.add(batteryText(context))
            parts.add("powerSave=" + pm.isPowerSaveMode)
            try {
                val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
                if (usm != null) parts.add("standbyBucket=" + usm.appStandbyBucket)
            } catch (t: Throwable) {
                parts.add("standbyBucket=loi:" + t.javaClass.simpleName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                parts.add("thermal=" + pm.currentThermalStatus)
            }
            // MỤC CP: GỐC của giả thuyết "wake lock bị hệ thống bỏ qua": dịch vụ nền có THẬT SỰ chạy ở trạng thái foreground không,
            // thông báo có bị tắt không, và chế độ Low Power Standby (tài liệu Android: wake lock của MỌI app, kể cả app có
            // dịch vụ nền, bị bỏ qua khi bật chế độ này lúc máy không tương tác).
            parts.add("svcRunning=" + GenerationService.isRunning)
            parts.add("svcWakeLockHeld=" + GenerationService.wakeLockHeldNow)
            // MỤC CU4: `svcWakeLockHeld` ở trên chỉ là cờ đặt lúc acquire (không tự hạ khi wake lock hết hạn 40 phút) => KHÔNG chứng minh gì.
            // `svcWakeLockLive` đọc isHeld THẬT của wake lock dịch vụ ngay lúc ghi.
            parts.add("svcWakeLockLive=" + GenerationService.wakeLockLiveHeld())
            // MỤC CQ: mức ưu tiên thật của tiến trình + lỗi startForeground thật (nếu có) + dịch vụ đã vào foreground được bao lâu.
            parts.add("procImportance=" + ownImportanceText())
            parts.add("svcFgError=" + (if (GenerationService.foregroundError.isEmpty()) "khong" else GenerationService.foregroundError))
            val fgAt = GenerationService.foregroundOkAtMs
            parts.add("svcFgAgeMs=" + (if (fgAt == 0L) "chua_vao_fg" else (SystemClock.elapsedRealtime() - fgAt).toString()))
            try {
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                var fg = false
                for (info in am.getRunningServices(100)) {
                    if (info.service.className == GenerationService::class.java.name) fg = info.foreground
                }
                parts.add("svcForegroundPerSystem=" + fg)
            } catch (t: Throwable) {
                parts.add("svcForegroundPerSystem=loi:" + t.javaClass.simpleName)
            }
            try {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                parts.add("notifEnabled=" + nm.areNotificationsEnabled())
                parts.add("notifActive=" + nm.activeNotifications.size)
            } catch (t: Throwable) {
                parts.add("notif=loi:" + t.javaClass.simpleName)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                try {
                    parts.add("lowPowerStandby=" + pm.isLowPowerStandbyEnabled)
                } catch (t: Throwable) {
                    parts.add("lowPowerStandby=khong_doc_duoc")
                }
            }
            // MỤC CU3 (2026-10-11): log 2026-10-11 cho thấy máy VẪN ngủ ~27/33 phút khi tắt màn hình dù: miễn tối ưu pin, dịch vụ foreground
            // được hệ thống công nhận (procImportance=125, svcForegroundPerSystem=true), wake lock đang giữ, lowPowerStandby=false, doze=false
            // lúc bắt đầu => không còn là lỗi dịch vụ nền của app. Giả thuyết còn lại có thể ĐỌC ĐƯỢC từ chính app: hãng/hệ thống đặt
            // "app-op" của app ở chế độ IGNORED (khi đó wake lock có `isHeld=true` nhưng không có tác dụng). Hàm công khai
            // AppOpsManager.unsafeCheckOpNoThrow (API 29+) cho app đọc app-op của CHÍNH MÌNH. Chuỗi op ẩn có thể không tồn tại trên
            // một số bản Android => bọc try/catch riêng từng op, in "loi" thay vì làm hỏng cả dòng log. 0=ALLOWED 1=IGNORED 2=ERRORED 3=DEFAULT 4=FOREGROUND.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    val aom = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
                    val myUid = android.os.Process.myUid()
                    for (op in arrayOf("android:wake_lock", "android:run_in_background", "android:run_any_in_background")) {
                        val modeText = try {
                            when (val m = aom.unsafeCheckOpNoThrow(op, myUid, context.packageName)) {
                                android.app.AppOpsManager.MODE_ALLOWED -> "ALLOWED"
                                android.app.AppOpsManager.MODE_IGNORED -> "IGNORED"
                                android.app.AppOpsManager.MODE_ERRORED -> "ERRORED"
                                android.app.AppOpsManager.MODE_DEFAULT -> "DEFAULT"
                                else -> "mode" + m.toString()
                            }
                        } catch (t: Throwable) {
                            "loi:" + t.javaClass.simpleName
                        }
                        parts.add("appop[" + op.removePrefix("android:") + "]=" + modeText)
                    }
                } catch (t: Throwable) {
                    parts.add("appop=loi:" + t.javaClass.simpleName)
                }
            }
            if (extra.isNotEmpty()) parts.add(extra)
            parts.joinToString(", ")
        } catch (t: Throwable) {
            "snapshot loi: " + t.javaClass.simpleName + ": " + t.message
        }
    }
}

// MỤC CU4 (2026-10-11) — DÒNG THỜI GIAN SỰ KIỆN NGUỒN CỦA CẢ TIẾN TRÌNH.
// VÌ SAO: người dùng chỉ ra đúng: trước đây "máy ngủ khi tắt màn hình" chỉ được SUY LUẬN từ vài mẫu, không có log dựng sẵn để KIỂM CHỨNG. Lớp này
// đăng ký (1 lần/tiến trình, trên application context) bộ nhận các broadcast hệ thống liên quan tới việc máy có ngủ/Doze hay không và ghi mỗi sự kiện
// kèm mốc "bao lâu sau khi tắt màn hình" + ảnh chụp trạng thái nguồn. CHỈ ĐỌC/GHI LOG — không đổi hành vi giữ máy thức.
internal object BgTimeline {
    @Volatile
    private var registered = false

    // 0 = màn hình đang sáng (hoặc chưa biết); >0 = elapsedRealtime lúc nhận SCREEN_OFF; -2 = đã tắt TRƯỚC khi bắt đầu theo dõi (không rõ từ bao giờ).
    @Volatile
    var screenOffSinceElapsedMs: Long = 0L

    @Volatile
    var activeGenerations: Int = 0

    private val lock = Any()
    private val events = ArrayList<Pair<Long, String>>() // (elapsedRealtime, mô tả ngắn) — giữ tối đa 300 sự kiện gần nhất

    fun sinceScreenOffText(): String {
        val s = screenOffSinceElapsedMs
        return when {
            s > 0L -> ((SystemClock.elapsedRealtime() - s) / 1000L).toString() + "s"
            s == -2L -> "tat_truoc_khi_theo_doi(khong_ro)"
            else -> "man_hinh_dang_sang"
        }
    }

    fun sinceScreenOffSeconds(): Long {
        val s = screenOffSinceElapsedMs
        return if (s > 0L) (SystemClock.elapsedRealtime() - s) / 1000L else -1L
    }

    fun eventsSince(elapsedMs: Long): List<Pair<Long, String>> {
        synchronized(lock) {
            val out = ArrayList<Pair<Long, String>>()
            for (e in events) if (e.first >= elapsedMs) out.add(e)
            return out
        }
    }

    private fun shortName(action: String): String {
        return when (action) {
            Intent.ACTION_SCREEN_OFF -> "TAT_MAN_HINH"
            Intent.ACTION_SCREEN_ON -> "BAT_MAN_HINH"
            Intent.ACTION_POWER_CONNECTED -> "CAM_SAC"
            Intent.ACTION_POWER_DISCONNECTED -> "RUT_SAC"
            PowerManager.ACTION_DEVICE_IDLE_MODE_CHANGED -> "DOZE_SAU_DOI"
            PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> "TIET_KIEM_PIN_DOI"
            "android.os.action.LIGHT_DEVICE_IDLE_MODE_CHANGED" -> "DOZE_NHE_DOI"
            "android.os.action.LOW_POWER_STANDBY_ENABLED_CHANGED" -> "LOW_POWER_STANDBY_DOI"
            "android.os.action.POWER_SAVE_WHITELIST_CHANGED" -> "DANH_SACH_MIEN_PIN_DOI"
            else -> action
        }
    }

    @Synchronized
    fun ensure(context: Context) {
        if (registered) return
        val app = context.applicationContext ?: context
        try {
            val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
            screenOffSinceElapsedMs = if (pm.isInteractive) 0L else -2L
        } catch (_: Throwable) {
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                try {
                    val action = intent?.action ?: return
                    val now = SystemClock.elapsedRealtime()
                    if (action == Intent.ACTION_SCREEN_OFF) screenOffSinceElapsedMs = now
                    if (action == Intent.ACTION_SCREEN_ON) screenOffSinceElapsedMs = 0L
                    val name = shortName(action)
                    synchronized(lock) {
                        events.add(Pair(now, name + " (sau_tat_man_hinh=" + sinceScreenOffText() + ")"))
                        while (events.size > 300) events.removeAt(0)
                    }
                    // slept: tổng thời gian máy đã ngủ từ lúc khởi động = elapsedRealtime - uptimeMillis (chung cho cả tiến trình, không cần mốc riêng).
                    val sleptSinceBoot = now - SystemClock.uptimeMillis()
                    kLog(app, "[BG-EVT] " + name + " | sau_tat_man_hinh=" + sinceScreenOffText() + " | dang_sinh=" + (activeGenerations > 0) +
                        " | ngu_tu_luc_bat_may=" + sleptSinceBoot + "ms | " + PowerDiagnostics.snapshot(app, ""))
                } catch (t: Throwable) {
                    kLog(app, "[BG-EVT] receiver loi: " + t.javaClass.simpleName + ": " + (t.message ?: ""))
                }
            }
        }
        val filter = IntentFilter()
        for (a in arrayOf(
            Intent.ACTION_SCREEN_OFF, Intent.ACTION_SCREEN_ON, Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED,
            PowerManager.ACTION_DEVICE_IDLE_MODE_CHANGED, PowerManager.ACTION_POWER_SAVE_MODE_CHANGED,
            "android.os.action.LIGHT_DEVICE_IDLE_MODE_CHANGED", "android.os.action.LOW_POWER_STANDBY_ENABLED_CHANGED",
            "android.os.action.POWER_SAVE_WHITELIST_CHANGED"
        )) filter.addAction(a)
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                app.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                app.registerReceiver(receiver, filter)
            }
            registered = true
            kLog(app, "[BG-EVT] da dang ky nhan su kien nguon (man hinh/sac/Doze sau/Doze nhe/tiet kiem pin/Low Power Standby/danh sach mien pin). " +
                "sau_tat_man_hinh=" + sinceScreenOffText())
            kLog(app, "[BG-ENV] " + PowerDiagnostics.envText(app))
        } catch (t: Throwable) {
            kLog(app, "[BG-EVT] KHONG dang ky duoc bo nhan su kien: " + t.javaClass.simpleName + ": " + (t.message ?: ""))
        }
    }
}

// Theo dõi trong lúc 1 lệnh sinh chữ chạy. MỤC CU4 viết lại để KIỂM CHỨNG ĐƯỢC chuyện "máy ngủ giữa chừng":
//  - mỗi 1 giây (đồng hồ uptime, tức là chỉ đếm lúc máy thức, nên KHÔNG làm máy thức thêm) đọc 2 đồng hồ elapsedRealtime/uptimeMillis; hiệu của chúng
//    tăng thêm = thời gian máy vừa ngủ (suspend) trong khoảng đó. Mỗi lần thức dậy sau ngủ > 1,5 giây ghi 1 dòng [BG-NGU] kèm ảnh chụp trạng thái.
//  - mỗi 30 giây thức liên tục ghi nhận 1 mẫu "KHÔNG ngủ" để so với các mẫu "vừa ngủ" (bảng đối chiếu trong kết luận).
//  - [BG-DOI] khi trạng thái đổi, [BG-TICK] mỗi 5 phút (tổng thời gian thực / ngủ / % / pha hiện tại), [BG-EVT] sự kiện hệ thống (BgTimeline).
//  - khi kết thúc: [BG-VERDICT] — số liệu tổng, bảng ngủ theo pha (MÀN HÌNH SÁNG / DOZE NHẸ / DOZE SÂU / TẮT MÀN HÌNH KHÔNG DOZE), đối chiếu các chỉ báo,
//    và kết luận TỰ ĐỘNG theo luật (nêu rõ cái gì chưa chứng minh được).
// THIÊN LỆCH LẤY MẪU phải nhớ khi đọc: mẫu chỉ lấy được lúc máy THỨC (đúng cửa sổ bảo trì), nên `doze=false` lúc vừa thức không tự chứng minh máy không ở Doze.
internal class PowerWatcher(
    private val context: Context,
    private val tag: String,
    private val extraProvider: () -> String
) {
    @Volatile
    private var running = false
    private var thread: Thread? = null
    private val elapsed0 = SystemClock.elapsedRealtime()
    private val uptime0 = SystemClock.uptimeMillis()

    private val lock = Any()
    private var episodes = 0
    private var longestEpisodeMs = 0L
    private var firstEpisodeScreenOffSec = -2L // -2 = chưa có lần ngủ nào; -1 = ngủ lúc màn hình sáng
    private val phaseAwakeMs = LinkedHashMap<String, Long>()
    private val phaseSleptMs = LinkedHashMap<String, Long>()
    private val valuesAtSuspend = HashMap<String, MutableSet<String>>()
    private val valuesContinuous = HashMap<String, MutableSet<String>>()
    private var continuousSamples = 0
    private var suspendSuccess0: Long? = null
    private var suspendFail0: Long? = null
    private val resumeReasons = LinkedHashMap<String, Int>()

    private val trackKeys = arrayOf(
        "ignoreBatteryOpt", "screenOn", "doze", "lightDoze", "powerSave", "standbyBucket", "thermal", "svcRunning", "svcWakeLockLive",
        "procImportance", "svcForegroundPerSystem", "lowPowerStandby", "appop[wake_lock]", "appop[run_in_background]",
        "appop[run_any_in_background]", "plugged", "directWakeLockHeld", "notifEnabled"
    )

    private fun sleptSoFarMs(): Long {
        val elapsed = SystemClock.elapsedRealtime() - elapsed0
        val uptime = SystemClock.uptimeMillis() - uptime0
        return elapsed - uptime
    }

    private fun addTo(map: HashMap<String, MutableSet<String>>, snap: Map<String, String>) {
        for (k in trackKeys) {
            val v = snap[k] ?: continue
            map.getOrPut(k) { LinkedHashSet() }.add(v)
        }
    }

    private fun diffText(old: Map<String, String>, new: Map<String, String>): String {
        val sb = StringBuilder()
        for ((k, v) in new) {
            if (k == "svcFgAgeMs") continue // đổi mỗi lần đọc, không mang thông tin
            val o = old[k]
            if (o != v) {
                if (sb.isNotEmpty()) sb.append("; ")
                sb.append(k).append(": ").append(o ?: "(chua co)").append(" -> ").append(v)
            }
        }
        return sb.toString()
    }

    fun start() {
        BgTimeline.ensure(context)
        BgTimeline.activeGenerations = BgTimeline.activeGenerations + 1
        suspendSuccess0 = PowerDiagnostics.suspendSuccessCount()
        suspendFail0 = PowerDiagnostics.suspendFailCount()
        kLog(context, "[PWR] " + tag + " BAT DAU: " + PowerDiagnostics.snapshot(context, extraProvider()))
        kLog(context, "[BG-NGU] " + tag + " bat dau theo doi: sau_tat_man_hinh=" + BgTimeline.sinceScreenOffText() +
            ", suspend_success(sysfs)=" + (suspendSuccess0?.toString() ?: "khong_doc_duoc") +
            ". Moi lan may thuc day sau khi ngu > 1500ms se co 1 dong [BG-NGU]; ket luan o [BG-VERDICT] khi ket thuc.")
        running = true
        val t = Thread {
            var lastE = SystemClock.elapsedRealtime()
            var lastU = SystemClock.uptimeMillis()
            var phase = PowerDiagnostics.currentPhase(context)
            var lastSnapMap = PowerDiagnostics.parseSnapshot(PowerDiagnostics.snapshot(context, extraProvider()))
            var awakeStreakMs = 0L
            var lastContinuousSampleU = lastU
            var lastTickE = lastE
            var loop = 0
            while (running) {
                try {
                    Thread.sleep(1000)
                } catch (_: InterruptedException) {
                    break
                }
                if (!running) break
                try {
                    val e = SystemClock.elapsedRealtime()
                    val u = SystemClock.uptimeMillis()
                    val dE = e - lastE
                    val dU = u - lastU
                    val gap = dE - dU
                    lastE = e
                    lastU = u
                    loop++
                    val episode = gap > 1500L
                    if (episode || loop % 5 == 0) phase = PowerDiagnostics.currentPhase(context)
                    synchronized(lock) {
                        phaseAwakeMs[phase] = (phaseAwakeMs[phase] ?: 0L) + dU
                        if (gap > 20L) phaseSleptMs[phase] = (phaseSleptMs[phase] ?: 0L) + gap
                    }
                    if (episode) {
                        awakeStreakMs = 0L
                        val snapText = PowerDiagnostics.snapshot(context, extraProvider())
                        val snap = PowerDiagnostics.parseSnapshot(snapText)
                        val reason = PowerDiagnostics.lastResumeReason()
                        val slept = sleptSoFarMs()
                        val wall = e - elapsed0
                        var n = 0
                        synchronized(lock) {
                            episodes++
                            n = episodes
                            if (gap > longestEpisodeMs) longestEpisodeMs = gap
                            if (firstEpisodeScreenOffSec == -2L) firstEpisodeScreenOffSec = BgTimeline.sinceScreenOffSeconds()
                            addTo(valuesAtSuspend, snap)
                            if (reason != null) resumeReasons[reason] = (resumeReasons[reason] ?: 0) + 1
                        }
                        if (n <= 40 || gap >= 60000L || n % 10 == 0) {
                            val pct = if (wall > 0) (slept * 1000L / wall).toInt() / 10.0 else 0.0
                            kLog(context, "[BG-NGU] " + tag + " #" + n + " MAY VUA NGU " + gap + "ms (tong ngu " + slept + "ms = " + pct +
                                "% thoi gian thuc) | pha=" + phase + " | sau_tat_man_hinh=" + BgTimeline.sinceScreenOffText() +
                                " | ly_do_thuc=" + (reason ?: "khong_doc_duoc") + " | " + snapText)
                        }
                        lastSnapMap = snap
                        lastContinuousSampleU = u
                    } else {
                        awakeStreakMs += dU
                        // mẫu "không ngủ": chỉ lấy khi đã thức LIÊN TỤC >= 20 giây, cách mẫu trước >= 30 giây (uptime)
                        if (awakeStreakMs >= 20000L && u - lastContinuousSampleU >= 30000L) {
                            lastContinuousSampleU = u
                            val snapText = PowerDiagnostics.snapshot(context, extraProvider())
                            val snap = PowerDiagnostics.parseSnapshot(snapText)
                            synchronized(lock) {
                                continuousSamples++
                                addTo(valuesContinuous, snap)
                            }
                            val d = diffText(lastSnapMap, snap)
                            if (d.isNotEmpty()) {
                                kLog(context, "[BG-DOI] " + tag + " trang thai doi (pha=" + phase + ", sau_tat_man_hinh=" +
                                    BgTimeline.sinceScreenOffText() + "): " + d)
                            }
                            lastSnapMap = snap
                        }
                    }
                    if (e - lastTickE >= 300000L) {
                        lastTickE = e
                        val wall = e - elapsed0
                        val slept = sleptSoFarMs()
                        val pct = if (wall > 0) (slept * 1000L / wall).toInt() / 10.0 else 0.0
                        kLog(context, "[BG-TICK] " + tag + " t=+" + (wall / 1000L) + "s thuc, chay that=" + ((wall - slept) / 1000L) + "s, ngu=" +
                            (slept / 1000L) + "s (" + pct + "%) | pha=" + phase + " | sau_tat_man_hinh=" + BgTimeline.sinceScreenOffText() +
                            " | so_lan_ngu=" + episodes)
                    }
                } catch (t: Throwable) {
                    kLog(context, "[BG-NGU] " + tag + " vong theo doi loi (bo qua): " + t.javaClass.simpleName + ": " + (t.message ?: ""))
                }
            }
        }
        t.isDaemon = true
        t.name = "PowerWatcher"
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        try {
            thread?.interrupt()
        } catch (_: Throwable) {
        }
        try {
            thread?.join(1500)
        } catch (_: Throwable) {
        }
        BgTimeline.activeGenerations = maxOf(0, BgTimeline.activeGenerations - 1)
        kLog(context, "[PWR] " + tag + " KET THUC: tong thoi gian may NGU = " + sleptSoFarMs() + "ms. " +
            PowerDiagnostics.snapshot(context, extraProvider()))
        try {
            for (line in buildVerdict()) kLog(context, "[BG-VERDICT] " + tag + " " + line)
        } catch (t: Throwable) {
            kLog(context, "[BG-VERDICT] " + tag + " loi khi tong hop: " + t.javaClass.simpleName + ": " + (t.message ?: ""))
        }
    }

    private fun seen(key: String): String {
        val a = valuesAtSuspend[key]?.joinToString("|") ?: "-"
        val c = valuesContinuous[key]?.joinToString("|") ?: "-"
        return "luc_vua_ngu={" + a + "} luc_chay_lien_tuc={" + c + "}"
    }

    private fun anyValue(key: String, pred: (String) -> Boolean): Boolean {
        val a = valuesAtSuspend[key]
        val c = valuesContinuous[key]
        if (a != null && a.any(pred)) return true
        if (c != null && c.any(pred)) return true
        return false
    }

    private fun buildVerdict(): List<String> {
        val out = ArrayList<String>()
        synchronized(lock) {
            val wall = SystemClock.elapsedRealtime() - elapsed0
            val steady = SystemClock.uptimeMillis() - uptime0
            val slept = wall - steady
            val pct = if (wall > 0) (slept * 1000L / wall).toInt() / 10.0 else 0.0
            out.add("=== TONG KET LAN SINH NAY ===")
            out.add("thoi_gian_thuc=" + (wall / 1000L) + "s, chay_that(steady, khong gom ngu)=" + (steady / 1000L) + "s, may_ngu=" + (slept / 1000L) +
                "s (" + pct + "%), so_lan_ngu_>1.5s=" + episodes + ", lan_ngu_dai_nhat=" + longestEpisodeMs + "ms, " +
                "lan_ngu_dau_tien_sau_tat_man_hinh=" + (if (firstEpisodeScreenOffSec == -2L) "khong_co" else if (firstEpisodeScreenOffSec < 0) "luc_man_hinh_sang" else firstEpisodeScreenOffSec.toString() + "s"))
            val s1 = PowerDiagnostics.suspendSuccessCount()
            val f1 = PowerDiagnostics.suspendFailCount()
            val s0 = suspendSuccess0
            val f0 = suspendFail0
            if (s0 != null && s1 != null) {
                out.add("suspend THAT theo nhan he dieu hanh (/sys/power/suspend_stats): thanh_cong +" + (s1 - s0) + ", that_bai +" +
                    (if (f0 != null && f1 != null) (f1 - f0).toString() else "?") + "  (doc duoc => so lan ngu o tren da duoc doi chung doc lap)")
            } else {
                out.add("suspend_stats cua nhan: khong_doc_duoc (SELinux chan app thuong) — chi dua vao 2 dong ho elapsedRealtime/uptimeMillis")
            }
            if (resumeReasons.isNotEmpty()) {
                out.add("ly_do_thuc_day: " + resumeReasons.entries.joinToString("; ") { it.key + " x" + it.value })
            }
            out.add("--- NGU THEO PHA (pha lay tai thoi diem thuc day; cua so bao tri cua Doze roi vao TAT_MAN_HINH_KHONG_DOZE) ---")
            val phases = LinkedHashSet<String>()
            phases.addAll(phaseAwakeMs.keys)
            phases.addAll(phaseSleptMs.keys)
            var maxPhase = ""
            var maxPct = -1.0
            for (p in phases) {
                val aw = phaseAwakeMs[p] ?: 0L
                val sl = phaseSleptMs[p] ?: 0L
                val tot = aw + sl
                val pp = if (tot > 0) (sl * 1000L / tot).toInt() / 10.0 else 0.0
                out.add("pha=" + p + ": chay_that=" + (aw / 1000L) + "s, ngu=" + (sl / 1000L) + "s (" + pp + "% cua pha)")
                if (tot >= 30000L && pp > maxPct) {
                    maxPct = pp
                    maxPhase = p
                }
            }
            out.add("--- DOI CHUNG CAC CHI BAO (so mau 'chay lien tuc' = " + continuousSamples + ", so lan ngu = " + episodes + ") ---")
            for (k in trackKeys) {
                if (valuesAtSuspend.containsKey(k) || valuesContinuous.containsKey(k)) out.add(k + ": " + seen(k))
            }
            // ---- kết luận theo luật ----
            out.add("--- KET LUAN TU DONG (theo luat; chi la goi y tu so lieu tren, KHONG phai chung minh) ---")
            val suspects = ArrayList<String>()
            if (anyValue("ignoreBatteryOpt") { it == "false" }) suspects.add("ignoreBatteryOpt=false: he thong KHONG coi app la duoc mien toi uu pin => wake lock co the bi vo hieu hoa khi Doze.")
            if (anyValue("procImportance") { !(it.startsWith("100") || it.startsWith("125")) }) suspects.add("procImportance khong phai 100/125: he thong khong xep tien trinh vao foreground/foreground-service luc dang sinh => wake lock co the bi bo qua.")
            if (anyValue("svcForegroundPerSystem") { it != "true" }) suspects.add("svcForegroundPerSystem khong true: he thong khong cong nhan dich vu la foreground.")
            if (anyValue("svcWakeLockLive") { it == "false" }) suspects.add("svcWakeLockLive=false luc may ngu: wake lock cua dich vu KHONG con giu (het han/chua acquire) => loi phia app.")
            if (anyValue("directWakeLockHeld") { it == "false" }) suspects.add("directWakeLockHeld=false luc may ngu: wake lock truc tiep KHONG con giu => loi phia app.")
            if (anyValue("appop[wake_lock]") { it == "IGNORED" || it == "ERRORED" }) suspects.add("appop[wake_lock]=IGNORED/ERRORED: he thong/hang dang vo hieu hoa wake lock cua app (isHeld=true nhung khong co tac dung) => KHOP voi hien tuong ngu.")
            if (anyValue("appop[run_in_background]") { it == "IGNORED" || it == "ERRORED" } ||
                anyValue("appop[run_any_in_background]") { it == "IGNORED" || it == "ERRORED" }) suspects.add("appop chay nen bi chan (run_in_background / run_any_in_background = IGNORED): app bi cam chay nen => co the bi tam dung/ngu.")
            if (anyValue("lowPowerStandby") { it == "true" }) suspects.add("lowPowerStandby=true: che do Low Power Standby bo qua wake lock cua app khi may khong tuong tac.")
            if (anyValue("standbyBucket") { (it.toIntOrNull() ?: 0) >= 45 }) suspects.add("standbyBucket>=45 (RESTRICTED): app bi han che nen manh.")
            for (sline in suspects) out.add("NGHI VAN: " + sline)
            if (steady < 30000L) {
                out.add("Luot sinh qua ngan (<30s chay that) — khong du du lieu de ket luan ve chay nen.")
            } else if (pct < 5.0) {
                out.add("Lan nay may KHONG ngu dang ke (" + pct + "%). Chua the ket luan gi ve cac lan khac; neu lan nay tat man hinh thi day la bang chung NGAN cho thay giu may thuc hoat dong (chi xet lan nay).")
            } else if (suspects.isEmpty()) {
                out.add("May ngu " + pct + "% du MOI chi bao ma app doc duoc deu ĐUNG (mien pin, foreground-service, wake lock con giu, app-op khong chan). => Nguyen nhan nam NGOAI tam nhin cua app (ROM/hang cat wake lock theo co che rieng, hoac kernel/modem). App khong tu sua duoc tu phia no; KHONG duoc tuyen bo da tim ra nguyen nhan.")
                out.add("DOI CHUNG BEN NGOAI de chot (khong can ban nao khac cua app): sau mot lan chay tat man hinh, chay `adb shell dumpsys power` (hoac bao cao loi/bugreport) xem muc Wake Locks cua LocalNovel co dau DISABLED khong, va muc 'Wakeup reason' trong dumpsys batterystats.")
            } else {
                out.add("May ngu " + pct + "% va co " + suspects.size + " nghi van o tren; xu ly nghi van theo thu tu liet ke roi chay lai de doi chieu (khong ket luan 'da sua' khi chua co log chay lai).")
            }
            if (maxPhase.isNotEmpty() && maxPct >= 20.0 && slept > 0) {
                out.add("Ngu tap trung nhat o pha " + maxPhase + " (" + maxPct + "% thoi gian cua pha).")
            }
            val deepAwake = phaseAwakeMs["DOZE_SAU"] ?: 0L
            val deepSlept = phaseSleptMs["DOZE_SAU"] ?: 0L
            if (deepAwake + deepSlept >= 60000L) {
                if (deepSlept < 3000L) {
                    out.add("DOI CHUNG DUONG: trong Doze sau (" + (deepAwake / 1000L) + "s) may KHONG ngu (ngu " + (deepSlept / 1000L) + "s) => o pha nay wake lock + mien pin + foreground-service HOAT DONG DUNG.")
                } else {
                    out.add("Trong Doze sau may van ngu " + (deepSlept / 1000L) + "s tren " + ((deepAwake + deepSlept) / 1000L) + "s.")
                }
            }
            val ev = BgTimeline.eventsSince(elapsed0)
            if (ev.isNotEmpty()) {
                out.add("--- SU KIEN HE THONG TRONG LAN NAY (moc = giay tu luc bat dau sinh) ---")
                var shown = 0
                for (x in ev) {
                    if (shown >= 40) break
                    out.add("+" + ((x.first - elapsed0) / 1000L) + "s " + x.second)
                    shown++
                }
            }
            out.add("LUU Y DOC: cac mau chi lay duoc luc may THUC; 'doze=false' luc vua thuc co the la cua so bao tri cua Doze, khong chung minh may khong o Doze. Cac con so 'ngu' thi do truc tiep tu 2 dong ho nen dung.")
        }
        return out
    }
}

package com.localnovel.mnnbridge

import android.content.Context
import android.content.Intent
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.system.Os
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ĐÃ SỬA — mục AZ: đổi private -> internal. `private` ở cấp top-level trong
// Kotlin chỉ nhìn thấy được TRONG ĐÚNG FILE này — CancelGenerationReceiver.kt
// (file khác, dù cùng package) gọi `kLog` sẽ KHÔNG BIÊN DỊCH ĐƯỢC nếu giữ
// nguyên `private`. `internal` nhìn thấy được toàn module (app này), vẫn
// không lộ ra ngoài — đủ dùng, không đổi hành vi ghi log hiện tại.
internal fun logDir(context: Context): File = context.filesDir

internal fun kLog(context: Context, msg: String) {
    try {
        val f = File(logDir(context), "native_debug.txt")
        val ts = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US).format(Date())
        FileWriter(f, true).use { it.write("[$ts] [Kotlin] $msg\n") }
    } catch (_: Throwable) {}
}

private var qnnEnvSetupDone = false
private fun setupQnnEnvironmentOnce(context: Context) {
    // ĐÃ THÊM (2026-08-29 — theo yêu cầu người dùng, cần biết chắc phần
    // này có phải thủ phạm gây "nạp lại chậm" hay không thay vì đoán):
    // đo cả 2 nhánh — bỏ qua (đã chạy 1 lần trong tiến trình này) hay
    // chạy đầy đủ — để đối chiếu trực tiếp với thời gian reset/createLLM/
    // load ở tầng native trong CÙNG 1 lần nạp.
    val tSetupStart = System.currentTimeMillis()
    if (qnnEnvSetupDone) {
        kLog(context, "setupQnnEnvironmentOnce: DA CHAY roi (trong tien trinh nay) — BO QUA, mat " +
            "${System.currentTimeMillis() - tSetupStart}ms")
        return
    }
    qnnEnvSetupDone = true
    try {
        val libDir = context.applicationInfo.nativeLibraryDir
        kLog(context, "setupQnnEnvironmentOnce: thu muc thu vien native = $libDir")
        Os.setenv("ADSP_LIBRARY_PATH", libDir, true)
        Os.setenv("LD_LIBRARY_PATH", libDir, true)
        kLog(context, "setupQnnEnvironmentOnce: da dat ADSP_LIBRARY_PATH va LD_LIBRARY_PATH = $libDir")
        // SUA LOI KIEN TRUC (phat hien khi doi chieu ky lai): libQnnHtpV68Skel.so
        // KHONG PHAI thu vien ARM64 — day la binary bien dich CHO CHINH
        // HEXAGON DSP (kien truc CPU hoan toan khac ARM64), chi chay duoc
        // BEN TRONG chip DSP, khong bao gio chay tren tien trinh ARM64 cua
        // app. Goi System.load() cho file nay se LUON LUON that bai (dung
        // linker cua Android/ARM64 khong the nap 1 file ELF cho kien truc
        // Hexagon) — BAT KE file co ton tai dung cho hay khong, bat ke
        // build.yml co copy dung hay khong. Day la 1 phan ly do TRUOC GIO
        // ca 5 dong log deu bao "THAT BAI", khien khong phan biet duoc dau
        // la loi that (4 file ARM64 kia thieu that) va dau la hanh vi BINH
        // THUONG DUOC MONG DOI (Skel luon "that bai" theo kieu nay).
        //
        // Cach dung: KHONG System.load() file Skel — chi can no NAM DUNG
        // CHO trong thu muc native (jniLibs/arm64-v8a, da duoc dat dung
        // ADSP_LIBRARY_PATH tro toi o tren) de chinh Qualcomm FastRPC/ADSP
        // runtime (chay o tang thap hon, khong qua System.load) tu tim va
        // day no vao DSP that khi can — dung theo tai lieu MNN Chat that.
        val libsToSystemLoad = listOf(
            "libQnnSystem.so",
            "libQnnHtp.so",
            "libQnnHtpPrepare.so",
            "libQnnHtpV68Stub.so",
        )
        for (name in libsToSystemLoad) {
            val fullPath = "$libDir/$name"
            try {
                System.load(fullPath)
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THANH CONG")
            } catch (e: Throwable) {
                kLog(context, "setupQnnEnvironmentOnce: System.load($name) THAT BAI: ${e.javaClass.simpleName}: ${e.message} — NEU day la 1 trong 4 file ARM64 that (System/Htp/HtpPrepare/Stub), day LA loi that, can kiem tra lai build.yml co copy dung file khong")
            }
        }
        // Chi kiem tra SU TON TAI cua file Skel (khong System.load()) — de
        // biet chac no co that trong APK hay khong, phong khi build.yml
        // copy thieu (Skel la file BAT BUOC de FastRPC tim thay tren DSP,
        // du khong System.load() no o tang ARM).
        val skelFile = java.io.File(libDir, "libQnnHtpV68Skel.so")
        if (skelFile.exists()) {
            kLog(context, "setupQnnEnvironmentOnce: libQnnHtpV68Skel.so CO TON TAI dung cho (${skelFile.length()} bytes) — se duoc FastRPC/ADSP tim thay qua ADSP_LIBRARY_PATH, khong can System.load()")
        } else {
            kLog(context, "setupQnnEnvironmentOnce: CANH BAO — libQnnHtpV68Skel.so KHONG TON TAI trong $libDir. Neu file nay thieu, QNN se khong bao gio chay duoc tren DSP that du 4 file kia nap thanh cong. Kiem tra lai buoc copy trong build.yml.")
        }
    } catch (e: Throwable) {
        kLog(context, "setupQnnEnvironmentOnce: LOI TONG QUAT: ${e.javaClass.simpleName}: ${e.message}")
    }
    kLog(context, "setupQnnEnvironmentOnce: CHAY DAY DU xong, mat ${System.currentTimeMillis() - tSetupStart}ms")
}

// ĐÃ THỬ RỒI BỎ (xem mục 5.75 tài liệu kiến trúc): từng thêm chọn thư mục
// qua Storage Access Framework (ACTION_OPEN_DOCUMENT_TREE) — build lỗi
// thật trên máy xác nhận: dù suy được "đường dẫn thật" từ URI, code native
// (fopen/opendir) vẫn KHÔNG đọc được nội dung (thư mục rỗng) vì quyền SAF
// chỉ cấp qua content:// URI, không cấp quyền đọc file hệ thống thô. Đã bỏ
// hẳn hướng này — quay về ĐÚNG 1 cơ chế duy nhất mà file manager thật dùng:
// quyền MANAGE_EXTERNAL_STORAGE (xin 1 lần, dùng mãi mãi cho mọi thư mục).
class MnnBridge(
    private val appContext: Context,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default),
) : MethodChannel.MethodCallHandler, EventChannel.StreamHandler {

    // ĐÃ THÊM — mục AZ, 2026-09-16 — theo dõi instance MnnBridge ĐANG SỐNG
    // gần nhất, để `CancelGenerationReceiver` (nút "Hủy" trên notification hệ
    // thống, xem GenerationService.buildNotification) có thể gọi ĐÚNG cùng 1
    // logic huỷ với MethodChannel "cancelGenerate" — không tạo đường huỷ
    // RIÊNG, tránh lệch hành vi giữa 2 nơi. `@Volatile` vì có thể bị đọc từ
    // luồng nhận broadcast (khác luồng Flutter/main tạo ra instance này).
    init {
        currentInstance = this
    }

    private var eventSink: EventChannel.EventSink? = null
    // ĐÃ SỬA (2026-09-05, sau sự cố "Tạo lại tất cả ghi chú" ngày
    // 2026-09-03 — xem lịch sử debug đầy đủ): trước đây `currentJob` là 1
    // BIẾN DUY NHẤT, bị GHI ĐÈ mỗi lần có lệnh "generate" mới — nếu nhiều
    // lệnh generate() dồn dập trước khi lệnh trước xong (chính là những gì
    // xảy ra hôm đó), `cancelGenerate()` chỉ còn huỷ được lệnh MỚI NHẤT;
    // mọi lệnh cũ hơn đang xếp hàng chờ Mutex (xem `generateMutexes` bên
    // dưới) hoàn toàn KHÔNG THỂ huỷ được nữa qua bất kỳ đường nào trong
    // app — user bấm "Huỷ" bao nhiêu lần cũng vô ích với chúng, phải đợi
    // từng cái tự chạy hết (vài phút/lệnh) hoặc khởi động lại app. Giờ
    // theo dõi TOÀN BỘ Job đang sống của MỖI slot (CopyOnWriteArrayList —
    // an toàn khi vừa add từ thread gọi "generate" vừa remove từ bên
    // trong chính coroutine đó, 2 thread có thể khác nhau vì scope dùng
    // Dispatchers.Default) — cancelGenerate() giờ huỷ ĐƯỢC HẾT, kể cả
    // những lệnh còn đang CHỜ Ở HÀNG ĐỢI Mutex (Kotlin Mutex.withLock có
    // thể bị huỷ ngay khi đang chờ khoá, không cần đợi tới lượt).
    private val jobsPerSlot: Array<java.util.concurrent.CopyOnWriteArrayList<Job>> =
        arrayOf(java.util.concurrent.CopyOnWriteArrayList(), java.util.concurrent.CopyOnWriteArrayList())
    private fun jobsForSlot(slot: Int) = jobsPerSlot.getOrElse(slot) { jobsPerSlot[0] }
    // ĐÃ SỬA (2026-08-02, phát hiện qua thiết kế lồng nhau mới của
    // ChapterBatchService + generateWithOptionalTranslation): trước đây
    // `pipelineActive` là Boolean đơn giản — nếu 1 vòng lặp NGOÀI (vd tạo
    // hàng loạt nhiều chương) gọi beginPipeline() 1 lần bọc cả vòng lặp,
    // rồi BÊN TRONG mỗi lượt lại có 1 lệnh generate KHÁC (vd dịch thuật
    // trung gian) cũng tự gọi beginPipeline()/endPipeline() riêng — lệnh
    // endPipeline() của lượt BÊN TRONG sẽ tắt Foreground Service NGAY,
    // dù vòng lặp NGOÀI vẫn còn nhiều việc phải làm tiếp — tạo lại đúng
    // kiểu lỗ hổng "chớp tắt thông báo giữa các bước" đã sửa ở mục 5.61
    // cho xử lý tài liệu, nhưng giờ xảy ra với tạo chương hàng loạt có
    // dịch thuật trung gian. Đổi sang ĐẾM SỐ LẦN LỒNG NHAU (giống khoá
    // reentrant) — chỉ thực sự dừng Foreground Service khi bộ đếm về 0,
    // hỗ trợ đúng bất kỳ độ sâu lồng nhau nào mà không cần Dart phải biết
    ///xử lý đặc biệt cho từng trường hợp.
    private var pipelineDepth = 0
    private val pipelineDepthLock = Object()

    // ===== FIX BUG 2: mainHandler dùng để dispatch mọi lệnh service =====
    // Khai báo ở đây để dùng được trong cả onMethodCallInner VÀ truyền
    // xuống GenerationService — tránh tạo nhiều Handler object.
    private val mainHandler = Handler(Looper.getMainLooper())

    // ĐÃ THÊM (theo log runtime thật — người dùng phát hiện: thời gian THẬT
    // đo bằng std::chrono BÊN TRONG llm->response() (73s) lệch RẤT XA so
    // với thời gian tường (log timestamp cho thấy cách nhau 452s) — chênh
    // lệch ~379s. Nguyên nhân: `std::chrono::steady_clock` (C++) map tới
    // CLOCK_MONOTONIC trên Android/Linux — clock này KHÔNG đếm thời gian
    // lúc thiết bị NGỦ SÂU (suspend), khác CLOCK_BOOTTIME. Log timestamp
    // (system_clock, giờ tường) VẪN đếm — nên chênh lệch = ĐÚNG BẰNG thời
    // gian máy đã ngủ sâu GIỮA CHỪNG lúc đang sinh văn bản. Nghĩa là
    // WakeLock KHÔNG thực sự ngăn được máy ngủ trong trường hợp này.
    //
    // TÌM RA NGUYÊN NHÂN GỐC: `GenerationService.start()`/`.stop()` (gọi từ
    // `beginPipeline`/`loadModel`/`generate` bên dưới) chỉ `mainHandler.post{}`
    // (ĐẨY việc vào hàng đợi main thread rồi TRẢ VỀ NGAY, KHÔNG đợi
    // `onStartCommand()` thật sự chạy xong và giữ được WakeLock) — có 1
    // KHOẢNG HỞ THẬT giữa lúc `nativeGenerate()`/`nativeLoadModel()` BẮT ĐẦU
    // chạy (trên coroutine, gần như ngay lập tức) và lúc WakeLock của
    // `GenerationService` THỰC SỰ được giữ (phụ thuộc main thread Looper xử
    // lý xong Intent đã post) — nếu màn hình vừa tắt/máy vừa chuyển nền ĐÚNG
    // vào khoảnh khắc đó, hệ điều hành có thể bắt đầu ngủ sâu TRƯỚC KHI
    // WakeLock kịp giữ, và 1 khi đã ngủ, CHÍNH quá trình xử lý Intent đang
    // chờ trên hàng đợi main thread cũng bị đóng băng theo — vòng luẩn quẩn
    // không tự thoát ra được cho tới lần "cửa sổ bảo trì" định kỳ tiếp theo
    // của Doze/App Standby (có thể cách nhau nhiều phút).
    //
    // SỬA TẬN GỐC: giữ 1 WakeLock TRỰC TIẾP, ĐỒNG BỘ (không qua post/Intent/
    // Service nào cả) NGAY TẠI ĐÂY, trong CÙNG 1 khối `synchronized` dùng để
    // tăng/giảm `pipelineDepth` — đảm bảo KHÔNG CÓ khoảng hở nào giữa lúc
    // quyết định "đây là lệnh NGOÀI CÙNG" và lúc WakeLock thực sự được giữ.
    // `GenerationService` (thông báo + WakeLock riêng, làm mới mỗi 30 phút)
    // VẪN GIỮ NGUYÊN — coi như lớp bảo vệ THỨ 2 cho phiên chạy DÀI (nhiều
    // giờ/qua đêm), còn WakeLock trực tiếp ở đây là lớp bảo vệ TỨC THỜI cho
    // đúng khoảng hở khởi động, không cần tự làm mới định kỳ (chỉ giữ tối đa
    // 40 phút/lần, đủ dư cho tới khi GenerationService kịp khởi động thật).
    private var directWakeLock: PowerManager.WakeLock? = null
    private val directWakeLockGrantMs = 40 * 60 * 1000L

    private fun acquireDirectWakeLock() {
        if (directWakeLock == null) {
            val pm = appContext.getSystemService(Context.POWER_SERVICE) as PowerManager
            directWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalNovel::MnnBridgeDirectWakeLock")
            directWakeLock?.setReferenceCounted(false)
        }
        directWakeLock?.acquire(directWakeLockGrantMs)
    }

    private fun releaseDirectWakeLockIfHeld() {
        if (directWakeLock?.isHeld == true) directWakeLock?.release()
    }

    // Bọc CẢ 2 việc (WakeLock trực tiếp + GenerationService.start) làm 1 —
    // gọi đúng những nơi TRƯỚC ĐÂY chỉ gọi `GenerationService.start()`, để
    // không nơi nào lỡ quên phần WakeLock trực tiếp.
    private fun startGenerationServiceSync(stage: String) {
        acquireDirectWakeLock()
        GenerationService.start(appContext, stage, mainHandler)
    }

    private fun stopGenerationServiceSync() {
        releaseDirectWakeLockIfHeld()
        GenerationService.stop(appContext, mainHandler)
    }

    // ===== MỤC CQ (2026-10-07) — ĐẾM "HỢP ĐỒNG GIỮ MÁY" CHO TỪNG LỆNH generate/loadModel =====
    // VÌ SAO: trước đây `finally` của generate()/loadModel() làm `if (pipelineDepth == 0) { nhả wake lock; dừng dịch vụ }`. pipelineDepth
    // chỉ đếm beginPipeline/endPipeline của Dart; nhiều lệnh chạy chồng (chat + kiểm tra nhất quán + tóm tắt nền — log thật từng có 2 lệnh
    // generate đè nhau trên 1 slot) thì lệnh NGẮN xong trước thấy depth==0 → NHẢ wake lock + DỪNG dịch vụ trong khi lệnh DÀI vẫn đang chạy.
    // Đúng kiểu "màn hình sáng thì ổn, tắt màn hình là ngủ" mà log 04-05/10 mô tả. Chưa có log chứng minh đây là nguyên nhân của lần
    // ngủ cụ thể đó (cần dòng [PWR] mới có `leases=`/`procImportance=`), nhưng đây là lỗ hổng THẬT trong code, nên đóng lại.
    // CÁCH LÀM: mỗi lệnh giữ 1 "lease" từ lúc nhận đến lúc xong. Chỉ nhả wake lock + dừng dịch vụ khi pipelineDepth==0 VÀ leaseCount==0.
    // `leaseEpoch` tăng khi huỷ toàn bộ (performFullCancel): các lệnh cũ còn kẹt trong native khi xong sẽ KHÔNG trừ nhầm vào bộ đếm mới,
    // và 1 lệnh treo vĩnh viễn không thể giữ dịch vụ sống mãi (huỷ → về 0).
    // Mọi lệnh start/stop dịch vụ nằm TRONG khối synchronized để thứ tự post lên main thread khớp thứ tự quyết định (không có
    // "A quyết định dừng → B xin giữ → lệnh dừng của A tới sau lệnh bật của B").
    private var leaseCount = 0
    private var leaseEpoch = 0

    private fun beginLease(stage: String): Int {
        synchronized(pipelineDepthLock) {
            leaseCount++
            acquireDirectWakeLock()
            GenerationService.start(appContext, stage, mainHandler)
            return leaseEpoch
        }
    }

    private fun endLease(epoch: Int) {
        synchronized(pipelineDepthLock) {
            if (epoch != leaseEpoch) return // lệnh cũ đã bị huỷ toàn bộ — bộ đếm đã được đặt lại, không trừ nữa
            if (leaseCount > 0) leaseCount--
            if (pipelineDepth == 0 && leaseCount == 0) {
                releaseDirectWakeLockIfHeld()
                GenerationService.stop(appContext, mainHandler)
            }
        }
    }

    private fun leaseDebugText(): String = "leases=" + leaseCount + ", pipelineDepth=" + pipelineDepth

    // ĐÃ THÊM — mục AZ: tách thân xử lý "cancelGenerate" (vốn nằm thẳng
    // trong onMethodCallInner) ra thành hàm riêng — để CancelGenerationReceiver
    // (nút "Hủy" trên notification) gọi ĐÚNG same logic thay vì phải chép
    // lại, tránh 2 nơi lệch hành vi theo thời gian. Hành vi giữ NGUYÊN VẸN
    // y hệt case "cancelGenerate" cũ, chỉ đổi chỗ ở.
    fun performFullCancel(slot: Int) {
        val jobsToCancel = jobsForSlot(slot).toList()
        jobsToCancel.forEach { it.cancel() }
        kLog(appContext, "performFullCancel: da huy ${jobsToCancel.size} job (dang cho/dang chay) cho slot=$slot")
        MnnNative.nativeRequestCancel(slot)
        synchronized(pipelineDepthLock) {
            pipelineDepth = 0
            leaseCount = 0   // MỤC CQ
            leaseEpoch++     // MỤC CQ: lệnh cũ còn kẹt native xong sau này sẽ không trừ nhầm
            releaseDirectWakeLockIfHeld()
            GenerationService.stop(appContext, mainHandler)
        }
    }

    // ĐÃ THÊM (2026-08-02, phát hiện qua log thật — CHUỖI CRASH HEAP CORRUPTION
    // BÍ ẨN Ở MỤC 62-64 RẤT CÓ THỂ DO ĐÂY): `nativeLoadModel()` đã có sẵn khoá
    // chống gọi trùng (`g_loadingInProgress` phía C++), nhưng `nativeGenerate()`
    // KHÔNG HỀ CÓ khoá tương tự — log thật bắt được đúng lúc 2 lệnh generate
    // (chat + kiểm tra tính nhất quán chương) chạy ĐÈ LÊN NHAU trên CÙNG 1 slot
    // (slot 0), gây SIGSEGV liên tục 30 lần do 2 luồng cùng ghi/đọc chung 1 đối
    // tượng `Llm` native (KV-cache, buffer tính toán) không có cơ chế loại trừ
    // lẫn nhau (mutual exclusion). MNN's `Llm::response()` KHÔNG được thiết kế
    // để gọi đồng thời từ nhiều luồng trên CÙNG 1 instance.
    // Mỗi slot có 1 Mutex riêng — lệnh generate() cho CÙNG slot phải XẾP HÀNG
    // chờ lệnh trước xong (không bị từ chối, không mất yêu cầu, chỉ chờ), còn
    // slot 0 (model chính) và slot 1 (model dịch, nếu dùng) vẫn chạy độc lập
    // song song bình thường — đúng kiến trúc "2 slot" đã thiết kế từ đầu.
    private val generateMutexes = arrayOf(Mutex(), Mutex())

    private fun mutexForSlot(slot: Int): Mutex = generateMutexes.getOrElse(slot) { generateMutexes[0] }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            onMethodCallInner(call, result)
        } catch (e: Throwable) {
            kLog(appContext, "onMethodCall: LOI NGHIEM TRONG bat duoc o tang ngoai cung — method=${call.method}, loi=${e.javaClass.simpleName}: ${e.message}")
            try {
                result.error("UNCAUGHT_KOTLIN_ERROR", "${e.javaClass.simpleName}: ${e.message}", null)
            } catch (_: Throwable) {}
        }
    }

    private var logDirSent = false

    private fun onMethodCallInner(call: MethodCall, result: MethodChannel.Result) {
        if (!logDirSent) {
            MnnNative.nativeSetLogDir(appContext.filesDir.absolutePath)
            // ĐÃ THÊM: cache dir riêng cho OpenCL kernel tuning cache —
            // dùng cacheDir (Android tự dọn khi cần thêm dung lượng, an
            // toàn để làm dữ liệu tạm), khác files dir dùng cho log.
            MnnNative.nativeSetCacheDir(appContext.cacheDir.absolutePath)
            // ĐÃ THÊM (2026-09-01 — theo yêu cầu người dùng): dọn cache
            // autotuning OpenCL đúng 1 lần lúc app KHỞI ĐỘNG (thêm SAU
            // điểm dọn lúc thoát app bên dưới — xem giải thích đầy đủ ở
            // mnn_bridge.cpp, `nativeEnforceOpenCLCacheCap`). Lý do cần
            // điểm này: điểm "lúc thoát" CHỈ chạy được khi thoát qua đúng
            // back-gesture ở màn gốc — thoát bằng vuốt-khỏi-đa-nhiệm hoặc
            // bị hệ điều hành tự kill vì thiếu RAM đều KHÔNG đi qua đó,
            // không có cách nào Flutter/Dart chặn được để chạy dọn dẹp có
            // `await`. Dọn lúc khởi động không phụ thuộc bắt đúng thời
            // điểm thoát — CHẮC CHẮN chạy được dù lần thoát trước đó xảy
            // ra kiểu gì.
            //
            // ĐÃ SỬA (cùng ngày, PHÁT HIỆN THÊM khi soát lại): ban đầu định
            // chạy trên thread nền (KHÔNG chặn) để khỏi làm chậm lệnh gọi
            // Dart đầu tiên — nhưng như vậy có RACE CONDITION thật: nếu
            // Dart gọi `loadModel` gần như ngay sau khi mở app (thường
            // gặp), thread đó (chạy trên platform thread, xử lý TUẦN TỰ
            // với `onMethodCallInner` — xem MethodChannel mặc định của
            // Flutter) có thể chạy `buildOptimizedOpenCLConfig()`
            // (đụng vào CÙNG thư mục `opencl_tuning/`) TRONG LÚC thread
            // dọn nền vẫn đang xoá — 2 thread thật, không chỉ sai thứ tự
            // trong 1 thread như bug đã sửa ở mục O.2, có thể xoá nhầm
            // đúng lúc `tmp_path` đang được dùng. Đổi lại ĐỒNG BỘ — chạy
            // ngay trên platform thread, TRƯỚC khi trả về từ hàm này —
            // đảm bảo dọn xong hẳn trước khi platform thread có thể xử lý
            // BẤT KỲ lệnh gọi tiếp theo nào (kể cả `loadModel`), loại hẳn
            // race. Đánh đổi: lệnh gọi native ĐẦU TIÊN của phiên (thường
            // là 1 lệnh vô hại như `isSlotGenerating`/`isLoaded`, không
            // nhất thiết là lệnh người dùng đang sốt ruột chờ) chậm thêm
            // đúng bằng thời gian quét+xoá cache — 1 lần duy nhất mỗi
            // phiên, không lặp lại.
            try {
                MnnNative.nativeEnforceOpenCLCacheCap()
            } catch (e: Throwable) {
                kLog(appContext, "nativeEnforceOpenCLCacheCap (khoi dong): loi (bo qua, khong nghiem trong): ${e.javaClass.simpleName}: ${e.message}")
            }
            logDirSent = true
        }
        val slot = call.argument<Int>("slot") ?: MnnNative.SLOT_MAIN
        when (call.method) {
            "beginPipeline" -> {
                val stage = call.argument<String>("stage") ?: "Đang chuẩn bị..."
                // ĐÃ THÊM — mục BB, 2026-09-17 (theo phản hồi người dùng:
                // không được bắt người dùng tự đoán/chứng minh nguồn gốc 1
                // lệnh generate() từ log — trước đây log KHÔNG hề ghi lại
                // stage/tên tính năng, nên lần trước tôi tự ĐOÁN "8B là tạo
                // chương, 7B là chat" chỉ dựa vào ĐỘ DÀI prompt — ĐOÁN SAI,
                // đã bị người dùng chỉ ra đúng). Ghi thẳng nội dung `stage`
                // (thường có tên chương/tính năng, vd "Đang viết: Chương 5
                // (2/5)...") ra log — từ nay log tự trả lời được câu hỏi
                // "lệnh generate() này thuộc tính năng nào", không cần đoán.
                kLog(appContext, "beginPipeline: stage=\"$stage\"")
                // ĐÃ SỬA: chỉ THẬT SỰ gọi start() (bật thông báo mới) khi
                // đây là lần bọc NGOÀI CÙNG (độ sâu từ 0 lên 1) — nếu đã có
                // 1 pipeline khác đang chạy bọc bên ngoài (độ sâu > 0), chỉ
                // cập nhật nội dung thông báo, KHÔNG bật/tắt lại service.
                // ĐÃ SỬA THÊM (xem giải thích đầy đủ ở khai báo `directWakeLock`
                // phía trên): giữ WakeLock trực tiếp NGAY TRONG khối
                // `synchronized` này — trước lúc trả `result.success()` về
                // Dart, tức là trước khi bất kỳ `nativeGenerate()`/
                // `nativeLoadModel()` nào có cơ hội bắt đầu chạy.
                // MỤC CQ: start() nằm TRONG synchronized (khớp thứ tự với endLease/endPipeline); start() tự biết đã chạy hay chưa nên
                // không còn phân biệt start/updateStage ở đây.
                synchronized(pipelineDepthLock) {
                    pipelineDepth++
                    acquireDirectWakeLock()
                    GenerationService.start(appContext, stage, mainHandler)
                }
                result.success(null)
            }
            "updateStage" -> {
                val stage = call.argument<String>("stage") ?: "Đang xử lý..."
                // ĐÃ THÊM — mục BB: xem giải thích đầy đủ ở case "beginPipeline".
                kLog(appContext, "updateStage: stage=\"$stage\"")
                // FIX: truyền mainHandler
                GenerationService.updateStage(appContext, stage, mainHandler)
                result.success(null)
            }
            "endPipeline" -> {
                // ĐÃ SỬA: chỉ THẬT SỰ gọi stop() khi độ sâu về lại 0 (lần
                // endPipeline() cuối cùng khớp với lần beginPipeline() đầu
                // tiên) — nếu vẫn còn pipeline khác bọc bên ngoài đang chạy
                // dở (độ sâu > 0 sau khi giảm), KHÔNG tắt thông báo, để
                // vòng lặp bên ngoài tự tắt khi thật sự xong.
                // MỤC CQ: chỉ nhả khi KHÔNG còn lệnh nào đang giữ lease (xem beginLease) — trước đây lệnh generate vẫn đang chạy dở
                // nhưng Dart đã gọi endPipeline() (huỷ/timeout phía Dart) là wake lock + dịch vụ bị tắt ngay.
                synchronized(pipelineDepthLock) {
                    if (pipelineDepth > 0) pipelineDepth--
                    if (pipelineDepth == 0 && leaseCount == 0) {
                        releaseDirectWakeLockIfHeld()
                        GenerationService.stop(appContext, mainHandler)
                    }
                }
                result.success(null)
            }
            "loadModel" -> {
                val configPath = call.argument<String>("configPath")
                val backendPreference = call.argument<Int>("backendPreference") ?: 0
                if (configPath == null) {
                    result.error("BAD_ARGS", "Thiếu configPath", null)
                    return
                }
                kLog(appContext, "loadModel: CHUAN BI goi GenerationService (pipelineDepth=$pipelineDepth)")
                // ĐÃ SỬA (2026-08-27 — bằng chứng thật từ log: STEADY=137495ms
                // nhưng WALL=1376108ms, chênh ~1239 GIÂY = máy ngủ sâu GIỮA
                // CHỪNG lúc generate() đang chạy, dù đoạn code này TƯỞNG đã có
                // WakeLock bảo vệ): trước đây CHỈ gọi acquireDirectWakeLock()
                // khi pipelineDepth==0 (tin tưởng nếu >0 thì đã có 1 lệnh
                // beginPipeline() NGOÀI giữ sẵn WakeLock). Nhưng pipelineDepth
                // có thể bị "kẹt" ở giá trị >0 VĨNH VIỄN nếu 1 lệnh generate()
                // TRƯỚC ĐÓ bị treo (xem mục D/E trong tài liệu kiến trúc — log
                // thật xác nhận CÓ xảy ra) và never chạm tới finally/endPipeline
                // tương ứng phía Dart để giảm lại bộ đếm — mọi lệnh SAU ĐÓ
                // trong cùng tiến trình mãi mãi nghĩ "đã có người giữ WakeLock
                // rồi", trong khi WakeLock thật (nếu có) từ lâu đã hết hạn (tối
                // đa 40 phút) hoặc chưa từng được giữ. Giờ LUÔN gọi
                // acquireDirectWakeLock() bất kể pipelineDepth — an toàn tuyệt
                // đối vì đây là WakeLock KHÔNG đếm tham chiếu
                // (setReferenceCounted(false)): gọi acquire() nhiều lần chỉ LÀM
                // MỚI hạn 40 phút, không cần release() thêm tương ứng.
                // MỤC CQ: xin lease (giữ wake lock + bật/cập nhật dịch vụ), nhả trong finally bằng endLease(epoch).
                val leaseEpochAtStart = beginLease("Đang nạp model...")
                kLog(appContext, "loadModel: GenerationService scheduled (main thread), chuan bi scope.launch... (${leaseDebugText()})")
                if (backendPreference == 0) {
                    setupQnnEnvironmentOnce(appContext)
                }
                scope.launch {
                    try {
                        kLog(appContext, "loadModel: BEN TRONG coroutine, chuan bi goi MnnNative.nativeLoadModel...")
                        // MỤC CB (2026-10-01): ghi mốc vào logcat TRƯỚC khi nạp, để nếu
                        // load() thất bại còn cắt đúng phần logcat của lần nạp này.
                        val diagMarker = LoadDiagnostics.markBegin(slot)
                        val ok = MnnNative.nativeLoadModel(slot, configPath, backendPreference)
                        val backend = if (ok) MnnNative.nativeActiveBackend(slot) else "loi"
                        mainHandler.post { result.success(mapOf("success" to ok, "backend" to backend)) }
                        // MỤC CB: CHỈ khi thất bại — chụp lý do THẬT do MNN in ra logcat +
                        // dấu vân tay runtime + nội dung file model vào native_debug.txt.
                        // Đặt SAU khi đã trả kết quả cho Dart (không làm chậm UI), và
                        // LoadDiagnostics không bao giờ ném exception (đã bọc try/catch).
                        if (!ok) {
                            LoadDiagnostics.dumpOnFailure(appContext, slot, configPath, diagMarker)
                        }
                    } catch (e: Throwable) {
                        kLog(appContext, "loadModel: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post { result.error("LOAD_FAILED", e.message ?: "Lỗi nạp model không rõ nguyên nhân", null) }
                    } finally {
                        endLease(leaseEpochAtStart) // MỤC CQ: thay cho `if (pipelineDepth == 0) {...}` cũ (xem beginLease)
                    }
                }
            }
            "generate" -> {
                val prompt = call.argument<String>("prompt")
                val stageLabel = call.argument<String>("stageLabel") ?: "Đang sinh văn bản..."
                val temperature = call.argument<Double>("temperature") ?: 0.9
                val topP = call.argument<Double>("topP") ?: 0.9
                val topK = call.argument<Int>("topK") ?: 40
                val repetitionPenalty = call.argument<Double>("repetitionPenalty") ?: 1.05
                val maxNewTokens = call.argument<Int>("maxNewTokens") ?: 1024
                // ĐÃ THÊM: reuse_kv — tham số CHÍNH THỨC của MNN (tài liệu
                // alibaba/MNN: "Whether to reuse the kv cache in multi-turn
                // dialogues. Defaults to false") — giảm thời gian chờ prefill
                // cho các lượt chat SAU lượt đầu trong cùng phiên, vì không
                // phải tính lại KV-cache cho phần system prompt + lịch sử đã
                // xử lý ở lượt trước. CHỈ bật true cho hội thoại thật sự
                // nhiều lượt (chat_screen.dart) — luôn false cho tác vụ 1
                // lần độc lập (dịch/tóm tắt từng đoạn tài liệu) để tránh lẫn
                // ngữ cảnh sai giữa các đoạn không liên quan.
                val reuseKv = call.argument<Boolean>("reuseKv") ?: false
                // ĐÃ THÊM (2026-09-06, sau sự cố: gõ outline kích hoạt hàng
                // chục lệnh tóm tắt nền chồng lên lệnh "Đắp thịt" thật —
                // xem lịch sử debug mục U): trước đây event token/done gửi
                // cho Dart CHỈ gắn `slot`, không gắn ID riêng theo LỆNH cụ
                // thể. Khi có ≥2 `generateStream()` cùng sống trên 1 slot
                // (dù đã hạn chế nhiều bằng BackgroundTaskManager, vẫn còn
                // đường lách qua `_updateSummaryAndIndexInBackground` chưa
                // qua hàng đợi đó), MỌI listener Dart đang mở cho slot này
                // đều nhận được TOÀN BỘ token/done của NHAU — 1 lệnh tóm
                // tắt ngắn xong trước có thể gửi "done=true" khiến màn
                // "Đắp thịt" tưởng NÓ đã xong (trong khi chưa nhận token
                // nào thật), và token của 2 lệnh xen kẽ nhau tạo ra "ký tự
                // rác". `requestId` do Dart tự sinh (duy nhất mỗi lần gọi
                // generateStream()), Kotlin không cần hiểu ý nghĩa, chỉ cần
                // ECHO lại nguyên vẹn trong mọi event — Dart lọc đúng theo
                // `requestId` của chính nó, bỏ qua mọi event không khớp.
                val requestId = call.argument<String>("requestId")
                if (prompt == null) {
                    result.error("BAD_ARGS", "Thiếu prompt", null)
                    return
                }
                kLog(appContext, "generate: da doc xong tham so tu Dart, stageLabel=\"$stageLabel\" (mục BB — trả lời thẳng \"lệnh này thuộc tính năng nào\" mà không cần đoán theo độ dài prompt), chuan bi tao JSON config...")
                val configJson = JSONObject().apply {
                    put("temperature", temperature)
                    put("top_p", topP)
                    put("top_k", topK)
                    put("repetition_penalty", repetitionPenalty)
                    put("max_new_tokens", maxNewTokens)
                    put("reuse_kv", reuseKv)
                    // ĐÃ THỬ (mục AY, 2026-09-16) rồi REVERT (mục BA, 2026-09-17
                    // — đo thật trên máy, không phải đoán): thêm
                    // penalty_window=0 (tường minh) + hạ n_gram 8→4 + tăng
                    // ngram_factor 1.0→1.3 vào đúng chỗ này, với kỳ vọng bắt
                    // được lặp sớm hơn. KẾT QUẢ THẬT xác nhận qua đối chiếu 2
                    // log lặp vô tận (cùng model OccultAI-Morpheus-8B, cùng
                    // "da sinh duoc 320 ky tu truoc do" — cùng lượng output):
                    //   - TRƯỚC mục AY (2026-09-16, STEADY=341842ms/320 ky tu)
                    //     = ~1068 ms/ký tự.
                    //   - SAU  mục AY (2026-09-17, STEADY=755620ms/320 ky tu)
                    //     = ~2361 ms/ký tự — CHẬM HƠN 2.21 LẦN, và lặp vẫn xảy
                    //     ra y hệt (vẫn đúng 320 ký tự mới dừng, không sớm
                    //     hơn chút nào) — nghĩa là hạ n_gram xuống 4 (bắt
                    //     nhiều n-gram ngắn hơn hẳn, quét lại toàn bộ lịch sử
                    //     mỗi token vì penalty_window=0) làm tính toán mỗi
                    //     token nặng hơn hẳn, mà KHÔNG hề ngăn được lặp — chỉ
                    //     tổng thời gian lãng phí trước khi bộ dò 320 ký tự
                    //     tự bắt được là như cũ. Suy đoán ban đầu (n_gram
                    //     nhỏ hơn sẽ chặn sớm hơn) SAI trên thực tế đo được.
                    // HỆ QUẢ PHỤ đáng ngại hơn: mỗi token chậm gấp 2.2 lần
                    // nghĩa là khoảng cách giữa 2 lần native kiểm tra cờ huỷ
                    // (chỉ kiểm tra "ở lần ghi token TIẾP THEO") cũng giãn ra
                    // gấp 2.2 lần — RẤT CÓ THỂ là 1 phần lý do nút Hủy (cả
                    // trong app lẫn trên notification, mục AZ) có cảm giác
                    // "bấm không ăn thua" trong lúc model đang kẹt ở đây.
                    // REVERT lại đúng trạng thái trước mục AY — không gửi 3
                    // field này nữa, để model dùng lại default TĨNH trong
                    // chính config.json (n_gram=8, ngram_factor=1.0,
                    // penalty_window=0 — vẫn y hệt giá trị cũ, chỉ khác là
                    // không ép qua set_config() lúc generate nữa). Việc BẮT
                    // sớm lặp vô tận vẫn phải dựa vào bộ dò 320 ký tự hiện có
                    // (mục AI/AJ) — CHƯA có hướng nào khác đã được đo thật là
                    // có tác dụng, không đoán tiếp bừa ở đây nữa.
                    // ĐÃ THỬ (mục AR, 2026-09-13) rồi BỎ (mục AS, cùng ngày —
                    // xem giải thích đầy đủ ở `local_provider.dart`): từng
                    // tách `system_prompt` thành field cấu hình RIÊNG ở đây.
                    // Bằng chứng chéo model (Qwen 7B trước kia ổn, cùng ngày
                    // cũng hỏng) cho thấy field này rất có thể KHÔNG được MNN
                    // bản đang build đọc — Story Bible/văn phong bị mất hẳn.
                    // Đã bỏ hoàn toàn — `systemPrompt` giờ được gộp thẳng vào
                    // `prompt` từ phía Dart, không cần field riêng ở đây nữa.
                    // ĐÃ THỬ Ở ĐÂY rồi BỎ (mục AL → mục AM, 2026-09-12): từng
                    // thêm `mixed_samplers` ngay tại JSON generate() này (xem
                    // lịch sử mục AL) để bật sampler "penalty" (nguyên nhân
                    // gốc model lặp ký tự đơn liên tục — xem mục AL). Log
                    // thật sau đó cho thấy `llm->response()` TREO HẲN, không
                    // sinh được ký tự nào — rất có thể do gọi `set_config()`
                    // LẦN THỨ HAI (sau lúc load) để THÊM sampler mới vào 1
                    // pipeline ĐÃ dựng sẵn không an toàn ở tầng MNN. Đã
                    // chuyển `mixed_samplers` sang đặt ở `mnn_bridge.cpp`
                    // (`buildOptimizedOpenCLConfig`, gọi TRƯỚC `load()`, đúng
                    // lúc pipeline được dựng LẦN ĐẦU — xem mục AM). KHÔNG đặt
                    // lại ở đây nữa — tránh giữ cả 2 nơi cùng lúc khi rủi ro
                    // gây treo vẫn chưa hiểu hết hoàn toàn.
                }.toString()
                kLog(appContext, "generate: config JSON xong: $configJson. Chuan bi goi GenerationService (pipelineDepth=$pipelineDepth)...")

                // ĐÃ SỬA (2026-08-27) — xem giải thích đầy đủ ở nhánh
                // "loadModel" phía trên, áp dụng y hệt cho generate(): không
                // còn tin tưởng pipelineDepth>0 để bỏ qua acquire — luôn gọi.
                // MỤC CQ: xin lease ngay tại đây (đồng bộ, trước khi trả về Dart); nhả trong finally bằng endLease(epoch). Việc GenerationService.start()
                // vẫn post lên main thread (sửa lỗi 2 cũ: không gọi startForegroundService từ luồng không phải main).
                val leaseEpochAtStart = beginLease(stageLabel)
                kLog(appContext, "generate: GenerationService scheduled, chuan bi scope.launch... (${leaseDebugText()})")
                val job = scope.launch {
                    try {
                        kLog(appContext, "generate: BEN TRONG coroutine, chuan bi cho khoa (mutex) cho slot=$slot truoc khi goi nativeGenerate...")
                        // ĐÃ THÊM: khoá theo slot — nếu slot này đang có 1 lệnh
                        // generate() khác chạy dở (vd chat đang chờ, đồng thời
                        // kiểm tra tính nhất quán chương cũng gọi generate trên
                        // CÙNG slot), lệnh này sẽ CHỜ ở đây cho tới khi lệnh
                        // trước xong hẳn, KHÔNG chạy song song — tránh 2 luồng
                        // cùng đụng vào 1 đối tượng Llm native cùng lúc (nguyên
                        // nhân rất có thể của chuỗi crash "heap corruption" bí
                        // ẩn ở mục 62-64). Xem giải thích đầy đủ ở khai báo
                        // generateMutexes phía trên.
                        mutexForSlot(slot).withLock {
                            kLog(appContext, "generate: DA CO khoa cho slot=$slot, chuan bi goi MnnNative.nativeGenerate...")
                            // MỤC CN: ghi TRẠNG THÁI NGUỒN THẬT (pin/Doze/màn hình/standby/wake lock) và thời gian máy ngủ trong lúc sinh.
                            val powerWatcher = PowerWatcher(appContext, "generate slot=$slot") { "directWakeLockHeld=" + (directWakeLock?.isHeld == true) + ", " + leaseDebugText() }
                            powerWatcher.start()
                            try {
                            MnnNative.nativeGenerate(slot, prompt, configJson, object : MnnNative.TokenCallback {
                                override fun onToken(token: String, done: Boolean) {
                                    // ĐÃ THÊM (theo yêu cầu người dùng — điều tra "khung chat
                                    // không sinh chữ, đợi lâu"): log RIÊNG BIỆT 2 mốc — (1)
                                    // lúc JNI THẬT SỰ gọi vào onToken() (trên thread native/
                                    // coroutine đang giữ mutex), và (2) lúc Runnable được
                                    // `mainHandler.post` THẬT SỰ chạy (trên main thread). Nếu
                                    // khoảng cách giữa 2 mốc này LỚN, nghĩa là hàng đợi
                                    // (MessageQueue) của MAIN THREAD bị nghẽn/trễ — đúng nghi
                                    // vấn "mất khả năng chạy nền" (Android có thể hạ ưu tiên xử
                                    // lý MAIN THREAD khi app không hiển thị, dù WakeLock vẫn giữ
                                    // CPU thức và Foreground Service vẫn sống — 2 thứ đó bảo vệ
                                    // TIẾN TRÌNH không bị giết và CPU không ngủ, KHÔNG đảm bảo
                                    // main thread được lập lịch NGAY LẬP TỨC). CHỈ log khi
                                    // done=true (tín hiệu cuối) để tránh spam file log hàng trăm
                                    // dòng/giây khi đang stream từng token.
                                    if (done) {
                                        kLog(appContext, "onToken: JNI goi vao (done=true)")
                                    }
                                    mainHandler.post {
                                        if (done) {
                                            kLog(appContext, "onToken: mainHandler.post THAT SU chay (done=true)")
                                        }
                                        eventSink?.success(mapOf("token" to token, "done" to done, "slot" to slot, "requestId" to requestId))
                                    }
                                }
                            })
                            } finally {
                                powerWatcher.stop()
                            }
                        }
                        kLog(appContext, "generate: MnnNative.nativeGenerate() TRA VE XONG (khong crash), da tha khoa")
                        mainHandler.post { result.success(null) }
                    } catch (e: Throwable) {
                        kLog(appContext, "generate: coroutine bat duoc loi: ${e.javaClass.simpleName}: ${e.message}")
                        mainHandler.post {
                            eventSink?.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                            result.error("GENERATE_FAILED", e.message ?: "Lỗi sinh văn bản", null)
                        }
                    } finally {
                        endLease(leaseEpochAtStart) // MỤC CQ: xem beginLease
                    }
                }
                jobsForSlot(slot).add(job)
                job.invokeOnCompletion { jobsForSlot(slot).remove(job) }
            }
            "cancelGenerate" -> {
                // ĐÃ SỬA — mục AZ: chuyển toàn bộ thân xử lý sang hàm dùng
                // chung `performFullCancel` (xem khai báo phía trên, cạnh
                // `stopGenerationServiceSync`) — để CancelGenerationReceiver
                // (nút "Hủy" trên notification hệ thống) gọi được ĐÚNG cùng
                // logic này, không tạo đường huỷ riêng dễ lệch hành vi. Hành
                // vi ở đây giữ NGUYÊN VẸN, không đổi gì cho đường gọi từ Dart.
                performFullCancel(slot)
                result.success(null)
            }
            // ĐÃ THÊM (2026-09-01 — theo yêu cầu người dùng): dọn cache
            // autotuning OpenCL, gọi ĐÚNG 1 lần lúc app thoát thật (xem
            // main.dart, gọi `await` ngay trước SystemNavigator.pop()).
            // CỐ Ý chạy ĐỒNG BỘ (không tách thread nền) — Dart `await` bên
            // gọi PHẢI đợi dọn xong thật rồi mới cho phép thoát, giống hệt
            // lý do vòng lặp `while (manager.runningCount > 0)` ở
            // main.dart phải CHỜ THẬT thay vì bắn lệnh rồi thoát ngay: nếu
            // tách thread nền rồi trả `result.success` ngay, Dart tưởng đã
            // xong trong khi việc xoá vẫn dở dang, `SystemNavigator.pop()`
            // chạy tiếp ngay sau đó có thể giết tiến trình giữa chừng lúc
            // đang xoá — hệt kiểu lỗi "bắn cờ rồi thoát ngay, không đợi"
            // đã sửa ở chính đoạn code exit này (xem comment phía trên).
            // Việc dọn tự nó chỉ là I/O file (stat/readdir/remove), không
            // đụng GPU/model, nên chấp nhận được dù chạy trên thread gọi.
            "cleanupCacheOnExit" -> {
                try {
                    MnnNative.nativeEnforceOpenCLCacheCap()
                } catch (e: Throwable) {
                    kLog(appContext, "cleanupCacheOnExit: loi (bo qua, khong nghiem trong): ${e.javaClass.simpleName}: ${e.message}")
                }
                result.success(null)
            }
            // ĐÃ THÊM (theo yêu cầu người dùng: "sao tác vụ nền không báo có
            // bất cứ cái gì hết" khi 1 lệnh generate() mồ côi từ phiên TRƯỚC
            // vẫn đang chạy — đúng, `BackgroundTaskManager` phía Dart chỉ là
            // 1 List trong RAM của phiên HIỆN TẠI, không biết gì về phiên đã
            // đóng). Cho Dart hỏi thẳng native — nơi DUY NHẤT còn giữ đúng sự
            // thật slot có đang bận hay không.
            "isSlotGenerating" -> {
                result.success(MnnNative.nativeIsGenerating(slot))
            }
            "unload" -> {
                scope.launch {
                    MnnNative.nativeUnload(slot)
                    mainHandler.post { result.success(null) }
                }
            }
            "isLoaded" -> {
                result.success(MnnNative.nativeIsLoaded(slot))
            }
            // ĐÃ THÊM (2026-08-29): xem giải thích đầy đủ ở MnnNative.kt,
            // khai báo nativeNeedsFullReload.
            "needsFullReload" -> {
                result.success(MnnNative.nativeNeedsFullReload(slot))
            }
            // ĐÃ THÊM (2026-09-05): xem giải thích đầy đủ ở MnnNative.kt,
            // khai báo nativeSlotStalledMs — Dart chỉ nên gọi case này SAU
            // khi đã xác nhận "isSlotGenerating" = true.
            "slotStalledMs" -> {
                result.success(MnnNative.nativeSlotStalledMs(slot))
            }
            // ĐÃ THÊM (theo yêu cầu người dùng: "hệ thống này đặc biệt để
            // treo máy, sáng dậy thấy chết thì dẹp luôn dự án"): lớp phòng
            // vệ CUỐI CÙNG cho độ tin cậy chạy xuyên đêm — Foreground
            // Service + WakeLock tự làm mới (mục 5.71) bảo vệ được ở tầng
            // Android chuẩn, nhưng 1 số OEM (đặc biệt ASUS ZenUI, đúng máy
            // test — xem mục 5.66) có trình quản lý pin RIÊNG, tự ý kill
            // app nền bất kể Foreground Service đúng chuẩn hay không, trừ
            // khi người dùng TỰ TAY loại trừ app khỏi tối ưu hoá pin.
            // Android không cho phép app tự động tắt hẳn tối ưu hoá pin
            // cho chính mình — chỉ có thể MỞ HỘP THOẠI HỆ THỐNG để người
            // dùng tự xác nhận (yêu cầu bảo mật, không thể bỏ qua).
            "isIgnoringBatteryOptimizations" -> {
                val pm = appContext.getSystemService(android.os.PowerManager::class.java)
                result.success(pm?.isIgnoringBatteryOptimizations(appContext.packageName) ?: false)
            }
            // MỤC CP (2026-10-05) — 2 lệnh mới cho màn "Tối ưu AI local":
            // getBackgroundStatus: trạng thái THẬT cần để biết wake lock có được hệ thống tôn trọng không.
            "getBackgroundStatus" -> {
                try {
                    val pm = appContext.getSystemService(android.os.PowerManager::class.java)
                    val nm = appContext.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                    val am = appContext.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                    var svcForeground = false
                    for (info in am.getRunningServices(100)) {
                        if (info.service.className == GenerationService::class.java.name) svcForeground = info.foreground
                    }
                    result.success(
                        mapOf(
                            "ignoringBattery" to (pm?.isIgnoringBatteryOptimizations(appContext.packageName) ?: false),
                            "notificationsEnabled" to nm.areNotificationsEnabled(),
                            "serviceRunning" to GenerationService.isRunning,
                            "serviceForeground" to svcForeground,
                            // MỤC CQ: tên hãng LẤY TỪ MÁY (không gõ cứng), có mục riêng trong bảng hãng không, và mức ưu tiên THẬT của tiến trình này.
                            "brand" to OemPowerSettings.brandLabel(),
                            "hasOemEntry" to OemPowerSettings.hasOemEntry(),
                            "procImportance" to PowerDiagnostics.ownImportanceText()
                        )
                    )
                } catch (e: Throwable) {
                    kLog(appContext, "getBackgroundStatus: LOI: ${e.javaClass.simpleName}: ${e.message}")
                    result.success(emptyMap<String, Any>())
                }
            }
            // MỤC CQ (2026-10-07): thay khối hardcode 3 màn hình ASUS (mục CP) bằng bộ giải quyết theo dữ liệu, xem OemPowerSettings.kt.
            // Bậc 1 (mọi máy): trang Thông tin ứng dụng của Android. Bậc 2 (tuỳ hãng): bảng theo Build.MANUFACTURER/BRAND, thử rồi rơi về bậc 1.
            "openOemPowerSettings" -> {
                val opened = OemPowerSettings.open(appContext)
                kLog(appContext, "openOemPowerSettings: da mo = $opened")
                result.success(opened)
            }
            "requestIgnoreBatteryOptimizations" -> {
                try {
                    val intent = android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    intent.data = android.net.Uri.parse("package:${appContext.packageName}")
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    appContext.startActivity(intent)
                    result.success(true)
                } catch (e: Throwable) {
                    kLog(appContext, "requestIgnoreBatteryOptimizations: LOI: ${e.javaClass.simpleName}: ${e.message}")
                    result.success(false)
                }
            }
            // ĐÃ THÊM (theo yêu cầu người dùng: "mất công vào cài đặt cài
            // thủ công quá"): quyền "Truy cập mọi tệp" (MANAGE_EXTERNAL_STORAGE,
            // đã khai báo ở build.yml) là quyền ĐẶC BIỆT — khác POST_NOTIFICATIONS
            // hay battery optimization, Android KHÔNG cho phép bật bằng 1 hộp
            // thoại Cho phép/Từ chối đơn giản, kể cả app hệ thống cũng không lách
            // được. Google buộc phải đi qua 1 màn Cài đặt để người dùng tự gạt —
            // đây là chủ đích thiết kế bảo mật, không phải thiếu sót của app.
            // Cái CÓ THỂ làm để đỡ mất công: dùng Intent
            // ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION để mở THẲNG đúng
            // trang gạt quyền của app này (Android 11+/API 30+), thay vì bắt
            // người dùng tự mò Cài đặt > Ứng dụng > LocalNovel > Quyền > Tệp.
            // Trên Android 9-10 (minSdk 28, quyền này chưa tồn tại) coi như
            // luôn có quyền — dùng API cũ (READ/WRITE_EXTERNAL_STORAGE thường).
            "hasManageStoragePermission" -> {
                val has = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                    android.os.Environment.isExternalStorageManager()
                } else {
                    true // Android 9-10: không có khái niệm quyền này, coi như đủ
                }
                result.success(has)
            }
            "requestManageStoragePermission" -> {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        // Mở thẳng trang gạt quyền CỦA APP NÀY — chỉ 1 công tắc,
                        // không phải mò trong danh sách toàn bộ app trên máy.
                        val intent = android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
                        )
                        intent.data = android.net.Uri.parse("package:${appContext.packageName}")
                        intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        appContext.startActivity(intent)
                    }
                    result.success(true)
                } catch (e: Throwable) {
                    kLog(appContext, "requestManageStoragePermission: LOI đường dẫn app-cụ-thể: ${e.javaClass.simpleName}: ${e.message}")
                    // Dự phòng: 1 số ROM tuỳ biến (đặc biệt ASUS ZenUI, xem mục
                    // 5.66 tài liệu kiến trúc) có thể không có đúng màn app-cụ-thể
                    // — lùi về màn danh sách chung, người dùng tự tìm LocalNovel
                    // trong danh sách (vẫn đỡ hơn phải tự mò từ Cài đặt gốc).
                    try {
                        val fallback = android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION
                        )
                        fallback.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                        appContext.startActivity(fallback)
                        result.success(true)
                    } catch (e2: Throwable) {
                        kLog(appContext, "requestManageStoragePermission: LOI du phong: ${e2.javaClass.simpleName}: ${e2.message}")
                        result.success(false)
                    }
                }
            }
            else -> result.notImplemented()
        }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }

    // ĐÃ THÊM — mục AZ: xem giải thích đầy đủ ở khối `init` đầu class.
    companion object {
        @Volatile
        var currentInstance: MnnBridge? = null
            private set
    }
}

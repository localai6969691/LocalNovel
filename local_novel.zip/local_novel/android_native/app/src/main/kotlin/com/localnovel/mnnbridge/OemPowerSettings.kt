package com.localnovel.mnnbridge

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

// MỤC CQ (2026-10-07) — MỞ CÀI ĐẶT NGUỒN/NỀN THEO HÃNG, KHÔNG HARDCODE MỘT HÃNG.
//
// VÌ SAO: mục CP chỉ có 3 màn hình của ASUS — người dùng chỉ ra đúng: đổi sang máy hãng khác là vô dụng và nút còn ghi
// sai tên hãng. Android KHÔNG có API chuẩn nào để mở "màn hình tự khởi động/chạy nền" của từng hãng (đó là phần mềm riêng của hãng),
// nên KHÔNG tồn tại giải pháp 100% tổng quát. Cái làm được và làm ở đây:
//   BẬC 1 (chuẩn AOSP, chạy trên MỌI máy): trang "Thông tin ứng dụng" của chính app (có mục Pin + Thông báo).
//   BẬC 2 (tuỳ hãng, cố gắng hết sức): bảng dữ liệu bên dưới, chọn theo Build.MANUFACTURER/BRAND của máy ĐANG CHẠY. Thêm hãng mới chỉ là
//          thêm 1 dòng vào bảng — không đụng logic. Mỗi mục thử lần lượt; thất bại (không có màn hình đó / không được phép mở) thì
//          bỏ qua im lặng và rơi về bậc 1. KHÔNG BAO GIỜ ném exception ra ngoài.
// GIỚI HẠN THẬT (không giấu): tên thành phần trong bảng do cộng đồng ghi lại, KHÔNG có tài liệu chính thức và tôi KHÔNG kiểm được trên máy
// thật của từng hãng — có thể sai/đổi theo đời ROM. Vì vậy giao diện chỉ gọi đây là "thử mở", và luôn có bậc 1 làm lưới an toàn.
internal object OemPowerSettings {

    private class Entry(val brandTokens: List<String>, val components: List<Pair<String, String>>)

    // Bảng theo từ khoá hãng (so khớp chuỗi con, chữ thường, trên MANUFACTURER + BRAND).
    private val table: List<Entry> = listOf(
        Entry(listOf("asus"), listOf(
            Pair("com.asus.mobilemanager", "com.asus.mobilemanager.powersaver.PowerSaverSettings"),
            Pair("com.asus.mobilemanager", "com.asus.mobilemanager.autostart.AutoStartActivity"),
            Pair("com.asus.mobilemanager", "com.asus.mobilemanager.MainActivity"))),
        Entry(listOf("xiaomi", "redmi", "poco"), listOf(
            Pair("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"))),
        Entry(listOf("huawei", "honor"), listOf(
            Pair("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
            Pair("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"))),
        Entry(listOf("oppo", "realme"), listOf(
            Pair("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
            Pair("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity"),
            Pair("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"))),
        Entry(listOf("vivo", "iqoo"), listOf(
            Pair("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
            Pair("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"),
            Pair("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"))),
        Entry(listOf("oneplus"), listOf(
            Pair("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity"))),
        Entry(listOf("samsung"), listOf(
            Pair("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"),
            Pair("com.samsung.android.sm_cn", "com.samsung.android.sm.ui.ram.AutoRunActivity"))),
        Entry(listOf("nokia", "hmd"), listOf(
            Pair("com.evenwell.powersaving.g3", "com.evenwell.powersaving.g3.exception.PowerSaverExceptionActivity"))),
        Entry(listOf("htc"), listOf(
            Pair("com.htc.pitroad", "com.htc.pitroad.landingpage.activity.LandingPageActivity"))),
        Entry(listOf("letv", "leeco"), listOf(
            Pair("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")))
    )

    // Tên hãng để HIỆN CHO NGƯỜI DÙNG (lấy từ chính máy, không gõ cứng).
    fun brandLabel(): String {
        val m = (Build.MANUFACTURER ?: "").trim()
        if (m.isEmpty()) return ""
        return m.substring(0, 1).uppercase() + m.substring(1)
    }

    private fun matchingComponents(): List<Pair<String, String>> {
        val hay = ((Build.MANUFACTURER ?: "") + " " + (Build.BRAND ?: "")).lowercase()
        val out = ArrayList<Pair<String, String>>()
        for (e in table) {
            if (e.brandTokens.any { hay.contains(it) }) out.addAll(e.components)
        }
        return out
    }

    // Máy này có mục riêng trong bảng không? (Giao diện dùng để quyết định ghi "của <hãng>" hay chỉ ghi chung.)
    fun hasOemEntry(): Boolean = matchingComponents().isNotEmpty()

    // Trả về: "oem:<gói>/<lớp>" nếu mở được màn hình hãng; "android_app_details" nếu rơi về bậc 1; "" nếu không mở được gì.
    fun open(context: Context): String {
        for ((pkg, cls) in matchingComponents()) {
            try {
                val intent = Intent()
                intent.component = ComponentName(pkg, cls)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                kLog(context, "OemPowerSettings: mo duoc man hinh hang: $pkg/$cls (hang=${Build.MANUFACTURER}/${Build.BRAND})")
                return "oem:$pkg/$cls"
            } catch (e: Throwable) {
                kLog(context, "OemPowerSettings: $cls KHONG MO DUOC (${e.javaClass.simpleName}) — thu muc tiep theo/roi ve bac 1")
            }
        }
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            intent.data = Uri.parse("package:" + context.packageName)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return "android_app_details"
        } catch (e: Throwable) {
            kLog(context, "OemPowerSettings: LOI mo cai dat ung dung: ${e.javaClass.simpleName}: ${e.message}")
        }
        return ""
    }
}

// story_sampler.hpp — DRY + XTC + min-p + top-k/top-p + temperature, thuần C++17, KHÔNG phụ thuộc MNN.
// MỤC DG (2026-10-17). Mục đích: thuật toán lấy mẫu dành cho văn xuôi mà llama.cpp/KoboldCpp có sẵn còn MNN không có,
// được viết và KIỂM THỬ độc lập (xem story_sampler_test.cpp) để sau này gắn vào đường sinh token khi biết chắc API thật của MNN.
// CHƯA được gọi từ app: file này nằm ngoài CMake của app.
//
// Nguồn thuật toán: tài liệu llama.cpp (tools/completion README) và mô tả DRY ban đầu của p-e-w (PR llama.cpp #9702):
//  - DRY: với mỗi token ứng viên t, tìm độ dài L lớn nhất của chuỗi token ngay trước t (ở lịch sử cũ) trùng với phần ĐUÔI hiện tại của ngữ cảnh;
//    nếu L >= allowed_length thì logit[t] -= multiplier * base^(L - allowed_length). "Sequence breaker" cắt phạm vi khớp.
//  - XTC: với xác suất p, nếu có >=2 token có xác suất >= threshold thì loại hết trừ token ÍT khả năng nhất trong nhóm đó.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <random>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace storysampler {

struct DryParams {
  float multiplier = 0.0f;        // 0 = tắt. llama.cpp gợi ý 0.8 cho văn xuôi.
  float base = 1.75f;
  int allowedLength = 2;
  int penaltyLastN = -1;          // -1 = toàn bộ lịch sử; 0 = tắt; N>0 = chỉ N token cuối
  std::vector<int> sequenceBreakers;  // id token (vd xuống dòng, dấu câu) làm đứt chuỗi khớp
};

// Z-array của chuỗi r: z[k] = độ dài tiền tố chung dài nhất của r và r[k..]. z[0] = r.size().
inline std::vector<int> zArray(const std::vector<int>& r) {
  const int n = static_cast<int>(r.size());
  std::vector<int> z(n, 0);
  if (n == 0) return z;
  z[0] = n;
  int l = 0, rr = 0;
  for (int i = 1; i < n; ++i) {
    if (i < rr) z[i] = std::min(rr - i, z[i - l]);
    while (i + z[i] < n && r[z[i]] == r[i + z[i]]) ++z[i];
    if (i + z[i] > rr) { l = i; rr = i + z[i]; }
  }
  return z;
}

// Với lịch sử `history` (cũ -> mới), trả map token -> độ dài khớp lớn nhất (chỉ L >= allowedLength). Độ phức tạp O(m), m = cỡ cửa sổ.
inline std::unordered_map<int, int> dryMaxMatches(const std::vector<int>& history, const DryParams& p) {
  std::unordered_map<int, int> best;
  if (p.multiplier <= 0.0f || p.penaltyLastN == 0 || history.size() < 2) return best;
  size_t begin = 0;
  if (p.penaltyLastN > 0 && history.size() > static_cast<size_t>(p.penaltyLastN)) begin = history.size() - p.penaltyLastN;
  std::vector<int> r(history.rbegin(), history.rend() - static_cast<std::ptrdiff_t>(begin));  // r[0] = token mới nhất
  const int m = static_cast<int>(r.size());
  if (m < 2) return best;
  const std::unordered_set<int> breakers(p.sequenceBreakers.begin(), p.sequenceBreakers.end());
  // Giới hạn do sequence breaker nằm trong đuôi hiện tại: chỉ đếm các token sau breaker gần nhất.
  int limit = m;
  for (int j = 0; j < m; ++j) {
    if (breakers.count(r[j])) { limit = j; break; }
  }
  if (limit <= 0) return best;
  const std::vector<int> z = zArray(r);
  for (int k = 1; k < m; ++k) {
    int len = std::min(z[k], limit);
    if (len >= p.allowedLength && len > 0) {
      const int next = r[k - 1];  // token đứng ngay sau lần xuất hiện cũ
      auto it = best.find(next);
      if (it == best.end() || it->second < len) best[next] = len;
    }
  }
  return best;
}

inline void applyDry(std::vector<float>& logits, const std::vector<int>& history, const DryParams& p) {
  const auto best = dryMaxMatches(history, p);
  for (const auto& kv : best) {
    const int token = kv.first;
    if (token < 0 || static_cast<size_t>(token) >= logits.size()) continue;
    const int exponent = kv.second - p.allowedLength;
    double penalty = static_cast<double>(p.multiplier) * std::pow(static_cast<double>(p.base), std::min(exponent, 1000));
    penalty = std::min(penalty, 1.0e30);
    logits[token] -= static_cast<float>(penalty);
  }
}

inline std::vector<float> softmax(const std::vector<float>& logits) {
  std::vector<float> p(logits.size(), 0.0f);
  float mx = -std::numeric_limits<float>::infinity();
  for (float v : logits) mx = std::max(mx, v);
  if (!std::isfinite(mx)) return p;
  double sum = 0.0;
  for (size_t i = 0; i < logits.size(); ++i) {
    p[i] = std::isfinite(logits[i]) ? static_cast<float>(std::exp(static_cast<double>(logits[i] - mx))) : 0.0f;
    sum += p[i];
  }
  if (sum > 0) for (auto& v : p) v = static_cast<float>(v / sum);
  return p;
}

// XTC: ngoại lệ "chỉ 1 token vượt ngưỡng" => không làm gì (giữ nguyên). Trả true nếu đã loại token.
inline bool applyXtc(std::vector<float>& logits, float probability, float threshold, std::mt19937& rng) {
  if (probability <= 0.0f || threshold <= 0.0f) return false;
  std::uniform_real_distribution<float> u(0.0f, 1.0f);
  if (u(rng) >= probability) return false;
  const std::vector<float> pr = softmax(logits);
  std::vector<int> above;
  for (size_t i = 0; i < pr.size(); ++i) if (pr[i] >= threshold) above.push_back(static_cast<int>(i));
  if (above.size() < 2) return false;
  int keep = above[0];
  for (int idx : above) if (pr[idx] < pr[keep]) keep = idx;  // token ÍT khả năng nhất trong nhóm
  for (int idx : above) if (idx != keep) logits[idx] = -std::numeric_limits<float>::infinity();
  return true;
}

inline void applyMinP(std::vector<float>& logits, float minP) {
  if (minP <= 0.0f) return;
  const std::vector<float> pr = softmax(logits);
  float mx = 0.0f;
  for (float v : pr) mx = std::max(mx, v);
  const float cut = minP * mx;
  for (size_t i = 0; i < pr.size(); ++i) if (pr[i] < cut) logits[i] = -std::numeric_limits<float>::infinity();
}

inline void applyTopK(std::vector<float>& logits, int topK) {
  if (topK <= 0 || static_cast<size_t>(topK) >= logits.size()) return;
  std::vector<float> sorted(logits);
  std::nth_element(sorted.begin(), sorted.begin() + (topK - 1), sorted.end(), std::greater<float>());
  const float kth = sorted[topK - 1];
  for (auto& v : logits) if (v < kth) v = -std::numeric_limits<float>::infinity();
}

inline void applyTopP(std::vector<float>& logits, float topP) {
  if (topP <= 0.0f || topP >= 1.0f) return;
  const std::vector<float> pr = softmax(logits);
  std::vector<int> order(pr.size());
  for (size_t i = 0; i < order.size(); ++i) order[i] = static_cast<int>(i);
  std::sort(order.begin(), order.end(), [&](int a, int b) { return pr[a] > pr[b]; });
  double cum = 0.0;
  size_t keepCount = 0;
  for (size_t i = 0; i < order.size(); ++i) {
    cum += pr[order[i]];
    keepCount = i + 1;
    if (cum >= topP) break;
  }
  for (size_t i = keepCount; i < order.size(); ++i) logits[order[i]] = -std::numeric_limits<float>::infinity();
}

struct StoryParams {
  float temperature = 0.8f;
  int topK = 40;
  float topP = 0.9f;
  float minP = 0.05f;
  float xtcProbability = 0.0f;  // 0 = tắt
  float xtcThreshold = 0.1f;
  DryParams dry;
};

// Thứ tự: DRY (sửa logit theo lịch sử) -> top-k -> top-p -> min-p -> XTC -> nhiệt độ -> lấy mẫu. Trả id token.
inline int sampleToken(std::vector<float> logits, const std::vector<int>& history, const StoryParams& sp, std::mt19937& rng) {
  applyDry(logits, history, sp.dry);
  applyTopK(logits, sp.topK);
  applyTopP(logits, sp.topP);
  applyMinP(logits, sp.minP);
  applyXtc(logits, sp.xtcProbability, sp.xtcThreshold, rng);
  const float t = sp.temperature > 1e-6f ? sp.temperature : 1e-6f;
  for (auto& v : logits) if (std::isfinite(v)) v /= t;
  const std::vector<float> pr = softmax(logits);
  std::discrete_distribution<int> dist(pr.begin(), pr.end());
  return dist(rng);
}

}  // namespace storysampler

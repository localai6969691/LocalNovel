// Kiểm thử độc lập cho story_sampler.hpp. Biên dịch: g++ -std=c++17 -O2 story_sampler_test.cpp -o story_sampler_test
#include "story_sampler.hpp"
#include <cassert>
#include <chrono>
#include <cstdio>
using namespace storysampler;

static int g_fail = 0;
#define CHECK(cond, msg) do { if (!(cond)) { std::printf("FAIL: %s (dong %d)\n", msg, __LINE__); ++g_fail; } else { std::printf("ok  : %s\n", msg); } } while (0)

// Bản ngây thơ O(m^2) để đối chiếu với bản Z-array.
static std::unordered_map<int, int> naive(const std::vector<int>& h, const DryParams& p) {
  std::unordered_map<int, int> best;
  size_t begin = 0;
  if (p.penaltyLastN > 0 && h.size() > (size_t)p.penaltyLastN) begin = h.size() - p.penaltyLastN;
  std::vector<int> w(h.begin() + begin, h.end());
  const int m = (int)w.size();
  std::unordered_set<int> br(p.sequenceBreakers.begin(), p.sequenceBreakers.end());
  int limit = m;
  for (int j = 0; j < m; ++j) if (br.count(w[m - 1 - j])) { limit = j; break; }
  for (int i = 0; i + 1 < m; ++i) {           // i = vị trí cũ; token tiếp theo = w[i+1]
    int len = 0;
    while (len < limit && i - len >= 0 && w[i - len] == w[m - 1 - len]) ++len;
    if (len >= p.allowedLength && len > 0) {
      int next = w[i + 1];
      if (!best.count(next) || best[next] < len) best[next] = len;
    }
  }
  return best;
}

int main() {
  // 1) DRY cơ bản: lịch sử A B C D A B C => token D bị phạt với L=3
  {
    DryParams p; p.multiplier = 0.8f; p.base = 1.75f; p.allowedLength = 2;
    std::vector<int> h = {1, 2, 3, 4, 1, 2, 3};          // 1=A 2=B 3=C 4=D
    std::vector<float> lg(6, 0.0f);
    applyDry(lg, h, p);
    const float expect = -0.8f * 1.75f;                  // 0.8*1.75^(3-2) = 1.4
    CHECK(std::fabs(lg[4] - expect) < 1e-5f, "DRY: token lap lai chuoi 3 bi phat 0.8*1.75^1 = 1.4");
    CHECK(lg[0] == 0.0f && lg[1] == 0.0f && lg[2] == 0.0f && lg[3] == 0.0f && lg[5] == 0.0f, "DRY: token khac khong bi phat");
  }
  // 2) DRY: khop ngan hon allowed_length => khong phat
  {
    DryParams p; p.multiplier = 0.8f; p.allowedLength = 2;
    std::vector<int> h = {1, 2, 1};                      // đuôi "1" khớp độ dài 1 < 2
    std::vector<float> lg(4, 0.0f);
    applyDry(lg, h, p);
    CHECK(lg[2] == 0.0f, "DRY: khop dai 1 < allowed_length 2 => khong phat");
  }
  // 3) DRY: sequence breaker cat chuoi khop
  {
    DryParams p; p.multiplier = 0.8f; p.allowedLength = 2; p.sequenceBreakers = {9};
    std::vector<int> h = {1, 9, 3, 4, 8, 1, 9, 3, 4};    // đuôi 1 9 3 4, breaker 9 => chỉ đếm "3 4" (L=2)
    std::vector<float> lg(10, 0.0f);
    applyDry(lg, h, p);
    CHECK(std::fabs(lg[8] - (-0.8f)) < 1e-5f, "DRY: breaker cat khop => L=2 => phat 0.8*1.75^0 = 0.8");
  }
  // 3b) Cua so penalty_last_n
  {
    DryParams p; p.multiplier = 0.8f; p.allowedLength = 2; p.penaltyLastN = 4;
    std::vector<int> h = {1, 2, 3, 7, 7, 7, 1, 2};       // lần xuất hiện cũ của "1 2 3" nằm NGOÀI cửa sổ 4 token cuối
    std::vector<float> lg(8, 0.0f);
    applyDry(lg, h, p);
    CHECK(lg[3] == 0.0f, "DRY: chi xet N token cuoi (penalty_last_n=4)");
  }
  // 4) Z-array == ban ngay tho tren 3000 chuoi ngau nhien (bang chung do dung)
  {
    std::mt19937 rng(12345);
    int mismatches = 0;
    for (int trial = 0; trial < 3000; ++trial) {
      int alpha = 2 + (int)(rng() % 4);
      int len = 2 + (int)(rng() % 60);
      std::vector<int> h(len);
      for (auto& x : h) x = (int)(rng() % alpha);
      DryParams p; p.multiplier = 0.8f; p.allowedLength = 1 + (int)(rng() % 3);
      p.penaltyLastN = (rng() % 3 == 0) ? (1 + (int)(rng() % len)) : -1;
      if (rng() % 2) p.sequenceBreakers = {(int)(rng() % alpha)};
      auto a = dryMaxMatches(h, p);
      auto b = naive(h, p);
      if (a != b) ++mismatches;
    }
    CHECK(mismatches == 0, "DRY: ban Z-array khop ban ngay tho tren 3000 chuoi ngau nhien");
  }
  // 5) XTC
  {
    std::mt19937 rng(1);
    std::vector<float> lg = {std::log(0.5f), std::log(0.3f), std::log(0.15f), std::log(0.05f)};
    auto a = lg;
    bool did = applyXtc(a, 1.0f, 0.1f, rng);
    CHECK(did && !std::isfinite(a[0]) && !std::isfinite(a[1]) && std::isfinite(a[2]) && std::isfinite(a[3]),
          "XTC: giu token it kha nang nhat trong nhom >= nguong (0.15), loai 0.5 va 0.3");
    auto b = lg;
    CHECK(!applyXtc(b, 0.0f, 0.1f, rng) && b == lg, "XTC: xac suat 0 => khong doi");
    std::vector<float> one = {std::log(0.9f), std::log(0.05f), std::log(0.05f)};
    auto c = one;
    CHECK(!applyXtc(c, 1.0f, 0.1f, rng) && c == one, "XTC: chi 1 token vuot nguong => khong loai");
  }
  // 6) min-p
  {
    std::vector<float> lg = {std::log(0.6f), std::log(0.3f), std::log(0.02f)};
    applyMinP(lg, 0.1f);  // cắt dưới 0.06
    CHECK(std::isfinite(lg[0]) && std::isfinite(lg[1]) && !std::isfinite(lg[2]), "min-p 0.1: cat token 0.02 < 0.1*0.6");
  }
  // 7) DRY lam giam xac suat lap cum trong lay mau thuc
  {
    std::mt19937 rng(7);
    std::vector<int> h = {1, 2, 3, 4, 1, 2, 3};
    std::vector<float> lg = {0, 0, 0, 0, 3.0f, 0.0f};    // token 4 (=D) đang rất nổi trội
    StoryParams off; off.topK = 0; off.topP = 1.0f; off.minP = 0.0f; off.temperature = 1.0f;
    StoryParams on = off; on.dry.multiplier = 5.0f; on.dry.allowedLength = 2;
    int cOff = 0, cOn = 0; const int N = 4000;
    for (int i = 0; i < N; ++i) { cOff += (sampleToken(lg, h, off, rng) == 4); cOn += (sampleToken(lg, h, on, rng) == 4); }
    std::printf("      P(lap D) tat DRY = %.3f, bat DRY(multiplier 5) = %.3f\n", cOff / (double)N, cOn / (double)N);
    CHECK(cOn < cOff * 0.2, "DRY: bat DRY giam manh xac suat lap lai chuoi");
  }
  // 8) Chi phi: 4000 token lich su
  {
    std::mt19937 rng(3);
    std::vector<int> h(4000);
    for (auto& x : h) x = (int)(rng() % 5000);
    DryParams p; p.multiplier = 0.8f; p.allowedLength = 2;
    std::vector<float> lg(32000, 0.0f);
    auto t0 = std::chrono::steady_clock::now();
    const int reps = 200;
    for (int i = 0; i < reps; ++i) applyDry(lg, h, p);
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / reps;
    std::printf("      chi phi DRY (4000 token lich su, may build, -O2): %.3f ms/token\n", ms);
    CHECK(ms < 5.0, "DRY: chi phi O(n) du nho (<5 ms/token o 4000 token tren may build)");
  }
  std::printf(g_fail == 0 ? "\nTAT CA KIEM THU DAT\n" : "\nCO %d KIEM THU THAT BAI\n", g_fail);
  return g_fail == 0 ? 0 : 1;
}

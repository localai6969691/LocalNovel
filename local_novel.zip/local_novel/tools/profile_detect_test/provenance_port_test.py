#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MỤC DM — kiểm thử LOGIC của lib/services/mnn_provenance_service.dart (bản PORT Python; KHÔNG chạy mã Dart, không kiểm biên dịch).
  (1) versionLabelFromTail: đọc nhãn "x.y.z" từ đuôi llm.mnn — dùng ĐÚNG 32 byte cuối đã ghi ở mục CE (log thật 2026-10-01).
  (2) compare: các tình huống KHỚP / LỆCH / thiếu thông tin.
  (3) đối chiếu chéo: các khoá JSON mà Dart đọc (`commit`, `mnn_commit`, ...) phải trùng với khoá mà build.yml và notebook GHI RA (đọc thẳng từ 2 file đó).
Chạy: python3 provenance_port_test.py
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DART = open(os.path.join(HERE, "../../lib/services/mnn_provenance_service.dart"), encoding="utf-8").read()


def version_label_from_tail(b):
    text = "".join(chr(x) if 0x20 <= x < 0x7F else " " for x in b)
    m = list(re.finditer(r"(?<![\d.])(\d+\.\d+\.\d+)(?![\d.])", text))
    return m[-1].group(1) if m else None


def compare(runtime=None, model=None, label=None):
    rc = runtime.get("commit", "") if runtime and isinstance(runtime.get("commit"), str) else ""
    mc = model.get("mnn_commit", "") if model and isinstance(model.get("mnn_commit"), str) else ""
    if not rc:
        return "KHONG-KET-LUAN-runtime"
    if not mc:
        return "KHONG-KET-LUAN-model"
    return "KHOP" if rc == mc else "LECH"


fails = 0
def check(desc, ok, extra=""):
    global fails
    fails += (not ok)
    print(("ok   " if ok else "FAIL ") + desc + (("  => " + str(extra)) if extra != "" else ""))

# (1) 32 byte cuối llm.mnn thật của model Qwen3 (mục CE)
tail = bytes.fromhex("0a000000040000000500000033 2e362e31 00000007000000 4d4e4e54657374 00".replace(" ", ""))
check("đuôi llm.mnn thật (mục CE) ⇒ nhãn '3.6.1'", len(tail) == 32 and version_label_from_tail(tail) == "3.6.1", version_label_from_tail(tail))
check("đuôi không có số phiên bản ⇒ None", version_label_from_tail(bytes(range(0, 40))) is None)
check("lấy nhãn CUỐI khi có nhiều chuỗi giống phiên bản", version_label_from_tail(b"1.2.3 xx 3.6.1 MNNTest") == "3.6.1")
check("không nhận nhầm số dài như 10.20.300.4", version_label_from_tail(b"..10.20.300.4..") is None)

# (2) so sánh
sha_a, sha_b = "a" * 40, "b" * 40
check("không có thông tin runtime ⇒ không kết luận", compare(runtime=None, model={"mnn_commit": sha_a}) == "KHONG-KET-LUAN-runtime")
check("runtime là bản mẫu (commit rỗng) ⇒ không kết luận", compare(runtime={"commit": ""}, model={"mnn_commit": sha_a}) == "KHONG-KET-LUAN-runtime")
check("model cũ chưa ghi commit ⇒ không kết luận về model", compare(runtime={"commit": sha_a}, model=None, label="3.6.1") == "KHONG-KET-LUAN-model")
check("cùng commit ⇒ KHỚP", compare(runtime={"commit": sha_a}, model={"mnn_commit": sha_a}) == "KHOP")
check("khác commit (cùng nhãn 3.6.1) ⇒ LỆCH", compare(runtime={"commit": sha_a, "version_header": "3.6.1"}, model={"mnn_commit": sha_b, "mnn_version_header": "3.6.1"}) == "LECH")

# (3) khoá JSON hai phía trùng nhau. build.yml và notebook KHÔNG nằm trong zip: truyền đường dẫn qua tham số
#     (python3 provenance_port_test.py <build.yml> <notebook.ipynb>); thiếu thì BỎ QUA phần này và nói rõ.
bld_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "../../../build.yml")
nbp = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "../../../LocalNovel_Convert_Model_To_MNN.ipynb")
bld = open(bld_path, encoding="utf-8").read() if os.path.exists(bld_path) else ""
nb_src = "".join("".join(c["source"]) for c in json.load(open(nbp, encoding="utf-8"))["cells"]) if os.path.exists(nbp) else ""
if not bld:
    print("BO QUA: khong thay build.yml tai", bld_path, "(truyen duong dan qua tham so 1)")
if not nb_src:
    print("BO QUA: khong thay notebook tai", nbp, "(truyen duong dan qua tham so 2)")
if bld:
    for k in ("commit", "exact_tag", "version_header", "requested_ref", "source"):
        check(f"khoá runtime '{k}': Dart đọc và build.yml ghi", (f"['{k}']" in DART or f"?['{k}']" in DART) and f'"{k}"' in bld)
if nb_src:
    for k in ("mnn_commit", "mnn_requested_ref", "mnn_version_header"):
        check(f"khoá model '{k}': Dart đọc và notebook ghi", f"['{k}']" in DART and f'"{k}"' in nb_src)
check("tên file thông tin model khớp giữa Dart và notebook", "localnovel_export_info.json" in DART and (not nb_src or "localnovel_export_info.json" in nb_src))
check("tên asset runtime khớp giữa Dart, pubspec và build.yml", "assets/mnn_runtime.json" in DART and "assets/mnn_runtime.json" in open(os.path.join(HERE, "../../pubspec.yaml"), encoding="utf-8").read() and (not bld or "scaffold/assets/mnn_runtime.json" in bld))

print("\nTAT CA DAT" if fails == 0 else "\nCO %d TRUONG HOP SAI" % fails)
sys.exit(1 if fails else 0)

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MỤC DL — kiểm thử LOGIC của phần mới trong lib/services/sampling_profile_service.dart:
  (1) `_sanitizeUserKeys` (lọc khoá lạ / ngoài miền) — dùng CHÍNH các bảng `_numericKeys`, `_intKeys`, `_samplerNames` đọc thẳng từ file Dart bằng regex
      (không gõ lại tay ⇒ bảng trong test không thể lệch với bảng trong app);
  (2) `_ensureNeededSamplers` (bổ sung bước penalty/dry/xtc còn thiếu vào mixed_samplers);
  (3) thứ tự ghép nguồn có thêm bước D (ghi đè trong app) và logic `changed` của `saveAppOverride`.
Đây là bản PORT Python của thuật toán Dart (không chạy mã Dart): kiểm DỮ LIỆU + THUẬT TOÁN, KHÔNG kiểm cú pháp/biên dịch Dart.
Chạy: python3 override_port_test.py   (thoát mã 1 nếu có ca sai)
"""
import json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
DART = open(os.path.join(HERE, "../../lib/services/sampling_profile_service.dart"), encoding="utf-8").read()
PRESETS = json.load(open(os.path.join(HERE, "../../assets/sampling_presets.json"), encoding="utf-8"))


def _table(name):
    m = re.search(r"static const Map<String, List<num>> %s = \{(.*?)\n  \};" % name, DART, re.S)
    assert m, "không tìm thấy bảng " + name
    return {k: (float(a), float(b)) for k, a, b in re.findall(r"'(\w+)':\s*\[\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*\]", m.group(1))}


NUM = _table("_numericKeys")
INT = _table("_intKeys")
m = re.search(r"static const Set<String> _samplerNames = \{(.*?)\};", DART, re.S)
SAMPLER_NAMES = set(re.findall(r"'(\w+)'", m.group(1)))
assert len(NUM) >= 14 and len(INT) >= 5 and "dry" in SAMPLER_NAMES and "xtc" in SAMPLER_NAMES, (len(NUM), len(INT), SAMPLER_NAMES)


def validate(k, v):
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return None
    if k in NUM:
        return float(v) if NUM[k][0] <= v <= NUM[k][1] else None
    if k in INT:
        return int(v) if INT[k][0] <= v <= INT[k][1] else None
    return None


def sanitize_user_keys(user):
    out = {}
    for k, v in user.items():
        if k == "mixed_samplers":
            if isinstance(v, list) and v and all(isinstance(e, str) and e in SAMPLER_NAMES for e in v):
                out[k] = list(v)
        elif k == "dry_sequence_breakers":
            if isinstance(v, list) and all(isinstance(e, int) for e in v):
                out[k] = v
        elif isinstance(v, (int, float)) and not isinstance(v, bool):
            ok = validate(k, v)
            if ok is not None:
                out[k] = ok
    return out


def ensure_needed_samplers(profile):
    ms = profile.get("mixed_samplers")
    if not isinstance(ms, list):
        return []
    lst = [x for x in ms if isinstance(x, str)]

    def n(k):
        v = profile.get(k)
        return float(v) if isinstance(v, (int, float)) else 0.0

    added = []
    if (n("repetition_penalty") > 1.0 or n("presence_penalty") > 0 or n("frequency_penalty") > 0) and "penalty" not in lst:
        lst.insert(0, "penalty"); added.append("penalty")
    if n("dry_multiplier") > 0 and "dry" not in lst:
        at = lst.index("penalty") if "penalty" in lst else -1
        lst.insert(0 if at < 0 else at + 1, "dry"); added.append("dry")
    if n("xtc_probability") > 0 and "xtc" not in lst:
        at = lst.index("temperature") if "temperature" in lst else -1
        if at < 0:
            lst.append("xtc")
        else:
            lst.insert(at, "xtc")
        added.append("xtc")
    if added:
        profile["mixed_samplers"] = lst
    return added


def base_profile_qwen3():
    d = PRESETS["_defaults"]
    prof = {"temperature": 0.7, "top_p": 0.8, "top_k": 20, "min_p": 0.0, "presence_penalty": 1.5, "penalty_window": 64}
    prof["mixed_samplers"] = list(d["mixed_samplers"])
    return prof


def merge_with_override(profile, enabled, params, slot=0):
    """bước D của prepareFor + ensure (applyAppOverride = slot == 0)"""
    if slot == 0 and enabled and params:
        cleaned = sanitize_user_keys(params)
        if cleaned:
            profile.update(cleaned)
    return ensure_needed_samplers(profile)


def effective(enabled, cleaned):
    return json.dumps(cleaned) if (enabled and cleaned) else ""


fails = 0


def check(desc, ok, extra=""):
    global fails
    fails += (not ok)
    print(("ok   " if ok else "FAIL ") + desc + (("  => " + str(extra)) if extra != "" else ""))


# --- bảng đọc từ Dart ---
check("bảng miền giá trị đọc từ Dart có đủ khoá DRY/XTC/penalty", all(k in NUM for k in ("dry_multiplier", "dry_base", "xtc_probability", "xtc_threshold", "repetition_penalty", "presence_penalty")) and all(k in INT for k in ("penalty_window", "dry_allowed_length", "n_gram", "top_k")))

# --- sanitize ---
s = sanitize_user_keys({"temperature": 0.9, "dry_multiplier": 99, "foo": 1, "top_k": 25.7, "repetition_penalty": True, "mixed_samplers": ["penalty", "nope"]})
check("khoá lạ / ngoài miền / bool / mixed_samplers chứa tên lạ đều bị bỏ", s == {"temperature": 0.9, "top_k": 25}, s)

# --- Qwen3 + DRY + XTC: danh sách mặc định (penalty, topK, topP, min_p, temperature) KHÔNG có dry/xtc ⇒ phải được thêm đúng vị trí ---
p = base_profile_qwen3()
check("tiền đề: danh sách mặc định của bảng KHÔNG có dry/xtc (đúng lý do cần bước bổ sung)", "dry" not in p["mixed_samplers"] and "xtc" not in p["mixed_samplers"], p["mixed_samplers"])
added = merge_with_override(p, True, {"dry_multiplier": 0.8, "dry_allowed_length": 8, "xtc_probability": 0.5})
check("bật DRY+XTC ⇒ thêm dry ngay sau penalty, xtc ngay trước temperature", p["mixed_samplers"] == ["penalty", "dry", "topK", "topP", "min_p", "xtc", "temperature"] and added == ["dry", "xtc"], p["mixed_samplers"])
check("giữ nguyên các khoá của họ model không bị ghi đè (presence_penalty 1.5, penalty_window 64)", p["presence_penalty"] == 1.5 and p["penalty_window"] == 64 and p["dry_allowed_length"] == 8)

# --- idempotent ---
again = ensure_needed_samplers(p)
check("chạy lại không thêm gì (idempotent)", again == [] and p["mixed_samplers"] == ["penalty", "dry", "topK", "topP", "min_p", "xtc", "temperature"])

# --- penalty thiếu trong danh sách do người dùng tự khai ---
p = {"mixed_samplers": ["topK", "topP", "min_p", "temperature"], "repetition_penalty": 1.15}
added = merge_with_override(p, True, {})
check("repetition_penalty>1 mà danh sách thiếu penalty ⇒ thêm penalty ở đầu (bài học mục AL)", added == ["penalty"] and p["mixed_samplers"][0] == "penalty", p["mixed_samplers"])

# --- repetition_penalty = 1.0 và presence = 0 ⇒ KHÔNG thêm (không bật vô cớ) ---
p = {"mixed_samplers": ["topK", "temperature"], "repetition_penalty": 1.0, "presence_penalty": 0.0}
check("penalty=1.0/presence=0 ⇒ không thêm bước penalty", ensure_needed_samplers(p) == [] and p["mixed_samplers"] == ["topK", "temperature"])

# --- dry khi không có penalty trong danh sách ⇒ chèn ở đầu ---
p = {"mixed_samplers": ["topK", "temperature"], "dry_multiplier": 0.5}
ensure_needed_samplers(p)
check("dry không có penalty ⇒ chèn ở đầu danh sách", p["mixed_samplers"] == ["dry", "topK", "temperature"], p["mixed_samplers"])

# --- xtc khi danh sách không có temperature ⇒ thêm cuối ---
p = {"mixed_samplers": ["topK", "topP"], "xtc_probability": 0.3}
ensure_needed_samplers(p)
check("xtc không có temperature ⇒ thêm cuối danh sách", p["mixed_samplers"] == ["topK", "topP", "xtc"], p["mixed_samplers"])

# --- không khai báo mixed_samplers ⇒ KHÔNG tự thêm khoá (tầng C++ dùng danh sách dự phòng đã có penalty/dry/xtc) ---
p = {"temperature": 0.8, "dry_multiplier": 0.8}
check("hồ sơ không khai báo mixed_samplers ⇒ không thêm khoá này", ensure_needed_samplers(p) == [] and "mixed_samplers" not in p)

# --- ghi đè TẮT ⇒ không đổi gì; ghi đè rỗng ⇒ không đổi gì ---
p = base_profile_qwen3(); snap = json.dumps(p, sort_keys=True)
merge_with_override(p, False, {"dry_multiplier": 0.8, "temperature": 2.0})
check("ghi đè TẮT ⇒ hồ sơ y nguyên (mặc định không đổi hành vi)", json.dumps(p, sort_keys=True) == snap)
p = base_profile_qwen3(); snap = json.dumps(p, sort_keys=True)
merge_with_override(p, True, {})
check("ghi đè BẬT nhưng rỗng ⇒ hồ sơ y nguyên", json.dumps(p, sort_keys=True) == snap)

# --- ghi đè thắng khoá cùng tên của họ model ---
p = base_profile_qwen3()
merge_with_override(p, True, {"temperature": 1.0, "presence_penalty": 0.0, "repetition_penalty": 1.0, "min_p": 0.05})
check("ghi đè thay khoá cùng tên (temperature, presence_penalty, min_p)", p["temperature"] == 1.0 and p["presence_penalty"] == 0.0 and p["min_p"] == 0.05 and p["top_p"] == 0.8)

# --- ghi đè CHỈ áp cho model chính (slot 0); slot 1 (dịch thuật/tài liệu) không bị ảnh hưởng ---
p = base_profile_qwen3(); snap = json.dumps(p, sort_keys=True)
merge_with_override(p, True, {"temperature": 1.5, "dry_multiplier": 0.8}, slot=1)
check("slot 1 (dịch thuật/tài liệu) KHÔNG nhận ghi đè dù đang bật", json.dumps(p, sort_keys=True) == snap)

# --- logic `changed` của saveAppOverride ---
b, a = effective(False, {}), effective(False, {"temperature": 0.9})
check("tắt → tắt (dù nội dung đổi) ⇒ KHÔNG đổi hiệu lực (không xả model vô ích)", b == a)
b, a = effective(False, {}), effective(True, {"temperature": 0.9})
check("tắt → bật có nội dung ⇒ đổi hiệu lực", b != a)
b, a = effective(True, {"temperature": 0.9}), effective(True, {"temperature": 0.9})
check("bật, nội dung giống ⇒ không đổi", b == a)
b, a = effective(True, {"temperature": 0.9}), effective(False, {"temperature": 0.9})
check("bật → tắt ⇒ đổi hiệu lực (trở về hồ sơ model)", b != a)
b, a = effective(False, {}), effective(True, {})
check("bật nhưng rỗng ⇒ không đổi hiệu lực", b == a)

# --- ví dụ A/B của notebook Colab (cấu hình D) ánh xạ được sang khoá hợp lệ của app ---
d_cfg = {"min_p": 0.05, "repetition_penalty": 1.0, "dry_multiplier": 0.8, "dry_base": 1.75, "dry_allowed_length": 8, "temperature": 0.8, "top_k": 40, "top_p": 0.9}
kept = sanitize_user_keys(d_cfg)
check("cấu hình D của colab_sampler_ab_cell.py (DRY len8) đi qua bộ lọc nguyên vẹn", set(kept) == set(d_cfg), sorted(set(d_cfg) - set(kept)))

print("\nTAT CA DAT" if fails == 0 else "\nCO %d TRUONG HOP SAI" % fails)
sys.exit(1 if fails else 0)

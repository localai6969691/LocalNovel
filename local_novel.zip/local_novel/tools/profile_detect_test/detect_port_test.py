#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MỤC DK — kiểm thử LOGIC nhận dạng họ model + ghép hồ sơ của lib/services/sampling_profile_service.dart.
Đây là bản PORT Python của thuật toán Dart (không chạy mã Dart) chạy trên CHÍNH assets/sampling_presets.json thật. Nó kiểm DỮ LIỆU + THUẬT TOÁN
(độ chính xác nhận dạng, không áp nhầm), không kiểm cú pháp/biên dịch Dart.
"""
import json, re, sys, os
HERE = os.path.dirname(os.path.abspath(__file__))
PRESETS = json.load(open(os.path.join(HERE, "../../assets/sampling_presets.json"), encoding="utf-8"))

NUM = {'temperature':(0.01,5.0),'top_p':(0.01,1.0),'min_p':(0.0,1.0),'repetition_penalty':(0.5,5.0),'presence_penalty':(0.0,5.0)}
INT = {'top_k':(0,1000),'penalty_window':(0,100000)}
def validate(k, v):
    if k in NUM: return float(v) if NUM[k][0] <= v <= NUM[k][1] else None
    if k in INT: return int(v) if INT[k][0] <= v <= INT[k][1] else None
    return None

def params_of(item):
    out = {}
    mode, modes = item.get('default_mode'), item.get('modes')
    if isinstance(mode, str) and isinstance(modes, dict) and isinstance(modes.get(mode), dict):
        for k, v in modes[mode].items():
            if isinstance(v, (int, float)) and validate(k, v) is not None: out[k] = validate(k, v)
    ex = item.get('extras_for_quantized')
    if isinstance(ex, dict):
        for k, v in ex.items():
            if isinstance(v, (int, float)) and validate(k, v) is not None: out[k] = validate(k, v)
    return out

def rx(p):
    return re.compile(p, re.I) if isinstance(p, str) and p else None

def detect(names, model_type, template):
    family_hit = None
    for item in PRESETS['presets']:
        det = item.get('detect')
        if not isinstance(det, dict): continue
        name_rx, ex_rx = rx(det.get('name')), rx(det.get('exclude'))
        types = [t.lower() for t in det.get('model_types', [])]
        markers = det.get('template_markers', [])
        if ex_rx and any(ex_rx.search(n) for n in names): continue
        name_hit = bool(name_rx and any(name_rx.search(n) for n in names))
        type_hit = None if (not types or model_type is None) else (model_type in types)
        if name_hit:
            if type_hit is False: continue
            p = params_of(item)
            if not p: continue
            return item['id'], 'exact', p
        if item.get('allow_family_match') is True and family_hit is None and type_hit is True and (not markers or any(m in template for m in markers)):
            p = params_of(item)
            if p: family_hit = (item['id'], 'family', p)
    return family_hit

def build_profile(names, model_type, template, gen_config=None, user=None):
    prof, src = {}, []
    hit = detect(names, model_type, template)
    if hit: prof.update(hit[2]); src.append(f"{hit[0]}({hit[1]})")
    if gen_config:
        for hf, k in (('temperature','temperature'),('top_k','top_k'),('top_p','top_p'),('min_p','min_p'),('repetition_penalty','repetition_penalty')):
            v = gen_config.get(hf)
            if isinstance(v,(int,float)) and validate(k,v) is not None: prof[k]=validate(k,v)
        src.append('generation_config')
    if prof:
        d = PRESETS['_defaults']
        for k, v in d['params'].items(): prof.setdefault(k, validate(k, v))
        prof.setdefault('mixed_samplers', d['mixed_samplers'])
    if user:
        for k, v in user.items():
            if isinstance(v,(int,float)) and validate(k,v) is not None: prof[k]=validate(k,v)
        src.append('user')
    return prof, src

CHATML, LLAMA3, GEMMA, INST = "<|im_start|>user", "<|start_header_id|>user", "<start_of_turn>user", "[INST] x [/INST]"
cases = [
  # (mô tả, names, model_type, template, kỳ vọng id|None, kỳ vọng độ tin cậy)
  ("UTENA-7B (gộp Mistral, không template) — model THẬT của người dùng", ["AI-B-UTENA-7B-NSFW-V2-MNN-q4-chinh"], "mistral", "", None, None),
  ("Qwen3-8B bản MNN chính thức", ["Qwen3-8B-MNN"], "qwen3", CHATML, "qwen3", "exact"),
  ("Qwen3 tinh chỉnh đổi tên (không có 'qwen3' trong tên)", ["Josiefied-8B-abliterated"], "qwen3", CHATML, "qwen3", "family"),
  ("Qwen3 đổi tên NHƯNG export_args.json nhớ tên nguồn", ["my-model-q4", "Qwen3-8B"], "qwen3", CHATML, "qwen3", "exact"),
  ("Qwen2.5-7B-Instruct-MNN", ["Qwen2.5-7B-Instruct-MNN"], "qwen2", CHATML, "qwen2_5", "exact"),
  ("DeepSeek-R1-Distill-Qwen-7B (model_type qwen2 dùng chung)", ["DeepSeek-R1-Distill-Qwen-7B-MNN"], "qwen2", "<｜User｜>", None, None),
  ("QwQ-32B bị loại", ["QwQ-32B-MNN"], "qwen2", CHATML, None, None),
  ("Qwen3.5 bị loại khỏi họ Qwen3", ["Qwen3.5-9B-MNN"], "qwen3_5", CHATML, None, None),
  ("Llama-3.1-8B-Instruct", ["Llama-3.1-8B-Instruct-MNN"], "llama", LLAMA3, "llama3_1", "exact"),
  ("Bản RP tinh chỉnh Llama-3 (model_type llama + template Llama3, tên lạ) — KHÔNG áp", ["L3-Stheno-8B"], "llama", LLAMA3, None, None),
  ("Gemma-3-4b-it", ["gemma-3-4b-it-MNN"], "gemma3_text", GEMMA, "gemma3", "exact"),
  ("Mistral-Nemo-Instruct", ["Mistral-Nemo-Instruct-2407-MNN"], "mistral", INST, "mistral_nemo", "exact"),
  ("Mistral-7B-Instruct-v0.3 — KHÔNG áp 0.3 của Nemo", ["Mistral-7B-Instruct-v0.3-MNN"], "mistral", INST, None, None),
  ("Morpheus (tinh chỉnh Hunyuan, tên không chứa 'hunyuan') — model THẬT của người dùng", ["OccultAI-Morpheus-8B-MNN"], "hunyuan_v1_dense", "", "hunyuan_dense", "family"),
  ("Hunyuan-7B-Instruct", ["Hunyuan-7B-Instruct-MNN"], "hunyuan_v1_dense", "", "hunyuan_dense", "exact"),
  ("Hunyuan-MT bị loại (khuyến nghị khác)", ["Hunyuan-MT-7B"], "hunyuan_v1_dense", "", None, None),
  ("Tên Qwen3 nhưng model_type llama => mâu thuẫn, bỏ qua", ["Qwen3-8B-merge"], "llama", LLAMA3, None, None),
  ("Tên Qwen3, KHÔNG có llm_config (model_type chưa biết) => vẫn nhận theo tên", ["Qwen3-4B"], None, "", "qwen3", "exact"),
]
fails = 0
for desc, names, mt, tpl, exp_id, exp_conf in cases:
    hit = detect(names, mt, tpl)
    got_id, got_conf = (hit[0], hit[1]) if hit else (None, None)
    ok = (got_id == exp_id and got_conf == exp_conf)
    fails += (not ok)
    print(("ok  " if ok else "FAIL"), desc, "=>", got_id, got_conf)
# ghép nguồn
prof, src = build_profile(["Qwen3-8B-MNN"], "qwen3", CHATML)
exp = {'temperature':0.7,'top_p':0.8,'top_k':20,'min_p':0.0,'presence_penalty':1.5,'penalty_window':64}
ok = all(prof.get(k)==v for k,v in exp.items()) and prof['mixed_samplers']==['penalty','topK','topP','min_p','temperature']
fails += (not ok); print(("ok  " if ok else "FAIL"), "hồ sơ Qwen3 đầy đủ:", prof)
prof, src = build_profile(["Qwen3-8B-MNN"], "qwen3", CHATML, gen_config={'temperature':0.6,'top_p':0.95,'top_k':20,'min_p':0})
ok = prof['temperature']==0.6 and prof['top_p']==0.95 and prof['presence_penalty']==1.5
fails += (not ok); print(("ok  " if ok else "FAIL"), "generation_config.json của model ghi đè khoá cùng tên, giữ presence_penalty của họ:", prof)
prof, src = build_profile(["Qwen3-8B-MNN"], "qwen3", CHATML, user={'temperature':1.0,'presence_penalty':0.0,'nonsense':5})
ok = prof['temperature']==1.0 and prof['presence_penalty']==0.0 and 'nonsense' not in prof
fails += (not ok); print(("ok  " if ok else "FAIL"), "file người dùng ghi đè cuối cùng; khoá lạ bị loại:", prof)
prof, src = build_profile(["AI-B-UTENA-7B-NSFW-V2-MNN-q4-chinh"], "mistral", "")
ok = prof == {}
fails += (not ok); print(("ok  " if ok else "FAIL"), "UTENA không có nguồn => hồ sơ rỗng (không áp số tự nghĩ):", prof)
prof, src = build_profile(["gemma-3-4b-it"], "gemma3_text", GEMMA)
ok = prof.get('top_k')==64 and prof.get('temperature')==1.0 and prof.get('min_p')==0.0 and prof.get('repetition_penalty')==1.0
fails += (not ok); print(("ok  " if ok else "FAIL"), "hồ sơ Gemma 3:", prof)
print("\nTAT CA DAT" if fails == 0 else f"\nCO {fails} TRUONG HOP SAI")
sys.exit(1 if fails else 0)

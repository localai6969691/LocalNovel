#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MỤC DQ — kiểm thử THUẬT TOÁN của lib/services/think_splitter.dart (bản PORT Python từng dòng; KHÔNG chạy mã Dart, không kiểm biên dịch).
So `ThinkSplitter` (theo dòng chảy) với bản tham chiếu KHÔNG streaming trên rất nhiều cách cắt chunk (mọi điểm cắt 2 mảnh, mọi điểm cắt 3 mảnh,
cắt ngẫu nhiên từng ký tự), để chắc thẻ bị cắt ngang giữa 2 chunk không làm rơi/lẫn chữ.
Hằng kAiFailureMarker đọc thẳng từ lib/services/ai_provider.dart.
"""
import itertools, os, random, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
AI = open(os.path.join(HERE, "../../lib/services/ai_provider.dart"), encoding="utf-8").read()
MARK = re.search(r"kAiFailureMarker\s*=\s*'([^']*)'", AI).group(1)
OPEN, CLOSE = "<think>", "</think>"


class ThinkSplitter:
    def __init__(self):
        self.state = 0; self.pending = ""; self.saw = False

    @staticmethod
    def tail_keep(s, target):
        mx = min(len(s), len(target) - 1)
        for k in range(mx, 0, -1):
            if s.endswith(target[:k]):
                return k
        return 0

    def feed(self, chunk):
        vis, th = [], []
        s = self.pending + chunk; self.pending = ""
        while s:
            if self.state == 0:
                t = s.lstrip()
                if not t:
                    self.pending = s; s = ""
                elif t.startswith(OPEN):
                    self.state = 1; self.saw = True; s = t[len(OPEN):]
                elif OPEN.startswith(t):
                    self.pending = s; s = ""
                else:
                    self.state = 3
            elif self.state == 1:
                ci = s.find(CLOSE); mi = s.find(MARK)
                if ci >= 0 and (mi < 0 or ci < mi):
                    th.append(s[:ci]); s = s[ci + len(CLOSE):]; self.state = 2
                elif mi >= 0:
                    th.append(s[:mi]); s = s[mi:]; self.state = 3
                else:
                    keep = max(self.tail_keep(s, CLOSE), self.tail_keep(s, MARK))
                    th.append(s[:len(s) - keep]); self.pending = s[len(s) - keep:]; s = ""
            elif self.state == 2:
                t = s.lstrip()
                if not t:
                    s = ""
                else:
                    s = t; self.state = 3
            else:
                vis.append(s); s = ""
        return "".join(vis), "".join(th)

    def flush(self):
        p = self.pending; self.pending = ""
        if self.state == 0:
            self.state = 3; return p, ""
        if self.state == 1:
            return "", p
        return "", ""


def run(chunks):
    sp = ThinkSplitter(); v, t = [], []
    for c in chunks:
        a, b = sp.feed(c); v.append(a); t.append(b)
    a, b = sp.flush(); v.append(a); t.append(b)
    return "".join(v), "".join(t), sp.saw


def reference(text):
    """Bản KHÔNG streaming: cùng ngữ nghĩa mong muốn."""
    t = text.lstrip()
    if t.startswith(OPEN):
        rest = t[len(OPEN):]
        ci = rest.find(CLOSE); mi = rest.find(MARK)
        if ci >= 0 and (mi < 0 or ci < mi):
            return rest[ci + len(CLOSE):].lstrip(), rest[:ci], True
        if mi >= 0:
            return rest[mi:], rest[:mi], True
        return "", rest, True
    return text, "", False


fails = 0
def check(desc, ok, extra=""):
    global fails
    fails += (not ok)
    print(("ok   " if ok else "FAIL ") + desc + (("  => " + str(extra)) if extra != "" else ""))

samples = [
    "<think>\nUser chào. Mình nên chào lại.\n</think>\n\nChào bạn! Mình có thể giúp gì?",
    "  \n<think>nghĩ</think>Trả lời ngay",
    "<think></think>Câu trả lời",
    "<think>\n\n</think>\n\nĐã chặn suy nghĩ rỗng, chương bắt đầu từ đây.\nDòng hai.",
    "Không có suy nghĩ nào ở đây, chỉ văn bản. <think> giữa dòng thì giữ nguyên </think> hết.",
    "<think>chưa đóng bao giờ vì hết token",
    "<think>nghĩ</think>",
    "<th",
    "<thinker> không phải thẻ",
    "   ",
    "<think>a</think>\n\n\n  B",
    "<think>nghĩ có chữ <b> và </think nhưng chưa đóng đúng</think>Xong",
    "<think>đang nghĩ" + MARK + "Đã tự dừng: model rơi vào lặp]",
    "<think>nghĩ</think>OK" + MARK + "Cần nạp lại model]",
    "Tiếng Việt có dấu: Chương 1 — Cô gái đứng trước cánh cửa",
]
# 1) mọi điểm cắt 1, 2 và 3 mảnh
bad = 0
for s in samples:
    exp = reference(s)
    cuts = [[s]]
    cuts += [[s[:i], s[i:]] for i in range(len(s) + 1)]
    if len(s) <= 40:
        for i, j in itertools.combinations(range(len(s) + 1), 2):
            cuts.append([s[:i], s[i:j], s[j:]])
    for ch in cuts:
        v, t, saw = run(ch)
        if (v, t, saw) != exp:
            bad += 1
            if bad <= 3: print("   sai ở mẫu", repr(s[:40]), "cắt", [c[:12] for c in ch], "→", (v[:30], t[:30], saw), "mong", (exp[0][:30], exp[1][:30], exp[2]))
check(f"{len(samples)} mẫu × mọi điểm cắt 1/2/3 mảnh khớp bản tham chiếu không-streaming", bad == 0, f"sai {bad}")
# 2) cắt ngẫu nhiên từng ký tự + chunk lớn nhỏ lẫn lộn
random.seed(7); bad = 0; total = 0
for s in samples:
    exp = reference(s)
    for _ in range(300):
        ch = []; i = 0
        while i < len(s):
            k = random.choice([1, 1, 1, 2, 3, 5, 8, 20]); ch.append(s[i:i + k]); i += k
        total += 1
        if run(ch) != exp: bad += 1
check(f"{total} lần cắt ngẫu nhiên (đa số 1–3 ký tự/chunk) đều khớp", bad == 0, f"sai {bad}")
# 3) tính chất riêng
v, t, saw = run(["<think>nghĩ</think>", "\n\nChào"])
check("khối suy nghĩ tách đúng, khoảng trắng sau </think> bị nuốt", (v, t, saw) == ("Chào", "nghĩ", True))
v, t, saw = run(["Chào bạn", "! Hôm nay"])
check("không có <think> ⇒ chữ đi qua NGUYÊN VẸN, saw=False", (v, t, saw) == ("Chào bạn! Hôm nay", "", False))
v, t, saw = run(["<think>đang nghĩ", MARK + "Đã tự dừng]"])
check("dòng cảnh báo lỗi nội bộ KHÔNG bị nuốt vào suy nghĩ", v == MARK + "Đã tự dừng]" and t == "đang nghĩ")
v, t, _ = run(["<think>hết token trước khi đóng"])
check("khối suy nghĩ chưa đóng ⇒ visible rỗng, suy nghĩ giữ đủ (UI báo 'mới chỉ suy nghĩ')", v == "" and t == "hết token trước khi đóng")
v, t, _ = run(["<thi"])
check("đầu thẻ dở ở cuối luồng ⇒ coi là chữ thường", v == "<thi" and t == "")
v, t, _ = run(["<think>x</thi", "nk>trả lời"])
check("thẻ đóng bị cắt đôi giữa 2 chunk vẫn nhận ra", (v, t) == ("trả lời", "x"))
sys.exit(1 if fails else 0)

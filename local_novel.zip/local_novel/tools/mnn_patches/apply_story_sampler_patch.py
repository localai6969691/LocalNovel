#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MỤC DG (LocalNovel, 2026-10-17) — vá bộ lấy mẫu của MNN (transformers/llm/engine) để thêm DRY + XTC và cho phép dựng lại sampler khi set_config.

Cách dùng:  python3 apply_story_sampler_patch.py <thư mục engine>   (vd MNN/transformers/llm/engine)

Viết dựa trên mã THẬT của MNN tag 3.6.1 (đã đọc: src/sampler.cpp, src/sampler.hpp, src/llmconfig.hpp, src/llm.cpp). Mỗi chỗ sửa dùng chuỗi neo CHÍNH XÁC và
kiểm "xuất hiện đúng 1 lần"; neo không khớp (MNN đổi mã) => dừng với lỗi RÕ RÀNG thay vì vá bừa. Chạy lại là no-op (nhận ra dấu MỤC DG).

Hành vi mặc định KHÔNG ĐỔI: dry_multiplier=0 và xtc_probability=0 => hai bước không làm gì; "live_sampler" mặc định false => set_config không dựng lại sampler.

Hai điều đã đọc thấy trong mã MNN làm nên bản vá:
 1) Sampler chỉ được tạo trong Llm::load(); Llm::set_config() chỉ trộn JSON vào cấu hình, KHÔNG dựng lại sampler, và Sampler tự sao chép mọi tham số lúc dựng.
    => set_config SAU load (đúng cách app gửi temperature/top_k/top_p/repetition_penalty mỗi lượt generate) không ảnh hưởng việc lấy mẫu.
    Khoá mới "live_sampler": true cho phép set_config dựng lại sampler (opt-in).
 2) stepPenalty thoát sớm khi repetition_penalty<=1 và presence/frequency_penalty<=0, nên phạt n-gram của MNN không dùng riêng được; DRY mới thay vai đó.
"""
import sys, os

MARK = "MỤC DG"

def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()

def write(p, s):
    with open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)

def replace_once(text, old, new, label):
    n = text.count(old)
    if n != 1:
        sys.exit(f"[LOI] neo '{label}' xuat hien {n} lan (can dung 1) — ma nguon MNN khac voi ban da doc, KHONG va bua.")
    return text.replace(old, new, 1)

# ----------------------------------------------------------------- llmconfig.hpp
def patch_llmconfig(p):
    t = read(p)
    if MARK in t:
        print(f"[bo qua] {p}: da va"); return
    old = '''    std::vector<int> banned_tokens() const {
        return config_.value("banned_tokens", std::vector<int>{});
    }
    // sampler config end >'''
    new = '''    std::vector<int> banned_tokens() const {
        return config_.value("banned_tokens", std::vector<int>{});
    }
    // MỤC DG (LocalNovel): DRY / XTC — mặc định TẮT (multiplier=0, probability=0).
    float dry_multiplier() const { return config_.value("dry_multiplier", 0.0f); }
    float dry_base() const { return config_.value("dry_base", 1.75f); }
    int dry_allowed_length() const { return config_.value("dry_allowed_length", 2); }
    int dry_penalty_last_n() const { return config_.value("dry_penalty_last_n", -1); }
    std::vector<int> dry_sequence_breakers() const { return config_.value("dry_sequence_breakers", std::vector<int>{}); }
    float xtc_probability() const { return config_.value("xtc_probability", 0.0f); }
    float xtc_threshold() const { return config_.value("xtc_threshold", 0.1f); }
    // sampler config end >'''
    write(p, replace_once(t, old, new, "llmconfig.banned_tokens"))
    print(f"[da va] {p}")

# ----------------------------------------------------------------- sampler.hpp
def patch_sampler_hpp(p):
    t = read(p)
    if MARK in t:
        print(f"[bo qua] {p}: da va"); return
    t = replace_once(t, '''        std::vector<int> banned_tokens;
        void configSampler(''', '''        std::vector<int> banned_tokens;
        // MỤC DG (LocalNovel): DRY / XTC
        float dry_multiplier = 0.0f;
        float dry_base = 1.75f;
        int dry_allowed_length = 2;
        int dry_penalty_last_n = -1;
        std::vector<int> dry_sequence_breakers;
        float xtc_probability = 0.0f;
        float xtc_threshold = 0.1f;
        void configSampler(''', "sampler.hpp.fields")
    t = replace_once(t, '''        void configMixed(std::shared_ptr<LlmConfig> llmConfig);
    };''', '''        void configMixed(std::shared_ptr<LlmConfig> llmConfig);
        void configDry(std::shared_ptr<LlmConfig> llmConfig);   // MỤC DG
        void configXtc(std::shared_ptr<LlmConfig> llmConfig);   // MỤC DG
    };''', "sampler.hpp.config")
    t = replace_once(t, '''    void stepBannedTokens(SamplerState& state);
    void stepSelect(SamplerState& state);''', '''    void stepBannedTokens(SamplerState& state);
    void stepDry(SamplerState& state);   // MỤC DG
    void stepXtc(SamplerState& state);   // MỤC DG
    void stepSelect(SamplerState& state);''', "sampler.hpp.steps")
    write(p, t)
    print(f"[da va] {p}")

# ----------------------------------------------------------------- sampler.cpp
STEPS_CPP = r'''// MỤC DG (LocalNovel): DRY — phạt theo CHUỖI token lặp (thay cho phạt lặp "cùn" theo từng token).
// Với mỗi token ứng viên t: L = độ dài lớn nhất của chuỗi token đứng ngay trước t ở LỊCH SỬ CŨ mà trùng với ĐUÔI hiện tại của ngữ cảnh;
// nếu L >= dry_allowed_length thì logit[t] -= dry_multiplier * dry_base^(L - dry_allowed_length). Dùng Z-array nên O(n) mỗi token.
// Chạy TRƯỚC top-k (khi logits còn đầy đủ), cùng cách chỉ mục với stepPenalty. Lịch sử lấy từ mContext->history_tokens như stepPenalty.
void Sampler::stepDry(SamplerState& state) {
    const float multiplier = mConfig.dry_multiplier;
    if (multiplier <= 0.0f || mConfig.dry_penalty_last_n == 0) return;
    const std::vector<int>& hist = mContext->history_tokens;
    if (hist.size() < 2) return;
    size_t begin = 0;
    if (mConfig.dry_penalty_last_n > 0 && hist.size() > (size_t)mConfig.dry_penalty_last_n) {
        begin = hist.size() - (size_t)mConfig.dry_penalty_last_n;
    }
    std::vector<int> r(hist.rbegin(), hist.rend() - (std::ptrdiff_t)begin);  // r[0] = token mới nhất
    const int m = (int)r.size();
    if (m < 2) return;
    int limit = m;
    if (!mConfig.dry_sequence_breakers.empty()) {
        const std::unordered_set<int> breakers(mConfig.dry_sequence_breakers.begin(), mConfig.dry_sequence_breakers.end());
        for (int j = 0; j < m; ++j) {
            if (breakers.count(r[j])) { limit = j; break; }
        }
    }
    if (limit <= 0) return;
    std::vector<int> z(m, 0);
    z[0] = m;
    int zl = 0, zr = 0;
    for (int i = 1; i < m; ++i) {
        if (i < zr) z[i] = std::min(zr - i, z[i - zl]);
        while (i + z[i] < m && r[z[i]] == r[i + z[i]]) ++z[i];
        if (i + z[i] > zr) { zl = i; zr = i + z[i]; }
    }
    const int allowed = std::max(1, mConfig.dry_allowed_length);
    std::unordered_map<int, int> best;
    for (int k = 1; k < m; ++k) {
        const int len = std::min(z[k], limit);
        if (len >= allowed) {
            const int next = r[k - 1];
            auto it = best.find(next);
            if (it == best.end() || it->second < len) best[next] = len;
        }
    }
    if (best.empty()) return;
    auto indexMap = buildIndexMap(state);
    for (const auto& kv : best) {
        int tokenId;
        if (state.is_subset) {
            auto it = indexMap.find(kv.first);
            if (it == indexMap.end()) continue;
            tokenId = it->second;
        } else {
            tokenId = kv.first;
        }
        if (tokenId < 0 || tokenId >= (int)state.logits.size()) continue;
        double penalty = (double)multiplier * std::pow((double)mConfig.dry_base, (double)std::min(kv.second - allowed, 1000));
        penalty = std::min(penalty, 1.0e30);
        state.logits[tokenId] -= (float)penalty;
    }
    state.invalidateProbs();
}

// MỤC DG (LocalNovel): XTC — với xác suất xtc_probability, nếu có >=2 token có xác suất >= xtc_threshold thì loại hết trừ token ÍT khả năng nhất
// trong nhóm đó (chống văn xuôi "hiển nhiên"). Dùng xác suất theo nhiệt độ như các bước lọc khác của MNN.
void Sampler::stepXtc(SamplerState& state) {
    const float prob = mConfig.xtc_probability;
    const float thr = mConfig.xtc_threshold;
    if (prob <= 0.0f || thr <= 0.0f) return;
    std::uniform_real_distribution<float> u(0.0f, 1.0f);
    if (u(mRng) >= prob) return;
    state.ensureProbs(mConfig.temperature);
    const int n = (int)state.logits.size();
    int keep = -1;
    int above = 0;
    for (int i = 0; i < n; ++i) {
        if (state.probs[i] >= thr) {
            ++above;
            if (keep < 0 || state.probs[i] < state.probs[keep]) keep = i;
        }
    }
    if (above < 2) return;
    std::vector<float> newLogits;
    std::vector<int> newIndices;
    newLogits.reserve(n - above + 1);
    newIndices.reserve(n - above + 1);
    for (int i = 0; i < n; ++i) {
        if (state.probs[i] >= thr && i != keep) continue;
        newLogits.push_back(state.logits[i]);
        newIndices.push_back(state.is_subset ? state.indices[i] : i);
    }
    state.logits = std::move(newLogits);
    state.indices = std::move(newIndices);
    state.is_subset = true;
    state.invalidateProbs();
}

'''

def patch_sampler_cpp(p):
    t = read(p)
    if MARK in t:
        print(f"[bo qua] {p}: da va"); return
    t = replace_once(t, '#include <unordered_map>\n#include <limits>\n',
                     '#include <unordered_map>\n#include <unordered_set>  // MỤC DG\n#include <limits>\n', "sampler.cpp.include")
    t = replace_once(t, '''    } else if (sampler_type == "mixed") {
        configMixed(llmConfig);
    }
}''', '''    } else if (sampler_type == "mixed") {
        configMixed(llmConfig);
    } else if (sampler_type == "dry") {   // MỤC DG
        configDry(llmConfig);
    } else if (sampler_type == "xtc") {   // MỤC DG
        configXtc(llmConfig);
    }
}''', "sampler.cpp.configSampler")
    t = replace_once(t, 'void Sampler::SamplerConfig::configMixed(std::shared_ptr<LlmConfig> llmConfig) {',
'''// MỤC DG (LocalNovel)
void Sampler::SamplerConfig::configDry(std::shared_ptr<LlmConfig> llmConfig) {
    dry_multiplier = llmConfig->dry_multiplier();
    dry_base = llmConfig->dry_base();
    dry_allowed_length = llmConfig->dry_allowed_length();
    dry_penalty_last_n = llmConfig->dry_penalty_last_n();
    dry_sequence_breakers = llmConfig->dry_sequence_breakers();
    // DRY chỉ sửa logit: không đổi select_type
}

void Sampler::SamplerConfig::configXtc(std::shared_ptr<LlmConfig> llmConfig) {
    xtc_probability = llmConfig->xtc_probability();
    xtc_threshold = llmConfig->xtc_threshold();
    temperature = llmConfig->temperature();
}

void Sampler::SamplerConfig::configMixed(std::shared_ptr<LlmConfig> llmConfig) {''', "sampler.cpp.configMixed.head")
    t = replace_once(t, '''    std::vector<std::string> newSamplers;
    bool hasPenalty = false;
    for (const auto& s : mixedSamplers) {
        if (s != "penalty") {
            newSamplers.push_back(s);
        } else {
            hasPenalty = true;
        }
    }
    if (hasPenalty) {
        newSamplers.insert(newSamplers.begin(), "penalty");
    }''', '''    std::vector<std::string> newSamplers;
    bool hasPenalty = false;
    bool hasDry = false;   // MỤC DG: "dry" cũng chạy sớm (sau penalty), khi logits còn đầy đủ
    for (const auto& s : mixedSamplers) {
        if (s == "penalty") {
            hasPenalty = true;
        } else if (s == "dry") {
            hasDry = true;
        } else {
            newSamplers.push_back(s);
        }
    }
    if (hasDry) {
        newSamplers.insert(newSamplers.begin(), "dry");
    }
    if (hasPenalty) {
        newSamplers.insert(newSamplers.begin(), "penalty");
    }''', "sampler.cpp.reorder")
    t = replace_once(t, '''        } else if (name == "typical") {
            mPipeline.push_back([this](SamplerState& s) { stepTypical(s); });
        }
        // greedy/temperature handled by stepSelect''', '''        } else if (name == "typical") {
            mPipeline.push_back([this](SamplerState& s) { stepTypical(s); });
        } else if (name == "dry") {   // MỤC DG
            mPipeline.push_back([this](SamplerState& s) { stepDry(s); });
        } else if (name == "xtc") {   // MỤC DG
            mPipeline.push_back([this](SamplerState& s) { stepXtc(s); });
        }
        // greedy/temperature handled by stepSelect''', "sampler.cpp.addStep")
    t = replace_once(t, 'void Sampler::stepLogitBias(SamplerState& state) {', STEPS_CPP + 'void Sampler::stepLogitBias(SamplerState& state) {', "sampler.cpp.steps")
    write(p, t)
    print(f"[da va] {p}")

# ----------------------------------------------------------------- llm.cpp
def patch_llm_cpp(p):
    t = read(p)
    if MARK in t:
        print(f"[bo qua] {p}: da va"); return
    old = '''bool Llm::set_config(const std::string& content) {
    mConfig->config_.merge(ujson::json::parse(content));
    setChatTemplate();
'''
    new = '''bool Llm::set_config(const std::string& content) {
    mConfig->config_.merge(ujson::json::parse(content));
    setChatTemplate();
    // MỤC DG (LocalNovel): Sampler chỉ được dựng trong Llm::load() và tự sao chép tham số, nên set_config() SAU load (app gửi temperature/top_k/top_p/
    // repetition_penalty mỗi lượt generate) không có tác dụng với việc lấy mẫu. Khi cấu hình có "live_sampler": true thì dựng lại sampler để các tham số
    // lấy mẫu (gồm dry_*/xtc_*) có hiệu lực. Mặc định false => hành vi cũ. Không gọi khi đang sinh (app gọi set_config trước mỗi lượt generate).
    if (mSampler && mConfig->config_.value("live_sampler", false)) {
        mSampler.reset(Sampler::createSampler(mContext, mConfig));
    }
'''
    write(p, replace_once(t, old, new, "llm.cpp.set_config"))
    print(f"[da va] {p}")

def main():
    if len(sys.argv) != 2:
        sys.exit("Cach dung: apply_story_sampler_patch.py <thu muc engine, vd MNN/transformers/llm/engine>")
    root = sys.argv[1]
    src = os.path.join(root, "src")
    needed = ["llmconfig.hpp", "sampler.hpp", "sampler.cpp", "llm.cpp"]
    for f in needed:
        if not os.path.isfile(os.path.join(src, f)):
            sys.exit(f"[LOI] khong thay {os.path.join(src, f)}")
    patch_llmconfig(os.path.join(src, "llmconfig.hpp"))
    patch_sampler_hpp(os.path.join(src, "sampler.hpp"))
    patch_sampler_cpp(os.path.join(src, "sampler.cpp"))
    patch_llm_cpp(os.path.join(src, "llm.cpp"))
    print("XONG: da va bo lay mau truyen (DRY/XTC/live_sampler). Mac dinh khong doi hanh vi.")

if __name__ == "__main__":
    main()

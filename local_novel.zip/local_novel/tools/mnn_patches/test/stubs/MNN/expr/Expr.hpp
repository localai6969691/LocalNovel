// Stub CHỈ cho bộ thử: giả lập phần VARP mà Sampler dùng (readMap<float>(), getInfo()->dim).
#pragma once
#include <memory>
#include <vector>
namespace MNN { namespace Express {
struct VarInfo { std::vector<int> dim; int size = 0; };
class Variable {
public:
    explicit Variable(std::vector<float> v) : mData(std::move(v)) { mInfo.dim = {1, (int)mData.size()}; mInfo.size = (int)mData.size(); }
    template <typename T> const T* readMap() { return reinterpret_cast<const T*>(mData.data()); }
    const VarInfo* getInfo() const { return &mInfo; }
private:
    std::vector<float> mData;
    VarInfo mInfo;
};
using VARP = std::shared_ptr<Variable>;
}}

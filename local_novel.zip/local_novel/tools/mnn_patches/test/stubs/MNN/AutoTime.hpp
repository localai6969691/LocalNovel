#pragma once
#include <cstdint>
#include <chrono>
namespace MNN {
class Timer {
public:
    Timer() : mStart(std::chrono::steady_clock::now()) {}
    int64_t durationInUs() { return std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now() - mStart).count(); }
private:
    std::chrono::steady_clock::time_point mStart;
};
}

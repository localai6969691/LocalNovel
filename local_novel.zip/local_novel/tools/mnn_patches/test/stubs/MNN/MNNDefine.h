// Stub tối thiểu CHỈ cho bộ thử: thay MNN/MNNDefine.h thật.
#pragma once
#include <cstdio>
#include <cassert>
#define MNN_PUBLIC
#define MNN_ERROR(...) do { std::fprintf(stderr, __VA_ARGS__); } while (0)
#define MNN_PRINT(...) do { std::fprintf(stdout, __VA_ARGS__); } while (0)
#define MNN_ASSERT(x) assert(x)

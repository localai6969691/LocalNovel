// Stub CHỈ cho bộ thử: thay ujson.hpp thật của MNN (vốn cần rapidjson/nlohmann không có trong môi trường thử).
// Chỉ hiện thực phần API mà llmconfig.hpp dùng: parse, value(key, mặc định), contains, operator[], merge, begin/end (cho logit_bias).
// Các hành vi liên quan sampler (mặc định, kiểu dữ liệu) bám theo cách llmconfig.hpp gọi; phần tách JSON phức tạp không được kiểm ở đây.
#pragma once
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cctype>
namespace ujson {
class json {
public:
    enum Type { Null, Bool, Num, Str, Arr, Obj };
    json() = default;
    static json parse(const std::string& s) { size_t i = 0; json j = parseValue(s, i); return j; }
    bool contains(const std::string& k) const { return type_ == Obj && obj_.count(k) > 0; }
    json operator[](const std::string& k) const { auto it = obj_.find(k); return it == obj_.end() ? json() : it->second; }
    void merge(const json& o) { if (o.type_ == Obj) { type_ = Obj; for (auto& kv : o.obj_) obj_[kv.first] = kv.second; } }
    // value() — kiểu T suy từ giá trị mặc định
    std::string value(const std::string& k, const char* def) const { auto it = obj_.find(k); return (it != obj_.end() && it->second.type_ == Str) ? it->second.s_ : std::string(def); }
    std::string value(const std::string& k, const std::string& def) const { auto it = obj_.find(k); return (it != obj_.end() && it->second.type_ == Str) ? it->second.s_ : def; }
    float value(const std::string& k, float def) const { auto it = obj_.find(k); return (it != obj_.end() && it->second.type_ == Num) ? (float)it->second.n_ : def; }
    double value(const std::string& k, double def) const { auto it = obj_.find(k); return (it != obj_.end() && it->second.type_ == Num) ? it->second.n_ : def; }
    int value(const std::string& k, int def) const { auto it = obj_.find(k); return (it != obj_.end() && it->second.type_ == Num) ? (int)it->second.n_ : def; }
    bool value(const std::string& k, bool def) const { auto it = obj_.find(k); return (it != obj_.end() && it->second.type_ == Bool) ? it->second.b_ : def; }
    std::vector<int> value(const std::string& k, const std::vector<int>& def) const {
        auto it = obj_.find(k); if (it == obj_.end() || it->second.type_ != Arr) return def;
        std::vector<int> r; for (auto& e : it->second.arr_) r.push_back((int)e.n_); return r; }
    std::vector<std::string> value(const std::string& k, const std::vector<std::string>& def) const {
        auto it = obj_.find(k); if (it == obj_.end() || it->second.type_ != Arr) return def;
        std::vector<std::string> r; for (auto& e : it->second.arr_) r.push_back(e.s_); return r; }
    int64_t value(const std::string& k, int64_t def) const { auto it = obj_.find(k); return (it != obj_.end() && it->second.type_ == Num) ? (int64_t)it->second.n_ : def; }
    json at(const std::string& k) const { auto it = obj_.find(k); if (it == obj_.end()) throw std::out_of_range(k); return it->second; }
    bool is_array() const { return type_ == Arr; }
    size_t size() const { return type_ == Arr ? arr_.size() : obj_.size(); }
    std::vector<int64_t> value(const std::string& k, const std::vector<int64_t>& def) const {
        auto it = obj_.find(k); if (it == obj_.end() || it->second.type_ != Arr) return def;
        std::vector<int64_t> r; for (auto& e : it->second.arr_) r.push_back((int64_t)e.n_); return r; }
    // duyệt đối tượng (cho logit_bias)
    struct iterator {
        std::map<std::string, json>::const_iterator it;
        iterator& operator++() { ++it; return *this; }
        bool operator!=(const iterator& o) const { return it != o.it; }
        std::string key() const { return it->first; }
        const json& value() const { return it->second; }
    };
    iterator find(const std::string& k) const { return {obj_.find(k)}; }
    iterator begin() const { return {obj_.begin()}; }
    iterator end() const { return {obj_.end()}; }
    template <typename T> T get() const { return (T)n_; }
private:
    Type type_ = Null; bool b_ = false; double n_ = 0; std::string s_; std::vector<json> arr_; std::map<std::string, json> obj_;
    static void ws(const std::string& s, size_t& i) { while (i < s.size() && std::isspace((unsigned char)s[i])) ++i; }
    static json parseValue(const std::string& s, size_t& i) {
        ws(s, i); json j;
        if (i >= s.size()) return j;
        char c = s[i];
        if (c == '{') { j.type_ = Obj; ++i; ws(s, i); if (s[i] == '}') { ++i; return j; }
            while (true) { ws(s, i); std::string k = parseString(s, i); ws(s, i); ++i; /* : */ j.obj_[k] = parseValue(s, i); ws(s, i); if (s[i] == ',') { ++i; continue; } ++i; break; }
            return j; }
        if (c == '[') { j.type_ = Arr; ++i; ws(s, i); if (s[i] == ']') { ++i; return j; }
            while (true) { j.arr_.push_back(parseValue(s, i)); ws(s, i); if (s[i] == ',') { ++i; continue; } ++i; break; }
            return j; }
        if (c == '"') { j.type_ = Str; j.s_ = parseString(s, i); return j; }
        if (s.compare(i, 4, "true") == 0) { j.type_ = Bool; j.b_ = true; i += 4; return j; }
        if (s.compare(i, 5, "false") == 0) { j.type_ = Bool; j.b_ = false; i += 5; return j; }
        if (s.compare(i, 4, "null") == 0) { i += 4; return j; }
        char* end = nullptr; j.n_ = std::strtod(s.c_str() + i, &end); j.type_ = Num; i = end - s.c_str(); return j;
    }
    static std::string parseString(const std::string& s, size_t& i) { std::string r; ++i; while (i < s.size() && s[i] != '"') { if (s[i] == '\\') ++i; r += s[i++]; } ++i; return r; }
};
}

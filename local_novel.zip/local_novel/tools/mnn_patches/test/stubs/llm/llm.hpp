// Stub CHỈ cho bộ thử: chỉ LlmContext (chép đúng các trường của llm.hpp thật) — Sampler không cần gì hơn từ llm.hpp.
#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include <ostream>
namespace MNN { namespace Transformer {
enum class LlmStatus { NOT_LOADED, LOADED };
struct LlmContext {
    int prompt_len = 0; int gen_seq_len = 0; int all_seq_len = 0;
    std::ostream* os = nullptr; std::string end_with;
    int64_t load_us = 0, vision_us = 0, audio_us = 0, prefill_us = 0, decode_us = 0, sample_us = 0, ttfa_us = 0;
    float pixels_mp = 0; float audio_input_s = 0;
    int current_token = 0;
    std::vector<int> history_tokens; std::vector<int> output_tokens; std::string generate_str;
    LlmStatus status = LlmStatus::NOT_LOADED; std::string log_buffer;
};
}}

#!/bin/sh
# Dùng: run_test.sh <thư mục engine ĐÃ VÁ (có src/sampler.cpp, src/sampler.hpp, src/llmconfig.hpp)>
# Biên dịch CHÍNH sampler.cpp/hpp + llmconfig.hpp THẬT của MNN (đã vá) với stub cho MNN expr/AutoTime/llm.hpp/ujson, rồi chạy bộ thử.
set -e
ENGINE="${1:?can thu muc engine da va}"
HERE="$(cd "$(dirname "$0")" && pwd)"
B=/tmp/mnn_patch_build
rm -rf "$B" && mkdir -p "$B"
cp "$ENGINE/src/sampler.cpp" "$ENGINE/src/sampler.hpp" "$ENGINE/src/llmconfig.hpp" "$B/"   # KHÔNG chép ujson.hpp thật (cần rapidjson)
g++ -std=c++17 -O2 -Wall -Wno-unused-function -I "$HERE/stubs" -I "$B" \
    "$HERE/sampler_patch_test.cpp" "$B/sampler.cpp" -o "$B/sampler_patch_test"
"$B/sampler_patch_test"

// Bộ thử cho bản vá bộ lấy mẫu MNN (MỤC DG): biên dịch CHÍNH sampler.cpp/sampler.hpp/llmconfig.hpp/ujson.hpp của MNN (đã vá) với stub cho phần MNN không liên quan.
#include "sampler.hpp"
#include "llmconfig.hpp"
#include <chrono>
#include <cstdio>
#include <map>
using namespace MNN::Transformer;
using MNN::Express::VARP;
using MNN::Express::Variable;

static int g_fail = 0;
#define CHECK(cond, msg) do { if (!(cond)) { std::printf("FAIL: %s (dong %d)\n", msg, __LINE__); ++g_fail; } else { std::printf("ok  : %s\n", msg); } } while (0)

static std::shared_ptr<LlmConfig> makeConfig(const std::string& json) {
    auto cfg = std::make_shared<LlmConfig>();
    cfg->config_.merge(ujson::json::parse(json));
    return cfg;
}
static VARP logitsOf(const std::vector<float>& v) { return std::make_shared<Variable>(v); }

// Tần suất token được chọn sau n lần lấy mẫu
static std::map<int, int> histogram(Sampler& s, const std::vector<float>& lg, int n) {
    std::map<int, int> h;
    for (int i = 0; i < n; ++i) h[s.sample(logitsOf(lg))]++;
    return h;
}

int main() {
    const int N = 4000;
    // ---- T1: tái hiện phát hiện: set_config SAU khi dựng sampler KHÔNG đổi hành vi; dựng lại thì có hiệu lực
    {
        auto ctx = std::make_shared<LlmContext>();
        ctx->history_tokens = {2, 2, 2, 2};                       // token 2 đã xuất hiện nhiều lần
        auto cfg = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["penalty","topK","temperature"],"temperature":1.0,"top_k":-1,"repetition_penalty":1.0})");
        std::unique_ptr<Sampler> s(Sampler::createSampler(ctx, cfg));
        std::vector<float> lg = {0, 0, 2.0f, 0};                  // token 2 nổi trội
        double p0 = histogram(*s, lg, N)[2] / (double)N;
        cfg->config_.merge(ujson::json::parse(R"({"repetition_penalty":8.0})"));  // giống Llm::set_config() lúc generate
        double p1 = histogram(*s, lg, N)[2] / (double)N;
        std::unique_ptr<Sampler> s2(Sampler::createSampler(ctx, cfg));            // giống bản vá live_sampler
        double p2 = histogram(*s2, lg, N)[2] / (double)N;
        std::printf("      P(token lap) ban dau=%.3f | sau set_config KHONG dung lai=%.3f | sau dung lai sampler=%.3f\n", p0, p1, p2);
        CHECK(std::fabs(p0 - p1) < 0.05, "ma MNN that: doi repetition_penalty SAU khi dung sampler KHONG co tac dung");
        CHECK(p2 < p0 * 0.5, "dung lai sampler (live_sampler) lam repetition_penalty co hieu luc");
    }
    // ---- T2: mặc định không đổi: dry_multiplier/xtc_probability = 0 thì có "dry","xtc" trong danh sách cũng không đổi phân phối
    {
        auto ctx = std::make_shared<LlmContext>();
        ctx->history_tokens = {1, 2, 3, 4, 1, 2, 3};
        std::vector<float> lg = {0, 0, 0, 0, 3.0f, 0};
        auto base = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["penalty","topK","temperature"],"temperature":1.0,"top_k":-1})");
        auto withNew = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["penalty","dry","topK","xtc","temperature"],"temperature":1.0,"top_k":-1})");
        std::unique_ptr<Sampler> a(Sampler::createSampler(ctx, base)), b(Sampler::createSampler(ctx, withNew));
        double pa = histogram(*a, lg, N)[4] / (double)N, pb = histogram(*b, lg, N)[4] / (double)N;
        std::printf("      P(token 4) khong co dry/xtc=%.3f | co dry/xtc nhung tat=%.3f\n", pa, pb);
        CHECK(std::fabs(pa - pb) < 0.04, "mac dinh TAT: them dry/xtc vao danh sach khong doi phan phoi");
    }
    // ---- T3: DRY có tác dụng và đúng ngưỡng allowed_length
    {
        auto ctx = std::make_shared<LlmContext>();
        ctx->history_tokens = {1, 2, 3, 4, 1, 2, 3};              // đuôi "1 2 3" khớp độ dài 3, kế tiếp cũ là 4
        std::vector<float> lg = {0, 0, 0, 0, 3.0f, 0};
        auto off = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["dry","temperature"],"temperature":1.0})");
        auto on2 = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["dry","temperature"],"temperature":1.0,"dry_multiplier":5.0,"dry_allowed_length":2})");
        auto on8 = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["dry","temperature"],"temperature":1.0,"dry_multiplier":5.0,"dry_allowed_length":8})");
        std::unique_ptr<Sampler> sOff(Sampler::createSampler(ctx, off)), s2(Sampler::createSampler(ctx, on2)), s8(Sampler::createSampler(ctx, on8));
        double pOff = histogram(*sOff, lg, N)[4] / (double)N, p2 = histogram(*s2, lg, N)[4] / (double)N, p8 = histogram(*s8, lg, N)[4] / (double)N;
        std::printf("      P(lap chuoi): tat=%.3f | DRY allowed=2 -> %.3f | DRY allowed=8 -> %.3f\n", pOff, p2, p8);
        CHECK(p2 < 0.01, "DRY allowed_length=2: khop 3 token bi phat manh");
        CHECK(std::fabs(p8 - pOff) < 0.04, "DRY allowed_length=8: khop ngan (3<8) KHONG bi phat — bao ve tu nhieu token cua tieng Viet");
    }
    // ---- T4: DRY chạy đúng dù đứng sau topK trong danh sách (tự dời lên trước) và cùng penalty
    {
        auto ctx = std::make_shared<LlmContext>();
        ctx->history_tokens = {1, 2, 3, 4, 1, 2, 3};
        std::vector<float> lg = {0, 0, 0, 0, 3.0f, 2.5f};
        auto cfg = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["topK","dry","penalty","temperature"],"temperature":1.0,"top_k":3,"dry_multiplier":5.0,"dry_allowed_length":2})");
        std::unique_ptr<Sampler> s(Sampler::createSampler(ctx, cfg));
        auto h = histogram(*s, lg, N);
        std::printf("      topK=3 + DRY: token4=%d token5=%d\n", h[4], h[5]);
        CHECK(h[4] < N * 0.02 && h[5] > N * 0.5, "DRY duoc doi len truoc topK: token lap (4) bi phat, token khac (5) tro nen nhieu nhat");
    }
    // ---- T5: XTC
    {
        auto ctx = std::make_shared<LlmContext>();
        std::vector<float> lg = {std::log(0.5f), std::log(0.3f), std::log(0.15f), std::log(0.05f)};
        auto cfg = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["xtc","temperature"],"temperature":1.0,"xtc_probability":1.0,"xtc_threshold":0.1})");
        std::unique_ptr<Sampler> s(Sampler::createSampler(ctx, cfg));
        auto h = histogram(*s, lg, N);
        std::printf("      XTC (p=1, thr=0.1): token0=%d token1=%d token2=%d token3=%d\n", h[0], h[1], h[2], h[3]);
        CHECK(h[0] == 0 && h[1] == 0 && h[2] > 0 && h[3] > 0, "XTC: loai token 0 (0.5) va 1 (0.3), giu token it kha nang nhat trong nhom (2) va duoi (3)");
        auto cfg0 = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["xtc","temperature"],"temperature":1.0})");
        std::unique_ptr<Sampler> s0(Sampler::createSampler(ctx, cfg0));
        auto h0 = histogram(*s0, lg, N);
        CHECK(h0[0] > N * 0.4, "XTC mac dinh tat: token 0 van duoc chon ~50%");
    }
    // ---- T6: min_p của MNN là NGƯỠNG TUYỆT ĐỐI (khác llama.cpp: tương đối so với token cao nhất)
    {
        auto ctx = std::make_shared<LlmContext>();
        std::vector<float> flat(25, 0.0f);                          // 25 token xác suất 0.04 mỗi cái < 0.05
        auto cfg = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["min_p","temperature"],"temperature":1.0,"min_p":0.05})");
        std::unique_ptr<Sampler> s(Sampler::createSampler(ctx, cfg));
        auto h = histogram(*s, flat, 2000);
        std::printf("      min_p=0.05 tren phan phoi PHANG 25 token: so token khac nhau duoc chon = %zu (llama.cpp tuong doi se giu ca 25)\n", h.size());
        CHECK(h.size() == 1, "min_p cua MNN la nguong TUYET DOI: phan phoi phang bi cat con 1 token (gan nhu tham lam)");
    }
    // ---- T7: tên không biết bị bỏ qua (an toàn nếu MNN chưa vá)
    {
        auto ctx = std::make_shared<LlmContext>();
        auto cfg = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["khong_ton_tai","topK","temperature"],"temperature":1.0,"top_k":2})");
        std::unique_ptr<Sampler> s(Sampler::createSampler(ctx, cfg));
        std::vector<float> lg = {3.0f, 2.0f, 1.0f, 0.0f};
        auto h = histogram(*s, lg, 1000);
        CHECK(h[2] == 0 && h[3] == 0, "ten sampler la bi bo qua, topK van chay");
    }
    // ---- T8: chi phí DRY trên 4000 token lịch sử + vocab 32000
    {
        auto ctx = std::make_shared<LlmContext>();
        std::mt19937 rng(5);
        ctx->history_tokens.resize(4000);
        for (auto& x : ctx->history_tokens) x = (int)(rng() % 5000);
        std::vector<float> lg(32000, 0.0f);
        auto cfg = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["dry","topK","temperature"],"temperature":1.0,"top_k":40,"dry_multiplier":0.8,"dry_allowed_length":2})");
        std::unique_ptr<Sampler> s(Sampler::createSampler(ctx, cfg));
        auto cfgNoDry = makeConfig(R"({"sampler_type":"mixed","mixed_samplers":["topK","temperature"],"temperature":1.0,"top_k":40})");
        std::unique_ptr<Sampler> sn(Sampler::createSampler(ctx, cfgNoDry));
        auto t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < 100; ++i) s->sample(logitsOf(lg));
        double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / 100;
        t0 = std::chrono::steady_clock::now();
        for (int i = 0; i < 100; ++i) sn->sample(logitsOf(lg));
        double msBase = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count() / 100;
        std::printf("      thoi gian lay mau/token (4000 lich su, vocab 32000, may build): khong DRY=%.3f ms | co DRY=%.3f ms\n", msBase, ms);
        CHECK(ms - msBase < 5.0, "DRY them < 5 ms/token (giai ma that ~250 ms/token tren dien thoai)");
    }
    std::printf(g_fail == 0 ? "\nTAT CA KIEM THU DAT\n" : "\nCO %d KIEM THU THAT BAI\n", g_fail);
    return g_fail == 0 ? 0 : 1;
}

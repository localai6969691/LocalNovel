# LocalNovel — Project Architecture & Implementation Spec

Tài liệu này tổng hợp toàn bộ kiến trúc, công nghệ, lỗi đã gặp/đã tránh, và
backlog của dự án **LocalNovel** — app Flutter hỗ trợ viết tiểu thuyết dài kỳ
(1000+ chương) bằng AI, chạy trên Android, ưu tiên AI local tận dụng GPU/NPU.
Dùng tài liệu này làm ngữ cảnh đầu vào cho phiên làm việc mới.

---

## 0. QUY TẮC BẮT BUỘC — đọc trước khi sửa bất kỳ lỗi nào ở đây

**Lý do mục này tồn tại (nói thẳng, không giấu):** mục AJ (2026-09-12) ghi
lại 1 lỗi thật đã xảy ra — đọc đúng đoạn mục Z nói rõ "còn 1 bộ dò lặp
THỨ HAI ở tầng Dart", TRÍCH DẪN nguyên văn đoạn đó, nhưng chỉ sửa đúng bộ
dò native rồi dừng lại, để người dùng phải tốn thêm 1 vòng build/test mới
lộ ra phần còn thiếu. Tài liệu này vô dụng nếu bị đọc lướt để tìm 1 đoạn
khớp với giả thuyết đang có rồi dừng lại — quy tắc dưới đây tồn tại để
việc đó không lặp lại.

1. **Đọc HẾT mục liên quan, không dừng ở đoạn đầu tiên khớp giả thuyết.**
   Nếu 1 mục nhắc tới "còn N chỗ khác"/"tương tự ở"/"xem thêm" — bắt buộc
   đi tìm và xử lý ĐỦ N chỗ đó trước khi coi là xong, không chỉ chỗ dễ
   thấy nhất qua log hiện tại.
2. **Đọc phần "Giới hạn thật"/"Chưa xác nhận" của MỌI mục liên quan trước
   khi bắt tay sửa** — đây là nơi các rủi ro/việc-chưa-làm được ghi lại
   có chủ đích, không phải phần phụ có thể bỏ qua. Mục AI từng bị chính
   mục Z cảnh báo trước ("Giới hạn thật") về đúng rủi ro sau này thành
   sự thật — nếu đọc kỹ phần đó ngay từ đầu, không cần 5 vòng build mới
   phát hiện ra.
3. **Trước khi coi 1 bản vá là "xong"**: chủ động `grep` tên hàm/logic
   liên quan trên TOÀN BỘ codebase (không chỉ file đang sửa) để xác nhận
   không còn bản sao/đường gọi nào khác chưa xử lý — như cách mục AJ đã
   làm SAU KHI bị nhắc, đáng lẽ phải làm TỪ ĐẦU ở mục AI.
4. **Ghi lại đúng những gì đã làm VÀ chưa làm** ở mục mới, theo đúng
   khuôn mẫu đã dùng xuyên suốt tài liệu này (Vì sao tồn tại / Nguyên
   nhân thật / Bản vá / Giới hạn thật — không giấu) — không tô hồng, không
   báo "đã xong" khi chỉ mới xử lý 1 phần.
5. **Build tag ở `main.dart`** (`MA_NGUON_BUILD=muc<X>_<ngày>`) phải liệt
   kê ĐỦ mọi mục đã gộp vào bản build đó — đây là cách DUY NHẤT để đối
   chiếu qua debug log xem APK đang chạy có đúng là bản mới nhất hay
   không, không suy đoán qua hành vi.

---

## 1. Tổng quan dự án & Cấu hình phần cứng mục tiêu

- **Nền tảng**: Android, viết bằng Flutter/Dart
- **Máy test chính**: Asus Zenfone 8 — chip **Snapdragon 888** (tên mã Qualcomm nội bộ **SM8350**), Hexagon 780 NPU (thế hệ **V68**), Adreno 660 GPU, **16GB RAM**, chạy **Android 13**
- **Build**: hoàn toàn qua **GitHub Actions** (không có máy tính/Android Studio) — người dùng chỉ thao tác qua trình duyệt điện thoại: upload file zip mã nguồn lên GitHub, dán nội dung `build.yml`, bấm "Run workflow", tải APK về từ mục Artifacts, cài thủ công
- **Yêu cầu số 1, không thương lượng của người dùng (ĐÃ CẬP NHẬT — xem mục 5.53)**: model AI local bắt buộc phải chạy được **tối thiểu GPU**. Ban đầu ưu tiên tuyệt đối là NPU, nhưng đã điều tra và xác nhận (mục 5.53): công cụ CHÍNH THỨC trưởng thành nhất của Qualcomm cho LLM-trên-NPU (Genie/AI Hub Models) yêu cầu tối thiểu **Hexagon v73** — Snapdragon 888/Hexagon 780 của máy test là **v68**, thấp hơn 2 thế hệ. Quyết định đã thống nhất với người dùng: **chấp nhận GPU (OpenCL) làm đường chính, tối ưu hết mức**; QNN/NPU chuyển thành lựa chọn thử nghiệm CÓ THỂ BẬT THỦ CÔNG (`backendPreference=3`), không còn nằm trên đường mặc định. CPU-only vẫn bị coi là "vứt".
- **Repo cấu trúc**: 1 file zip (`local_novel.zip`) chứa toàn bộ `lib/` (Dart) + `android_native/` (Kotlin/C++ sẽ được ghép vào project Android lúc build) + `pubspec.yaml`; `build.yml` là workflow GitHub Actions dán trực tiếp trên web GitHub (không nằm trong zip).

---

## 2. Kiến trúc phần mềm

### 2.1. Interface AI chung — `AIProvider` (không phải `IInferenceProvider`)

File: `lib/services/ai_provider.dart`. Interface trừu tượng, 3 implementation:

- `LocalLlamaProvider` (`lib/services/providers/local_provider.dart`) — gọi vào tầng native MNN-LLM + QNN qua **Platform Channel** (KHÔNG dùng `dart:ffi`)
- `AnthropicProvider` (`lib/services/providers/anthropic_provider.dart`)
- `OpenAICompatibleProvider` (`lib/services/providers/openai_compatible_provider.dart`) — dùng cho OpenAI hoặc bất kỳ endpoint tương thích chuẩn OpenAI

Interface có: `generate()` (non-streaming), `generateStream()` (streaming), `isReady()`. Tham số sinh văn bản: `temperature`, `maxTokens`, `topP`, `topK`, `repetitionPenalty` — đều có default, người dùng chỉnh trong màn "Tham số sinh văn bản".

Model/provider **không hardcode** — người dùng tự thêm nhiều `LocalModelEntry` (nhiều model local) và nhiều `ApiProviderEntry` (nhiều provider API), chọn 1 cái đang active. Đổi model/provider giữa chừng **không mất bối cảnh** vì Story Bible/lịch sử chat lưu SQLite, tách biệt hoàn toàn khỏi provider đang dùng.

### 2.2. Kiến trúc native AI — MNN-LLM + QNN qua Platform Channel

**Lịch sử quan trọng cần biết**: dự án đã đổi engine AI local **4 lần** trước khi tới MNN:
`fllama` → `lib_llama_cpp` → `flutter_llama` → `llama_cpp_dart` (netdur) → **MNN-LLM (Alibaba) + QNN (Qualcomm)** (hiện tại).

Lý do đổi lần cuối: `llama_cpp_dart` do 1 cá nhân duy trì, API đổi liên tục, **chưa từng xác nhận chạy được GPU/NPU thật trên Android**. MNN-LLM được chọn vì:
- Có sản phẩm thật đã public ("MNN Chat" trên Google Play) chứng minh QNN NPU chạy thật trên Snapdragon 8-series
- Benchmark thật đo trên chính Zenfone 8 của người dùng (app MNN Chat gốc): **Prefill 129.8 t/s, Decode 16.7 t/s trên backend OpenCL (GPU)** — nhanh hơn ~15-16 lần so với CPU thuần (~1 tok/s) của các engine cũ
- Snapdragon 888/SM8350 nằm trong danh sách chip Qualcomm/Microsoft chính thức test QNN

**Kiến trúc native** (`android_native/`):
```
android_native/app/src/main/
  cpp/
    mnn_bridge.cpp       — JNI, gọi API công khai MNN (llm.hpp, class Llm)
    CMakeLists.txt       — biên dịch mnn_bridge.cpp, link với libMNN.so build ở bước trước
  kotlin/com/localnovel/
    MainActivity.kt      — đăng ký MethodChannel + EventChannel, xin quyền POST_NOTIFICATIONS
    mnnbridge/
      MnnNative.kt       — khai báo external fun JNI
      MnnBridge.kt       — xử lý MethodCallHandler + EventChannel.StreamHandler, điều phối GenerationService
      GenerationService.kt — Foreground Service + WakeLock
```

**2 SLOT MODEL ĐỘC LẬP** (multi-context thật, không giả): `slot 0` = model chính (viết truyện), `slot 1` = model dịch thuật trung gian. Mỗi slot có `Llm*` riêng trong `mnn_bridge.cpp` (mảng `g_slots[2]`), có thể cùng tồn tại trong RAM hoặc xả riêng từng cái — quyết định ở tầng Dart (`TranslationService`), không hardcode ở tầng native.

Cầu nối gọi native theo cơ chế **ĐÃ ĐỔI (mục 5.53) — mặc định đi thẳng GPU đã tối ưu, QNN chuyển thành thử nghiệm CÓ THỂ BẬT THỦ CÔNG**:
```
backendPreference=0/1 (mặc định) → OpenCL (GPU, đã tối ưu precision/memory/thread_num) → lỗi thì mới rơi xuống CPU
backendPreference=2 → ép CPU
backendPreference=3 (thử nghiệm, người dùng tự bật) → thử QNN trong tiến trình con cách ly + timeout 90s → lỗi/treo thì rơi xuống OpenCL → CPU
```
Lý do đổi: Hexagon v68 (Snapdragon 888) dưới mức Qualcomm chính thức hỗ trợ LLM-trên-NPU (yêu cầu v73+, xem mục 5.53) — thử QNN mỗi lần mở model chỉ tốn thời gian chờ vô ích, không có cơ hội thành công thật trên máy này.

Dart gọi qua `MethodChannel('com.localnovel/mnn_method')` (lệnh 1 lần: loadModel/generate/unload/isLoaded/cancelGenerate) và `EventChannel('com.localnovel/mnn_stream')` (luồng token trả về, lọc theo `slot`).

### 2.3. Foreground Service — chạy nền không bị Android kill

Lý do: luồng dịch tuần tự (dịch → sinh văn → dịch ngược) có thể mất vài phút tới hàng giờ (chạy overnight), Android sẽ kill tiến trình nếu app xuống nền/tắt màn hình mà không có Foreground Service.

`GenerationService.kt`: Foreground Service + `PARTIAL_WAKE_LOCK` (trần an toàn 8 tiếng, đủ cho tác vụ qua đêm, tự nhả nếu quên gọi stop để tránh hao pin vô hạn nếu có lỗi). `foregroundServiceType="dataSync"` (suy luận hợp lý nhất, Android không có type "AI inference" riêng — nếu bị từ chối lúc chạy thì đổi sang `specialUse`, **CHƯA XÁC NHẬN 100%**). Bật/tắt tự động quanh mỗi lệnh `loadModel`/`generate` trong `MnnBridge.kt`.

**TỒN ĐỌNG CHƯA XONG**: mỗi lệnh generate hiện tự start/stop service riêng — với luồng dịch tuần tự nhiều bước (dịch → sinh → dịch ngược), nên gộp thành **1 lần start ở đầu pipeline, update nội dung thông báo giữa các bước qua `updateStage()`, chỉ stop ở cuối** — tránh khoảng hở ngắn giữa các bước. Chưa sửa.

### 2.4. Đa truyện (multi-novel)

Mọi bảng nội dung (`characters`, `world_rules`, `timeline_events`, `chapters`, `style_profiles`, `chat_sessions`, `chat_messages`, `imported_documents`) đều có cột `novel_id`. `local_models`/`api_providers` KHÔNG gắn theo novel (tài nguyên máy dùng chung). Máy nâng cấp từ bản cũ (1 truyện) tự động migrate dữ liệu vào 1 "Truyện của tôi" mặc định — không mất dữ liệu (`database_service.dart`, hàm `_migrateToMultiNovel`).

`main.dart`: `NovelGateScreen` (tự vào thẳng truyện active nếu đã chọn trước đó) → `NovelListScreen` (tạo/chọn/xóa truyện) → `RootScreen` (5 tab: Chương/Bách khoa/Trợ lý AI/Tài liệu/Cài đặt, dùng `IndexedStack` giữ trạng thái khi chuyển tab).

### 2.5. RAG (Retrieval-Augmented Generation) — 1 tầng, chưa phân tầng

`RagService` kết hợp 3 cơ chế: luật cứng (luôn nạp), khớp từ khóa (Character/WorldRule.keywords), truy xuất embedding ngữ nghĩa (cosine similarity, `EmbeddingService` — ưu tiên embedding thật nếu có, dự phòng vector "hashing" thuần Dart). Toàn bộ giới hạn trong `novelId`, có ngân sách ký tự (`contextBudgetChars`) theo hồ sơ thiết bị.

**GAP THẬT CHƯA LÀM**: chỉ có 1 tầng tóm tắt (mỗi chương → 3-5 câu, `summary_service.dart`). **CHƯA CÓ** tóm tắt phân tầng đệ quy (tier 2: nén cụm ~10 chương thành "tóm tắt cung"; tier 3: nén toàn bộ thành "bản đồ kịch bản" tổng thể) — cần thiết thật sự cho truyện triệu chữ, đã xác nhận là gap hợp lệ, chưa code.

---

## 3. Thư viện & Công nghệ đã chọn (Tech Stack)

| Lớp | Công nghệ | Ghi chú |
|---|---|---|
| UI/Framework | Flutter/Dart | An toàn dài hạn, Google chính thức |
| Lưu trữ | SQLite qua `sqflite` | Ổn định, có FTS4 cho tìm kiếm toàn văn chương |
| Gọi API cloud | HTTP thuần (không SDK riêng) | An toàn tuyệt đối, không phụ thuộc hãng nào ngừng hỗ trợ |
| AI local (engine) | **MNN-LLM** (Alibaba), build từ mã nguồn qua NDK/CMake trong CI, cờ `-DMNN_BUILD_LLM=true -DMNN_OPENCL=true -DMNN_QNN=true -DMNN_ARM82=true` | Core do Alibaba duy trì, không phải cá nhân |
| AI local (NPU) | **QNN SDK** (Qualcomm), bản "Community" tải công khai không cần đăng nhập: `https://softwarecenter.qualcomm.com/api/download/software/sdks/Qualcomm_AI_Runtime_Community/All/2.40.0.251030/v2.40.0.251030.zip` | Copy `include/QNN` + `lib` vào `MNN/source/backend/qnn/3rdParty/` trước khi build |
| Cầu nối Flutter↔Native | **Platform Channel** (MethodChannel/EventChannel) — KHÔNG dùng `dart:ffi` | Tránh lỗi dlopen .so đã ám cả dự án trước đây |
| Xuất file | Tự dựng EPUB/DOCX/TXT bằng `archive` package (không dùng thư viện xuất bản ngoài) | EPUB hiện đơn giản, chưa có bìa/mục lục thật |
| CI/CD | GitHub Actions, NDK mới nhất (tự dò bản mới nhất qua `sdkmanager --list`, KHÔNG ghim NDK 21 vì quá cũ) | Xem mục 5 — nhiều lỗi build đã xảy ra ở đây |

**Cân nhắc đã loại bỏ** (không dùng, đã so sánh kỹ trước khi quyết định MNN):
- ONNX Runtime GenAI + QNN EP: engine lõi rất chắc (Maven Central chính thức), nhưng gói GenAI cho Android "Java API pending" (chưa publish chính thức) — kém chín hơn MNN tại thời điểm quyết định.
- MediaPipe LLM Inference (Google), MNN gốc Tencent (nhầm lẫn — thực ra là NCNN của Tencent, chỉ mạnh thị giác máy tính, không có LLM binding Flutter): đều yêu cầu bỏ định dạng GGUF, không phải yêu cầu cứng của người dùng nhưng MNN vẫn thắng nhờ bằng chứng thật cụ thể hơn.

---

## 4. Logic các tính năng chính

### 4.1. Story Bible / Lorebook
`Character`, `WorldRule` (có `isHardRule`), `TimelineEvent` — mỗi entry có `keywords` kích hoạt kiểu lorebook NovelAI. Xem trước lorebook khi soạn chương (chip hiện nhân vật/luật đang được nạp).

### 4.2. Chương & xuất bản
CRUD chương, cảnh báo mâu thuẫn (`consistencyWarning`), tìm kiếm FTS toàn văn theo `novelId`. Xuất EPUB/DOCX/TXT (`export_service.dart`).

### 4.3. Chat đa phiên
Nhiều `ChatSession` mỗi truyện, lưu bền vững `ChatMessageRecord` (kèm `providerLabel` — biết tin nhắn nào do model nào trả lời). Xuất cuộc trò chuyện ra TXT/DOCX.

### 4.4. Tài liệu (dịch/tóm tắt cuốn chiếu)
`DocumentService` chia file `.txt`/`.md` thành chunk, xử lý tuần tự (dịch hoặc tóm tắt), ráp kết quả, xuất file. **Giai đoạn 2 (PDF/DOCX/ảnh) CHƯA làm** — chủ động hoãn để tránh rủi ro build.

### 4.5. Văn phong & đắp thịt outline
`StyleService` — mô tả văn phong bằng lời hoặc học từ mẫu văn CỦA CHÍNH người dùng (không lưu nguyên văn tác phẩm người khác, tránh vi phạm bản quyền). "Đắp thịt" outline sơ sài thành chương đầy đủ.

### 4.6. Tối ưu thiết bị
`DeviceProfileService` đọc `/proc/meminfo` + mã chipset thật, `BenchmarkService` đo tốc độ token/giây thực tế (có chặn số liệu vô lý — bài học từ lỗi cũ khi `fllama` từng trả kết quả giả). RAG budget tùy theo hồ sơ máy.

### 4.7. Tham số sinh văn bản
Màn `GenerationSettingsScreen`: `temperature`, `top_p`, `top_k`, `repetition_penalty`, `max_new_tokens` — lưu qua `SettingsService`, áp dụng lại mỗi lần gọi `generate()`/`generateStream()` qua JSON gửi xuống `set_config()` của MNN (tên khóa JSON xác nhận đúng theo tài liệu chính thức MNN: `temperature`, `top_p`, `top_k`, `repetition_penalty`, `max_new_tokens`).

**ĐÃ NỐI**: khung chat (`chat_screen.dart`) VÀ `chapter_editor_screen.dart` (Viết tiếp/Đắp thịt/In-line AI Rewrite đều đọc `SettingsService().loadGenerationConfig()`).

### 4.8. Dịch thuật trung gian
Vấn đề giải quyết: model viết truyện hay thường không train nhiều tiếng Việt, viết trực tiếp dễ ra câu ngô nghê/lặp từ vô nghĩa/ký tự lạ.

`TranslationService`: tùy chọn bật/tắt (mặc định TẮT). Khi bật: dịch câu hỏi/outline sang ngôn ngữ đích (mặc định tiếng Anh) bằng model dịch nhỏ ở **slot 1** → gọi model chính ở **slot 0** sinh văn bản → dịch kết quả về tiếng Việt bằng slot 1. **Luôn chạy tuần tự** (không song song), gộp cả 3 bước vào 1 phiên Foreground Service duy nhất (`beginPipeline`/`updateStage`/`endPipeline`). Quyết định giữ hay xả slot 1 giữa các bước: `SettingsService.loadTranslationKeepResidentMode()` — 'auto' (theo RAM máy, ngưỡng `ramKeepResidentThresholdMb = 6000`) / 'always' / 'never', cấu hình thủ công được ở màn "Tối ưu AI local".

**ĐÃ NỐI**: khung chat VÀ `chapter_editor_screen.dart`.

### 4.9. In-line AI Rewrite
Bôi đen đoạn văn trong `chapter_editor_screen.dart` (qua `TextField.contextMenuBuilder`, thêm mục vào menu bôi đen mặc định của Flutter) → menu lệnh nhanh: chữa lỗi chính tả, viết sinh động hơn, rút ngắn, đổi ngôi kể. Có bảo vệ nếu nội dung đổi trong lúc chờ AI (không ghi đè nhầm chỗ, fallback copy vào clipboard).

### 4.10. Version snapshot (undo AI viết đè) — MỚI
`ChapterVersion` (bảng `chapter_versions`) — chụp lại nội dung chương TRƯỚC mỗi lần "Viết tiếp"/"Đắp thịt"/"Viết lại bằng AI" có khả năng ghi đè. Tối đa `maxVersionsPerChapter = 20` bản mỗi chương, vượt quá tự xóa bản cũ nhất (tránh phình DB vô hạn qua hàng nghìn lần bấm AI). Màn `ChapterVersionsScreen` (mở qua menu "⋮" trong `chapter_editor_screen.dart`) xem/khôi phục — khôi phục cũng tự chụp lại trạng thái hiện tại trước, nên không bao giờ mất hoàn toàn dù khôi phục nhầm.

### 4.11. Tìm kiếm toàn văn UI — MỚI
Tầng DB (`chapters_fts`, FTS4) đã có sẵn từ trước qua `searchChapters()`, chỉ dùng ngầm cho RAG — trước đây KHÔNG có ô tìm kiếm cho người dùng tự tra cứu. `SearchScreen` (mở qua icon kính lúp trong `ChaptersScreen`) tìm ngay khi gõ (không debounce, FTS4 đủ nhanh), hiện đoạn trích quanh từ khóa khớp đầu tiên.

### 4.12. Glossary + chống lặp từ — MỚI
`GlossaryTerm` (bảng `glossary_terms`) — từ điển tra nhanh cho địa danh/thuật ngữ riêng của truyện, khác Story Bible ở chỗ KHÔNG tự động nạp vào prompt AI (không có `keywords` kích hoạt). Quản lý ở tab "Thuật ngữ" trong `StoryBibleScreen`.

`RepetitionAnalyzer` (`repetition_analyzer_service.dart`, thuần Dart không phụ thuộc Flutter) — thống kê từ/cụm bị lặp nhiều. Có xử lý riêng cho đặc thù tiếng Việt: đếm cả âm tiết đơn (unigram) LẪN cụm 2 âm tiết liền nhau (bigram), vì 1 "từ" tiếng Việt thường gồm nhiều âm tiết cách nhau bởi dấu cách — đếm âm tiết đơn riêng lẻ sẽ nhiễu do các âm tiết phổ biến (một, người...) lặp lại là bình thường. Có danh sách hư từ (`stopSyllables`) loại khỏi thống kê, và phát hiện riêng "lặp gần" (từ/cụm dồn vào rất ít đoạn văn — kiểu lặp gây khó chịu khi đọc nhất). Mở qua menu "⋮" → "Kiểm tra lặp từ" trong `chapter_editor_screen.dart`.

### 4.13. Story Bible nâng cao: phân loại thẻ + auto-mention — MỚI
`Character.category` (Nhân vật chính/phụ/Phản diện/Khác) và `WorldRule.category` (Luật lệ/Địa điểm/Vũ khí/Tổ chức/Vật phẩm/Khác) — trường phân loại RIÊNG, tách khỏi `role`/mô tả tự do, hiện dưới dạng chip trong danh sách. Nhân tiện sửa 1 bug có sẵn: `_addRule` trước đây LUÔN đặt `isHardRule: true` bất kể người dùng nhập gì ở ô từ khóa — giờ có `SwitchListTile` thật để chọn.

Auto-mention: gõ `@` trong nội dung chương → hiện hàng gợi ý tên nhân vật khớp (lọc theo phần đã gõ sau `@`), bấm để chèn. **Đơn giản hóa có chủ đích**: hàng gợi ý cố định ngay phía trên ô nội dung (không phải overlay bám theo đúng vị trí con trỏ) — tránh phải tính toán vị trí con trỏ bằng `TextPainter` (dễ sai lệch, không kiểm chứng được nếu không build/test thật nhiều vòng). Đánh đổi chấp nhận được: vẫn đúng chức năng, chỉ khác vị trí hiển thị.

### 4.14. EPUB bìa + mục lục thật — MỚI
Trước đây EPUB có mục lục qua `toc.ncx` (điều hướng bên trong app đọc sách) nhưng KHÔNG có ảnh bìa và không có trang mục lục hiện ngay trong nội dung sách. Giờ:
- Ảnh bìa tự sinh bằng `dart:ui` (`Canvas`/`ParagraphBuilder` vẽ gradient + tên truyện + tác giả) — không cần người dùng tự chuẩn bị ảnh (app cố tình không có `file_picker`, xem mục 5.2-tương-tự lý do lịch sử build).
- Thêm `nav.xhtml` (EPUB3 nav document, `properties="nav"`) — vừa là trang "Mục lục" THẬT nằm trong nội dung sách (trang đầu tiên sau bìa), vừa tương thích các reader hiện đại (Apple Books, KOReader...) ưu tiên `nav.xhtml` hơn `toc.ncx`. Giữ `toc.ncx` song song cho reader cũ — nâng `content.opf` lên `version="3.0"` nhưng vẫn khai `<spine toc="ncx">` để tương thích ngược.

### 4.15. Sao lưu & khôi phục toàn bộ dữ liệu — MỚI
`BackupService` xuất TOÀN BỘ dữ liệu (mọi truyện) thành JSON đóng gói trong `.zip`, chia sẻ qua `share_plus`. Khôi phục qua `FileBrowserScreen` (chọn file `.zip`/`.json`, tái dùng — không cần thêm `file_picker`).

**Quyết định thiết kế quan trọng**: xuất JSON (đi qua các hàm `query()` bình thường) thay vì copy thẳng file `.db` nhị phân — tránh phụ thuộc journal mode/WAL còn dở dang lúc copy, và khi khôi phục đi qua đúng các hàm `upsert*()` sẵn có (tự đồng bộ lại `chapters_fts`...) thay vì ghi đè thẳng file. **KHÔNG xuất API key** (nằm ở `flutter_secure_storage` riêng, tách biệt có chủ đích vì bảo mật) — người dùng cần nhập lại API key thủ công sau khi khôi phục trên máy mới, nhưng danh sách provider/model local (tên, base URL, model ID) vẫn khôi phục đầy đủ.

### 4.16. Quy trình viết tiểu thuyết: Dàn ý/Tuyến truyện/Mục tiêu/Quyển
**Phát hiện thiếu tài liệu (2026-09-06)**: comment trong `database_service.dart` (`_backupTables`) từ lâu đã ghi "5 bảng của tính năng 'quy trình viết tiểu thuyết' (mục 4.16/5.77 tài liệu kiến trúc)" — nhưng mục đó CHƯA TỪNG được viết, dù code đã tồn tại đầy đủ từ trước (comment nói dối chính nó, giống lỗi `recordWordSnapshot()` đã ghi ở mục N). Bổ sung ở đây để đồng bộ:

- **`PlotBeat`** (tab "Dàn ý" trong Story Bible): các nút thắt cốt truyện đã lên kế hoạch, không gắn cứng vào 1 chương cụ thể — dùng làm nguyên liệu khi AI viết chương (`plot_summary_prefer_outline`, xem mục 4.7).
- **`PlotThread`** (tab "Tuyến truyện"): theo dõi các mạch truyện đang mở/đã đóng xuyên suốt nhiều chương (vd "bí ẩn thân thế nhân vật X") — `chapters.thread_ids` liên kết chương nào thuộc tuyến nào.
- **`WritingGoal`** + `daily_word_log` (tab "Mục tiêu"): mục tiêu số từ/ngày hoặc theo hạn, `recordWordSnapshot()` (gọi trong `_save()` ở `chapter_editor_screen.dart`) ghi lại số từ luỹ kế mỗi lần lưu chương để tính streak/biểu đồ "14 ngày gần nhất".
- **`Volume`** (Quyển): nhóm chương thành các quyển/tập — dùng làm mốc phạm vi hiệu lực cho Nhân vật/Luật thế giới (`effectiveFromVolumeId`/`effectiveToVolumeId`, xem mục 4.17 và `_pickScope()` trong `story_bible_screen.dart`), không có tab riêng, quản lý qua màn danh sách chương.

---

### 4.17. Kiểm tra & khôi phục dữ liệu bị lỗi — MỚI (2026-09-05)
Ra đời sau sự cố mục T (xem mục 5): tính năng "Tạo lại tất cả ghi chú" từng có thể ghi đè đoạn văn trong chương bằng thông báo lỗi nội bộ (dạng `⚠️ [...]`, xem hằng số `kAiFailureMarker` ở `ai_provider.dart`) mà không ai nhận ra ngay. Thay vì bắt người dùng tự mở từng chương dò bằng mắt, `DataIntegrityService` (`data_integrity_service.dart`) tự quét toàn bộ chương của 1 truyện tìm dấu hiệu đó, tự tìm bản `ChapterVersion` gần nhất KHÔNG dính lỗi (tận dụng cơ chế snapshot đã có sẵn ở mục 4.10) làm gợi ý khôi phục. `DataIntegrityScreen` (mở qua icon 🩺 trên `ChaptersScreen`) hiện danh sách + nút "Khôi phục" 1 chạm — tự chụp lại bản hiện tại trước khi ghi đè, không mất gì dù bấm nhầm.

**Giới hạn cố tình chưa xử lý**: nếu chương chưa từng có snapshot sạch (vd bị lỗi ngay từ bản đầu tiên, hoặc snapshot sạch đã bị dọn do vượt `maxVersionsPerChapter=20`), công cụ chỉ báo "không tự khôi phục được", không đoán mò/tự viết lại — người dùng cần tự sửa tay đoạn đó.

---

## 5. Lỗi đã gặp & bài học kỹ thuật quan trọng (tránh lặp lại)

Đây là phần quan trọng nhất để phiên sau không đi lại đúng đường cũ:

1. **Không đoán API — luôn đọc log/tài liệu thật trước khi viết code.** Toàn bộ chuỗi đổi engine AI (fllama → lib_llama_cpp → flutter_llama → llama_cpp_dart) đều do đoán sai tên hàm/tham số của package, gây hàng chục vòng build-lỗi-sửa. Nguyên tắc rút ra: trước khi viết cầu nối vào 1 thư viện mới, phải tra cứu (web search/đọc header thật qua bước build in log) — không suy luận từ tên hàm nghe hợp lý.

2. **`libllama.so not found` (đã giải quyết bằng cách đổi kiến trúc)**: nguyên nhân gốc là gói `llama_cpp_dart` không đóng gói sẵn thư viện native, phải tự tải AAR — rất mong manh. Giải pháp triệt để: đổi hẳn sang MNN + biên dịch native trực tiếp trong CI, dùng Platform Channel thay FFI (loại bỏ hoàn toàn kiểu lỗi dlopen).

3. **NDK 21 quá cũ, không hỗ trợ SVE2/KleidiAI**: lỗi `clang++: error: the clang compiler does not support '-march=...+sve2'`. Nguyên nhân: MNN dùng tối ưu ARM mới (KleidiAI/SME2) nhưng README của MNN khuyến nghị NDK 21 đã lỗi thời so với code thật. **Sửa**: luôn tự dò NDK mới nhất qua `sdkmanager --list`, không ghim version cứng.

4. **`QnnInterface.h file not found`**: `-DMNN_QNN=true` cần header/lib thật của Qualcomm QNN SDK, MNN không mang theo sẵn (SDK độc quyền). **Sửa**: tải QNN SDK bản Community công khai, copy vào `MNN/source/backend/qnn/3rdParty/`.

5. **Đường dẫn tương đối bị lệch khi `working-directory` đổi giữa các step GitHub Actions**: đặt `QNN_SDK_ROOT` bằng đường dẫn tương đối ở 1 step, dùng lại ở step khác có `working-directory` khác → sai đường dẫn dù CMake không báo lỗi cú pháp. **Bài học**: mọi biến môi trường dùng xuyên step PHẢI là đường dẫn tuyệt đối.

6. **`find_library` chỉ tìm đúng path cố định, không tìm thấy `libMNN.so`**: MNN đặt file `.so` không đúng chỗ đoán trước. **Sửa**: dùng `file(GLOB_RECURSE ...)` quét toàn bộ thư mục install thay vì đoán 1-2 path cố định.

7. **APK "release" build ra không cài được ("gói có vẻ không hợp lệ")**: bản release không có signing key (mã nguồn công khai không kèm khóa ký riêng). **Sửa**: dùng `assembleDebug` cho mục đích test (tự động ký bằng debug keystore).

8. **Android 14+ bắt buộc khai báo `foregroundServiceType`** — dùng `dataSync` (suy luận hợp lý nhất, **chưa xác nhận 100%** là lựa chọn đúng, có thể cần đổi `specialUse` nếu bị từ chối lúc chạy thật).

9. **Danh sách chip được phép dùng QNN trong app "MNN Chat" của Alibaba (`sQnnLibMap`) là hardcode riêng của họ, KHÔNG phải giới hạn kỹ thuật thật của QNN** — quyết định của dự án: không copy theo whitelist đó, luôn thử QNN trực tiếp trên mọi máy, bắt lỗi rồi rơi xuống GPU/CPU.

10. **Chưa xác minh, nghi ngờ là bịa**: tên hàm `MNN::Interpreter::releaseCache` (được đề xuất từ 1 tài liệu ngoài) — tra không ra bằng chứng, CHƯA đưa vào code. Nếu phiên sau cần quản lý KV cache giữa các đoạn xử lý (tóm tắt phân tầng, dịch tuần tự nhiều đoạn), phải đọc lại `llm.hpp` thật (đã từng in ra log CI 1 lần, hỏi người dùng có còn giữ log đó không) trước khi thêm lời gọi hàm nào.

11. **Snapdragon 888 (Zenfone 8) là chip 2021, không nằm trong danh sách máy Alibaba tự test ổn định** (README MNN cũ ghi rõ chỉ test kỹ trên OnePlus 13/Xiaomi 14 Ultra — chip 2025) — rủi ro ổn định runtime tổng quát (không riêng QNN) chưa loại trừ hoàn toàn, cần theo dõi khi test thật.

12. **`AnthropicProvider`/`OpenAICompatibleProvider` thiếu tham số so với interface `AIProvider`**: lỗi build lần đầu thật (Build APK #30) — `generate()`/`generateStream()` của 2 provider cloud này thiếu `topP`/`topK`/`repetitionPenalty` (chỉ có ở bản khai báo interface và ở `LocalLlamaProvider`), Dart bắt lỗi ngay ở bước biên dịch (`kernel_snapshot_program failed`), không phải lỗi runtime. **Đã sửa**: thêm đủ 3 tham số vào cả 2 provider — Anthropic Messages API nhận thẳng `top_p`/`top_k`, OpenAI-compatible nhận `top_p` + xấp xỉ `repetitionPenalty` bằng `frequency_penalty` (map thô `repetitionPenalty - 1.0`), `top_k` gửi kèm cho các endpoint tương thích mở rộng (llama.cpp server, vLLM, Ollama) dù không phải chuẩn OpenAI chính thức. Bài học: khi thêm tham số mới vào 1 interface dùng chung nhiều implementation, phải rà lại TẤT CẢ implementation, không chỉ implementation đang cần dùng ngay lúc đó.

13. **Cảnh báo (chưa phải lỗi) — Kotlin Gradle Plugin (KGP) legacy ở `device_info_plus`/`share_plus`**: log build in cảnh báo các bản Flutter tương lai sẽ FAIL nếu plugin còn áp dụng KGP kiểu cũ thay vì "Built-in Kotlin". Build #30 vẫn qua được bước này (chỉ warning), nhưng cần theo dõi: nếu 1 phiên bản Flutter sau này thật sự chặn cứng, phải nâng version 2 package này trong `pubspec.yaml` lên bản đã hỗ trợ Built-in Kotlin (tra changelog thật trước khi đổi version, không đoán).

14. **`translation_settings_screen.dart` hứa hẹn 1 mục ở màn "Tối ưu AI local" nhưng chưa từng code**: text giới thiệu ghi "xem 'Tối ưu AI local' để biết máy có nên giữ cả 2 model trong RAM hay không", nhưng màn đó chưa từng có phần này (phát hiện qua ảnh chụp màn hình thật của người dùng). **Đã sửa**: thêm mục "Dịch thuật trung gian — giữ model trong RAM" vào `local_optimization_screen.dart` (hiện RAM máy phát hiện được, ngưỡng tự động, và `SegmentedButton` cho 3 chế độ Tự động/Luôn giữ/Luôn xả — lưu qua `SettingsService.saveTranslationKeepResidentMode`, `TranslationService._shouldKeepResident()` đọc lại đúng lựa chọn này thay vì luôn tự đoán theo RAM). Thêm nút điều hướng thẳng từ màn dịch thuật sang màn tối ưu. Bài học: khi 1 màn hình VIẾT text nhắc tới 1 màn khác, phải THẬT SỰ đi kiểm tra màn kia có đúng như mô tả không, không được giả định.

15. **`TextField.labelText` bị cắt "..." khi field trống/chưa focus và label dài**: label chỉ hiển thị đủ nhiều dòng khi đã "float" lên trên (field có nội dung hoặc đang được focus) — khi field trống và chưa chạm vào, label render inline trong khung 1 dòng nên bị ellipsis. **Đã sửa** ở field "Thư mục model dịch thuật": rút ngắn `labelText`, chuyển phần giải thích dài xuống `helperText` (luôn hiển thị, tự xuống dòng qua `helperMaxLines`). Cần rà lại các `TextField` khác trong app có `labelText` dài tương tự nếu người dùng báo gặp lại vấn đề này ở màn hình khác.

16. **`dart:ui` (`Canvas`/`ParagraphBuilder`) dùng được trong 1 service thuần, không cần widget**: để sinh ảnh bìa EPUB (mục 4.14) không cần `file_picker` hay ảnh có sẵn — vẽ trực tiếp bằng `dart:ui` ngay trong `export_service.dart` (không phải file `.dart` UI/widget). Hoạt động được vì Flutter engine đã khởi tạo sẵn khi hàm này được gọi (luôn gọi sau khi app đã chạy, từ 1 hành động người dùng bấm nút xuất bản) — **CHƯA build/test thật để xác nhận không có vấn đề threading/timing nào** (lý thuyết đúng theo tài liệu Flutter, nhưng đây là lần đầu dự án dùng `dart:ui` trực tiếp ngoài widget tree).

17. **Khi thêm cột mới vào bảng đã tồn tại qua nhiều đời migration, luôn dùng `PRAGMA table_info` kiểm tra tồn tại trước khi `ALTER TABLE ADD COLUMN`** (mẫu `addColumnIfMissing` đã có sẵn từ migration v1→v2, tái dùng y hệt cho v2→v3 ở mục 4.10/4.13) — an toàn nếu 1 máy nào đó lỡ chạy migration 2 lần (vd do lỗi mất kết nối DB giữa chừng), không bị lỗi "duplicate column".

18. **[NGHIÊM TRỌNG NHẤT TỪ TRƯỚC TỚI NAY] `flutter create --org com.localnovel --project-name local_novel` sinh ra package THẬT là `com.localnovel.local_novel` (org + tên project ghép lại), KHÔNG PHẢI chỉ `com.localnovel`** — nhưng bước "Ghép code native (Kotlin + JNI) vào project Android" trong `build.yml` từ trước tới giờ luôn copy `MainActivity.kt` (file THẬT, có đăng ký `MethodChannel`) vào `scaffold/android/app/src/main/kotlin/com/localnovel/MainActivity.kt` — SAI đường dẫn, thiếu `/local_novel`. Hậu quả: file thật nằm ở nhầm chỗ (class thừa, không ai gọi tới), còn `AndroidManifest.xml` (đúng theo package thật `com.localnovel.local_novel`) vẫn khai báo dùng bản `MainActivity` MẶC ĐỊNH RỖNG do chính `flutter create` tự sinh — bản này build/cài/chạy giao diện đều bình thường (không lỗi biên dịch, không crash lúc mở app) nhưng KHÔNG ĐĂNG KÝ `MethodChannel` NÀO CẢ. Kết quả: **mọi tính năng dùng model local (chat, đo tốc độ...) đều lỗi `MissingPluginException` ngay từ Build APK #30 tới #33** — nghĩa là **chưa từng có bản build nào trước đó thực sự chạm tới code native/JNI/MNN cả**, toàn bộ những gì tưởng đã "xác nhận" trước đó (QNN, Foreground Service...) đều CHƯA từng được kiểm chứng thật.
    **Đã sửa** (từ Build APK #34): bước "Ghép code native" giờ **tự dò** đường dẫn + package thật bằng cách tìm file `MainActivity.kt`/`.java` mặc định mà `flutter create` vừa sinh ra (`find scaffold/android/app/src/main -name 'MainActivity.kt' -o -name 'MainActivity.java'`), đọc dòng `package ...` bên trong để biết package thật, xóa bản mặc định, copy file thật vào ĐÚNG chỗ + tự sửa dòng `package` cho khớp — không hardcode đường dẫn nữa.
    **Bài học lớn nhất**: khi 1 quy trình build có bước "sinh khung tự động rồi ghép code riêng vào", PHẢI xác minh runtime thật xem code ghép vào có đúng là code ĐANG CHẠY hay không (vd bằng cách cho code tự in ra 1 dấu hiệu nhận biết), không được tin ngầm định chỉ vì build "thành công" và app "mở lên bình thường" — 2 thứ này hoàn toàn không đảm bảo code native thật sự được dùng.

19. **Hạ tầng ghi log chẩn đoán 3 tầng (Dart/Kotlin/C++) khi chưa có ADB/logcat thật**: xây dựng `DebugLogService` (Dart, ghi trước/sau mỗi lệnh gọi `invokeMethod` rủi ro) + `kLog()` (Kotlin, ghi trước/sau mỗi bước trong `onMethodCall`) + `nativeLog()` (C++, ghi từng dòng trong `nativeGenerate`/`nativeLoadModel`) — TẤT CẢ ghi vào CÙNG 1 file, flush đĩa ngay lập tức (không đợi buffer), để nếu app crash cứng (SIGSEGV, native, không throw exception Kotlin/C++ bắt được), dòng log CUỐI CÙNG còn sống sót trên đĩa cho biết chính xác code dừng ở đâu. Đây là kỹ thuật chẩn đoán thay thế tạm cho logcat/tombstone thật khi người dùng không có máy tính + ADB. Xem trực tiếp trong app qua Cài đặt → "Log debug" (`DebugLogScreen`), không cần vào Files.

20. **Ghi file vào `/storage/emulated/0/Download/` cần quyền `MANAGE_EXTERNAL_STORAGE` ĐƯỢC CẤP THẬT (qua Cài đặt hệ thống), không tự có chỉ vì khai báo trong `AndroidManifest.xml`** — lần đầu thử ghi log debug vào `Download`, cả Kotlin lẫn C++ đều ghi thất bại ÂM THẦM (lỗi bị code tự bắt rồi bỏ qua, không báo gì) vì quyền này chưa từng được người dùng bật tay. **Đã sửa**: chuyển hẳn sang ghi vào thư mục RIÊNG của app (`appContext.filesDir` phía Kotlin, truyền xuống C++ qua hàm `nativeSetLogDir()` gọi 1 lần lúc khởi động) — thư mục này luôn ghi được, không cần xin quyền gì cả.

21. **`getApplicationDocumentsDirectory()` (Dart, gói `path_provider`) KHÔNG trùng thư mục với `context.filesDir` (Kotlin) trên Android** — dù nghe tên tưởng tương đương. Đã tra cứu xác nhận: `getApplicationDocumentsDirectory()` map sang 1 thư mục riêng (`.../app_flutter`), còn `getApplicationSupportDirectory()` mới đúng là map sang `getFilesDir()`. Khi cần Dart đọc lại đúng file mà tầng Kotlin/C++ vừa ghi vào `filesDir`, PHẢI dùng `getApplicationSupportDirectory()`, không phải `getApplicationDocumentsDirectory()` — nếu không sẽ không bao giờ đọc được file dù nó ghi ra thành công.

22. **`backendPreference` (QNN tự động / ép GPU / ép CPU) giờ đọc từ Cài đặt (`SettingsService.loadBackendPreference()`), không còn hardcode `0` trong `MnnBridge.kt` nữa** — cho phép người dùng tự đổi qua lại giữa 3 chế độ ngay trong app để khoanh vùng lỗi native theo backend, KHÔNG cần build lại APK mỗi lần thử. Bài học: khi đang debug 1 vấn đề mà giả thuyết hàng đầu là "lỗi backend X", nên ưu tiên làm tham số đó CẤU HÌNH ĐƯỢC từ UI trước khi thử sửa cứng trong code — tiết kiệm rất nhiều vòng build (mỗi vòng build native mất 15-20+ phút).

23. **[Đã LOẠI TRỪ, không phải nguyên nhân]** Từng nghi ngờ tham số `max_new_tokens = 0` truyền cứng cho `llm->response(...)` gây crash native (SIGSEGV) — sửa thành `-1` nhưng **crash vẫn xảy ra y hệt**, xác nhận qua log debug thật. Giả thuyết này đã bị loại bỏ hoàn toàn. Bài học: 1 giả thuyết nghe hợp lý về mặt kỹ thuật (khớp với "tài liệu chính thức không ai truyền 0") vẫn PHẢI được xác nhận bằng thực nghiệm thật trước khi coi là đã sửa xong — không dừng lại ở "nghe có vẻ đúng".

24. **[NGUYÊN NHÂN THẬT của crash native, đã xác nhận bằng log thật] R8/ProGuard đổi tên class/hàm Kotlin trong bản `--release`, làm JNI `GetMethodID("onToken", "(Ljava/lang/String;Z)V")` trả về `NULL`** — log debug xác nhận tên lớp thật lúc chạy của callback bị đổi thành `a0.a` (dấu hiệu R8 đổi tên kinh điển). Vì `GetMethodID` trả `NULL` không phải throw C++ exception (mà là "pending exception" phía JVM), nếu code cũ không kiểm tra `NULL` trước khi gọi tiếp `CallVoidMethod` sẽ crash cứng ngay (SIGSEGV/undefined behavior) — đúng khớp mọi triệu chứng quan sát được (crash y hệt ở mọi backend QNN/GPU/CPU, vì đây là lỗi ở TẦNG GỌI JNI, không liên quan gì tới backend suy luận).
    **Phát hiện quan trọng khác**: theo tài liệu chính thức Flutter, các bản gần đây **KHÔNG tắt được** code shrinking (R8) cho bản release nữa (cờ `--no-shrink` hết tác dụng, "Code shrinking is always enabled in release builds") — thử set `minifyEnabled false` trong `build.gradle` qua `sed` KHÔNG có tác dụng (đã xác nhận qua thực nghiệm, không phải chỉ tra tài liệu suông).
    **Cách sửa ĐÚNG** (khuyến nghị chính thức cho JNI + R8): thêm luật ProGuard `-keep class com.localnovel.** { *; }` (rộng, giữ nguyên cả package thay vì chỉ đúng `TokenCallback`, phòng hờ chỗ khác cũng dùng JNI tương tự) vào `proguard-rules.pro`, VÀ kiểm tra/tự chèn dòng `proguardFiles ...` vào khối `buildTypes { release { ... } }` của `build.gradle`/`build.gradle.kts` nếu còn thiếu (khung `flutter create` mặc định KHÔNG chắc đã có sẵn dòng này) — làm bằng Python (không dùng `sed` mù quáng) để xác nhận chắc chắn đã thêm đúng chỗ, in lại nội dung sau khi sửa để đối chiếu.
    **Bài học viết script build**: heredoc bash (`<< 'EOF' ... EOF`) LỒNG bên trong khối `run: |` của YAML rất dễ vỡ — YAML literal block scalar yêu cầu MỌI dòng (kể cả dòng kết thúc heredoc) phải thụt lề nhất quán, nhưng bash heredoc lại yêu cầu dòng kết thúc phải sát lề trái (trừ khi dùng `<<-` với TAB, không phải space) — 2 yêu cầu xung đột nhau. Cách né an toàn: dùng `python3 -c "..."` với code Python truyền qua 1 chuỗi (có thể nhiều dòng trong chuỗi double-quote của bash, bash hỗ trợ xuống dòng thật trong chuỗi), tránh hẳn heredoc lồng nhau. Luôn kiểm tra lại bằng `python3 -c "import yaml; yaml.safe_load(open('build.yml'))"` sau khi sửa `build.yml` bằng tay/script, và mô phỏng chạy thử đoạn script trích ra trong môi trường giả lập trước khi gửi cho người dùng chạy thật trên GitHub Actions (tiết kiệm được 1 vòng build/test mất 15-20 phút mỗi lần sai).

25. **Toàn bộ `onMethodCall` của `MnnBridge.kt` trước đây KHÔNG có try/catch bao ngoài cùng** — nghĩa là bất kỳ exception Kotlin nào ném ra TRỰC TIẾP trong hàm này (không phải trong coroutine, nên `finally`/`catch` của coroutine không với tới được) sẽ làm crash toàn bộ app ngay lập tức, không kịp gọi `result.error(...)` để báo cho Dart biết. Đã thêm 1 lớp try/catch bao ngoài cùng (`onMethodCall` gọi `onMethodCallInner` bên trong try/catch, bắt `Throwable`, log + trả lỗi qua `result.error(...)` thay vì để crash) — áp dụng cho MỌI lỗi Kotlin tương lai ở tầng này, không chỉ lỗi đã biết. Bài học: `MethodChannel.MethodCallHandler.onMethodCall` không tự động được Flutter engine bọc try/catch — bất kỳ handler nào có logic đủ phức tạp (gọi Android API có thể ném exception như Foreground Service, file I/O...) đều nên tự bọc try/catch ngay từ đầu, không đợi tới khi crash thật mới thêm.

26. **[GHI LẠI MUỘN — lỗi này đã xảy ra và ĐÃ ĐƯỢC SỬA ở phiên trước, nhưng chưa từng được chép vào tài liệu này] Lỗi `RuntimeException: Methods marked with @UiThread must be executed on the main thread`** — sau khi mục 24 (ProGuard) được sửa, `llm->response()` chạy trọn vẹn lần đầu tiên (không còn crash native), nhưng `eventSink?.success(...)` (gửi token về Flutter qua `EventChannel`) và `result.success(...)`/`result.error(...)` (trả kết quả `MethodChannel`) đang bị gọi từ luồng nền `Dispatchers.Default` (dùng để nạp/sinh model nặng, tránh treo UI) — trong khi Flutter bắt buộc 2 lệnh này phải chạy trên luồng chính (UI thread). **Cách sửa đã áp dụng**: bọc toàn bộ 7 chỗ gọi `eventSink?.success/error` và `result.success/error` nằm bên trong `scope.launch { ... }` (luồng nền) bằng `mainHandler.post { ... }` (đẩy đúng lệnh gọi lại Flutter về luồng chính), còn phần tính toán nặng (nạp/sinh model) vẫn giữ nguyên ở luồng nền, không đổi. **Xác nhận qua code hiện tại**: `MnnBridge.kt` đã có đủ các chỗ bọc này. **Xác nhận qua log thật** (`debug_log.txt` ngày 2026-07-26): không còn xuất hiện lỗi `@UiThread` nữa — lỗi này coi như đã đóng, chỉ là tài liệu quên cập nhật, nay bổ sung lại cho đủ lịch sử.

27. **[BUG MỚI PHÁT HIỆN VÀ ĐÃ SỬA — 2026-07-27] `SettingsService.currentProvider()` dựng 1 `LocalLlamaProvider()` MỚI mỗi lần được gọi**, thay vì tái sử dụng instance cũ. Vì cờ `_loaded` (đánh dấu model đã nạp hay chưa) nằm trên instance, không phải static/toàn cục, mỗi lần `chat_screen.dart`/`chapter_editor_screen.dart` gọi `SettingsService().currentProvider()` (tức là mỗi lần gửi tin nhắn/bấm AI) đều tạo instance mới với `_loaded=false` → luôn gọi lại `loadModel` native dù model không đổi. Xác nhận qua `debug_log.txt`: cả 3 lần chat cách nhau 5-10 giây đều có dòng `ensureLoaded... CHUẨN BỊ gọi loadModel native`. Không gây crash (MNN dùng mmap nên "nạp lại" vẫn nhanh vì trang nhớ đã có sẵn trong cache của hệ điều hành từ lần trước), nhưng tốn thời gian dựng lại không cần thiết mỗi lần chat. **Đã sửa**: thêm cache tĩnh (`_cachedLocalProvider`/`_cachedLocalModelPath`) trong `SettingsService`, chỉ tạo `LocalLlamaProvider` mới khi `modelPath` thật sự đổi (người dùng đổi model trong Cài đặt).

28. **[ĐANG DEBUG — CHƯA CÓ KẾT LUẬN CUỐI, đây là việc ưu tiên số 1 hiện tại] `llm->response()` chạy xong không crash, nhưng luôn trả về chuỗi RỖNG (`do dai ket qua=0`)** ở cả 3 lần thử trong `debug_log.txt` (kể cả lần `max_new_tokens=1024`, prompt 494 ký tự). Quan sát quan trọng nhất: khoảng thời gian giữa lúc Kotlin gọi `nativeGenerate` và lúc nó trả về chỉ ~1ms theo dấu thời gian tầng Kotlin — trong khi theo benchmark thật của chính máy này (mục 3, bảng tech stack: decode ~16.7 token/giây trên OpenCL), dù chỉ sinh đúng 1 token cũng không thể xong trong 1ms. Kết luận tạm thời: `response()` gần như chắc chắn KHÔNG chạy forward-pass thật nào — dừng ngay ở điều kiện dừng (EOS) từ token đầu tiên, không phải do máy chậm hay lỗi backend. Nghi ngờ hàng đầu: model `Orion-zhen-Qwen2.5-7B-Instruct-Uncensored-MNN-q4-chinh` (convert qua `LocalNovel_Convert_Model_To_MNN.ipynb`, dùng đúng `llmexport.py` chính thức của MNN — không phải script tự chế, nên ít khả năng lỗi quy trình convert) có `tokenizer_config.json`/`generation_config.json`/EOS token id lệch chuẩn so với bản Qwen2.5 gốc do đây là bản fine-tune "Uncensored" của bên thứ ba. **Đã thêm vào `mnn_bridge.cpp`** (chưa build/test): (a) đo thời gian thật bằng `std::chrono` quanh `llm->response()` để xác nhận chắc chắn giả thuyết "không chạy forward-pass thật" thay vì suy đoán qua log Kotlin; (b) log 120 ký tự đầu + 120 ký tự cuối của prompt thật (thay `\n` bằng `|`) để kiểm tra định dạng prompt gửi xuống native có đúng như kỳ vọng không; (c) log cảnh báo rõ khi kết quả rỗng, gợi ý hướng nghi ngờ. **Việc cần làm tiếp**: build lại với bản sửa này, đọc log mới để xác nhận/loại trừ giả thuyết; nếu xác nhận đúng, thử convert + test lại bằng 1 model Qwen2.5 gốc (không phải bản uncensored) để cô lập xem lỗi nằm ở bản convert cụ thể này hay ở tầng code.

30. **[CẬP NHẬT QUAN TRỌNG — tiếp tục mục 28, dựa trên bằng chứng thật, KHÔNG còn nghi ngờ model nữa] Đã cô lập được: lỗi KHÔNG nằm ở model, mà ở code cầu nối.** Trình tự bằng chứng, theo đúng thời gian thật xảy ra:
    - **CI (build #45-47)**: gặp lỗi build hoàn toàn khác, không liên quan tới MNN — `Could not find method kotlin()` khi biên dịch package Dart `jni` (bị kéo vào gián tiếp qua 1 plugin khác). Truy ra tận gốc: package `jni` (bản `1.0.1`, đã xác nhận qua log là bản mới nhất hiện có, không có bản nào mới hơn để nâng cấp) chỉ tự áp dụng plugin Kotlin khi `AGP major version < 9`; scaffold Flutter (bản `3.44.7`, đã pin) mặc định sinh ra AGP `9.0.1` → điều kiện đó sai → khối `kotlin { compilerOptions {...} }` trong chính `build.gradle` của `jni` không tìm thấy extension tương ứng → lỗi. **Đã sửa**: hạ AGP xuống `8.13.0` (đúng version Google xác nhận đi kèm Gradle `8.13` — "AGP 8.13 now requires Gradle 8.13"), hạ Gradle wrapper xuống `8.13`, hạ Kotlin xuống `2.1.20` (phần này chỉ có bằng chứng gián tiếp, chưa xác nhận 100% là cặp version tối ưu nhất, nhưng đã build qua được nên coi như đạt yêu cầu tối thiểu). Build APK từ đó đã qua được ổn định.
    - **Test cô lập model (2026-07-28)**: convert thêm 1 bản `Qwen/Qwen2.5-1.5B-Instruct` CHÍNH THỨC (không phải fine-tune "Uncensored"), qua đúng `LocalNovel_Convert_Model_To_MNN.ipynb`, dùng đúng `llmexport.py` chính thức của MNN. Kết quả: **lỗi giống hệt bản Uncensored** — `llm->response()` vẫn trả rỗng, `THOI GIAN THAT (ms)=0` ở cả 2 model, cả 2 prompt khác nhau hoàn toàn (chat có Story Bible lẫn benchmark cố định). → **Loại bỏ hoàn toàn giả thuyết "lỗi do tokenizer/EOS của bản Uncensored"** đã đặt ra ở mục 28 — không phải lỗi model, mà là lỗi hệ thống ở tầng code, ảnh hưởng như nhau bất kể model nào.
    - **Đọc `llm.hpp` THẬT** (lấy trực tiếp từ log CI, bước "In cấu trúc thư mục install thật" vốn đã in sẵn từ trước, chỉ là chưa ai đọc tới — đúng việc đã ghi nợ ở mục 5.10): xác nhận chữ ký `response(const std::string&, std::ostream*, const char*, int max_new_tokens=-1)` khớp chính xác 100% với cách `mnn_bridge.cpp` đang gọi — không phải lỗi tham số. Nhưng phát hiện 2 điều quan trọng chưa từng khai thác:
      - `set_config()` trả về `bool` (thành công/thất bại) — code cũ **bỏ qua hoàn toàn** giá trị này, không hề biết JSON cấu hình có thực sự được MNN chấp nhận hay không.
      - `class Llm` có `getContext()` trả về `const LlmContext*` — struct này MNN tự ghi lại `status` (enum `LlmStatus`: `NORMAL_FINISHED`/`MAX_TOKENS_FINISHED`/`INTERNAL_ERROR`/`TIMEOUT`...), `prompt_len`, `gen_seq_len`, `prefill_us`/`decode_us` thật — đây là nguồn duy nhất cho biết **chính xác** lý do MNN dừng sinh văn bản, thay vì phải suy đoán qua thời gian chạy như trước giờ.
    - **Đã thêm vào `mnn_bridge.cpp`** (chưa build/test): log giá trị `bool` thật của `set_config()`, và log toàn bộ `LlmContext` (status/prompt_len/gen_seq_len/prefill_us/decode_us) ngay sau mỗi lần `response()`. **Việc cần làm ngay ở phiên tiếp theo**: build lại, đọc đúng dòng log `LlmContext THAT — status=...` — con số đó sẽ cho biết chính xác hướng sửa (nếu `status=INTERNAL_ERROR`, tìm lỗi nội bộ MNN; nếu `prompt_len=0`, lỗi nằm ở bước tokenize/encode prompt, có thể liên quan tới `initRuntime()`/`load()` chưa hoàn tất đúng cách dù trả về `success:true`).

31. **[BUG MỚI PHÁT HIỆN VÀ ĐÃ SỬA — 2026-07-28] Cắt chuỗi preview prompt trong log (mục 5.28) làm hỏng cả file `native_debug.txt`.** `preview.substr(0, 120)`/`substr(size-120)` cắt theo byte, không theo ký tự — tiếng Việt có dấu dùng UTF-8 nhiều byte/ký tự, nếu điểm cắt rơi giữa 1 ký tự nhiều byte sẽ tạo chuỗi byte không hợp lệ. App đọc file log bằng UTF-8 (`File.readAsString()`) gặp đoạn hỏng đó ném `FileSystemException: Failed to decode data using encoding 'utf-8'`, hỏng toàn bộ file log (không đọc được cả các dòng quan trọng phía sau, kể cả `LlmContext` mới thêm ở mục 5.30) — không phải chỉ 1 dòng bị lỗi. **Đã sửa**: thêm 2 hàm `utf8SafeHead`/`utf8SafeTail`, lùi/tiến điểm cắt tới đúng ranh giới ký tự (bỏ qua continuation byte dạng `10xxxxxx`) trước khi cắt, đảm bảo không bao giờ cắt giữa 1 ký tự UTF-8 nhiều byte nữa.

33. **[NGHI NGỜ NGUYÊN NHÂN GỐC MẠNH NHẤT TỪ TRƯỚC TỚI NAY — 2026-07-28, tiếp tục mục 30] Ép backend OpenCL để loại trừ QNN — lỗi vẫn giống hệt, loại bỏ luôn nghi ngờ backend.** `status` vẫn `NOT_LOADED (-1)`, mọi trường `LlmContext` vẫn 0, dù đã ép chạy OpenCL thay vì QNN. Vì `NOT_LOADED` chính là giá trị khởi tạo MẶC ĐỊNH của `LlmContext` lúc vừa tạo, chưa từng bị đụng tới — kết luận: `response()` thoát ra ngay từ đầu, trước cả bước mã hoá prompt, không phụ thuộc backend nào. Truy ngược lên tận `createLLM()`: header thật (`llm.hpp`) đặt tên tham số là `config_path` — đường dẫn tới 1 FILE cấu hình, nhưng `local_provider.dart`/`mnn_bridge.cpp` từ đầu dự án luôn truyền thẳng đường dẫn THƯ MỤC model (`modelPath`) vào thẳng `createLLM()`, không phải file. Đối chiếu với `LocalNovel_Convert_Model_To_MNN.ipynb`: file cấu hình thật do notebook sinh ra tên là `llm_config.json` (xác nhận qua chính bước kiểm tra file bắt buộc của notebook, mục "Bước 6"). Nếu `createLLM` cố đọc 1 thư mục như thể là file JSON, tuỳ thư viện có thể không ném exception C++ nhưng cấu hình sẽ rỗng/mặc định hoàn toàn — khớp chính xác với MỌI triệu chứng quan sát được xuyên suốt từ mục 28 tới giờ (không crash, `LlmContext` chưa từng được đụng tới, giống hệt nhau ở mọi model/mọi backend). **Đã sửa**: `nativeLoadModel` giờ tự động dò đúng file cấu hình thật bên trong thư mục được truyền vào — ưu tiên `llm_config.json` (đúng tên notebook dùng), dự phòng `config.json` (quy ước MNN cũ hơn), chỉ dùng nguyên `path` gốc nếu bản thân nó đã là 1 file `.json` rồi (không đoán mù, có log cảnh báo rõ nếu không tìm thấy file nào). **CHƯA build/test** — đây là việc ưu tiên số 1 tuyệt đối cho phiên tiếp theo, nhiều khả năng là nguyên nhân gốc thật sự của toàn bộ chuỗi debug từ mục 28.

35. **[SỬA LẠI LẦN 2, DỰA TRÊN TÀI LIỆU CHÍNH THỨC MNN — 2026-07-29, tiếp tục mục 33] Ưu tiên sai thứ tự giữa `config.json` và `llm_config.json`.** Sau khi mục 33 sửa xong đường dẫn (dò đúng file bên trong thư mục thay vì dùng thẳng thư mục), `load()` vẫn trả về `false` ở cả 3 backend (QNN/OpenCL/CPU — xác nhận qua log thật, không phải giả thuyết). Tra cứu tài liệu chính thức `alibaba/MNN/transformers/README.md`: **`config.json` mới là file truyền thẳng vào `createLLM()`/`llm_demo` (mọi ví dụ dòng lệnh chính thức đều dùng `model_dir/config.json`)**; `llm_config.json` chỉ là file được chính `config.json` tự tham chiếu tới bên trong qua field `llm_config` (mặc định trỏ ngược lại `config.json` nếu field đó không có) — không phải điểm vào trực tiếp. Bản sửa ở mục 33 ưu tiên nhầm `llm_config.json` trước — sai thứ tự so với quy ước thật của MNN, dù cả 2 file đều tồn tại thật trong thư mục model (xác nhận qua ảnh chụp file explorer của người dùng: `config.json` 502B, `llm_config.json` 0,90kB). **Đã sửa**: đảo lại thứ tự — ưu tiên `config.json` trước, chỉ dùng `llm_config.json` làm dự phòng nếu không có `config.json`. **CHƯA build/test** — việc cần làm ngay phiên sau.

37. **[ĐANG NGHI NGỜ, ĐÃ ÁP DỤNG KHUYẾN NGHỊ CHÍNH THỨC MNN — 2026-07-29, tiếp tục mục 35] App crash ngay lập tức (không kịp ghi thêm log) ở lần đầu tiên `createLLM()` đọc đúng `config.json` thật, tham chiếu đầy đủ tới file weight thật.** Đây là lần đầu tiên xuyên suốt chuỗi debug mà code thực sự cố nạp dữ liệu nặng vào RAM (trước đó luôn đọc nhầm file, nên `load()` trả `false` gần như tức thì, không kịp chạm tới bước nạp weight thật). Máy test 16GB RAM (bổ sung vào mục 1, trước đây tài liệu chỉ ghi tên chip, thiếu RAM) — về lý thuyết đủ cho model 7B q4 (~4,85GB weight+embedding), nhưng RAM khả dụng thực tế tại thời điểm nạp có thể thấp hơn nhiều do hệ thống/app nền. Tra lại tài liệu chính thức MNN (đã đọc ở mục 35): có tuỳ chọn cấu hình `use_mmap` — "mặc định `false`, khuyến nghị bật `true` cho thiết bị di động" để tránh đúng kiểu OOM cấp phát 1 khối RAM liên tục lớn này. Code từ đầu dự án CHƯA từng bật tuỳ chọn này. **Đã sửa**: thêm `"use_mmap": true` vào JSON cấu hình gửi cho `set_config()` ở cả 3 backend (QNN/OpenCL/CPU), cả nhánh tự động lẫn ép buộc. **CHƯA build/test, CHƯA xác nhận đây có đúng là nguyên nhân hay không** — cần thử thêm cả model 1.5B nhỏ hơn (đã convert sẵn) để so sánh trước khi kết luận chắc chắn.

39. **[ĐANG DEBUG, ĐÃ THÊM CÔNG CỤ CHẨN ĐOÁN MỚI — 2026-07-29, tiếp tục mục 37] Xác nhận qua CI (`✅ CO use_mmap`, `✅ CO chot chan chong lenh`) rằng bản build ĐÚNG là mới nhất — loại bỏ hẳn nghi ngờ "test nhầm bản cũ".** Nhưng crash vẫn xảy ra y hệt ở CẢ model 7B lẫn 1.5B, đúng cùng 1 điểm (ngay sau log đường dẫn config, trước cả khi log "CHUAN BI goi Llm::createLLM()" — chỉ là 1 câu in chữ, không tính toán gì — kịp chạy). Vì model 1.5B không thể OOM trên máy 16GB, giả thuyết hết RAM (mục 37) gần như bị loại. Nghi ngờ mới: crash cứng thật (SIGSEGV hoặc bị hệ thống kill) xảy ra ngay trong `Llm::createLLM()` của thư viện MNN đã build sẵn — try/catch C++ không bắt được loại crash này. Thử dùng tính năng "Báo cáo lỗi" (bug report) của Android để lấy logcat thật nhưng không hoạt động trên máy người dùng (bấm không phản hồi). **Đã thêm**: bộ bắt tín hiệu crash (`signal handler`) tự viết trong `mnn_bridge.cpp` — bắt `SIGSEGV`/`SIGABRT`/`SIGBUS`/`SIGILL`/`SIGFPE`, tự ghi vào `native_debug.txt` bằng syscall thô (`open`/`write`/`close`, KHÔNG dùng `std::string`/cấp phát bộ nhớ động vì không an toàn trong ngữ cảnh signal handler thật) trước khi trả lại hành vi mặc định của hệ điều hành. Cài đặt 1 lần trong `nativeSetLogDir` (gọi sớm nhất lúc app khởi động).

40. **[CỘT MỐC LỚN NHẤT DỰ ÁN — 2026-07-30] LẦN ĐẦU TIÊN model local sinh ra văn bản thật thành công, kết thúc chuỗi debug từ mục 28.** Xác nhận qua log thật: `LlmContext status=1 (NORMAL_FINISHED)`, sinh ra 264 ký tự, `prompt_len=128`, `gen_seq_len=58`. Nguyên nhân cuối cùng: bộ bắt crash (mục 39) xác nhận **backend QNN crash cứng (`SIGSEGV`) mọi lúc, mọi model** ngay trong `llmSlot->load()`; **backend OpenCL (ép buộc, `backendPreference=1`) chạy được, không crash**. Kết luận: lỗi tích hợp QNN trên bản build này là thật, không liên quan gì tới toàn bộ chuỗi nguyên nhân đã sửa trước đó (đường dẫn config mục 33/35, quyền file, `use_mmap` mục 37...) — tất cả đều ĐÚNG và CẦN THIẾT, chỉ là QNN tự nó bị lỗi ở bước cuối cùng. **Việc cần làm tiếp**: đổi mặc định app dùng OpenCL thay vì thử QNN trước (tránh crash mỗi lần mở app), ghi nhận việc sửa QNN là backlog tối ưu sau, không phải chặn đường chính nữa. **Hiệu năng lần đầu rất chậm** (`decode_us=313505345` ~313 giây cho 58 token, `prefill_us=46756357` ~47 giây cho 128 token) — nghi ngờ hiện tượng "khởi động nguội" của OpenCL (GPU driver biên dịch kernel/shader lần đầu chạy), cần xác nhận qua lần sinh thứ 2 trong cùng phiên (không tải lại model) có nhanh hơn hẳn không. **Đã sửa thêm**: màu chữ phản hồi AI trong `chat_screen.dart` không tương phản với nền (chữ sáng mặc định theo theme tối đè lên nền `grey.shade100` sáng, gần như không đọc được) — đã chỉ định rõ `Colors.black87` cho khung AI và `onPrimaryContainer` cho khung người dùng.

42. **[PHÁT HIỆN QUAN TRỌNG — 2026-07-30] `GenerationService` (Foreground Service + WakeLock) chưa từng khai báo trong `AndroidManifest.xml`, khiến nó không có tác dụng thật từ đầu dự án.** Người dùng quan sát: khi tắt màn hình lúc đang sinh văn bản, đồng hồ đếm giây dừng hẳn, chạy tiếp khi bật màn hình lại — đúng hành vi Android đóng băng tiến trình khi không chạy đúng Foreground Service. Kiểm tra lại: `GenerationService.kt` viết đúng (start/stop/WakeLock `PARTIAL_WAKE_LOCK`), gọi đúng từ `MnnBridge.kt`, nhưng **`build.yml` chưa từng thêm bước khai báo `<service>` trong Manifest**, cũng thiếu quyền `FOREGROUND_SERVICE`/`WAKE_LOCK`. Với `compileSdk 35` (Android 15), thiếu `android:foregroundServiceType` trên khai báo `<service>` khiến `startForegroundService()` ném lỗi ngay khi gọi — rất có thể bị nuốt bởi try/catch bọc quanh (`MnnBridge.kt` dòng 44), khiến app tiếp tục chạy nhưng KHÔNG có Foreground Service/WakeLock thật, dễ bị hệ thống đóng băng khi màn hình tắt. Đây cũng giải thích số liệu `prefill_us` tăng bất thường (46,8s → 68,9s → 708,4s) qua các lần sinh trong log — nhiều khả năng không phải GPU chậm dần, mà là thời gian đóng băng khi màn hình tắt bị tính lẫn vào đồng hồ đo (`chrono` đo theo giờ tường, không phân biệt được lúc tiến trình bị đóng băng). **Đã sửa**: thêm bước vào `build.yml` khai báo `<service android:name="com.localnovel.mnnbridge.GenerationService" android:foregroundServiceType="dataSync" .../>` + 3 quyền còn thiếu. **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, thử sinh văn bản dài, tắt màn hình giữa chừng, xác nhận đồng hồ vẫn chạy tiếp (không đóng băng) và thời gian đo được ổn định qua nhiều lần, không tăng bất thường nữa.

43. **[BACKLOG, CHƯA ĐỦ BẰNG CHỨNG ĐỂ SỬA NGAY — 2026-07-30] Yêu cầu ép chạy QNN (NPU) thay vì OpenCL (GPU) để tăng tốc — theo kinh nghiệm người dùng, NPU thường nhanh hơn GPU tới 10 lần (dẫn chứng từ Stable Diffusion 1.5).** Về nguyên tắc, đúng — NPU thường nhanh và tiết kiệm điện hơn GPU nhiều cho suy luận LLM. Nhưng hiện tại **QNN đang crash cứng thật (`SIGSEGV`, xác nhận qua bộ bắt crash mục 39)** ngay trong `llmSlot->load()`, không phải vấn đề tốc độ — cần sửa được lỗi crash đó trước khi bàn tới việc "ép dùng". Chưa đủ bằng chứng để xác định chính xác nguyên nhân crash (cần bản backtrace symbolized thật, ví dụ qua `ndk-stack`/`addr2line` đối chiếu file `.so` debug, hiện chưa có công cụ này trong quy trình) — có thể do phiên bản QNN SDK 2.40.0 Community không khớp hoàn toàn driver Hexagon 780 thật trên Snapdragon 888, hoặc lỗi cấu hình graph riêng cho model 7B q4. Không nên tiếp tục đầu tư thời gian vào việc này trước khi mục 42 (Foreground Service) được xác nhận sửa xong, vì đó là vấn đề ảnh hưởng rộng hơn (mọi backend), còn QNN chỉ ảnh hưởng riêng tốc độ.

44. **[SỬA XONG — 2026-07-30] Chat không hiện chữ dần, phải đợi sinh xong hết mới thấy — người dùng phát hiện đúng.** Tầng Dart (`local_provider.dart`, `chat_screen.dart`) đã viết đúng cơ chế hiển thị từng chữ (`await for (chunk in stream) setState(() => reply.text += chunk)`), nhưng tầng C++ (`mnn_bridge.cpp`) trước đây gọi `llm->response(promptStr, &fullOutput, ...)` với `fullOutput` là 1 `std::ostringstream` THƯỜNG — chỉ gom chữ vào bộ nhớ, không đẩy ra JNI cho tới khi `response()` hoàn toàn kết thúc, rồi mới gọi `CallVoidMethod` đúng 1 lần duy nhất với toàn bộ văn bản. Trong khi đó, MNN nội bộ THẬT SỰ ghi (`operator<<`) vào đúng `ostream` được truyền vào ngay mỗi khi sinh xong 1 đoạn — chỉ là code chưa "nghe" được thời điểm đó. **Đã sửa**: viết lớp `JniStreamingBuf` kế thừa `std::streambuf`, chặn đúng điểm MNN ghi chữ vào (`xsputn`/`overflow`), gọi `CallVoidMethod` (JNI_FALSE, "chưa xong") ngay lập tức mỗi lần MNN ghi 1 đoạn, thay vì gom hết. Sau khi `response()` trả về, chỉ gửi thêm 1 tín hiệu rỗng kèm JNI_TRUE để báo "xong" (không gửi lại toàn bộ văn bản, vì Dart đã có sẵn cơ chế bỏ qua token rỗng, chỉ dùng cờ `done` để đóng stream — không cần sửa gì ở tầng Dart). **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, xác nhận chữ hiện dần từng đoạn khi chat, không còn đợi sinh xong hết mới thấy.

46. **[THAM KHẢO MNN CHAT CHÍNH THỨC — 2026-07-30, tiếp tục mục 43] Tìm được 2 khác biệt quan trọng giữa cách app này và MNN Chat (app chính thức Alibaba) xử lý QNN.** Đọc mã nguồn thật `apps/Android/MnnLlmChat/.../qnn/QnnModule.kt`: (1) MNN Chat nạp TƯỜNG MINH từng thư viện QNN bằng `System.load()` với đường dẫn tuyệt đối, đúng thứ tự, TRƯỚC khi gọi `Llm.createLLM()` — tài liệu ghi rõ "QNN libraries phải được nạp trước khi gọi createLLM để đăng ký backend đúng cách"; app này trước giờ chỉ đặt file `.so` vào `jniLibs/` và để Android tự nạp theo cơ chế JNI thông thường, không đảm bảo đúng thời điểm. (2) MNN Chat thiết lập 2 biến môi trường `ADSP_LIBRARY_PATH` và `LD_LIBRARY_PATH` trỏ đúng thư mục chứa file `.so`, để runtime RPC của Hexagon DSP tìm thấy thư viện skeleton/stub khi giao tiếp với NPU thật — app này **chưa từng thiết lập 2 biến này**. Ngoài ra phát hiện **thiếu hẳn 1 file `libQnnSystem.so`** ("thư viện giao diện quản lý backend QNN") trong danh sách 5 thành phần bắt buộc mà MNN Chat liệt kê — `build.yml` trước giờ chỉ copy 4/5 file. Xác nhận Snapdragon 888 (SM8350) đúng là Hexagon V68 theo bảng chính thức, khớp với `HEXAGON_ARCH="68"` đã dùng — không phải nguyên nhân. **Đã sửa**: thêm bước copy `libQnnSystem.so` vào `build.yml`; thêm hàm `setupQnnEnvironmentOnce()` trong `MnnBridge.kt` — thiết lập 2 biến môi trường qua `Os.setenv()` + nạp tường minh 5 thư viện QNN bằng `System.load()` đường dẫn tuyệt đối theo đúng thứ tự MNN Chat dùng, gọi đúng 1 lần trước khi thử QNN lần đầu. **CHƯA build/test** — việc cần làm ngay phiên sau: build lại, đổi backend về "Tự động (QNN trước)", thử chat, xem QNN có còn crash không; nếu vẫn crash, đọc thêm `si_addr`/backtrace (mục 39 nâng cấp) để biết chính xác vị trí lỗi còn lại.

47. **[BACKLOG — đã bàn kỹ, CHỦ ĐỘNG HOÃN lại sau khi xong mục 28/33/35/37/39/40/42/44] Provider "GPU ngoài" (mượn/thuê GPU người khác, vd qua Colab) + lớp ẩn danh hoá thực thể.** Bối cảnh: người dùng muốn thêm 1 `AIProvider` mới gọi tới model chạy trên GPU không thuộc sở hữu mình (Colab free hoặc GPU thuê), với yêu cầu bảo mật cao nhất có thể đạt được thật (không phải ảo tưởng "tuyệt đối"). Đã thống nhất kiến trúc phòng thủ theo lớp, KHÔNG làm tới khi mục 28 xong (ưu tiên có model local chạy ổn định trước, giảm phụ thuộc GPU ngoài):
    - **Lớp 1 (ưu tiên cao nhất khi quay lại, rẻ nhất)**: ẩn danh hoá thực thể — thay tên nhân vật/địa danh/thuật ngữ riêng (đọc từ `Character`/`WorldRule`/`GlossaryTerm` có sẵn trong Story Bible) bằng placeholder trước khi gửi, map ngược khi nhận về. Chạy hoàn toàn ở Dart, không tốn hiệu năng GPU.
    - **Lớp 2**: không định danh người gửi (token phiên ngẫu nhiên, tài khoản Google phụ tách biệt khỏi tài khoản chính khi dùng Colab).
    - **Lớp 3**: rải yêu cầu qua nhiều provider/phiên khác nhau theo thời gian (kiến trúc `ApiProviderEntry` đã hỗ trợ sẵn nhiều provider) — không để 1 nơi tích luỹ toàn bộ 1 tác phẩm.
    - **Lớp 4**: không giữ Colab runtime chạy 24/7, không log phía server tự viết.
    - **Lớp 5**: TLS/HTTPS qua Cloudflare Tunnel hoặc ngrok (đã có sẵn theo yêu cầu ban đầu).
    - **Giới hạn đã thống nhất, KHÔNG được quên khi làm**: không lớp nào ở trên ngăn được chủ hạ tầng vật lý (Google/chủ GPU thuê) đọc plaintext nếu họ có quyền hypervisor — mức bảo vệ thật duy nhất cho việc đó là GPU Confidential Computing (NVIDIA H100/H200 CC, có ở 1 số gói GPU thuê riêng trả phí như Azure NCC H100 v5, KHÔNG có ở Colab miễn phí), chấp nhận ~5-15% chậm hơn. UI thêm provider "GPU ngoài" phải hiển thị rõ giới hạn này, không được quảng cáo là "an toàn tuyệt đối".
    - Việc cần code khi quay lại: module ẩn danh hoá 2 chiều (Dart) + `TrustedRemoteGpuProvider` (kế thừa `OpenAICompatibleProvider`) + khối cảnh báo rõ trong UI màn thêm provider.

48. **[SỬA XONG — 2026-07-31, tiếp tục mục 43] Bug nút "+" ở `story_bible_screen.dart` luôn mở "Nhân vật mới" bất kể đang ở tab nào (Nhân vật/Luật thế giới/Văn phong/Thuật ngữ) — xác nhận qua 3 ảnh chụp màn hình giống hệt nhau.** Nguyên nhân: `Builder(builder: (context) { final tabIndex = DefaultTabController.of(context).index; ... })` — `Builder` không tự động lắng nghe `TabController`; đọc `.index` bên trong nó chỉ lấy đúng giá trị tại lần build ĐẦU TIÊN của toàn màn hình, vuốt/chạm đổi tab sau đó KHÔNG kích hoạt build lại FAB (vì `TabController.index` đổi qua `notifyListeners()`, không qua cơ chế InheritedWidget rebuild thông thường). **Đã sửa (lần 1, có bug — xem mục 49)**: đổi `Builder` thành `AnimatedBuilder(animation: DefaultTabController.of(context), builder: ...)`.

49. **[BUG DO CHÍNH PHIÊN NÀY GÂY RA, ĐÃ SỬA TRIỆT ĐỂ CÙNG NGÀY — 2026-07-31] Bản sửa mục 48 làm toàn bộ tab "Bách khoa" hiện MÀN HÌNH TRẮNG XOÁ** (xác nhận qua ảnh chụp màn hình thật của người dùng — chỉ còn thanh điều hướng dưới, không còn AppBar/TabBar/nội dung/FAB nào). **Nguyên nhân**: `DefaultTabController.of(context)` đặt ở vị trí tham số `animation:` của `AnimatedBuilder` được tính TOÁN NGAY LẬP TỨC bằng `context` CỦA CHÍNH `build()` hàm này — context đó nằm ở vị trí TRÊN `DefaultTabController` trong cây widget thật sự dựng ra (vì `DefaultTabController` chính là widget được TRẢ VỀ bởi lời gọi `build()` này), không phải context nằm DƯỚI nó — nên `.of(context)` luôn thất bại ngay khi build, ném lỗi khiến build() không trả về được gì, và ở bản release Flutter ẩn traceback lỗi, chỉ hiện màn hình trắng/xám trơn thay vì "red screen of death" như bản debug. Đây chính xác là lý do bản gốc dùng `Builder` (không phải quên làm reactive) — `Builder` tạo ra 1 context MỚI, đúng vị trí bên dưới `DefaultTabController` một khi đã mount. **Đã sửa triệt để**: bỏ hẳn `DefaultTabController` khỏi cây widget, cho `_StoryBibleScreenState` (đã có sẵn `SingleTickerProviderStateMixin`) tự sở hữu 1 `TabController` riêng (`late final TabController _tabController`, khởi tạo ở `initState()`, `dispose()` đúng cách), gán trực tiếp vào `TabBar(controller: _tabController)`/`TabBarView(controller: _tabController)`, và FAB dùng thẳng `AnimatedBuilder(animation: _tabController, builder: (context, _) { final tabIndex = _tabController.index; ... })` — không còn `.of(context)` ở đâu trong màn hình này nữa, loại bỏ hẳn cả nhóm lỗi định phạm vi context (context scoping) liên quan tới `InheritedWidget`. **Bài học lớn**: khi 1 sửa lỗi cần đọc giá trị từ `XxxController.of(context)` bên trong 1 vị trí không phải `build(BuildContext context)` trực tiếp (ví dụ tham số của 1 widget con), phải kiểm tra kỹ CONTEXT NÀO đang được dùng có thực sự nằm DƯỚI ancestor widget cần tìm trong cây ĐàDỰNG hay không — nếu nghi ngờ, cách an toàn nhất luôn là cho `State` tự sở hữu `Controller` riêng thay vì phụ thuộc `Default*Controller.of(context)`.

50. **[SỬA XONG — 2026-07-31] `setState()` không kiểm tra `mounted` sau khi `await` AI sinh văn bản dài (30 giây tới vài phút) trong `chapter_editor_screen.dart` — lặp lại y hệt ở 4 hàm: `_continueWithAI`, `_fleshOutOutline`, `_checkConsistency`, `_applyRewrite`.** Người dùng báo "tạo chương thì cũng dễ bị văng" — đúng nguyên nhân: nếu thoát màn hình (back/chuyển tab) trong lúc đang chờ AI, khi tác vụ hoàn tất và gọi `setState()` trên 1 `State` đã bị huỷ (`dispose()`), Flutter ném `setState() called after dispose()`, crash. **Đã sửa**: thêm `if (!mounted) return;`/`if (mounted) {...}` bao quanh MỌI `setState()` xảy ra sau 1 điểm `await` trong cả 4 hàm trên, bao gồm cả nhánh `finally` (dùng để tắt cờ `generating`/`fleshingOut`/`checking`/`rewriting`).

51. **[SỬA XONG — 2026-07-31] `rag_service.dart` — model tự bịa ra nội dung Story Bible giả khi Story Bible thực tế đang TRỐNG.** Người dùng báo hiện tượng model trả lời như đã có sẵn 1 bộ Story Bible chi tiết (thế giới ma thuật, nhân vật chính...) dù mới gõ "alo", nghi ngờ spyware/bộ lọc ẩn — **xác nhận không phải**, là hallucination thuần tuý do lỗi prompt: `buildContext()` trả về chuỗi RỖNG khi chưa có luật thế giới/nhân vật/chương nào, nhưng `buildSystemPrompt()` vẫn viết cứng "Dưới đây là dữ liệu Story Bible... [để trống]... tham chiếu đúng Story Bible" — ra lệnh model tham chiếu 1 thứ không tồn tại, model 7B (đặc biệt bản "uncensored") chọn cách tự dựng nội dung cho hợp lý thay vì báo "không có dữ liệu". **Đã sửa**: khi context rỗng, đổi hẳn nội dung — nói thẳng "Story Bible hiện đang trống, TUYỆT ĐỐI KHÔNG được tự bịa", áp dụng cho cả `buildSystemPrompt()` (chat) và `buildConsistencyCheckPrompt()` (kiểm tra mâu thuẫn chương).

52. **[XÁC NHẬN QUAN TRỌNG NHẤT VỀ QNN, KẾT THÚC ĐIỀU TRA TỪ MỤC 43/46 — 2026-07-31] QNN crash SIGSEGV không phải lỗi packaging/config có thể vá bằng code — máy test nằm DƯỚI mức phần cứng tối thiểu mà chính Qualcomm công bố cho LLM-trên-NPU.** Tra cứu tài liệu chính thức Qualcomm AI Hub Models/Genie (công cụ LLM-trên-NPU trưởng thành nhất, do chính Qualcomm phát triển): yêu cầu tối thiểu **Hexagon architecture v73**. Snapdragon 888 dùng Hexagon 780 = **v68** (xác nhận qua Wikipedia + bảng ánh xạ kiến trúc Qualcomm) — thấp hơn 2 thế hệ (v73 ứng với Snapdragon 8 Gen 2 trở lên). RAM 16GB của máy dư thừa theo yêu cầu Qualcomm nêu cho model 7B — cái thiếu KHÔNG phải RAM, mà là thế hệ NPU. Giải thích hợp lý cho toàn bộ chuỗi crash: LLM có KV-cache đổi hình dạng đồ thị (shape) liên tục qua từng token, đòi hỏi QNN compiler (vốn biên dịch đồ thị TĨNH offline) phải tách thành hàng chục đồ thị con cố định — hỗ trợ attention/RoPE trên HTP mới được bổ sung ở các thế hệ Hexagon gần đây hơn hẳn hỗ trợ tích chập (convolution — thứ NPU đời cũ như v68 đã làm tốt từ lâu, giải thích vì sao NPU chạy Stable Diffusion 1.5 — đồ thị tĩnh, không đổi hình dạng — chạy tốt trên cùng máy này). Model dùng trong app (kể cả tự convert bằng `LocalNovel_Convert_Model_To_MNN.ipynb`) cũng CHƯA từng qua bước biên dịch riêng cho QNN (`generate_llm_qnn.py` + build cờ `-DMNN_QNN_CONVERT_MODE=ON`, cần QNN SDK trên máy tính) — càng củng cố kết luận trên. **Quyết định đã thống nhất với người dùng**: chấp nhận GPU (OpenCL) làm đường chính, tối ưu hết mức (mục 5.54); QNN chuyển hẳn thành lựa chọn thử nghiệm CÓ THỂ BẬT THỦ CÔNG, không xoá code (`backendPreference=3`), dành cho trường hợp đổi sang máy chip mới hơn (Snapdragon 8 Gen 2+) sau này.

53. **[NÂNG CẤP CƠ CHẾ AN TOÀN CHO QNN — 2026-07-31, thay thế mục 39 khi backendPreference=3 được bật] `sigsetjmp`/`siglongjmp` chỉ bắt được crash TỨC THỜI (SIGSEGV ngay lập tức), KHÔNG bắt được TREO VÔ HẠN.** Ảnh chụp màn hình thật cho thấy có lần "Đang chạy... 6545s" (~109 phút)/"1925s" (~32 phút) KHÔNG hề crash, chỉ đứng im không ra chữ — rất có thể QNN đang chờ phản hồi từ Hexagon DSP qua FastRPC mà không bao giờ trả lời, không phải signal nào cả. **Đã thay** cơ chế bắt crash bằng cách ly tiến trình con (`fork()` + `pipe()` + `poll()` với timeout 90 giây): tiến trình con thử `Llm::createLLM()` + `load()` backend QNN thuần C++ (không đụng JNI/JVM sau `fork()` — an toàn); tiến trình cha chờ kết quả có giới hạn thời gian bằng `poll()`, nếu tiến trình con CRASH (bắt qua `waitpid`) hoặc TREO quá 90s (chủ động `SIGKILL`), tiến trình cha (app thật) không hề bị ảnh hưởng, rơi xuống OpenCL ngay. Nếu probe báo thành công, tiến trình cha tự load lại QNN thật (không dùng chung bộ nhớ giữa 2 tiến trình được). Cơ chế này giờ chỉ chạy khi `backendPreference=3` (xem mục 52).

54. **[SỬA XONG — 2026-07-31, theo quyết định mục 52] Tối ưu tốc độ GPU thật sự theo đúng khuyến nghị chính thức MNN — trước đây thiếu hoàn toàn.** Config OpenCL cũ chỉ có `backend_type` + `use_mmap`, thiếu 3 tham số tài liệu MNN khuyến nghị rõ ràng để tăng tốc: `"precision": "low"` (ưu tiên fp16, nhanh hơn trên GPU di động Adreno), `"memory": "low"` (bật lượng tử hoá runtime, giảm băng thông bộ nhớ — nút thắt cổ chai lớn nhất khi chạy LLM trên GPU di động, không phải tốc độ tính toán thuần), `"thread_num": 68` (giá trị cụ thể tài liệu MNN chỉ định riêng cho suy luận OpenCL). Thêm `"tmp_path"` trỏ vào cache dir riêng của app (JNI mới `nativeSetCacheDir`, dùng `context.cacheDir` bên Kotlin) — MNN OpenCL tự lưu cache kết quả autotuning kernel vào đây, các lần load SAU tái sử dụng cache thay vì dò lại từ đầu mỗi lần mở model. Cập nhật UI `local_optimization_screen.dart`: nhãn "Tự động (QNN trước)" → "Tự động (GPU tối ưu)", thêm lựa chọn thứ 4 "Thử QNN (thử nghiệm)" ứng với `backendPreference=3`.

55. **[SỬA XONG — 2026-07-31] Xử lý tài liệu (dịch/tóm tắt) thiếu 2 việc: không có UI chỉnh prompt, và không thể tiếp tục dở dang nếu văng giữa chừng.** `DocumentService.processDocument()` đã có sẵn tham số `customInstruction` từ đầu nhưng CHƯA từng có UI nào truyền vào — người dùng phát hiện đúng. **Đã sửa**: thêm hộp thoại chỉnh prompt trước khi chạy (`_askCustomPrompt`) trong `document_screen.dart`, hiện sẵn prompt mặc định để người dùng biết đang dùng gì. Đồng thời `processDocument()` trước đây LUÔN xử lý lại từ đoạn đầu tiên kể cả đoạn đã có kết quả — với tài liệu dài (dễ dính lỗi native khi `generate()`, phần này KHÔNG được cách ly như bước `loadModel` ở mục 53), văng giữa chừng mất hết tiến độ. **Đã sửa**: thêm `resumeFromProgress` (mặc định `true`) — bỏ qua đoạn đã có `resultText`, chỉ xử lý tiếp đoạn còn thiếu.

56. **[SỬA XONG — 2026-07-31] Android 13+ "vuốt back dự đoán" (predictive back gesture) có thể thoát màn hình ngay giữa lúc AI đang chạy (tạo chương/dịch/tóm tắt), làm mất kết quả đang chờ dù mounted-guard (mục 50) đã tránh được crash.** Chưa xác định được cơ chế kỹ thuật chính xác 100% vì không có máy thật để dựng lại (nghi ngờ liên quan tới cách Flutter/Android 13+ xử lý cử chỉ back mới nếu app chưa khai báo rõ ràng qua `PopScope`), nhưng đây là hành vi Flutter khuyến nghị xử lý rõ ràng bằng `PopScope` (thay thế `WillPopScope` cũ) khi có tác vụ quan trọng đang chạy — dự án dùng Dart SDK `>=3.3.0` nên `PopScope` có sẵn. **Đã thêm**: `PopScope(canPop: !busy, onPopInvokedWithPop: ...)` bọc `Scaffold` trong cả `chapter_editor_screen.dart` (biến `busy` gộp sẵn 4 cờ `generating/fleshingOut/checking/rewriting`) và `document_screen.dart` (cờ mới `_processingDoc`) — chặn back trong lúc đang chạy, hiện rõ SnackBar giải thích + nút "Huỷ & thoát" để người dùng chủ động quyết định thay vì bị thoát âm thầm. **CHƯA build/test thật trên máy** — việc cần làm ở phiên sau: xác nhận vuốt back trong lúc đang chạy AI bị chặn đúng như mong đợi, không còn mất tiến độ.

57. **[TÍNH NĂNG MỚI, CHƯA build/test — 2026-07-31] Tìm kiếm web — bật/tắt THỦ CÔNG theo yêu cầu rõ ràng của người dùng ("không nhất thiết lúc nào cũng tìm kiếm mạng, khi nào cần thì mới bật").** Thêm `lib/services/web_search_service.dart` — gọi endpoint HTML rút gọn của DuckDuckGo (`html.duckduckgo.com/html/`, KHÔNG cần đăng ký API key), parse bằng package `html` (mới thêm vào `pubspec.yaml`) qua CSS selector cố định (`.result__body`, `.result__title`, `.result__snippet`) — có rủi ro DuckDuckGo đổi cấu trúc trang làm hỏng việc trích xuất, khi đó trả về danh sách rỗng và báo rõ cho người dùng thay vì crash/im lặng. Thêm nút bật/tắt (icon địa cầu) trong `chat_screen.dart` cạnh nút đính kèm tài liệu — mặc định TẮT, chỉ áp dụng cho phiên chat hiện tại (không lưu lại), khi bật hiện rõ giai đoạn "🔍 Đang tìm kiếm web..." trước khi tiếp tục sinh văn bản như bình thường. **Cân nhắc bảo mật/quyền hạn CHƯA xác nhận**: `AndroidManifest.xml` không nằm trong repo (được `flutter create` tự sinh trong `build.yml`), nên KHÔNG xác nhận được chắc chắn quyền `INTERNET` đã có sẵn hay chưa — suy luận hợp lý là CÓ (vì `AnthropicProvider`/`OpenAICompatibleProvider` đã dùng `http` package gọi mạng từ trước), nhưng cần xác nhận thật khi build/test lần đầu tính năng này. **Việc cần làm ở phiên sau**: build lại, bật thử tìm kiếm web trong chat, xác nhận có kết quả trả về thật (không lỗi mạng/quyền), và tinh chỉnh CSS selector nếu DuckDuckGo đã đổi cấu trúc HTML.

58. **[ĐÃ SỬA, CHƯA build/test — 2026-07-31] `build.yml` từng để các bước `cp` file QNN thất bại ÂM THẦM (`|| echo "THIẾU..."` không dừng build), có thể tạo ra APK "build thành công" nhưng thiếu hẳn file QNN mà không ai biết cho tới khi cài lên máy thật.** Dù QNN giờ không còn trên đường mặc định (mục 52), vẫn cần đúng cho `backendPreference=3` (thử nghiệm) hoạt động nếu người dùng chọn dùng. **Đã sửa**: mọi lệnh `cp` file QNN giờ DỪNG BUILD NGAY nếu thất bại (`|| { echo ...; exit 1; }`), và thêm bước xác minh CUỐI CÙNG ngay trên chính file APK (`unzip` thật, kiểm tra `lib/arm64-v8a/` có đủ 5 file QNN + `libmnn_bridge.so` không) trước khi upload artifact — không còn tin tưởng mù quáng vào "copy vào jniLibs xong là chắc chắn có trong APK".

59. **[SỬA XONG, ĐÃ XÁC NHẬN QUA LOG BUILD THẬT — 2026-07-31] Lỗi biên dịch Dart ở mục 56 (`PopScope`): dùng sai tên tham số `onPopInvokedWithPop` (không tồn tại — tự bịa nhầm tên).** Log build APK #67 báo lỗi rõ ràng ở cả 2 file `chapter_editor_screen.dart:642` và `document_screen.dart:234`: `Error: No named parameter with the name 'onPopInvokedWithPop'`. Tra cứu API `PopScope` thật của Flutter (bản pin trong CI là `stable-3.44.7`): tham số đúng là **`onPopInvokedWithResult`**, nhận `(bool didPop, Object? result)` — không phải `(bool didPop)` như đã viết nhầm. Lịch sử API: `onPopInvoked` (cũ, `(bool didPop)`) → deprecated từ Flutter 3.22 → thay bằng `onPopInvokedWithResult` (thêm tham số `result` kiểu generic). **Đã sửa** cả 2 chỗ dùng `onPopInvokedWithResult: (didPop, result) { ... }`. **Bài học**: khi dùng API Flutter có lịch sử đổi tên tham số qua nhiều phiên bản (như `PopScope`), phải tra cứu ĐÚNG PHIÊN BẢN Flutter đang pin trong `build.yml` (ở đây là `stable-3.44.7`) thay vì suy đoán tên tham số từ trí nhớ — nhất là khi có nhiều tên gần giống nhau dễ nhầm (`onPopInvoked`/`onPopInvokedWithResult`/tên bịa `onPopInvokedWithPop`).

61. **[SỬA XONG, CHƯA build/test — 2026-07-31] Cải tiến xử lý tài liệu dài (dịch/tóm tắt), theo 4 câu hỏi kiến trúc người dùng đặt ra — 3/4 điểm có lỗ hổng thật, đã sửa:**
    - **Thanh tiến trình**: trước chỉ có spinner tròn + chữ "d/t đoạn", giờ có `LinearProgressIndicator` hiện % thật.
    - **Chọn phạm vi đoạn**: trước LUÔN xử lý toàn bộ tài liệu, giờ có `RangeSlider` trong hộp thoại cấu hình (`_askProcessConfig`) cho chọn "từ đoạn __ đến đoạn __" — `processDocument()` nhận thêm `startIndex`/`endIndex` (0-based, dùng `sublist` trên danh sách đã `ORDER BY idx ASC` từ DB).
    - **Chạy nền khi tắt màn hình — LỖ HỔNG THẬT đã tìm ra và sửa**: `processDocument()` trước đây KHÔNG gọi `beginPipeline()`/`endPipeline()` (đã có sẵn từ trước, dùng cho `TranslationService`) — mỗi đoạn gọi `generate()` riêng lẻ tự bật/tắt Foreground Service ĐỘC LẬP (xem cơ chế ở mục 2.3 và `MnnBridge.kt`: `if (pipelineActive) updateStage else start`, rồi `if (!pipelineActive) stop` trong `finally`) — với tài liệu 100+ đoạn là 100+ lần bật/tắt liên tục, tạo khe hở giữa các đoạn có thể bị Android trừ tiến trình nếu tắt màn hình đúng lúc đó. **Đã sửa**: bọc cả vòng lặp nhiều đoạn bằng `LocalLlamaProvider.beginPipeline()`/`updatePipelineStage()`/`endPipeline()` (chỉ áp dụng khi `provider is LocalLlamaProvider` — cloud API không cần) — giữ 1 thông báo Foreground Service LIÊN TỤC suốt cả quá trình thay vì chớp tắt từng đoạn.
    - **Huỷ giữa chừng**: `resumeFromProgress` (mục 55) đã đảm bảo tiếp tục đúng chỗ dừng khi CHẠY LẠI, nhưng trước đây không có cách chủ động dừng SẠCH — chỉ có `PopScope` chặn back (mục 56). **Đã thêm**: nút "Huỷ" trong hộp thoại tiến trình, đặt cờ hợp tác (`isCancelled` callback) được `processDocument()` kiểm tra GIỮA MỖI đoạn (không ngắt dở đoạn đang chạy — không an toàn để huỷ nửa chừng 1 lệnh `generate()` đang gọi, chỉ có thể không bắt đầu đoạn kế tiếp).
    - **Xuất kết quả từng phần**: kiểm tra lại code — **đã hoạt động từ trước, không cần sửa**: `exportResult()` xử lý đoạn chưa có `resultText` bằng placeholder `[Chưa xử lý đoạn N]` thay vì chặn lại, nút "Xuất kết quả" trong UI luôn bật sẵn không phụ thuộc trạng thái xử lý.
    - **Việc cần làm ở phiên sau**: build/test thật cả 3 điểm đã sửa — đặc biệt xác nhận Foreground Service giữ được 1 thông báo liên tục (không chớp tắt) khi theo dõi qua thanh thông báo Android trong lúc xử lý tài liệu nhiều đoạn.

62. **[CRASH THẬT MỚI, KHÁC HẲN QNN, CHƯA CÓ CÁCH VÁ TRIỆT ĐỂ — 2026-08-01] SIGSEGV xảy ra ngay TRONG LÚC `nativeGenerate()` (không phải `nativeLoadModel()`) trên backend OpenCL (GPU) — xác nhận qua log thật kèm backtrace đầy đủ lần đầu tiên có symbol tên hàm rõ ràng của MNN.** Log cho thấy: model 1.5B (nhỏ hơn hẳn 7B, để loại trừ khả năng do model quá lớn) nạp OpenCL thành công, generate lần 1 (chat "alo", prompt ngắn) chạy xong không lỗi, nhưng generate lần 2 — **đúng lúc `DocumentService.processDocument()` dịch 1 đoạn tài liệu dài** (system prompt dịch thuật + đoạn văn gốc, tổng 3871 ký tự, dài hơn hẳn lần 1) — crash SIGSEGV tại địa chỉ `0x7031a8e000`. Backtrace (lần đầu có tên hàm rõ, không còn toàn "khong ro thieu symbol table" như các lần trước) cho thấy chuỗi gọi: `Java_..._nativeGenerate` → `Llm::response()` → `Llm::generate()` → `Llm::forwardVec()` → `Llm::forwardRaw()` → `MNN::Session::run()` → `MNN::ThreadPool::enqueue()` — tức là crash xảy ra **trên 1 luồng WORKER do MNN tự tạo ra để tính toán song song** (thấy rõ ở đáy backtrace: `art::Thread::CreateCallback` → `pthread_create`), không phải trên luồng chính gọi JNI. **Ý nghĩa quan trọng**: cơ chế cách ly tiến trình con (`fork()` + timeout, mục 53) CHỈ bọc bước `nativeLoadModel()` với QNN — KHÔNG bọc `nativeGenerate()` — nên loại crash này (xảy ra giữa lúc sinh văn bản, trên GPU/OpenCL — con đường vừa được xác nhận là "đường chính, đã tối ưu" ở mục 52/54) **hoàn toàn không được bảo vệ**, làm chết cả app ngay lập tức. **Nghi ngờ hàng đầu** (chưa xác nhận được, cần điều tra thêm nếu tái diễn): độ dài prompt lớn hơn hẳn (3871 ký tự so với 543 ký tự chạy được) có thể chạm vào 1 edge case về kích thước buffer/tensor trong `ThreadPool`/`Session::run()` của chính MNN — đây là lỗi NẰM TRONG chính thư viện MNN (`libMNN.so`), không phải trong code cầu nối (`libmnn_bridge.so`) của app, nên KHÔNG có cách vá trực tiếp từ phía app, chỉ có thể tránh/giảm thiểu.
    - **KHÔNG CÓ CÁCH cô lập crash loại này bằng kỹ thuật tương tự mục 53** (fork từng lần `generate()`) — vì phải fork() lại toàn bộ tiến trình cho MỖI LẦN sinh văn bản sẽ cực kỳ chậm (phải nạp lại model mỗi lần, mất hết lợi ích giữ model resident trong RAM), không khả thi cho việc dùng thực tế. Cách duy nhất triệt để là chuyển hẳn việc chạy MNN sang 1 **tiến trình Android riêng** (`android:process=":modelservice"` trong Manifest, giao tiếp qua AIDL/Binder) — 1 thay đổi kiến trúc lớn, CHƯA làm, cần cân nhắc kỹ ở phiên sau nếu loại crash này tái diễn thường xuyên.
    - **Đã làm ngay được (giảm thiệt hại, không phải sửa gốc)**: người dùng hỏi đúng trọng tâm "sao không có nút tiếp tục nhiệm vụ dang dở" — **thực ra ĐÃ CÓ SẴN** nhờ `resumeFromProgress` (mục 55/61: mỗi đoạn lưu `resultText` vào DB ngay khi xong, đoạn đang crash dở là đoạn DUY NHẤT mất, mọi đoạn trước đó vẫn giữ nguyên) — nhưng TRƯỚC ĐÂY không có gì hiển thị trên danh sách tài liệu để biết còn dở dang hay đã xong, dễ hiểu lầm phải bắt đầu lại từ đầu. **Đã sửa `document_screen.dart`**: `_load()` giờ đếm luôn số đoạn đã có `resultText` cho mỗi tài liệu (`_doneCounts`), danh sách hiện rõ nhãn "Dang dở: X/Y đoạn đã xong" hoặc dấu tick xanh nếu đã xong hết, và nút đổi nhãn động thành "Tiếp tục dịch (X/Y)"/"Tiếp tục tóm tắt (X/Y)" thay vì luôn ghi "Dịch toàn bộ"/"Tóm tắt" như chưa từng chạy. **CHƯA build/test thật.**

63. **[XÁC NHẬN CRASH MỤC 62 TÁI DIỄN — BẰNG CHỨNG THỨ 2, CÙNG PATTERN — 2026-08-01] Log lần 2 (model 7B lần này, không phải 1.5B) cho thấy CHÍNH XÁC cùng 1 kiểu crash: generate lần 1 (prompt 543 ký tự, chat "alo") chạy ổn, generate lần 2 (prompt 3832 ký tự, dịch tài liệu) crash SIGSEGV, backtrace đáy giống hệt mục 62 (`libMNN.so` các offset `0x3ce33c`/`0x3d0438`/`0x339c00` gần các offset lần trước, cùng nằm trong nhánh gọi từ `ThreadPool`/`libc pthread`).** Củng cố mạnh giả thuyết: **crash liên quan tới ĐỘ DÀI PROMPT** (luôn xảy ra ở lần generate có prompt dài ~3800+ ký tự, không phải do model 7B hay 1.5B — loại trừ hẳn khả năng do kích thước model) — rất có thể là 1 giới hạn/edge case cứng trong `MNN::ThreadPool`/`Session::run()` khi xử lý sequence length hoặc kích thước tensor vượt 1 ngưỡng nào đó trên backend OpenCL. **Quan sát phụ đáng chú ý (log lần 2)**: lần `loadModel` ĐẦU TIÊN trong phiên này thất bại hoàn toàn (`llmSlot->load() (OpenCL) TRA VE = FALSE` VÀ `llmSlot->load() (CPU) TRA VE = FALSE` — cả 2 backend cùng fail, không phải crash, chỉ trả về false) kèm cảnh báo `khong tim thay config.json — thu muc RONG` — rất giống hiện tượng đọc file trên storage ngoài (`/storage/emulated/0/Download/...`) chưa sẵn sàng ngay lúc app vừa khởi động (storage mount trễ hoặc quyền truy cập chưa cấp xong) — lần thử THỨ HAI (35s sau) mới đọc được `config.json` bình thường và load thành công. **Chưa đủ bằng chứng để kết luận chắc chắn, cần theo dõi thêm nếu tái diễn** — nếu lặp lại, có thể cần thêm bước "thử lại tự động sau vài giây" ở `ensureLoaded()` khi lần đầu thất bại ngay từ bước đọc `config.json`.
    - **Đã thêm màn hình MỚI theo yêu cầu người dùng: `document_chunks_screen.dart`** — thay vì chỉ chọn 1 khoảng liên tục (`RangeSlider`, mục 61), giờ có màn hình riêng cho từng tài liệu hiện DANH SÁCH TỪNG ĐOẠN cụ thể, mỗi đoạn có checkbox chọn RỜI RẠC (không bắt buộc liền kề), icon xanh/xám cho biết đã xong/chưa xong, xem trước 90 ký tự đầu + bấm vào xem toàn văn (gốc + kết quả) trong hộp thoại. Có nút chọn nhanh "Chọn tất cả"/"Chỉ chọn đoạn chưa xong"/"Bỏ chọn tất cả". Lý do trực tiếp: nếu xác định được đúng 1 đoạn cụ thể liên tục gây crash (mục 62/63), có thể BỎ QUA riêng đoạn đó, xử lý mọi đoạn khác trước, quay lại xử lý đoạn khó sau. **`processDocument()` thêm tham số `chunkIndices` (Set rời rạc, khác `startIndex`/`endIndex` liên tục)** — khi dùng chọn thủ công, LUÔN xử lý lại các đoạn được chọn (bỏ qua `resumeFromProgress`, vì chọn lại thủ công nghĩa là chủ động muốn làm lại). Mở màn hình này qua nút "Chọn từng đoạn" mới thêm trên mỗi thẻ tài liệu trong `document_screen.dart`. **CHƯA build/test thật.**

64. **[PHÁT HIỆN NGHIÊM TRỌNG HƠN HẲN MỤC 62/63 — CRASH LÀM HỎNG TRẠNG THÁI NỘI BỘ, LAN SANG MỌI ĐOẠN SAU — 2026-08-01] Đọc kỹ log thứ 3 (cùng pattern SIGSEGV lúc dịch tài liệu) phát hiện: đây KHÔNG chỉ là 1 crash đơn lẻ mất 1 đoạn — mà là 1 chuỗi hỏng hóc lan rộng, kết thúc bằng SIGABRT làm chết hẳn app.** Trình tự chính xác quan sát được:
    - Đoạn 1: `llm->response()` "chạy xong không crash" nhưng chỉ trả về **17 ký tự** cho 1 đoạn văn 800+ ký tự nguồn, mất 12.8 giây, `LlmContext` báo `status=4, gen_seq_len=3` (chỉ sinh đúng 3 token!) — kết quả này **VẪN ĐƯỢC LƯU vào DB và đánh dấu "đã xong"** (dấu tick xanh) dù rõ ràng là rác (người dùng xác nhận qua ảnh chụp: nội dung lưu là `"dan生态环境"` — lẫn cả chữ Hán, hoàn toàn không phải bản dịch tiếng Việt của đoạn văn gốc).
    - **NGAY SAU ĐÓ**: SIGSEGV tại địa chỉ `0x0` (null pointer) — signal handler bắt được, log lại, nhưng **process KHÔNG chết ngay** (khác với các lần trước) — điều này cho thấy signal xảy ra trên 1 luồng phụ (ThreadPool worker, giống mục 62) và vì lý do nào đó (cơ chế signal chain của ART, hoặc timing) không lập tức kết liễu tiến trình chính.
    - **11 đoạn tiếp theo**: mỗi đoạn `generate()` "chạy xong không crash" nhưng **hoàn thành trong ĐÚNG 0ms** (không phải suy luận thật), kết quả **RỖNG HOÀN TOÀN**, và **`LlmContext` báo CHÍNH XÁC `status=4, prompt_len=848, gen_seq_len=3` GIỐNG HỆT NHAU cho mọi đoạn** dù `prompt_len` thật in ra ngay phía trên mỗi lần đều KHÁC NHAU (3998, 3660, 3991, 3995, 3692, 4023, 3973, 3953, 3851, 3901, 4014 ký tự) — bằng chứng rõ ràng: đối tượng `Llm`/`Session` phía native đã **hỏng bộ nhớ (heap corruption)** ngay sau lần SIGSEGV đầu tiên, các lệnh gọi sau đó không còn thực hiện suy luận thật nữa, chỉ trả về ngay lập tức 1 trạng thái "xác chết" đã lưu sẵn từ trước lúc hỏng.
    - **Cuối cùng**: SIGABRT (signal 6) — backtrace cho thấy `abort()` → `art::Runtime::Abort` → `android::base::LogMessage` — đây là **chữ ký điển hình của bộ dò lỗi bộ nhớ của Android** (Scudo/hardened allocator) bắt được tham nhũng heap tích lũy từ trước và chủ động `abort()` để tránh hỏng nặng hơn — đây mới là nguyên nhân app **thật sự chết hẳn**, không phải SIGSEGV đầu tiên.
    - **Ý nghĩa quan trọng nhất**: các đoạn "đã xong" (dấu tick xanh) trong khoảng thời gian giữa lần SIGSEGV đầu và lúc app chết hẳn **ĐỀU LÀ RÁC**, không phải kết quả thật — nhưng UI trước đây (kể cả bản mới thêm dấu tick xanh ở mục 62) không có cách nào phân biệt được "xong thật" và "xong giả" — chỉ cần `resultText` không rỗng là hiện tick xanh, đúng như người dùng phát hiện qua ảnh chụp: "đoạn 1 đã xong, nhưng kết quả là cái gì vậy".
    - **Đã sửa `document_service.dart`**: thêm class `DocumentProcessingAnomalyException` — sau MỖI lần `generate()`, kiểm tra kết quả có "trông hợp lý" không (rỗng, HOẶC ngắn hơn 15% độ dài văn bản nguồn khi nguồn dài trên 50 ký tự) — nếu bất thường, **NÉM EXCEPTION NGAY, KHÔNG LƯU kết quả rác vào DB**, dừng hẳn vòng lặp xử lý nhiều đoạn tại đó thay vì chạy tiếp qua hàng chục đoạn khác cũng sẽ ra rác (vì trạng thái native đã hỏng). `document_screen.dart` và `document_chunks_screen.dart` đều đã cập nhật: gọi `_load()` ngay cả khi lỗi (để cập nhật đúng số đoạn ĐÃ THẬT SỰ xong trước khi gặp bất thường), hiện thông báo lỗi rõ ràng nêu đúng số đoạn gặp vấn đề, thời gian hiện lâu hơn (8 giây) để đọc kịp.
    - **CHƯA sửa được nguyên nhân gốc** (heap corruption bên trong `libMNN.so`) — đây vẫn là lỗi nằm trong chính thư viện MNN, ngoài khả năng vá từ phía app. Việc vừa làm chỉ NGĂN THIỆT HẠI LAN RỘNG (không lưu rác, dừng sớm) chứ không ngăn được crash gốc. **Nếu cần chặn triệt để, phương án duy nhất còn lại là chuyển MNN sang chạy ở 1 tiến trình Android riêng** (đã ghi ở mục 62) — chưa làm, cần cân nhắc mức độ ưu tiên ở phiên sau tuỳ tần suất tái diễn. **CHƯA build/test thật.**

65. **[LÀM RÕ KIẾN TRÚC + TỐI ƯU TỐC ĐỘ THẬT MỚI — 2026-08-01] Người dùng hỏi 2 việc: (a) tách MNN sang process riêng (mục 62) có giúp nhanh hơn không, (b) GGUF/llama.cpp có phải lựa chọn tốc độ tốt hơn không, công nghệ nào giảm thời gian chờ.**
    - **(a) Đã làm rõ, KHÔNG cần sửa code**: tách process CHỈ giúp cô lập crash (model lỗi không kéo chết cả app UI), **KHÔNG giúp nhanh hơn** — tốc độ do phần cứng GPU/CPU + thư viện MNN + cấu hình quyết định, không phụ thuộc process nào chạy nó. Thậm chí IPC/Binder giữa 2 process cộng thêm 1 chút overhead (dù nhỏ so với thời gian tính toán thật), nên tách process nếu làm có thể CHẬM HƠN chút ít, không nhanh hơn.
    - **(b) Tra cứu tài liệu chính thức `llama.cpp` (`docs/backend/OPENCL.md`)**: backend OpenCL cho Adreno chỉ liệt kê **đã kiểm chứng** trên Snapdragon 8 Gen 3/8 Elite (Adreno 750/830) — **KHÔNG có Adreno 660** (Snapdragon 888, máy test) trong danh sách. Vulkan trên Adreno được chính tài liệu cộng đồng ghi "có thể chậm nếu chưa vá driver". Kết luận: GGUF/llama.cpp **không chắc chắn nhanh hơn** trên đúng phần cứng này — cùng vùng chưa kiểm chứng như MNN, cần thử nghiệm thật (không phải sửa code ngay) mới biết, không phải giải pháp chắc ăn.
    - **Đã tìm và áp dụng công nghệ THẬT sự giúp giảm thời gian chờ**: tra cứu tài liệu chính thức `alibaba/MNN` (`transformers/README.md`) xác nhận tham số `reuse_kv` ("Whether to reuse the kv cache in multi-turn dialogues. Defaults to false") — đối chiếu thêm 1 issue GitHub thật của MNN dùng chính xác cấu hình này để xác nhận cú pháp đúng, tránh lặp lại sai lầm bịa tên tham số như mục 59. **Code cũ CHƯA hề dùng tham số này** — mỗi lượt chat phải tính lại KV-cache cho TOÀN BỘ system prompt + lịch sử từ đầu, dù phần lớn nội dung đó đã xử lý ở lượt trước.
    - **Đã sửa, luồng đầy đủ từ Dart xuống native**: thêm tham số `reuseKv` vào `AIProvider.generateStream()` (interface trừu tượng, mặc định `false`, 2 provider cloud nhận nhưng bỏ qua vì không có khái niệm tương đương) → `LocalLlamaProvider.generateStream()` truyền xuống qua `MethodChannel` (`'reuseKv': reuseKv`) → `MnnBridge.kt` đọc và đưa vào JSON config gửi cho `nativeGenerate()` (`put("reuse_kv", reuseKv)`) → không cần sửa gì ở tầng C++ vì `llm->set_config(configStr)` đã forward thẳng chuỗi JSON, MNN tự đọc key `reuse_kv`.
    - **Phạm vi bật CÓ CHỦ ĐÍCH, không bật tràn lan**: CHỈ bật `reuseKv: true` ở `chat_screen.dart` (hội thoại nhiều lượt thật sự, mỗi tin nhắn nối tiếp đúng nghĩa lượt trước). **Tắt (`false`, mặc định)** ở: `LocalLlamaProvider.generate()` — dùng cho từng đoạn tài liệu dịch/tóm tắt độc lập, tái dùng sai sẽ lẫn ngữ cảnh giữa các đoạn không liên quan; và "viết tiếp chương" (`chapter_editor_screen.dart`) — nội dung chương có thể bị người dùng sửa tự do giữa các lần gọi AI, phá vỡ giả định "tiền tố chung không đổi" mà `reuse_kv` cần để đúng.
    - **Lưu ý về phạm vi cải thiện**: `reuse_kv` CHỈ giúp lượt chat thứ 2 trở đi trong cùng phiên (không giúp lượt đầu tiên — chưa có gì để tái dùng). **CHƯA build/test thật.**

66. **[PHÁT HIỆN LỖ HỔNG THẬT TRONG `build.yml`, KHÔNG PHẢI TRONG CODE APP — 2026-08-02] Người dùng báo cáo: sau nhiều lần sửa, app bị hệ điều hành KILL khi đang chat chờ AI trả lời mà chuyển sang trình duyệt lướt web rồi quay lại — mất hẳn tiến trình, không phải chỉ mất kết nối.** Điều tra kỹ `build.yml` (không phải file Dart/Kotlin/C++ đã sửa nhiều lần trước đó) phát hiện 2 lỗ hổng thật, tồn tại TỪ TRƯỚC (không phải do các lần sửa gần đây gây ra — người dùng chỉ mới nhận ra/thử đúng kịch bản này lần đầu):
    - **Thiếu quyền `POST_NOTIFICATIONS` trong Manifest, dù `MainActivity.kt` ĐÃ CÓ SẴN code xin quyền này lúc chạy** (`ActivityCompat.requestPermissions`, thêm từ 1 phiên trước — comment cũ trong code còn ghi rõ). Thiếu khai báo `<uses-permission>` tương ứng trong Manifest khiến lệnh xin quyền runtime gần như vô tác dụng (Android không cho xin quyền ứng dụng chưa tự khai báo là mình cần). Thiếu quyền này, thông báo liên tục của Foreground Service có thể không hiển thị đúng cách — nhiều OEM (đặc biệt ASUS ZenUI, đúng máy test) dùng "có thông báo hiển thị hay không" làm 1 tiêu chí quyết định có bảo vệ tiến trình nền hay không.
    - **`foregroundServiceType="dataSync"` không đúng bản chất công việc** — tài liệu Android chính thức mô tả `dataSync` dành cho "upload/download dữ liệu... sẽ bị loại bỏ dần, nên cân nhắc thay thế", trong khi việc thực tế đang làm là **tính toán AI cục bộ**, không phải đồng bộ dữ liệu qua mạng. Loại đúng bản chất hơn là `specialUse` ("khi các loại khác không phù hợp với trường hợp sử dụng") — không bị giới hạn 6 giờ/24 giờ như `dataSync`/`mediaProcessing` trên Android 15+.
    - **Đã sửa `build.yml`**: thêm `<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>` khớp với code runtime đã có sẵn. Đổi `foregroundServiceType` từ `dataSync` sang `specialUse`, kèm bắt buộc thêm `<property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="local_on_device_ai_text_generation" />` bên trong thẻ `<service>` (tra cứu xác nhận qua nhiều nguồn độc lập — thiếu property này Android ném `SecurityException`/crash ngay khi gọi `startForeground()`), và thêm quyền tương ứng bắt buộc `<uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>` (khác hẳn quyền của `dataSync` — mỗi loại `foregroundServiceType` có quyền Manifest riêng, đây là điểm dễ quên nhất khi đổi loại).
    - **Đã tự kiểm tra**: `build.yml` sau khi sửa vẫn là YAML hợp lệ (parse bằng `pyyaml`), và đoạn code Python nhúng bên trong bước sửa Manifest vẫn biên dịch được (`compile()`) không lỗi cú pháp.
    - **CHƯA build/test thật** — đây là suy luận có căn cứ kỹ thuật vững (nhiều nguồn tài liệu Android độc lập xác nhận), nhưng KHÔNG chắc chắn 100% giải quyết dứt điểm triệu chứng "bị kill" — vẫn có khả năng liên quan tới trình quản lý pin đặc thù của ASUS ZenUI (cần người dùng tự thêm app vào danh sách loại trừ tối ưu hoá pin trong Cài đặt máy, việc này nằm ngoài khả năng sửa từ code). Việc cần làm ở phiên sau: build lại, lặp lại đúng kịch bản (chat chờ AI → chuyển trình duyệt → quay lại) xem còn bị kill không; nếu vẫn còn, hướng dẫn người dùng kiểm tra Cài đặt > Pin > tối ưu hoá pin cho từng ứng dụng, loại trừ LocalNovel.

67. **[PHÁT HIỆN QUAN TRỌNG NHẤT VỀ CRASH — RẤT CÓ THỂ LÀ LỜI GIẢI CHO TOÀN BỘ CHUỖI "HEAP CORRUPTION" BÍ ẨN Ở MỤC 62/63/64 — 2026-08-02] Đọc kỹ 1 log thật khác phát hiện bằng chứng trực tiếp: 2 LỆNH `generateStream` CHẠY ĐÈ LÊN NHAU TRÊN CÙNG 1 SLOT, không lệnh nào chờ lệnh kia xong.** Dòng thời gian chính xác trong log:
    - 04:24:48.374 (Dart): `generateStream` bắt đầu — chat, prompt 595 ký tự, slot 0.
    - Native: `nativeGenerate` bắt đầu, gọi `llm->response()`... — **KHÔNG có dòng "trả về xong" cho lệnh này** trước khi dòng tiếp theo xuất hiện.
    - 04:27:00.619 (Dart): `generateStream` bắt đầu LẦN 2 — nội dung khớp `RagService.buildConsistencyCheckPrompt()` (kiểm tra tính nhất quán chương, gọi từ `_checkConsistency()` trong `chapter_editor_screen.dart`), prompt 382 ký tự, **VẪN LÀ SLOT 0**.
    - Native: `nativeGenerate` bắt đầu LẦN 2, gọi `llm->response()` — **TRONG KHI LỆNH 1 VẪN ĐANG CHẠY DỞ**.
    - Ngay sau đó: **30 SIGSEGV liên tiếp**, địa chỉ lỗi khác nhau nhưng cùng 1 vùng bộ nhớ lân cận (`0x70c38...`) — đúng dấu hiệu 2 luồng cùng ghi/đọc chồng chéo lên cùng 1 vùng bộ nhớ chưa được bảo vệ.
    - **Nguyên nhân gốc xác nhận qua chính source code**: `nativeLoadModel()` đã có sẵn khoá chống gọi trùng (`g_loadingInProgress`, dùng `std::atomic::compare_exchange_strong`) — thêm từ rất sớm trong dự án. Nhưng **`nativeGenerate()` KHÔNG HỀ CÓ khoá tương tự** — bất kỳ số lượng lệnh `generate()` nào cũng có thể chạy đồng thời trên cùng 1 slot, không có gì ngăn cản. `Llm::response()` của MNN **không được thiết kế để gọi đồng thời từ nhiều luồng trên cùng 1 instance** (mutate chung KV-cache, buffer `ThreadPool`, tensor nội bộ) — khớp hoàn hảo với mọi triệu chứng "heap corruption" quan sát được trước đó (mục 62: SIGSEGV giữa `ThreadPool::enqueue`; mục 64: trạng thái hỏng lan sang các lệnh sau, kết thúc bằng SIGABRT).
    - **Kịch bản thực tế xảy ra**: người dùng đang chat (chờ AI trả lời) VÀ đồng thời (cùng lúc hoặc chuyển màn hình rất nhanh) bấm "Kiểm tra mâu thuẫn" ở màn hình soạn chương — cả 2 thao tác đều dùng slot 0 (model chính), không có gì ngăn chặn chạy song song.
    - **Đã sửa — 2 tầng phòng thủ**:
      1. **Tầng chính (Kotlin, `MnnBridge.kt`)**: thêm `Mutex` riêng cho từng slot (`generateMutexes`, dùng `kotlinx.coroutines.sync.Mutex`/`withLock`) — bọc quanh lệnh gọi `MnnNative.nativeGenerate()` thật. Lệnh generate() thứ 2 cho CÙNG slot giờ **CHỜ** (xếp hàng, không mất yêu cầu, không bị từ chối) cho tới khi lệnh trước xong hẳn mới chạy — slot 0 và slot 1 (nếu dùng model dịch riêng) vẫn chạy độc lập song song bình thường, đúng kiến trúc "2 slot" đã thiết kế.
      2. **Tầng dự phòng (C++, `mnn_bridge.cpp`)**: thêm `g_generatingInProgress[slot]` (tái dùng cấu trúc `LoadingGuard` RAII đã có sẵn cho `g_loadingInProgress`) — nếu vì lý do nào đó khoá Kotlin bị bỏ qua (lỗi tương lai, code path khác), lệnh generate thứ 2 bị **TỪ CHỐI NGAY LẬP TỨC** thay vì chạy song song và làm hỏng bộ nhớ — hàng phòng thủ thứ 2, trong điều kiện bình thường không bao giờ nên bị kích hoạt.
    - **Đã tự kiểm tra**: biên dịch cú pháp C++ sạch (`g++ -fsyntax-only` với header giả lập), kiểm tra ngoặc bằng stack-parser cho cả 2 file — không lỗi.
    - **CHƯA build/test thật.** Nếu đúng giả thuyết này, các crash "heap corruption" ở mục 62/63/64 (vốn nghi ngờ do độ dài prompt) rất có thể **không hề liên quan tới độ dài prompt** — mà do 2 tác vụ tình cờ chạy chồng chéo đúng lúc đó (document processing chạy nền + có tác vụ khác cũng gọi generate). Việc cần làm ở phiên sau: build lại, cố tình tái tạo kịch bản "vừa chat vừa bấm kiểm tra tính nhất quán chương cùng lúc" xem có còn crash không; nếu hết crash, xác nhận luôn giả thuyết gốc rễ cho mục 62/63/64 (không cần điều tra "độ dài prompt" hay "heap corruption trong MNN" nữa — vấn đề nằm ở app, không phải thư viện MNN).

68. **[LỖI DO CHÍNH MỤC 65 GÂY RA, ĐÃ TẮT LẠI — 2026-08-02] Người dùng báo cáo: câu chat THỨ 2 trong 1 phiên, model trả về chuỗi lặp vô nghĩa `"8888888"`.** Đây gần như chắc chắn là hậu quả trực tiếp của việc bật `reuseKv: true` cho chat ở mục 65 — dấu hiệu ("8888888", lặp 1 token liên tục) là triệu chứng kinh điển của lệch KV-cache/vị trí token trong các engine LLM, và đúng lúc xảy ra là lượt chat **THỨ 2** — lần ĐẦU TIÊN `reuse_kv` thực sự có gì đó từ lượt trước để "tái sử dụng" (lượt 1 luôn có cache rỗng nên không lộ lỗi). **Nguyên nhân kỹ thuật nghi ngờ nhiều nhất**: `local_provider.dart` luôn xây LẠI TOÀN BỘ prompt mỗi lượt (`'$systemPrompt\n\n$userPrompt'`), KHÔNG gửi kèm phần model đã TỰ SINH ra ở lượt trước — khi MNN cố tái sử dụng KV-cache của lượt trước (đã bao gồm cả phần tự sinh đó) mà prompt mới gửi vào lại không khớp đúng chuỗi tương ứng, model bị lệch ngữ cảnh, suy biến thành lặp token. **KHÔNG có tài liệu MNN nào xác nhận chính xác hợp đồng hành vi cần thiết** (cần gửi prompt kiểu gì — chỉ phần mới, hay toàn bộ, hay có API riêng để "tiếp tục" — để `reuse_kv` hoạt động đúng) — mục 65 đã bật tính năng này dựa trên tên tham số + mô tả ngắn mà chưa kiểm chứng đủ kỹ hợp đồng hành vi thật, đây là bài học nhắc lại: xác nhận được TÊN tham số đúng (tránh lặp lỗi mục 59) là điều kiện CẦN nhưng CHƯA ĐỦ — còn phải hiểu đúng ngữ nghĩa/hợp đồng sử dụng trước khi bật trên đường chính (production path).
    - **Đã sửa an toàn**: tắt lại `reuseKv: false` ở đúng 1 dòng gọi trong `chat_screen.dart` — **giữ nguyên toàn bộ hạ tầng** đã nối dây xuyên suốt (`AIProvider` → `MethodChannel` → `MnnBridge.kt` → JSON config), chỉ tắt nơi bật. Muốn bật lại sau khi xác minh đúng cách dùng, chỉ cần sửa đúng 1 dòng, không cần làm lại hạ tầng.
    - **Hệ quả**: lượt chat thứ 2 trở đi sẽ CHẬM HƠN LẠI như trước mục 65 (không còn tái sử dụng KV-cache) — đánh đổi tốc độ lấy đúng đắn, hợp lý cho tới khi có cách xác minh chắc chắn cách dùng đúng `reuse_kv` (ví dụ: tìm được ví dụ code chính thức của MNN dùng nó trong ngữ cảnh multi-turn thật, không chỉ tên tham số).
    - **CHƯA build/test thật** (bản thân việc tắt lại thì rủi ro thấp — chỉ là quay về hành vi mặc định `false` đã hoạt động ổn định trước đó — nhưng vẫn cần xác nhận qua build thật là hết hẳn hiện tượng "8888888").

69. **[TÍNH NĂNG LỚN MỚI, CHƯA build/test — 2026-08-02] Theo yêu cầu người dùng: tách hẳn giai đoạn LÊN KẾ HOẠCH (nhanh, không gọi AI) khỏi giai đoạn THỰC THI (chậm, AI chạy tuần tự theo hàng đợi) — trực tiếp giải quyết đúng nguyên nhân crash "2 lệnh generate chạy chồng chéo" đã tìm ra ở mục 5.67: nếu người dùng KHÔNG CÒN BỊ BẮT phải ngồi chờ AI viết XONG TỪNG CHƯƠNG/ĐOẠN MỘT mới được làm việc khác, sẽ giảm hẳn khả năng 2 tác vụ AI tình cờ trùng thời điểm.** Gồm 2 hệ thống song song, dùng chung tư duy "ghi chú trước, xử lý hàng loạt sau":
    - **Migration DB v3→v4** (`database_service.dart`): thêm cột `chapters.outline` (dàn ý/"chương mồi" — trước đây chỉ tồn tại tạm trong `outlineCtrl`, KHÔNG lưu DB, mất trắng nếu rời màn hình chưa bấm "Đắp thịt" — giờ `_save()` lưu bền, `initState()` nạp lại đúng); thêm bảng mới `pending_rewrites` (model `PendingRewrite` trong `story_models.dart`: `id, chapterId, novelId, originalText, note, status, resultText, createdAt`).
    - **Hệ thống A — Tạo chương hàng loạt từ outline**: `chapter_batch_service.dart` (MỚI) — nhận danh sách `Chapter` đã chọn (có `outline`), gọi `StyleService.fleshOutOutline()` (logic có sẵn, dùng lại nguyên) TUẦN TỰ từng chương, bọc `beginPipeline`/`endPipeline` (mẫu đã có ở `document_service.dart`, mục 61), có kiểm tra tính hợp lý kết quả trước khi lưu (ngưỡng độ dài, cùng tư duy `DocumentProcessingAnomalyException` ở mục 64 — dừng ngay nếu 1 chương ra kết quả bất thường, không chạy tiếp qua chương khác). `chapters_batch_generate_screen.dart` (MỚI) — màn hình chọn chương (checkbox, lọc nhanh "có outline"/"có outline + chưa viết"), thanh tiến trình %, nút Huỷ, `PopScope` chặn back — TÁI DÙNG gần như y hệt cấu trúc `document_chunks_screen.dart` (mục 63). Thêm nút mở màn hình này + badge trạng thái outline trên `chapters_screen.dart`.
    - **Hệ thống B — Ghi chú bôi đen, xử lý hàng loạt**: `_showRewriteMenu()` trong `chapter_editor_screen.dart` **THAY ĐỔI HOÀN TOÀN** — trước đây hiện 4 lựa chọn HARDCODE ("Sửa lỗi chính tả", "Viết sinh động hơn"...) và **GỌI AI NGAY LẬP TỨC** khi chọn (chính là 1 trong các đường có thể vô tình trùng thời điểm với tác vụ AI khác — nguyên nhân crash mục 5.67). Giờ: bôi đen → viết NHẬN XÉT/YÊU CẦU TỰ DO (không hardcode) → **LƯU thành `PendingRewrite` vào DB, KHÔNG GỌI AI** — có thể lặp lại ở nhiều chỗ. Khi sẵn sàng, bấm "Tạo lại tất cả" (`_applyAllPendingRewrites()`) xử lý TUẦN TỰ từng ghi chú.
      - **Định vị lại đoạn văn khi áp dụng**: dùng NGUYÊN VĂN `originalText` tìm trong nội dung HIỆN TẠI (không dùng offset số — nội dung có thể đã bị sửa ở chỗ khác giữa lúc ghi chú và lúc xử lý, đúng rủi ro đã lường trước khi thiết kế). Nếu không tìm thấy ĐÚNG 1 LẦN (đã bị sửa/xoá, hoặc trùng nhiều chỗ gây mơ hồ) → BỎ QUA ghi chú đó (`status = 'skipped_text_changed'`), không đoán mò áp dụng nhầm chỗ.
      - Hàm cũ `_applyRewrite()` (gọi AI ngay khi bôi đen) đã **XOÁ HẲN** (không còn nơi gọi tới) — biến `rewriting` gộp chung vào `applyingRewrites` mới, tránh biến chết.
      - UI mới trên AppBar `chapter_editor_screen.dart`: badge "N ghi chú" (mở xem/xoá từng ghi chú qua `_showPendingRewritesSheet`) + nút "Tạo lại tất cả".
    - **Lỗi tự phát hiện và sửa ngay trong lúc viết**: dùng `final context = await rag.buildContext(...)` bên trong `_applyAllPendingRewrites()` — biến cục bộ `context` (String) **CHE KHUẤT** `BuildContext context` kế thừa từ `State` (Dart cho phép shadowing, không báo lỗi ngay dòng đó) — nhưng dòng sau đó gọi `ScaffoldMessenger.of(context)` sẽ cố gọi `.of()` trên String, LỖI BIÊN DỊCH THẬT nếu không phát hiện. Đã đổi tên thành `storyBibleContext` trước khi đóng gói. **Bài học**: tên biến `context` cực kỳ dễ vô tình che khuất `BuildContext` trong bất kỳ hàm nào của `State` — luôn tránh đặt tên biến cục bộ trùng `context` trong file Flutter, dù ở phạm vi hẹp.
    - **Đã tự kiểm tra**: bracket-check nghiêm ngặt (stack-based) cho toàn bộ 6 file thay đổi (`chapter_editor_screen.dart`, `chapter_batch_service.dart`, `chapters_batch_generate_screen.dart`, `chapters_screen.dart`, `story_models.dart`, `database_service.dart`) — tất cả sạch.
    - **CHƯA build/test thật.** Việc cần làm ở phiên sau: build lại, thử viết vài outline chương (không gọi AI), dùng "Tạo chương hàng loạt" tạo 2-3 chương liên tiếp xem thanh tiến trình + huỷ hoạt động đúng; thử bôi đen nhiều chỗ trong 1 chương, viết ghi chú, bấm "Tạo lại tất cả", xác nhận định vị lại đúng đoạn (thử cả trường hợp sửa nội dung ở chỗ khác giữa lúc ghi chú và lúc xử lý, xem có bị bỏ qua đúng như thiết kế không thay vì áp dụng nhầm chỗ).

70. **[LỖ HỔNG THẬT DO CHÍNH MỤC 69 GÂY RA, PHÁT HIỆN QUA CÂU HỎI TRỰC TIẾP CỦA NGƯỜI DÙNG — 2026-08-02] Cả 2 hệ thống mới ở mục 69 (tạo chương hàng loạt + hàng đợi ghi chú bôi đen) đều ÂM THẦM BỎ QUA pipeline dịch thuật trung gian (`TranslationService`), dù luồng tương tác đơn lẻ tương ứng đã có từ trước.** Người dùng hỏi thẳng "2 hệ thống này có chạy theo quy trình dịch từ prompt->model sinh->dịch lại ngôn ngữ người dùng nếu bật hạ tầng dịch trung gian không" — kiểm tra code xác nhận: KHÔNG.
    - `ChapterBatchService.generateBatch()` dùng `StyleService.fleshOutOutline()` — hàm này **TỰ GHI RÕ TRONG COMMENT** là "gọi thẳng provider, không qua dịch thuật trung gian" (thiết kế cho 1 mục đích khác trước đó) — tạo chương hàng loạt vì vậy bỏ qua hoàn toàn cài đặt dịch thuật trung gian nếu người dùng đã bật.
    - `_applyAllPendingRewrites()` (mục 69, code MỚI VIẾT) gọi thẳng `provider.generate()` thay vì `_generateRespectingTranslation()` — khác với hàm cũ `_applyRewrite()` (đã xoá) vốn có dùng đúng `_generateRespectingTranslation()`. Đây là **lỗi hồi quy tôi tự gây ra** khi viết tính năng mới, không kiểm tra lại tính nhất quán với luồng cũ.
    - **Nhân tiện phát hiện thêm 1 lỗ hổng khác, có sẵn từ trước (không phải do mục 69 gây ra)**: `TranslationService.generateWithOptionalTranslation()` — hàm DÙNG CHUNG cho mọi nơi có route qua dịch thuật — trước giờ chỉ nhận `temperature`/`maxTokens`, **ÂM THẦM BỎ QUA `topP`/`topK`/`repetitionPenalty`** ở CẢ HAI nhánh (có dịch/không dịch) — nghĩa là các tham số này người dùng chỉnh trong Cài đặt KHÔNG có tác dụng thật với BẤT KỲ lệnh nào đi qua hàm này, kể cả trước khi có mục 69.
    - **Đã sửa tận gốc, 1 nơi sửa áp dụng cho mọi nơi gọi**: mở rộng `generateWithOptionalTranslation()` nhận đủ `topP`/`topK`/`repetitionPenalty`, truyền xuyên suốt CẢ HAI nhánh. `_generateRespectingTranslation()` trong `chapter_editor_screen.dart` rút gọn thành 1 lớp mỏng gọi thẳng hàm dùng chung (bỏ nhánh rẽ trùng lặp cũ). `ChapterBatchService` đổi sang tự build prompt qua `buildFleshOutPrompt()` (công khai, logic prompt giữ nguyên) rồi gọi `generateWithOptionalTranslation()` trực tiếp — nhất quán với luồng đơn lẻ. `_applyAllPendingRewrites()` đổi sang gọi `_generateRespectingTranslation()` thay vì `provider.generate()` trực tiếp, đồng thời nạp đúng `genCfg` từ Cài đặt thay vì hardcode `temperature: 0.8, maxTokens: 1500` như bản viết vội trước đó.
    - **Lỗi kỹ thuật thứ 2 tự phát hiện khi sửa**: `pipelineActive` (Boolean đơn giản, không đếm số lần lồng nhau) trong `MnnBridge.kt` **KHÔNG AN TOÀN** khi 2 lớp pipeline lồng nhau — `ChapterBatchService` bọc `beginPipeline()`/`endPipeline()` quanh CẢ vòng lặp nhiều chương, nhưng BÊN TRONG mỗi lượt, `generateWithOptionalTranslation()` (khi dịch thuật bật) CŨNG tự gọi `beginPipeline()`/`endPipeline()` riêng cho từng bước dịch — `endPipeline()` của lớp TRONG sẽ tắt Foreground Service NGAY sau 1 chương, dù vòng lặp NGOÀI còn nhiều chương chưa xử lý — tái tạo đúng kiểu lỗ hổng "chớp tắt thông báo giữa các bước" đã sửa ở mục 5.61 cho xử lý tài liệu, nhưng theo cách mới (lồng nhau, không phải tuần tự đơn giản). **Đã sửa**: đổi `pipelineActive` (Boolean) thành `pipelineDepth` (Int, đếm số lần lồng nhau, có khoá `synchronized` bảo vệ) trong `MnnBridge.kt` — chỉ THẬT SỰ bật Foreground Service khi độ sâu từ 0 lên 1 (lần bọc ngoài cùng), chỉ THẬT SỰ tắt khi độ sâu về lại 0 (lần kết thúc cuối cùng khớp với lần bắt đầu đầu tiên) — hỗ trợ đúng bất kỳ độ sâu lồng nhau nào (2 lớp như hiện tại, hoặc nhiều hơn trong tương lai) mà không cần Dart phải biết xử lý đặc biệt. `cancelGenerate` reset thẳng độ sâu về 0 (huỷ thủ công phải dừng toàn bộ, không chỉ giảm 1 lớp).
    - **Đã tự kiểm tra**: bracket-check nghiêm ngặt cho toàn bộ 4 file liên quan (`translation_service.dart`, `chapter_editor_screen.dart`, `chapter_batch_service.dart`, `MnnBridge.kt`) — sạch. Phát hiện và tự sửa thêm 1 lỗi ngoặc treo (dangling brackets) sót lại từ thao tác `str_replace` trước đó ở `chapter_editor_screen.dart` trong lúc rút gọn `_generateRespectingTranslation()` — nhờ thói quen kiểm tra ngay sau mỗi lần sửa mà bắt được trước khi đóng gói.
    - **Bài học quy trình**: khi thêm 1 luồng gọi AI MỚI (đặc biệt dạng hàng loạt/batch), phải RÀ LẠI xem có ĐANG ĐI ĐÚNG qua các lớp hạ tầng dùng chung đã có (dịch thuật trung gian, cấu hình sinh văn bản đầy đủ, quản lý Foreground Service) hay đã vô tình viết tắt/bỏ qua — nhất là khi có sẵn 1 hàm helper cũ (`StyleService.fleshOutOutline`) ghi rõ trong comment là "phiên bản rút gọn, bỏ qua X" — dễ bị tái sử dụng nhầm trong ngữ cảnh MỚI cần đầy đủ hơn ngữ cảnh nó được viết ra ban đầu.
    - **CHƯA build/test thật.**

71. **[RÀ SOÁT TOÀN HỆ THỐNG THEO YÊU CẦU TRỰC TIẾP CỦA NGƯỜI DÙNG — 2026-08-02] Người dùng KHÔNG chấp nhận câu trả lời "đã sửa" chung chung ở mục 70, hỏi thẳng: (a) đã sửa triệt để chưa hay chỉ vá 1-2 chỗ, (b) model dịch có áp dụng cài đặt không, có prompt văn phong dịch không, (c) Foreground Service có đủ tin cậy để CHẠY XUYÊN ĐÊM không ("sáng dậy thấy chết thì dẹp luôn dự án"). Rà soát bằng `grep` toàn bộ `lib/` tìm MỌI nơi gọi `provider.generate()`/`generateStream()` — phát hiện mục 70 CHỈ sửa 2/8 điểm thật.**
    - **(a) Danh sách đầy đủ sau khi rà soát toàn bộ, phân loại ĐÚNG/SAI theo bản chất kỹ thuật (không sửa tràn lan)**:
      - **THẬT SỰ THIẾU, ĐÃ SỬA thêm ở mục này**: `_checkConsistency()` (chapter_editor_screen.dart — trước đây không hề qua dịch thuật LẪN không dùng `genCfg` đầy đủ, chỉ có `maxTokens: 400` hardcode); `SummaryService.summarizeChapter()` (tóm tắt tự động sau khi lưu chương); `StyleService.analyzeStyleFromSample()` (phân tích văn phong từ mẫu import); `chat_screen.dart` nhánh CÓ dịch thuật (dù mục 70 đã sửa HẠ TẦNG `generateWithOptionalTranslation()` nhận đủ `topP`/`topK`/`repetitionPenalty`, nhưng CHÍNH nơi gọi đầu tiên phát hiện ra vấn đề — `chat_screen.dart` — lại QUÊN cập nhật truyền các tham số đó vào lệnh gọi thật — **đúng như người dùng lo ngại "có phải chỉ làm mã như lúc đầu"**, vá hạ tầng không tự động vá nơi gọi).
      - **CỐ Ý BỎ QUA, XÁC NHẬN ĐÚNG (không phải lỗi)**: `document_service.dart` (dịch/tóm tắt tài liệu) — văn bản gốc là NGOẠI NGỮ (Trung/Anh...) CHƯA dịch, khác hẳn các trường hợp trên (nội dung tiếng Việt của chính người dùng) — pipeline `generateWithOptionalTranslation` giả định đầu vào là TIẾNG VIỆT cần dịch sang ngôn ngữ trung gian; áp dụng nhầm ở đây sẽ dịch SAI HẲN (tưởng văn bản Trung là tiếng Việt). `benchmark_service.dart` — cố ý đo tốc độ THUẦN của model, áp dụng dịch thuật sẽ làm sai lệch phép đo.
    - **(b) Model dịch CÓ áp dụng cài đặt văn phong** (`loadTranslationStylePrompt()`, người dùng tự chỉnh trong Cài đặt, đã có từ trước — xác nhận qua code, không phải phỏng đoán) — nhưng **KHÔNG áp dụng** `topP`/`topK`/`repetitionPenalty` từ Cài đặt sinh văn bản chung (model dịch dùng `temperature: 0.3` cứng — **đây là THIẾT KẾ ĐÚNG, không phải lỗi**: dịch thuật cần chính xác/xác định, không nên dùng tham số "sáng tạo" của việc viết truyện). Hiện CHƯA có cài đặt `topP`/`topK`/`repetitionPenalty` RIÊNG cho model dịch — ghi nhận là thiếu SÓT NHỎ (không khẩn cấp), chưa làm ở phiên này.
    - **(c) Foreground Service cho chạy xuyên đêm — audit kỹ, tìm ra 1 lỗ hổng thật + xác nhận 1 điểm đã ổn**:
      - **XÁC NHẬN ỔN (tra cứu tài liệu Android chính thức)**: loại `specialUse` (đổi từ `dataSync` ở mục 66) KHÔNG bị giới hạn 6 tiếng như `dataSync`/`mediaProcessing` trên Android 15 — quyết định đổi loại ở mục 66 vô tình đã giải quyết đúng vấn đề này trước cả khi được hỏi.
      - **LỖ HỔNG THẬT, ĐÃ SỬA**: `GenerationService.kt` — WakeLock trước đây xin TRẦN CỨNG 8 TIẾNG (`acquire(8*60*60*1000L)`) — đây là giới hạn APP TỰ ĐẶT (không phải hệ điều hành), không đủ cho việc để máy chạy nhiều tiếng qua đêm. **Đã sửa**: đổi sang TỰ LÀM MỚI ĐỊNH KỲ — mỗi 30 phút gia hạn thêm 40 phút (luôn dư 10 phút) — hỗ trợ chạy dài KHÔNG GIỚI HẠN thời gian trong khi vẫn có lưới an toàn (nếu vòng lặp làm mới vì lý do gì đó dừng bất thường, WakeLock tự hết hạn sau tối đa 40 phút thay vì rò rỉ vĩnh viễn hút cạn pin).
      - **LỚP PHÒNG VỆ MỚI THÊM (không phải sửa lỗi có sẵn, mà bổ sung do bản chất yêu cầu độ tin cậy cao)**: thêm khả năng xin loại trừ khỏi tối ưu hoá pin của hãng máy (`isIgnoringBatteryOptimizations`/`requestIgnoreBatteryOptimizations`, qua Intent `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` — Android bắt buộc phải hỏi người dùng, không cho app tự tắt) — vì Foreground Service đúng chuẩn Android **không đảm bảo tuyệt đối** trên các máy có trình quản lý pin riêng của hãng (đặc biệt ASUS ZenUI, đúng máy test — mục 5.66) — hãng có thể tự ý kill app nền bất kể đúng chuẩn Android hay không, TRỪ KHI người dùng tự loại trừ thủ công. Thêm UI trong `local_optimization_screen.dart`: hiện rõ trạng thái (đã loại trừ/chưa), nút yêu cầu + nút kiểm tra lại.
    - **Tổng cộng đã sửa trong lượt này**: `summary_service.dart`, `style_service.dart`, `chapter_editor_screen.dart` (`_checkConsistency`), `chat_screen.dart`, `GenerationService.kt` (WakeLock renewal), `MnnBridge.kt` (2 handler pin mới), `build.yml` (quyền `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`), `local_provider.dart` (2 static method mới), `local_optimization_screen.dart` (UI trạng thái pin).
    - **Đã tự kiểm tra**: bracket-check nghiêm ngặt cho toàn bộ 8 file Dart/Kotlin thay đổi — sạch; `build.yml` xác nhận vẫn là YAML hợp lệ sau khi thêm quyền.
    - **Bài học quan trọng nhất phiên này**: khi hạ tầng dùng chung được SỬA (ví dụ mở rộng tham số 1 hàm), phải RÀ LẠI TỪNG NƠI GỌI để xác nhận thật sự dùng tham số mới — sửa xong khả năng của hàm KHÔNG tự động nghĩa là mọi nơi gọi đã dùng đúng khả năng đó; đây chính xác là điều người dùng nghi ngờ khi hỏi "hay chỉ là làm mã như lúc đầu" — và nghi ngờ đó đúng ở 1 nửa số điểm.
    - **CHƯA build/test thật.**

---

## 6. Danh sách yêu cầu người dùng — đã hoàn thành / chưa hoàn thành

### ✅ Đã hoàn thành và có trong source zip mới nhất

- [x] App viết truyện AI, đa truyện (multi-novel), Story Bible/RAG/timeline
- [x] Chat đa phiên, lưu bền vững, không mất khi đổi tab/model
- [x] Nhiều model local + nhiều API provider, không hardcode, đổi giữa chừng không mất bối cảnh
- [x] Không bộ lọc nội dung ở tầng app
- [x] Xuất chương (EPUB/DOCX/TXT), xuất chat (TXT/DOCX), xuất kết quả tài liệu
- [x] Đính kèm/dịch/tóm tắt tài liệu `.txt`/`.md` (Giai đoạn 1)
- [x] Văn phong + đắp thịt outline (không vi phạm bản quyền)
- [x] Tối ưu thiết bị: nhận diện chip, benchmark thật, RAG budget theo máy
- [x] Đổi engine AI local sang MNN-LLM + QNN, build qua GitHub Actions thành công (bao gồm tải QNN SDK, build native, biên dịch cầu nối JNI, và build Dart/Flutter)
- [x] **Provider "GPU ngoài" qua Google Colab (miễn phí)** — `OpenAICompatibleProvider` + notebook `LocalNovel_GPU_tu_xa_qua_Colab.ipynb` (build `llama-server` có CUDA + Cloudflare Tunnel), `BackgroundTaskManager` cho phép NHIỀU chương chạy THẬT SỰ song song khi provider là remote (giới hạn theo `maxParallelRemoteTasks`, xem `settings_screen.dart`) — mục này TRƯỚC ĐÂY ghi nhầm là "⬜ CHƯA code" gộp chung với lớp ẩn danh hoá (rà soát lại 2026-08-21, xem mục ⬜ bên dưới để biết phần THẬT SỰ chưa làm của kế hoạch 5 lớp mục 5.29 gốc).
- [x] Kiến trúc Platform Channel thay FFI (loại bỏ lỗi dlopen)
- [x] 2 slot model độc lập (multi-context) ở tầng native
- [x] Foreground Service + WakeLock chống bị Android kill khi chạy nền/qua đêm (wake lock trần 8 tiếng), gộp thành 1 pipeline cho luồng dịch tuần tự
- [x] Sửa UI model MNN (thư mục thay vì file `.gguf`), `FileBrowserScreen` hỗ trợ chọn thư mục VÀ chọn file (lọc theo đuôi file)
- [x] Tham số sinh văn bản — đã nối vào khung chat VÀ `chapter_editor_screen.dart`
- [x] Dịch thuật trung gian tuần tự — đã nối vào khung chat VÀ `chapter_editor_screen.dart`
- [x] In-line AI Rewrite (mục 4.9)
- [x] Notebook Colab convert model HuggingFace/ModelScope → định dạng MNN (`LocalNovel_Convert_Model_To_MNN.ipynb`, không nằm trong zip app — file riêng), đã convert thành công thật 1 model 7B, dùng được trên app
- [x] **QNN NPU XÁC NHẬN KÍCH HOẠT ĐƯỢC THẬT** trên Zenfone 8 (log debug thật: `loadModel TRẢ VỀ xong: {success: true, backend: qnn}`) — không còn là rủi ro treo nữa, xem mục 6 "Đã code nhưng CHƯA xác nhận" bên dưới đã bỏ mục này ra
- [x] Sửa lỗi nền tảng nghiêm trọng nhất từ trước tới giờ: `MainActivity.kt` thật bị copy sai đường dẫn package trong `build.yml` (mục 5.18) — mọi bản build từ #30-33 chưa từng thực sự chạy code native
- [x] Sửa nguyên nhân THẬT của crash native khi chat/đo tốc độ: R8/ProGuard đổi tên hàm JNI cần tới bằng tên chuỗi (mục 5.24) — đã thêm luật ProGuard `-keep`, kiểm tra/tự chèn `proguardFiles` vào `build.gradle`
- [x] Hạ tầng log chẩn đoán 3 tầng Dart/Kotlin/C++ ghi ra file xem được ngay trong app (mục 5.19-21), không cần ADB/máy tính
- [x] `backendPreference` (QNN tự động/ép GPU/ép CPU) cấu hình được từ UI, không cần build lại (mục 5.22)
- [x] Bọc toàn bộ `onMethodCall` trong try/catch — không còn nguy cơ 1 lỗi Kotlin bất kỳ làm crash cả app (mục 5.25)
- [x] Lỗi `@UiThread must be executed on the main thread` — đã sửa từ phiên trước (bọc `mainHandler.post{}`), nay mới được ghi lại vào tài liệu (mục 5.26)
- [x] Bug reload model mỗi lần chat (`currentProvider()` tạo instance mới mỗi lần gọi) — đã sửa bằng cache tĩnh trong `SettingsService` (mục 5.27)
- [x] **`llm->response()` sinh văn bản thật THÀNH CÔNG** (mục 5.28 → 5.40, đã đóng). Nguyên nhân cuối: backend QNN crash cứng (SIGSEGV) mọi lúc; OpenCL chạy được. App hiện dùng OpenCL khi ép buộc; cần đổi mặc định sang OpenCL (bỏ QNN khỏi đường thử đầu tiên) — xem việc cần làm ở mục 5.40. QNN để backlog tối ưu sau (mục 5.43).
- [ ] **`GenerationService` (Foreground Service/WakeLock) chưa từng khai báo trong Manifest — ĐANG SỬA, ưu tiên cao** (mục 5.42). Giải thích hiện tượng app "đóng băng" khi tắt màn hình lúc đang sinh văn bản, và số liệu `prefill_us` tăng bất thường qua các lần trong log. Đã thêm bước khai báo `<service>` + quyền vào `build.yml`, CHƯA build/test.
- [x] CI build ổn định trở lại sau lỗi `jni`/AGP 9 không tương thích (mục 5.30) — đã hạ AGP xuống 8.13.0 + Gradle 8.13 + Kotlin 2.1.20, build APK qua được nhiều lần liên tiếp.
- [x] **Xác nhận nguyên nhân gốc QNN không dùng được trên máy test — không phải lỗi code, mà do Hexagon v68 dưới mức Qualcomm chính thức hỗ trợ LLM-trên-NPU (v73+)** (mục 5.52). Đã đổi mặc định sang GPU (OpenCL) đã tối ưu, QNN chuyển thành thử nghiệm bật thủ công (`backendPreference=3`), giữ nguyên cơ chế cách ly tiến trình con + timeout an toàn (mục 5.53) cho ai muốn thử trên máy chip mới hơn.
- [x] Tối ưu tốc độ GPU thật sự theo tài liệu MNN chính thức: `precision:low`, `memory:low`, `thread_num:68`, cache autotuning kernel (`tmp_path`) — mục 5.54.
- [x] Sửa bug FAB "Bách khoa" luôn mở sai form theo tab + sửa luôn bug màn hình trắng do chính phiên này gây ra khi vá lần 1 — mục 5.48/5.49.
- [x] Sửa 4 chỗ crash `setState() called after dispose()` trong `chapter_editor_screen.dart` khi thoát màn hình lúc AI đang chạy — mục 5.50.
- [x] Sửa bug hallucination Story Bible (model tự bịa nội dung khi Story Bible trống) — mục 5.51.
- [x] Thêm UI chỉnh prompt tóm tắt/dịch tài liệu + làm xử lý tài liệu tiếp tục được dở dang — mục 5.55.
- [x] Thêm `PopScope` chặn vuốt back Android 13+ giữa lúc AI đang chạy (chương/tài liệu) — mục 5.56, CHƯA build/test thật.
- [x] Tính năng mới: tìm kiếm web thủ công (bật/tắt theo phiên chat, không tự động) — mục 5.57, CHƯA build/test thật.
- [x] `build.yml` không còn để bước copy file QNN thất bại âm thầm — mục 5.58, CHƯA build/test thật.

### ⚠️ Đã code nhưng CHƯA xác nhận chạy đúng thật (rủi ro còn treo)

- [ ] `foregroundServiceType="dataSync"` có bị hệ thống từ chối lúc chạy không — vẫn chưa test riêng biệt, dù Foreground Service đã chạy được nhiều lần trong lúc debug crash (log cho thấy `GenerationService.start()` không hề ném lỗi) nên rủi ro này coi như đã giảm đáng kể, có thể hạ độ ưu tiên.
- [ ] **Bản sửa ProGuard/R8 (mục 5.24) — CHƯA build+test lần nào**. Đây là việc ưu tiên SỐ 1 tuyệt đối ngay phiên tiếp theo — nếu sửa đúng, tính năng chat/sinh văn bản với model local sẽ LẦN ĐẦU TIÊN hoạt động thật sự từ đầu dự án tới giờ.
- [ ] **TẤT CẢ 6 tính năng ở mục 4.10-4.15** (version snapshot, tìm kiếm, glossary/chống lặp từ, Story Bible nâng cao/auto-mention, EPUB bìa+mục lục, backup/restore) — vẫn CHƯA build/test lần nào kể từ khi viết (nhiều vòng build gần đây đều tập trung vá lỗi native/crash, chưa quay lại kiểm tra các tính năng Dart-only này).

### 🔧 Đã bắt đầu nhưng CHƯA hoàn thiện hết

*(không còn mục nào ở trạng thái này — 2 mục từng ở đây đã hoàn thành ở phiên trước)*

### ⬜ Yêu cầu đã nêu, CHƯA code

- [ ] Tóm tắt phân tầng đệ quy (tier 2: cụm chương, tier 3: bản đồ kịch bản toàn truyện) — cần cho truyện triệu chữ. **Cố tình chưa làm** — cần đọc `llm.hpp` thật trước để biết API quản lý KV cache đúng (mục 5.10), rủi ro kỹ thuật cao nhất trong các việc còn lại, không nên làm vội chung đợt với 6 tính năng khác.
- [ ] Scene bên trong Chapter + Corkboard kéo-thả — UI lớn, nhiều tương tác kéo-thả phức tạp, nên làm riêng 1 phiên để có không gian rà soát kỹ.
- [ ] TTS (đọc chương thành giọng nói) — cần thêm plugin native mới (chưa có trong `pubspec.yaml`), rủi ro build tương tự các lần đổi engine AI trước đây (mục 5.1-5.6) — cố tình hoãn, không thêm dependency mới khi chưa xác nhận build hiện tại ổn định.
- [ ] Đọc tài liệu PDF/DOCX/ảnh (Giai đoạn 2 của tính năng tài liệu) — cố tình hoãn từ trước, lý do tương tự TTS.
- [ ] Author's Note/Memory field tách riêng Story Bible, Canvas outline trực quan, tùy biến font/theme trình soạn thảo — chưa có yêu cầu cụ thể, độ ưu tiên thấp hơn các mục trên.
- [ ] **Lớp ẩn danh hoá thực thể trước khi gửi ra provider ngoài** (tên nhân vật/địa danh riêng → mã hoá tạm trước khi gửi HTTP ra GPU remote/API, giải mã lại khi nhận về) — phần kiến trúc 5 lớp thống nhất ở mục 5.29 gốc, TÁCH RIÊNG khỏi dòng "Provider GPU ngoài" (đã hoàn thành, xem mục ✅ phía trên) vì rà soát lại (2026-08-21, theo yêu cầu người dùng "kiểm tra tính năng nào có UI nhưng không hoạt động") xác nhận: **CHƯA có 1 dòng code nào** cho lớp ẩn danh hoá này trong toàn bộ `lib/` — không có hàm, không có UI, không có bảng ánh xạ tên thật↔mã hoá. Rủi ro thật đang tồn tại: dùng "GPU từ xa qua Colab"/API ngoài hiện gửi NGUYÊN VĂN tên riêng/nội dung truyện qua HTTP, không qua bước ẩn danh nào — nếu người dùng coi đây là yêu cầu bảo mật quan trọng (không phải chỉ optimization), cần ưu tiên làm sớm hơn vị trí hiện tại trong danh sách.

### 🆕 Mới hoàn thành phiên này (mục 4.10-4.15 phía trên) — CHƯA build/test thật

- [x] Version snapshot (undo AI viết đè) — mục 4.10
- [x] Tìm kiếm toàn văn UI — mục 4.11
- [x] Glossary (bảng thuật ngữ) + thống kê chống lặp từ — mục 4.12
- [x] Story Bible nâng cao: phân loại thẻ chi tiết + auto-mention — mục 4.13
- [x] EPUB có bìa + mục lục nhấp được thật — mục 4.14
- [x] Backup/restore toàn bộ dữ liệu — mục 4.15

---

## 7. Việc cần làm ngay khi bắt đầu phiên mới

**Cập nhật (2026-07-31 — trạng thái mới nhất, phiên dài, nhiều thay đổi lớn)**:

**Quyết định chiến lược quan trọng nhất phiên này**: đã điều tra và xác nhận
QNN/NPU không khả thi trên máy test (Snapdragon 888/Hexagon v68 dưới mức
Qualcomm chính thức hỗ trợ v73+ cho LLM — mục 5.52) — **không phải lỗi
code có thể vá tiếp**. Đã đổi chiến lược: **GPU (OpenCL) là đường chính**,
tối ưu hết mức theo tài liệu MNN chính thức (mục 5.54); QNN lùi thành lựa
chọn thử nghiệm bật thủ công (`backendPreference=3`), giữ nguyên cơ chế an
toàn (cách ly tiến trình con + timeout, mục 5.53) cho tương lai nếu đổi
máy chip mới hơn.

Ngoài ra phiên này sửa thêm nhiều bug UI/UX thật do người dùng phát hiện
qua ảnh chụp màn hình: bug FAB "Bách khoa" sai form theo tab (mục 5.48) —
**và chính bản vá lần 1 của bug đó lại gây ra 1 bug MỚI nghiêm trọng hơn
(màn hình trắng xoá cả tab Bách khoa, mục 5.49)** — bài học: mọi sửa lỗi
liên quan tới `context`/`InheritedWidget` phải được kiểm tra rất kỹ, ưu
tiên cho `State` tự sở hữu `Controller` riêng thay vì `.of(context)` khi
còn nghi ngờ. Sửa crash `setState() after dispose()` (mục 5.50), sửa
hallucination Story Bible trống (mục 5.51), thêm `PopScope` chặn back
Android 13+ (mục 5.56), thêm tính năng mới tìm kiếm web thủ công (mục
5.57).

**TRẠNG THÁI BUILD/TEST THẬT**: các mục 5.48 (bản đã sửa lỗi ở 5.49),
5.50, 5.51, 5.52, 5.53, 5.54 đã được người dùng xác nhận qua log/ảnh chụp
màn hình thật trong chính phiên hội thoại này (không phải suy đoán). Mục
5.56 (`PopScope`) từng có lỗi biên dịch thật (build APK #67 fail, xem mục
5.59) — **đã sửa tên tham số đúng, nhưng CHƯA build lại lần nào sau khi
sửa**. Mục 5.65 (`reuse_kv`) đã bật rồi PHẢI TẮT LẠI ngay do gây lỗi thật
("8888888", xem mục 5.68) — hạ tầng vẫn giữ, chỉ tắt nơi bật. Mục 5.67
(khoá Mutex chống generate() chạy chồng chéo) là phát hiện quan trọng
nhất phiên này, CHƯA build/test thật — ưu tiên xác nhận đầu tiên ở phiên
sau. Mục 5.69 (tạo chương hàng loạt + hàng đợi ghi chú) là tính năng lớn
MỚI, mục 5.70+5.71 (rà soát toàn hệ thống 2 lượt liên tiếp — dịch thuật
trung gian áp dụng đủ nơi chưa, `pipelineActive`→`pipelineDepth`, WakeLock
tự làm mới thay vì trần 8 tiếng, thêm loại trừ tối ưu hoá pin) — TẤT CẢ
CHƯA build/test thật lần nào, độ phức tạp cao (nhiều file mới + sửa hạ
tầng dùng chung nhiều lớp), cần test kỹ ở phiên sau hơn các mục khác —
**đặc biệt mục 5.71 (độ tin cậy chạy xuyên đêm) là yêu cầu cứng của
người dùng, cần xác nhận thật bằng cách để chạy 1 tác vụ dài qua đêm
thật sự, không chỉ tin vào suy luận kỹ thuật**. Các mục
**5.55, 5.56, 5.57, 5.58, 5.61, 5.66, 5.67, 5.68, 5.69, 5.70, 5.71 vẫn
CHƯA build/test thành công lần nào** — đây là việc ưu tiên ngay khi bắt
đầu phiên mới.

1. **Việc cần làm ĐẦU TIÊN**: build lại qua GitHub Actions với zip source
   MỚI NHẤT (đã gộp toàn bộ mục 5.48-5.58). Cài đè, thử LẦN LƯỢT từng
   tính năng:
   - Mở tab "Bách khoa", chuyển qua lại cả 4 tab, xác nhận nút "+" mở
     đúng form theo tab, KHÔNG còn màn hình trắng xoá (mục 5.48/5.49).
   - Chat/viết tiếp chương, đo tốc độ GPU có nhanh hơn rõ rệt không so
     với trước (mục 5.54) — cả bước mở model (không còn chờ 90s QNN vô
     ích) lẫn tốc độ sinh token (precision/memory tối ưu).
   - Story Bible còn trống, thử hỏi chat — xác nhận model KHÔNG còn tự
     bịa nội dung (mục 5.51).
   - Đang tạo chương/dịch/tóm tắt, thử vuốt back — xác nhận bị chặn đúng
     kỳ vọng, không mất tiến độ (mục 5.56, CHƯA test thật).
   - Bật nút tìm kiếm web trong chat, hỏi 1 câu cần thông tin mới — xác
     nhận có tìm được kết quả thật, không lỗi quyền `INTERNET`/mạng (mục
     5.57, CHƯA test thật — nếu lỗi quyền, cần thêm bước khai báo
     `INTERNET` permission vào `build.yml` tương tự cách đã làm cho
     Foreground Service ở mục 5.42).
   - Thử dịch/tóm tắt 1 tài liệu dài, xác nhận có hộp thoại chỉnh prompt
     trước khi chạy (mục 5.55).
2. **Nếu build.yml fail ở bước copy QNN** (mục 5.58, giờ dừng cứng thay
   vì im lặng): đọc log lỗi cụ thể — đường dẫn thư mục thật trong QNN SDK
   Community có thể khác giả định `aarch64-android/`/`hexagon-v68/unsigned/`,
   cần đối chiếu lại (chỉ ảnh hưởng nếu người dùng bật thử
   `backendPreference=3`, không ảnh hưởng đường chính GPU).
3. **`GenerationService` chưa khai báo Manifest (mục 5.42) — vẫn CHƯA
   build/test riêng biệt**, dù đã chạy nhiều lần trong lúc debug các lỗi
   khác không thấy báo lỗi cụ thể liên quan — rủi ro đã giảm nhưng chưa
   xác nhận dứt điểm bằng phép thử riêng (tắt màn hình giữa lúc sinh văn
   bản dài, xem đồng hồ có dừng không).
4. **TẤT CẢ 6 tính năng ở mục 4.10-4.15** (version snapshot, tìm kiếm,
   glossary, Story Bible nâng cao, EPUB, backup/restore) — vẫn CHƯA
   build/test lần nào kể từ khi viết, nhiều phiên gần đây tập trung vá
   lỗi native/crash/UX, chưa quay lại kiểm tra các tính năng Dart-only
   này.
5. Sau khi các mục trên ổn định: **tóm tắt phân tầng đệ quy** (giá trị
   cao nhất cho truyện dài, nhưng CHỈ sau khi đọc được `llm.hpp` thật kỹ
   hơn nếu cần quản lý KV cache, mục 5.10) → provider "GPU ngoài" + ẩn
   danh hoá thực thể (mục 5.47, đã hoãn có chủ đích) → Scene/Corkboard/
   TTS/đọc PDF-DOCX-ảnh (vẫn hoãn, xem lý do ở mục 6).
6. **Bài học quy trình quan trọng nhất phiên này**: (a) khi build "thành
   công", KHÔNG được coi là đã xác nhận tính năng hoạt động — phải tự tay
   MỞ APP, THỬ TỪNG TÍNH NĂNG THẬT; (b) khi 1 giả thuyết kỹ thuật nghe rất
   hợp lý (vd "chip đủ mạnh nên NPU phải chạy được") vẫn PHẢI đối chiếu với
   tài liệu/yêu cầu tối thiểu CHÍNH THỨC của nhà sản xuất trước khi tiếp
   tục đầu tư công sức vá lỗi — mục 5.52 tiết kiệm được rất nhiều vòng
   debug vô ích nếu được tra cứu sớm hơn; (c) mọi bản vá liên quan tới
   `BuildContext`/`InheritedWidget` (`.of(context)`) phải tự kiểm tra kỹ
   context nào đang thực sự được dùng nằm ở đâu trong cây widget — 1 bản
   vá tưởng đơn giản (mục 5.48) đã tự gây ra 1 bug nghiêm trọng hơn (mục
   5.49) ngay trong cùng 1 phiên vì bỏ qua bước này.

---

**Cập nhật (2026-08-21 — schema v12→v13: cài đặt "Tóm tắt cốt truyện" chuyển
sang riêng từng truyện + nguồn nén rẻ hơn từ Dòng thời gian/outline)**:

Theo 2 câu hỏi người dùng đặt ra ở cuối phiên trước ("cài đặt riêng từng
truyện hay chung cả app?" và đề xuất "đồng bộ theo hướng bible: xong 1
chương thì Timeline tạo sự kiện, từ đó cập nhật cốt truyện; hoặc dựa vào
outline/dàn ý của chương nếu có"):

1. **4 cài đặt của tính năng "Tự tóm tắt cốt truyện luỹ kế" chuyển từ
   SharedPreferences (chung TOÀN APP) thành cột riêng của bảng `novels`**
   (`plot_summary_enabled`, `plot_summary_interval`, và 2 cột MỚI
   `plot_summary_prefer_timeline`/`plot_summary_prefer_outline`) — lý do:
   chiến lược đồng bộ hợp lý cho 1 truyện (vd truyện chuyển cảnh nhanh cần
   giãn cách ngắn) không nhất thiết hợp cho truyện khác đang mở song song.
   `_migrateToV13` (database_service.dart) đọc lại 2 giá trị SharedPreferences
   CŨ đúng 1 lần lúc migrate DB, sao chép làm giá trị khởi tạo cho MỌI
   truyện đã có sẵn — không làm mất cài đặt người dùng cũ đang dùng. 2 cột
   mới không có tiền lệ cũ, mặc định BẬT (rủi ro thấp — chỉ tận dụng dữ
   liệu ĐÃ CÓ SẴN, không tự tạo gì mới). `GenerationSettingsScreen` giờ bắt
   buộc nhận `novelId` (đọc/ghi qua `DatabaseService`, không qua
   `SettingsService` nữa cho riêng 4 mục này — 5 tham số sinh văn bản khác
   ở trên vẫn CHUNG toàn app như cũ, đúng bản chất tài nguyên máy).
2. **`RagService._doUpdateCumulativeStorySummary` — thêm chuỗi ưu tiên
   nguồn RẺ HƠN thay vì luôn đọc lại nội dung/autoSummary đầy đủ mỗi
   chương**: (a) sự kiện Timeline của đúng chương đó nếu ĐÃ có sẵn (nhập
   tay hoặc "AI gợi ý") — mô tả cái ĐÃ xảy ra thật, đã lọc qua Bible, 0 chi
   phí AI thêm để lấy; (b) nếu Timeline rỗng, dùng `Chapter.outline` nếu có
   và người dùng đã bật — rẻ NHẤT (viết trước khi chương tồn tại) nhưng là
   KẾ HOẠCH, có thể lệch với văn bản thật đã "đắp thịt" nên luôn xếp SAU
   Timeline; (c) fallback cuối cùng: autoSummary/excerpt nội dung chương
   (hành vi cũ, không đổi). **Không tự động tạo Timeline event mới ở bước
   này** — nếu tự tạo sẽ lại tốn 1 lượt gọi AI, triệt tiêu chính mục đích
   "rẻ hơn"; muốn có Timeline, người dùng tự bấm "AI gợi ý" (mục 4.13 hoặc
   tab Dòng thời gian) hoặc tự nhập tay, độc lập với luồng viết chương.
3. **TRẠNG THÁI BUILD/TEST**: đổi thuần Dart + 1 cột SQLite mới (ADD COLUMN,
   không đụng cấu trúc bảng nào khác), rủi ro build thấp hơn các mục
   native/JNI ở các phiên trước — nhưng **CHƯA build/test thật lần nào**,
   đặc biệt cần xác nhận: (a) nâng cấp từ bản DB v12 → v13 không mất cài
   đặt tóm tắt cũ đang dùng; (b) tạo chương có sẵn Timeline/outline thật sự
   dùng đúng nguồn đó (xem qua log debug, không chỉ tin suy luận); (c) 2
   switch mới ẩn/hiện đúng trong `GenerationSettingsScreen` khi
   `plotSummaryEnabled` bật/tắt.
4. **CHƯA làm** (đã nêu nhưng ngoài phạm vi phiên này): tóm tắt phân tầng
   đệ quy thật (mục 2.5, "hierarchical merging" — Chang et al. 2023) vẫn là
   GAP hợp lệ cho truyện thật dài (nghìn chương); AI KHÔNG tự động tạo
   Timeline event ngay sau khi chương hoàn thành (có chủ đích, xem lý do
   "rẻ hơn" ở mục 2 trên) — nếu về sau người dùng muốn luồng này TỰ ĐỘNG
   (đánh đổi lại chi phí AI để đổi lấy Timeline luôn đầy đủ), cần 1 công
   tắc riêng, rõ ràng là BẬT SẼ TỐN THÊM, không gộp ngầm vào tính năng này.

---

**Cập nhật (2026-08-21, phiên 2 — rà soát "chưa nối dây"/"chỉ mã bề ngoài" +
huỷ giữa chừng khi stream + màn Tác vụ nền toàn app):**

Theo yêu cầu người dùng "kiểm tra tính năng nào có UI nhưng không hoạt
động, tính năng nào có UI nhưng chỉ là mã bề ngoài, tài liệu và code đồng
bộ chưa" — rà soát bằng cách đối chiếu MỌI hàm public ở tầng `services/`
với nơi thực sự gọi nó (không chỉ đọc lướt code), phát hiện + xử lý:

1. **`AIProvider.isReady()`** — khai báo ở interface, CẢ 3 provider implement,
   nhưng **0 nơi gọi trong toàn app**. Đã gọi tại ĐÚNG 1 điểm duy nhất —
   `SettingsService.currentProvider()` (nơi MỌI màn hình lấy provider đang
   active) — throw thông báo cụ thể (thiếu API key / thiếu đường dẫn model)
   thay vì để lỗi HTTP/native thô rơi ra tận màn hình.
2. **`BackgroundTaskManager.requestCancel()`/`clearFinished()`/`tasks`** — đã
   có sẵn, comment ghi rõ ý định dùng cho UI "Huỷ"/"Xoá lịch sử", nhưng
   KHÔNG CÓ màn hình nào gọi tới. Đã thêm `BackgroundTasksScreen` (màn "Tác
   vụ nền" — vào từ Cài đặt, có badge số lượng realtime) làm điểm truy cập
   DUY NHẤT, DÙNG CHUNG cho mọi loại nhiệm vụ nền (chat/tạo chương hàng
   loạt/tài liệu) — sống độc lập với màn hình đã tạo ra nhiệm vụ, đúng tinh
   thần thiết kế gốc của `BackgroundTaskManager`.
3. **Huỷ giữa chừng LÚC ĐANG STREAM** (theo câu hỏi người dùng: "phải đợi
   tạo xong toàn bộ rồi mới hủy?") — TRƯỚC bản vá này, đúng là gần như vậy:
   nút Huỷ (nếu có) chỉ chặn được việc THẢ THÊM chương mới vào hàng đợi,
   KHÔNG dừng được chương ĐANG stream dở (`isCancelled` chỉ được kiểm tra
   GIỮA 2 chương). Đã thêm tham số `isCancelled` vào
   `TranslationService.generateResumableWithOptionalTranslation()` — kiểm
   tra ngay sau MỖI đoạn chunk nhận được từ stream, huỷ được đúng
   giữa chừng 1 chương, không cần đợi nó viết xong. `ChapterBatchService`
   giờ gắn `onCancelRequested` cho TỪNG chương (mỗi chương = 1
   `BackgroundTask` độc lập) khi thả vào `BackgroundTaskManager` — nghĩa là
   từ màn "Tác vụ nền" (mục 2), có thể huỷ ĐÚNG 1 chương cụ thể đang chạy
   dở, kể cả sau khi đã rời màn "Tạo hàng loạt". Checkpoint được lưu tại
   ĐÚNG điểm dừng (không mất phần đã sinh), chương đó coi như "chưa xong",
   resume đúng chỗ gãy nếu tạo lại sau — KHÔNG bị tính là lỗi/bất thường
   (không chặn các chương khác đang chạy song song).
   **Giới hạn còn lại (không giấu)**: đây là huỷ CHỦ ĐỘNG qua cờ kiểm tra
   định kỳ (điểm dừng an toàn gần nhất), không phải abort cứng ngay lập
   tức — nếu HTTP đang chờ phản hồi 1 chunk lớn, độ trễ huỷ thực tế bằng
   đúng thời gian chờ chunk đó. Nhánh LOCAL tuần tự và luồng chat/tài liệu
   CHƯA được nối `onCancelRequested` tương tự (chỉ mới làm cho batch remote
   — đúng phạm vi câu hỏi gốc của người dùng).
4. **Dọn code chết phát sinh từ chính lượt vá trước** (v13): 4 hàm
   `load/savePlotSummaryEnabled/Interval` ở `SettingsService` — comment cũ
   nói "giữ vì migration cần", nhưng migration thực đọc thẳng
   SharedPreferences bằng chuỗi, không hề gọi 4 hàm đó → code chết thật sự.
   Đã xoá.
5. **Tài liệu vs code lệch pha** — mục 6 (checklist) trước đó gộp chung 1
   dòng "Provider GPU ngoài (Colab) + lớp ẩn danh hoá" là "⬜ CHƯA code" —
   SAI MỘT NỬA: provider GPU ngoài đã xong và đang dùng thật (notebook
   Colab + `OpenAICompatibleProvider` + chạy song song qua
   `BackgroundTaskManager`), nhưng **lớp ẩn danh hoá thực thể (kế hoạch 5
   lớp mục 5.29 gốc) thì đúng là CHƯA có 1 dòng code nào** — đã tách 2 mục
   này ra đúng trạng thái thật, giữ nguyên cảnh báo rủi ro bảo mật (gửi
   nguyên văn tên riêng/nội dung truyện ra GPU remote/API, không qua ẩn
   danh) cho tới khi làm.
6. **Xác nhận với người dùng (không phải bug, là thiết kế đã có sẵn)**:
   streaming + checkpoint + resume cho GPU remote (mục 5.93, phần "GHI CHÚ"
   ở đầu `_generateBatchParallel`) **đã hoạt động từ trước phiên này** —
   `generateResumableWithOptionalTranslation()` nhận từng đoạn NGAY khi
   model sinh ra, lưu định kỳ vào `Chapter.generationCheckpoint`, nên GPU
   remote sập giữa chừng không mất trắng — resume đúng chỗ gãy ở lần chạy
   tiếp theo. Đây là câu trả lời cho câu hỏi người dùng "GPU remote có hoạt
   động như model local, sinh tới đâu lưu tới đó không" — CÓ, đã làm.
7. **CHƯA làm, người dùng đã yêu cầu, để phiên sau (phạm vi lớn, cần làm
   riêng để dễ soát lỗi — đúng bài học đã rút ra ở mục 5.71)**:
   - Mở rộng phạm vi "cài đặt riêng từng truyện" ra XA HƠN 4 cài đặt tóm
     tắt cốt truyện (v13) — người dùng nêu rõ: **provider/model đang dùng,
     và 5 tham số sinh văn bản (temperature...) cũng nên riêng từng truyện**,
     không dùng chung 1 giá trị cho mọi truyện (khác hẳn giả định BAN ĐẦU
     của kiến trúc gốc mục 2.1 — "model không phải nội dung truyện nên
     dùng chung" — người dùng phản đối giả định này, cần sửa lại).
   - **Sao lưu/khôi phục THEO TỪNG TRUYỆN** (khác `BackupService` hiện tại
     — CHỈ xuất/nhập TOÀN BỘ app, mọi truyện gộp chung 1 file) — người dùng
     yêu cầu xuất được 1 file/truyện, bao gồm MỌI bảng liên quan tới đúng
     truyện đó (chương, Bách khoa, chat, tài liệu, version snapshot...).
     Rà soát nhân tiện phát hiện: `DatabaseService._backupTables` (dùng cho
     backup TOÀN APP hiện tại) đang THIẾU 2 bảng — `embeddings` (vector RAG)
     và `pending_rewrites` (hàng đợi gợi ý sửa đang chờ duyệt) — khôi phục
     từ backup hiện tại sẽ mất 2 loại dữ liệu này dù không có thông báo gì.
     Cần sửa chung khi làm mục sao lưu theo truyện.

---

**Cập nhật (2026-08-21, phiên 3 — provider/model/tham số sinh văn bản
chuyển thành cài đặt riêng từng truyện, schema v14):**

Theo phản đối trực tiếp của người dùng với giả định gốc mục 2.1 ("model
không phải nội dung truyện nên dùng chung") — lý do thật: 1 truyện có thể
đang dùng model local nhẹ để viết nhanh, 1 truyện khác đang dùng GPU remote
mạnh hơn, tham số sinh văn bản (temperature...) cũng có thể cần khác nhau
giữa 2 truyện.

1. `Novel` (story_models.dart) thêm 8 cột mới: `providerType`,
   `activeLocalModelId`, `activeApiProviderId`, `genTemperature`, `genTopP`,
   `genTopK`, `genRepetitionPenalty`, `genMaxNewTokens`. `_migrateToV14`
   sao chép giá trị SharedPreferences CŨ vào MỌI truyện đã có (cùng cách
   làm với v13). Bảng `local_models`/`api_providers` (danh sách THẬT các
   model/API key đã cấu hình) **vẫn dùng chung toàn app** — chỉ CON TRỎ
   "truyện này đang chọn cái nào" mới tách riêng; 2 truyện có thể cùng trỏ
   tới 1 model, hoặc mỗi truyện trỏ 1 cái khác nhau.
2. `SettingsService.currentProvider()` giờ **bắt buộc nhận `novelId`** —
   đã cập nhật đủ ~14 nơi gọi trong app (`chapter_editor_screen.dart` dùng
   `widget.chapter.novelId`, các màn khác dùng `widget.novelId`,
   `background_task_manager.dart` — không gắn với truyện cụ thể nào vì là
   1 singleton dùng chung cho MỌI truyện — tạm dùng `loadActiveNovelId()`
   làm căn cứ, có ghi rõ giới hạn thật ở ngay trong code).
3. `SettingsScreen`/`GenerationSettingsScreen`/`TranslationSettingsScreen`/
   `LocalOptimizationScreen` đều nhận `novelId`, xuyên suốt từ `RootScreen`.
4. **CHƯA làm — người dùng đã nói rõ "mọi dữ liệu sau khi vào truyện cụ
   thể đó là cài đặt riêng của truyện đó, chứ không chỉ những dữ liệu đó
   thôi"** — nghĩa là còn phải mở rộng tiếp sang: cấu hình local
   (threads/context/gpu layers/backend preference), RAG budget, TOÀN BỘ
   cài đặt dịch thuật trung gian, và số nhiệm vụ song song GPU remote.
   **Cố tình để lại phiên sau** — lưu ý thật cần cân nhắc khi làm: 1 số cài
   đặt trong nhóm này (threads/gpu layers/backend preference) về bản chất
   là cấu hình PHẦN CỨNG của máy, không phải nội dung truyện — chuyển
   chúng thành riêng-từng-truyện có nghĩa là ĐỔI TRUYỆN sẽ có thể kéo theo
   NẠP LẠI model với cấu hình khác (tốn thời gian hơn hẳn so với chỉ đổi
   con trỏ "đang chọn model nào" như đã làm ở mục 1-3 trên) — cần người
   dùng xác nhận đã hiểu đánh đổi này trước khi làm, không tự ý làm ngầm.
5. **Yêu cầu MỚI, CHƯA làm, đã ghi nhận cho phiên sau**:
   - Sao lưu/khôi phục: **2 lựa chọn** (toàn app HOẶC theo từng truyện),
     không phải chỉ 1 trong 2 — khác với kế hoạch phiên 2 (chỉ thêm chọn
     theo truyện).
   - **Đổi cơ chế hiển thị của MỌI loại sinh văn bản** (tạo chương, tóm
     tắt, dịch...) sang kiểu như chat hiện tại — chữ hiện DẦN ngay khi
     model sinh ra, không đợi xong cả đoạn mới hiện — áp dụng CẢ cho GPU
     remote. Đi kèm: thanh tiến trình (batch/mọi tác vụ có tiến độ) chuyển
     từ hiện GIỮA màn hình sang 1 GÓC màn hình, không còn chặn xem chữ
     đang sinh ra. Đây là thay đổi UI/luồng dữ liệu LỚN, đụng tới
     `chapter_editor_screen.dart` (đắp thịt/viết tiếp), `chapters_batch_generate_screen.dart`,
     `document_screen.dart`/`document_chunks_screen.dart`, và cách
     `TranslationService`/`ChapterBatchService` phát dữ liệu ra UI (hiện
     đang stream ở tầng service NHƯNG UI tầng trên đang đợi cả khối/hiện
     qua callback tiến trình dạng số %, không đẩy TỪNG CHỮ ra UI) — cần 1
     phiên riêng để làm cho đúng, không lẫn với các việc khác.

---

**Cập nhật (2026-08-21, phiên 4 — TOÀN BỘ cài đặt còn lại chuyển thành
riêng từng truyện, schema v15):**

Người dùng xác nhận: "Tất cả (kể cả threads/gpu layers/backend thuần phần
cứng)" — đã cảnh báo trước về đánh đổi (đổi truyện có thể kéo theo nạp lại
model), người dùng chấp nhận. Đã chuyển NỐT toàn bộ nhóm cài đặt còn lại từ
SharedPreferences sang cột riêng của `novels` (16 cột mới): cấu hình local
(`localThreads`/`localContextSize`/`localGpuLayers`/`backendPreference`),
`ragBudgetChars`, toàn bộ 7 cài đặt dịch thuật trung gian
(`translationEnabled`/`translationModelPath`/`translationTargetLanguage`/
`translationStylePrompt`/`translationPromptToTarget`/`translationPromptFromTarget`/
`translationKeepResidentMode`), `maxParallelRemoteTasks`, và 3 cài đặt xử
lý tài liệu (`docTranslatePrompt`/`docSummarizePrompt`/`docModelChoice`).
`_migrateToV15` sao chép giá trị SharedPreferences CŨ vào MỌI truyện đã có
(cùng cách làm v13/v14).

**Thay đổi cấu trúc quan trọng đi kèm** (không chỉ thêm cột, còn phải sửa
LOGIC vì hệ quả thật của việc hardware-setting giờ theo truyện):
- `LocalLlamaProvider` thêm field `novelId` (nullable — slot dịch thuật đôi
  khi được tạo mà chưa rõ truyện nào, rơi về `loadActiveNovelId()`) để tự
  đọc đúng `backendPreference` của truyện đang phục vụ khi `ensureLoaded()`.
- **Bug thật đã bắt được TRƯỚC KHI xảy ra** (rà soát kỹ trước khi coi là
  xong): cache provider local trong `SettingsService._buildProvider()` TRƯỚC
  ĐÂY khoá theo model path — nếu giữ nguyên, 2 truyện cùng chọn 1 model
  nhưng khác `backendPreference` sẽ ĐEM NHẦM backend của truyện này sang
  truyện kia (vì `ensureLoaded()` chỉ gọi lại `loadModel` native khi model
  CHƯA `_loaded`, không kiểm tra `backendPreference` có đổi hay không). Đã
  sửa: khoá cache theo cặp `(path, novelId)` — 2 truyện cùng model giờ nạp
  riêng (đúng chấp nhận đánh đổi ở trên), backend không còn lẫn.
- `TranslationService` thêm field bắt buộc `novelId` ở constructor — đã cập
  nhật toàn bộ ~11 nơi tạo `TranslationService(...)` trong app.
  `StyleService.analyzeStyleFromSample()`/`document_service.dart._generateChunk()`
  thêm tham số `novelId`/`required String novelId` tương ứng.
- `BackgroundTaskManager._currentConcurrencyCap()` giờ dùng
  `loadMaxParallelRemoteTasks(activeNovelId)` — cùng cơ chế suy ra "truyện
  đang mở" đã dùng cho `currentProvider()` ở phiên 3, GIỚI HẠN THẬT tương tự
  đã ghi ở đó vẫn áp dụng.

**Trạng thái**: cân bằng ngoặc toàn bộ project, quét sạch mọi lời gọi thiếu
`novelId` (không còn hàm nào trong `SettingsService` liên quan tới cài đặt
đọc/ghi SharedPreferences cho các nhóm đã chuyển). **CHƯA build/test thật.**

---

**Cập nhật (2026-08-21, phiên 5 — sao lưu theo từng truyện + hiện chữ dần
khi sinh văn bản + thanh tiến trình dời ra góc màn hình):**

Theo 2 yêu cầu người dùng: "sao lưu thì nên có 2 lựa chọn là sao lưu toàn
app hay sao lưu từng truyện" và "toàn bộ việc tạo chương, tóm tắt, dịch...
đều như chat là sinh ra chữ nào thì hiện chữ đó trên màn hình... thanh tiến
trình đó thay vì hiện giữa màn hình thì bây giờ hiện ở góc — áp dụng cả
cho GPU remote".

**1. Sao lưu theo từng truyện:**
- `DatabaseService.exportNovelData(novelId)`/`importNovelData(data)` mới —
  lọc đúng dữ liệu 1 truyện qua MỌI bảng liên quan, kể cả 3 bảng KHÔNG có
  cột `novel_id` trực tiếp (`document_chunks` lọc qua `document_id`,
  `chat_messages` lọc qua `session_id`, `embeddings` lọc qua `entity_id` +
  `entity_type`).
- Tiện thể rà soát lại phát hiện `_backupTables` (backup TOÀN APP) THIẾU 2
  bảng `pending_rewrites`/`embeddings` từ trước — đã bổ sung, backup toàn
  app từ giờ đầy đủ hơn (backup cũ vẫn khôi phục bình thường, chỉ đơn giản
  thiếu 2 loại dữ liệu đó).
- `BackupService`: `exportBackup()` (toàn app) và `exportNovelBackup(novelId, title)`
  (1 truyện) — file JSON có thêm `scope` ('app'/'novel') để bên đọc tự nhận
  diện, không đoán mò. `BackupRestoreScreen` giờ có 2 nút sao lưu riêng, hộp
  thoại xác nhận khôi phục tự đổi nội dung theo scope, CẢNH BÁO RÕ nếu
  truyện trong file backup ('novel') trùng id với truyện đã có trên máy —
  khôi phục sẽ GHI ĐÈ đúng truyện đó (không tạo id mới — theo đúng cách
  `importAllData`/`importNovelData` đã làm từ trước, giữ nhất quán 1 kiểu
  hành vi "ghi đè theo id" xuyên suốt app, không phát minh thêm 1 kiểu mới
  chỉ cho tính năng này).

**2. Hiện chữ dần khi sinh văn bản (giống chat) + progress dời ra góc:**
- `chapter_editor_screen.dart` ("Viết tiếp"/"Đắp thịt"): khi dịch thuật
  trung gian TẮT (mặc định), giờ bỏ qua `TranslationService` và stream
  trực tiếp từ provider — CÙNG NHÁNH NHANH `chat_screen.dart` đã dùng —
  chữ hiện thẳng vào ô nội dung chương ngay khi model sinh ra. Màn này
  TRƯỚC ĐÓ đã không dùng dialog chặn (chỉ có `aiStage` inline nhỏ), nên
  không cần dời gì, chỉ thêm phần hiện chữ dần.
- `chapters_batch_generate_screen.dart`: **bỏ hẳn** `AlertDialog`
  (`barrierDismissible: false`) từng chặn giữa màn hình — thân màn hình
  trong lúc chạy đổi sang hiện TRỰC TIẾP văn bản đang sinh của TỪNG chương
  (có thể NHIỀU chương cùng lúc nếu là GPU remote — mỗi chương 1 thẻ cuộn
  riêng), tiến trình TỔNG dời xuống 1 thẻ nhỏ ở góc dưới phải. `ChapterBatchService`
  thêm `currentText`/`currentChapterId` vào callback `onProgress` để UI biết
  ĐÚNG chương nào đang gửi chữ gì (quan trọng khi nhiều chương chạy song
  song — không thể chỉ có 1 giá trị "text hiện tại" dùng chung).
- `document_screen.dart`: cùng cách — bỏ `AlertDialog`, dời thẻ tiến trình
  ra góc dưới phải. **CHƯA làm hiện chữ dần cho tài liệu** (mỗi đơn vị xử
  lý là 1 đoạn ngắn, hoàn thành nhanh — ưu tiên thấp hơn phần dời thanh
  tiến trình, đã làm xong phần đó).
- **GIỚI HẠN THẬT đã có từ trước, không đổi** (đã ghi rõ ở
  `chat_screen.dart` gốc, nay lặp lại ở `chapter_editor_screen.dart`): khi
  dịch thuật trung gian BẬT, không stream được — dịch câu vào/model
  sinh/dịch câu ra là 3 lượt AI tuần tự, vẫn hiện theo giai đoạn (`aiStage`)
  như cũ. Nhánh LOCAL tuần tự của tạo chương hàng loạt (`_generateBatchSequential`)
  CHƯA có `currentText`/`currentPercent` — cố tình KHÔNG đổi (mục 5.67, lý
  do an toàn crash) — bất đối xứng với nhánh REMOTE giống hệt `currentPercent`
  đã có từ trước.

**Trạng thái**: cân bằng ngoặc toàn bộ project. **CHƯA build/test thật** —
đặc biệt cần xác nhận: (a) khôi phục 1 truyện từ backup không làm hỏng dữ
liệu của các truyện khác trên máy; (b) chữ hiện dần trong "Viết tiếp"/"Đắp
thịt" không bị giật/lag khi model sinh nhanh (nhiều lần setState liên tiếp);
(c) nhiều thẻ chương chạy song song trong "Tạo hàng loạt" hiện đúng, không
lẫn text của nhau.

---

**Cập nhật (2026-08-22, phiên 6 — sửa 2 "giới hạn thật" ghi sai ở phiên 5,
theo phản biện đúng của người dùng):**

Người dùng chỉ ra 2 điểm ở phiên 5 mà Claude tự nhận là "giới hạn thật"
thực ra là kết luận SAI/thiếu suy xét, không phải giới hạn kỹ thuật có
thật — cả 2 đã được sửa tận gốc:

1. **"Dịch thuật trung gian bật thì không stream được"** — SAI. Đường ống 3
   bước (dịch câu vào → model chính sinh → dịch câu ra) chỉ có bước GIỮA
   không hiện ra màn hình (chỉ là ngữ cảnh cho model), còn bước DỊCH NGƯỢC
   (bước 3) MỚI là văn bản người dùng thực sự nhìn thấy — và bước đó chạy
   trên `LocalLlamaProvider` (model dịch nhỏ), vốn dĩ đã hỗ trợ
   `generateStream()` y hệt model chính, không có lý do kỹ thuật nào để
   không stream được. Đã sửa: `TranslationService.translate()` thêm tham
   số `onChunk` tùy chọn (stream khi có, gọi `generate()` thường khi
   không); `generateWithOptionalTranslation()`/`generateResumableWithOptionalTranslation()`
   truyền `onChunk`/`onTranslatedChunk` xuống đúng bước dịch ngược. Nhánh
   TẮT dịch thuật cũng được nâng cấp tương tự (trước đó vẫn gọi
   `mainProvider.generate()` không streaming ngay cả khi tắt — bất nhất
   với cách `chapter_editor_screen.dart` đã tự bypass streaming trực tiếp).
   Kết quả: `chapter_editor_screen.dart`/`chat_screen.dart` giờ gọi THẲNG
   `generateWithOptionalTranslation(..., onChunk: ...)` cho CẢ 2 trường hợp
   bật/tắt dịch thuật — không cần nhánh rẽ/bypass riêng như trước, code gọn
   hơn HẲN so với phiên 5 (tự nó là bằng chứng "giới hạn" trước đó chỉ là
   thiếu nhìn kỹ, không phải rào cản thật).
2. **"Batch local không thêm live text vì lo crash 2 lệnh generate chạy
   chồng chéo (mục 5.67)"** — NHẬN ĐỊNH NHẦM LẪN 2 VIỆC KHÁC NHAU. Mục 5.67
   nói về việc ĐỔI CẤU TRÚC CHẠY (chạy song song thay vì tuần tự — tăng số
   lệnh generate() ĐANG CHẠY CÙNG LÚC), không liên quan gì tới việc thêm 1
   callback QUAN SÁT THỤ ĐỘNG (`onChunk`) lên 1 lệnh generate() VỐN DĨ đã
   chạy tuần tự (vòng `for` vẫn `await` xong chương này mới sang chương kế
   — không đổi). Đã sửa: `_generateBatchSequential` (nhánh LOCAL) giờ CŨNG
   có live text qua `onChunk`, xoá bất đối xứng vô lý với nhánh REMOTE.
   Phần checkpoint/resume khi crash (khác với live text — đây là việc LƯU
   TẠM xuống DB để phục hồi) VẪN chỉ ở nhánh REMOTE — đây MỚI là giới hạn
   thật (model LOCAL "sập" thường kéo theo crash cả tiến trình Dart đang
   giữ checkpoint, remote thì GPU chết nhưng app điện thoại vẫn sống) —
   không đổi, không liên quan gì tới việc vừa sửa.

**Bài học rút ra** (tự phê bình, ghi lại để không lặp lại): khi tự đánh giá
"limitation" trước khi người dùng hỏi lại, cần THỬ TÌM CÁCH GIẢI QUYẾT
TRƯỚC, không chỉ liệt kê lý do rồi dừng — cả 2 "giới hạn" ở phiên 5 đều
xuất phát từ việc dừng phân tích quá sớm, không truy tới tận gốc xem có
thật sự không giải quyết được không.

**Trạng thái**: cân bằng ngoặc toàn bộ project. **CHƯA build/test thật** —
đặc biệt cần xác nhận: (a) stream bước dịch ngược trong `translate()` hoạt
động đúng qua `LocalLlamaProvider.generateStream()` (chưa từng gọi
generateStream trên model dịch trước đây, chỉ gọi generate() thường); (b)
UI batch local hiện chữ dần mượt, không giật khi kèm cả `LocalLlamaProvider.updatePipelineStage()`
gọi song song trong cùng vòng lặp.

---

**Cập nhật (2026-08-22, phiên 7 — tài liệu cũng hiện chữ dần, cho NHẤT
QUÁN 100% với mọi màn sinh văn bản khác):**

Người dùng phản đối trực tiếp quyết định "ưu tiên thấp hơn" ở phiên 5 cho
xử lý tài liệu ("sao lì lợm dữ vậy, các màn hình AI tạo sinh văn bản đều
làm theo dạng chữ xuất hiện từng chữ 1 hết chứ") — đúng, "mỗi đoạn ngắn nên
ưu tiên thấp" không phải lý do kỹ thuật, chỉ là lựa chọn dừng sớm không cần
thiết. Đã sửa hết:

- `_generateChunk` (document_service.dart) thêm `onChunk` — hành động
  "Tóm tắt" đã qua `TranslationService.generateWithOptionalTranslation`
  (tự hỗ trợ `onChunk` từ phiên 6) nên chỉ cần truyền xuống; hành động
  "Dịch" (cố tình KHÔNG qua `TranslationService`, xem comment gốc đầu file
  — lý do NGÔN NGỮ, không liên quan gì tới streaming) đổi từ
  `provider.generate()` sang `provider.generateStream()` — cùng 1
  interface `AIProvider`, đổi đúng 1 chỗ.
- `onProgress` (cả `DocumentService`/UI) thêm `currentText`/`currentChunkId`
  — CÙNG QUY ƯỚC hệt `ChapterBatchService` (mục 5, phiên 5): text rỗng/null
  = đoạn đó vừa xong/lỗi, bỏ khỏi danh sách "đang chạy".
- `document_screen.dart`: thêm panel hiện chữ đang sinh của (các) đoạn
  đang chạy — CHÈN THÊM phía trên danh sách tài liệu (không thay thế hẳn,
  khác chapters_batch_generate_screen.dart — ở đây người dùng có thể vẫn
  cần thấy các tài liệu KHÁC trong lúc 1 tài liệu đang xử lý), cao tối đa
  35% màn hình, tự cuộn. Thẻ góc dưới phải giữ nguyên (đã làm ở phiên 5).
- Nhánh LOCAL tuần tự CŨNG có live text (không có lý do gì để bất đối xứng
  với remote — cùng bài học "quan sát thụ động ≠ đổi cấu trúc chạy" đã rút
  ra ở phiên 6 cho `ChapterBatchService`).

Tới đây, MỌI nơi trong app gọi model sinh văn bản Việt (chat, viết chương,
tạo hàng loạt, dịch/tóm tắt tài liệu) đều hiện chữ dần khi có thể về mặt kỹ
thuật — giới hạn CÒN LẠI DUY NHẤT là "kiểm tra tính nhất quán"/"tóm tắt
chương"/1 số tác vụ nội bộ ngắn khác gọi `generateWithOptionalTranslation`
KHÔNG truyền `onChunk` (không hiện lên UI dạng chữ chạy vì bản thân UI đó
chỉ hiện 1 dòng kết quả ngắn/không phải ô văn bản lớn — không phải giới
hạn kỹ thuật, mà là các UI đó chưa cần thiết kế lại dạng "khung lớn hiện
chữ chạy" cho 1 câu trả lời ngắn).

**Trạng thái**: cân bằng ngoặc toàn bộ project. **CHƯA build/test thật.**

---

**Cập nhật (2026-08-22, phiên 8 — lỗi build THẬT từ CI, xác nhận có lệch
pha thật giữa "đã sửa" và "đã sửa ĐỦ"):**

Người dùng hỏi thẳng "tài liệu kỹ thuật đã đồng bộ với code chưa hay có sự
lệch pha" — trong lúc đang tra soát để trả lời, người dùng dán log build
GitHub Actions THẤT BẠI THẬT:

```
lib/screens/document_chunks_screen.dart:149:21: Error: The argument type
'void Function(int, int)' can't be assigned to the parameter type
'void Function(int, int, {String? currentChunkId, String? currentText})?'.
```

**Nguyên nhân**: `document_chunks_screen.dart` — 1 màn hình RIÊNG (xử lý
từng đoạn được CHỌN RIÊNG RẼ của 1 tài liệu, khác `document_screen.dart` xử
lý theo PHẠM VI liên tục) — dùng chung `DocumentService.processDocument()`
nhưng bị BỎ SÓT hoàn toàn ở phiên 7 khi thêm `currentText`/`currentChunkId`
vào chữ ký `onProgress`. Phiên 7 chỉ rà soát "callback dùng chung" bằng
cách xem lại các file ĐÃ ĐỘNG TỚI gần nhất (`document_service.dart`,
`document_screen.dart`) — không `grep` lại TOÀN BỘ project theo ĐÚNG TÊN
HÀM `processDocument`/`onProgress` — nên bỏ sót đúng 1 file có cùng cách
dùng nhưng chưa từng được sửa ở các phiên trước (dùng dialog chặn CŨ,
chưa bao giờ được nâng cấp lên corner-progress như 2 màn kia).

**Đã sửa**: nâng `document_chunks_screen.dart` lên ĐÚNG cùng pattern đã áp
dụng cho `document_screen.dart` (bỏ `AlertDialog` chặn, thêm panel chữ chạy
dần + thẻ tiến trình góc dưới phải) — không chỉ vá cho qua lỗi build.

**Trả lời thẳng câu hỏi "đồng bộ chưa"**: KHÔNG — vừa có bằng chứng cụ thể
(lỗi build thật) rằng "đã rà soát" ở các phiên trước KHÔNG đồng nghĩa
"rà soát đủ". Đã kiểm lại toàn bộ 3 nơi gọi `DocumentService.processDocument()`/
`ChapterBatchService.generateBatch()` trong app bằng `grep -rn "onProgress: ("`
— xác nhận cả 3 (`chapters_batch_generate_screen.dart`,
`document_chunks_screen.dart`, `document_screen.dart`) giờ khớp đúng chữ ký
mới. Cân bằng ngoặc lại toàn bộ project.

**Bài học rút ra (lần 2 — nghiêm trọng hơn lần trước vì lần này là lỗi
build thật, không phải chỉ nhận định sai)**: đổi CHỮ KÝ của 1 hàm/callback
DÙNG CHUNG (không riêng của 1 màn hình) bắt buộc phải `grep` lại theo ĐÚNG
TÊN HÀM trên TOÀN BỘ `lib/`, không được giới hạn phạm vi rà soát theo "các
file vừa sửa trong phiên này" — 2 màn hình cùng gọi 1 hàm có thể được viết
ở 2 thời điểm khác nhau, sửa 1 màn không có nghĩa màn kia đã được cập nhật
theo.

---

**Cập nhật (2026-08-23, phiên 9 — TÌM RA NGUYÊN NHÂN GỐC "máy nóng, chờ
lâu, chat không sinh chữ": WakeLock có khoảng hở, thiết bị ngủ sâu giữa
chừng lúc đang sinh văn bản):**

Log lần 2 (đã có timestamp mới ở cả tầng C++/Kotlin, xem phiên 8) cho thấy
điều bất ngờ: KHÔNG có khoảng hở nào giữa lúc native báo xong và lúc
Kotlin/Dart nhận được (`onToken`/`nativeGenerate() TRA VE XONG` đều lệch
nhau <1ms) — giả thuyết "main thread bị nghẽn" ở phiên 8 SAI. Nguyên nhân
thật nằm ở CHỖ KHÁC: `THOI GIAN THAT (ms)=73487` (đo bằng `std::chrono::steady_clock`,
map tới `CLOCK_MONOTONIC` trên Android — **KHÔNG đếm thời gian lúc thiết bị
ngủ sâu**) lệch ~379 GIÂY so với thời gian tường thật giữa 2 mốc log (đo
bằng `system_clock`, CÓ đếm cả lúc ngủ sâu). Nghĩa là: **thiết bị đã ngủ
sâu ~379 giây NGAY GIỮA LÚC đang sinh văn bản**, dù `PARTIAL_WAKE_LOCK` +
`startForeground` đáng lẽ phải ngăn việc này.

**Nguyên nhân gốc tìm thấy trong code**: `GenerationService.start()`/`.stop()`
(gọi từ `beginPipeline`/`loadModel`/`generate` trong `MnnBridge.kt`) chỉ
`mainHandler.post{}` (ĐẨY việc vào hàng đợi main thread rồi TRẢ VỀ NGAY,
KHÔNG ĐỢI `onStartCommand()` của `GenerationService` thật sự chạy xong và
giữ được WakeLock). Có 1 KHOẢNG HỞ THẬT giữa lúc `nativeGenerate()`/
`nativeLoadModel()` BẮT ĐẦU chạy (trên coroutine, gần như ngay lập tức) và
lúc WakeLock của `GenerationService` THỰC SỰ được giữ (phụ thuộc main
thread Looper xử lý xong Intent đã post) — nếu màn hình vừa tắt/máy vừa
chuyển nền ĐÚNG vào khoảnh khắc đó, hệ điều hành có thể bắt đầu ngủ sâu
TRƯỚC KHI WakeLock kịp giữ, và một khi đã ngủ, chính việc xử lý Intent
đang chờ trên hàng đợi main thread cũng bị đóng băng theo — vòng luẩn quẩn
không tự thoát ra được cho tới "cửa sổ bảo trì" định kỳ tiếp theo của
Doze/App Standby.

**Đã sửa tận gốc**: thêm 1 `PowerManager.WakeLock` TRỰC TIẾP trong chính
`MnnBridge.kt` (`directWakeLock`), giữ NGAY TRONG cùng khối `synchronized`
dùng để tăng/giảm `pipelineDepth` (cho `beginPipeline`/`endPipeline`) hoặc
ngay tại điểm quyết định "lệnh độc lập" (cho `loadModel`/`generate` gọi
không qua pipeline) — ĐẢM BẢO KHÔNG CÓ khoảng hở nào giữa lúc quyết định
bắt đầu 1 phiên sinh và lúc WakeLock thực sự được giữ, không phụ thuộc vào
việc main thread xử lý Intent kịp hay không. `GenerationService` (thông
báo + WakeLock riêng, tự làm mới mỗi 30 phút) vẫn giữ nguyên làm lớp bảo vệ
THỨ 2 cho phiên chạy DÀI — WakeLock trực tiếp chỉ là lớp bảo vệ TỨC THỜI
cho đúng khoảng hở khởi động (giữ tối đa 40 phút/lần, không tự làm mới,
không cần vì đến lúc đó `GenerationService` đã chắc chắn chạy xong).

**Đã thêm** (để lần sau — nếu còn xảy ra — chẩn đoán được ngay trong 1 dòng
log): `nativeGenerate()` giờ đo CẢ `steady_clock` lẫn `system_clock` song
song quanh `llm->response()`, in luôn chênh lệch — nếu > 3 giây, tự in cảnh
báo rõ ràng "RẤT CÓ THỂ máy đã ngủ sâu giữa chừng" ngay trong log, không
cần tự trừ tay 2 timestamp ở 2 dòng khác nhau như trước.

**Phát hiện thêm (riêng, chưa sửa)**: kết quả dịch systemPrompt trong log
vẫn cho thấy dấu hiệu model dịch 1.8B ĐANG DỊCH NHẦM CHÍNH CÂU LỆNH thay vì
nội dung được giao (kết quả = bản tiếng Anh của chính prompt hướng dẫn, không
phải bản tiếng Anh của nội dung Story Bible cần dịch) — lỗi CHẤT LƯỢNG
riêng, không liên quan tốc độ/WakeLock, cần điều tra thêm ở phiên sau (có
thể do model quá nhỏ để tách biệt "hướng dẫn" khỏi "nội dung", hoặc cần
format prompt rõ ràng hơn — vd bọc nội dung cần dịch trong dấu ngoặc kép/
markdown code block để model phân biệt rõ hơn).

**QNN .so vẫn thiếu ở lần chạy build gần nhất** (log runtime lần 2 vẫn báo
UnsatisfiedLinkError cho cả 5 file) — vẫn đang chờ log đầy đủ của bước
"Đặt file .so vào đúng chỗ..." (có in cấu trúc thư mục thật của QNN SDK) để
xác định đúng đường dẫn cần sửa trong `build.yml`.

**Trạng thái**: cân bằng ngoặc cả Dart lẫn native (C++/Kotlin, đã kiểm tra
comment-aware, không chỉ đếm ký tự thô). **CHƯA build/test thật trên thiết
bị** — đặc biệt cần xác nhận: WakeLock trực tiếp mới thêm có thực sự ngăn
được ngủ sâu giữa chừng hay không (chỉ xác nhận được qua chạy lại thật, xem
log có còn dòng "CHENH LECH...ms" hay không).

---

**Cập nhật (2026-08-23, phiên 10 — thêm chẩn đoán chi tiết cho lỗi load()
FALSE của model 8B, không cần PC/adb):**

Người dùng đã tự tay đổi tên `llm_config.json` → `config.json` theo đúng
gợi ý của 1 bên phân tích khác — **KHÔNG hết lỗi**, `load()` vẫn trả FALSE
cho cả OpenCL lẫn CPU, và fail trong **~1 mili giây** (giữa lúc
`createLLM()` xong và `load() FALSE` chỉ cách nhau 1ms) — quá nhanh để là
lỗi đọc dở file weight 4GB, nhiều khả năng fail ngay ở bước kiểm tra đầu
(tên file tham chiếu bên trong config không khớp file thật, hoặc file bị
thiếu/hỏng) — nhưng KHÔNG có cách xác nhận chắc chắn nếu không thấy được
nội dung `config.json` ĐANG DÙNG đối chiếu với file THẬT trong thư mục.

Người dùng không có PC/adb để lấy `logcat` thật — đã thêm 2 hàm chẩn đoán
mới vào `mnn_bridge.cpp`, chạy TRƯỚC MỌI lần gọi `Llm::createLLM()` (không
chỉ khi nghi lỗi, vì lỗi không đoán trước được lúc nào xảy ra):

1. `logConfigDiagnostics()` — in TOÀN BỘ nội dung `config.json` ĐANG ĐƯỢC
   DÙNG (tối đa 3000 ký tự) thẳng vào `native_debug.txt` — người dùng xem
   được ngay trong app, không cần tự mở file quản lý riêng. Sau đó dò 3
   field quan trọng nhất (`llm_model`/`llm_weight`/`tokenizer_file`) bằng
   tìm chuỗi thô (KHÔNG parse JSON thật — chỉ để LOG, không ảnh hưởng logic
   nạp thật của MNN) — với MỖI field, kiểm tra file được khai báo có THẬT
   SỰ tồn tại trong thư mục hay không và kích thước thật là bao nhiêu, in
   rõ dòng cảnh báo `!!!` nếu không khớp — đây chính là bước "đối chiếu tự
   động" mà trước đó phải đoán qua ảnh chụp màn hình người dùng gửi.
2. `listDirWithSizes()` — liệt kê MỌI file trong thư mục model kèm kích
   thước byte thật — lộ ngay các trường hợp file tải dở/cắt cụt.

**Cân nhắc đã bỏ qua (ghi lại để không thử lại vô ích)**: có xem xét dùng
`__android_log_set_logger()` để bắt luôn log nội bộ CỦA CHÍNH MNN (macro
`MNN_ERROR`/`MNN_PRINT` ghi thẳng vào Android logcat qua `liblog`, không
qua `nativeLog()` của app) — hàm này chỉ có từ API 30 trong khi `minSdk=28`
của project, cần thêm lớp `dlsym` runtime-check phức tạp và có rủi ro ảnh
hưởng toàn bộ logging của tiến trình. Tạm KHÔNG làm — ưu tiên 2 hàm chẩn
đoán ở trên trước (an toàn, tương thích mọi API, khả năng cao đã đủ tìm ra
nguyên nhân dựa trên bằng chứng hiện có — ảnh chụp màn hình cho thấy
`llm.mnn` chỉ 2,30 MB trong khi có 1 file lạ `llm.mnn.json` 5,73 MB chưa
từng được nhắc tới trước đây, rất đáng ngờ).

**Trạng thái**: cân bằng ngoặc (đã kiểm tra comment/string-aware). **CHƯA
build/test thật** — cần người dùng build lại + thử load model 8B 1 lần nữa,
rồi gửi đoạn log mới (sẽ có thêm nhiều dòng `[CHAN DOAN]`) để xác định
chính xác nguyên nhân thay vì tiếp tục suy đoán.

---

**Cập nhật (2026-08-23, phiên 11 — TÌM RA LỖI NGHIÊM TRỌNG NHẤT TỪ ĐẦU TỚI
GIỜ: crash thật (SIGSEGV) do gửi chồng nhiều lệnh chat cùng lúc):**

Sau khi khôi phục đúng cặp `config.json`/`llm_config.json` (đúng như phiên
10 dự đoán — file `config.json.arch` là `llm_config.json` gốc bị đặt sai
tên khi làm theo gợi ý của 1 bên phân tích khác), model 8B **load thành
công** — nhưng log ngay sau đó lộ ra 1 lỗi HOÀN TOÀN KHÁC, nghiêm trọng
hơn nhiều: người dùng gõ "alo" 3 lần liên tiếp trong lúc model còn đang xử
lý câu đầu → native tự phát hiện **"TU CHOI vi phat hien lenh generate
KHAC dang chay dong thoi tren cung slot 0"** → ngay sau đó **crash SIGSEGV
thật** sâu trong `MNN::Session::run()` (stack trace đầy đủ trong log CI).

**Nguyên nhân gốc**: `chat_screen.dart._send()` có cờ chặn gửi trùng
(`sending`), nhưng cờ đó bị đặt **SAU** dòng `await db.upsertChatMessage(...)`
— tạo ra 1 khoảng hở race condition thật: bấm gửi 2-3 lần trong đúng vài
chục mili giây đó, MỌI lần bấm đều đọc `sending == false` (chưa kịp cập
nhật) và đều lọt qua, dẫn tới nhiều lệnh gọi model native chạy chồng lên
nhau — làm hỏng session/KV-cache nội bộ MNN và crash cứng cả tiến trình.
**Đây chính là lý do "tác vụ nền vẫn chạy dù đã vuốt xoá app khỏi recent
apps"** — app không "chạy dở bình thường", nó đã CRASH, nên luồng dọn dẹp
bình thường (tắt thông báo Foreground Service, thả WakeLock) không kịp
chạy, để lại thông báo + WakeLock kẹt lại (giải thích luôn hiện tượng máy
nóng/pin tụt đã báo cáo nhiều lần trước đó — CÓ THỂ chính là lỗi này, không
phải hoàn toàn do ngủ sâu như phiên 9 kết luận).

**Đã sửa**: đặt `sending = true` NGAY DÒNG ĐẦU của `_send()`, TRƯỚC MỌI
`await` — đóng kín khoảng hở hoàn toàn (đúng nguyên tắc đã áp dụng chuẩn ở
`chapter_editor_screen.dart._continueWithAI()`/`_fleshOutOutline()` từ đầu,
rà soát lại xác nhận 2 hàm đó KHÔNG dính lỗi này). Thêm lớp bảo vệ thứ 2:
vô hiệu hoá nút gửi + gửi qua bàn phím (`onSubmitted`) khi `sending == true`.

**Đã rà soát các màn hình khác có nguy cơ tương tự** (`document_screen.dart`,
`document_chunks_screen.dart`, `chapters_batch_generate_screen.dart`) —
mỗi màn đều có 1 `showDialog` (modal, chặn tương tác) đứng TRƯỚC lúc đặt cờ
bận, nên khoảng hở race hẹp hơn NHIỀU so với chat (khoảng hở ở chat là 1
lệnh ĐỌC/GHI DATABASE thật, không phải chỉ đợi 1 dialog đóng) — rủi ro thấp
hơn hẳn, chưa sửa ngay nhưng ghi nhận để theo dõi nếu còn crash tương tự.

**Trạng thái**: cân bằng ngoặc. **CHƯA build/test thật** — cần xác nhận
sau khi build lại, gõ gửi liên tiếp nhiều lần không còn crash, và (nếu vẫn
còn hiện tượng máy nóng/thông báo kẹt) mới cần quay lại nghi vấn ngủ sâu
(WakeLock) của phiên 9.

---

**Cập nhật (2026-08-23, phiên 12 — bản sửa phiên 11 CHƯA đủ, tìm ra nguyên
nhân crash THẬT SỰ chính xác: use-after-free khi nạp model mới đè lên
lệnh generate() "mồ côi" từ phiên trước):**

Người dùng làm rõ lại đúng trình tự 3 lần gõ "alo" — KHÔNG phải gõ liên
tiếp trong vài chục mili giây như phiên 11 suy đoán, mà là 3 LẦN THỬ RIÊNG
BIỆT cách nhau nhiều phút, ứng với 3 lần sửa file config khác nhau. Bản sửa
`sending = true` (chặn double-tap) ở phiên 11 tuy đúng và nên giữ, nhưng
**KHÔNG PHẢI nguyên nhân của crash đã thấy trong log**.

**Nguyên nhân THẬT (đọc lại chính xác trình tự log)**:
1. Lần thử ở `16:36:48` gọi `nativeGenerate()` trên slot=0 — log KHÔNG BAO
   GIỜ thấy dòng "TRA VE XONG" cho lệnh này trước khi phiên app kết thúc
   (người dùng rời màn hình/đóng app giữa chừng — khớp lời kể "bị chết
   chạy nền, hay do lỡ vuốt nhầm nút back"). Lệnh generate() này **KHÔNG
   HỀ BỊ HUỶ THẬT SỰ** — tiếp tục chạy "mồ côi" trong tiến trình native.
2. App khởi động lại (`16:58:11`), người dùng sửa xong config lần cuối,
   bấm nạp lại model 8B vào **CÙNG slot=0**. `nativeLoadModel()` gọi thẳng
   `llmSlot.reset(Llm::createLLM(path))` — **HUỶ NGAY object `Llm` cũ**,
   KHÔNG kiểm tra xem lệnh generate() mồ côi từ bước 1 có còn đang cầm con
   trỏ tới đúng object đó hay không.
3. Lệnh generate() mồ côi (vẫn đang chạy) tiếp tục dùng con trỏ `Llm*` giờ
   đã TRỎ TỚI VÙNG NHỚ ĐÃ GIẢI PHÓNG → **use-after-free** → SIGSEGV thật
   trong `MNN::Session::run()` — khớp CHÍNH XÁC stack trace trong log CI.

**Đã sửa tận gốc**: `nativeLoadModel()` giờ kiểm tra `g_generatingInProgress[slot]`
NGAY TRƯỚC khi huỷ object cũ — nếu slot đang có generate() chạy dở (kể cả
"mồ côi"), **TỪ CHỐI nạp model mới** (trả `JNI_FALSE`, không huỷ gì cả)
thay vì âm thầm huỷ và gây use-after-free. `local_provider.dart.generateStream()`
cũng được sửa: bọc `yield* controller.stream` trong `try/finally`, gọi
`cancelGenerate` native ngay khi consumer (màn hình chat) ngừng lắng nghe
GIỮA CHỪNG (rời màn hình, chưa nhận `done=true`).

**GIỚI HẠN THẬT — chưa giải quyết hoàn toàn (không giấu)**: `cancelGenerate`
phía Kotlin hiện chỉ gọi `currentJob?.cancel()` — đây là **huỷ hợp tác**
(cooperative cancellation) của Kotlin coroutine, KHÔNG có khả năng ngắt
NGANG 1 lời gọi JNI đồng bộ (blocking) đang chạy dở bên trong
`llm->response()` của MNN — vì MNN (dựa trên rà soát code trong repo này)
KHÔNG lộ ra cờ "dừng giữa chừng" nào để tầng Kotlin/C++ kiểm tra định kỳ.
Nghĩa là: lệnh generate() mồ côi VẪN SẼ tiếp tục chạy tới khi tự nhiên
xong (có thể vài phút), KHÔNG dừng ngay lập tức khi rời màn hình — nhưng
giờ đã AN TOÀN (không còn crash use-after-free nếu người dùng thử nạp
model khác trong lúc đó, chỉ đơn giản bị từ chối với thông báo rõ ràng).
Muốn dừng THẬT SỰ ngay lập tức, cách chắc chắn duy nhất hiện tại là
**đóng hẳn app (force-stop), không chỉ rời màn hình** — vì force-stop giết
cả tiến trình OS, không có cách nào để 1 luồng "mồ côi" sống sót qua đó.

**Trạng thái**: cân bằng ngoặc (Dart + C++/Kotlin, comment-aware). **CHƯA
build/test thật** — cần xác nhận: (a) không còn crash SIGSEGV nếu lặp lại
đúng kịch bản "rời màn hình giữa chừng rồi nạp model khác"; (b) thông báo
lỗi rõ ràng hiện ra thay vì crash trong tình huống đó.

---

**Cập nhật (2026-08-25, phiên 13 — sửa 3 vấn đề xác nhận thật từ log/ảnh
chụp: nút "X" chat vẫn không huỷ được, model lặp vô tận không có gì chặn,
`repetitionPenalty` mặc định quá thấp):**

1. **Nút "X" ở màn "Tác vụ nền" KHÔNG huỷ được chat local đang stream —
   XÁC NHẬN ĐÚNG LÀ BUG, chưa từng được sửa thật (dù có 1 phiên làm việc
   trước tự nhận "đã sửa xong" — kiểm tra lại mã nguồn thật cho thấy chưa
   hề áp dụng)**: `BackgroundTaskManager.submitAndWait()` (hàm `chat_screen.dart`
   dùng để nộp việc chat) gọi `submit()` bên dưới nhưng KHÔNG truyền
   `onCancelRequested` — mọi nhiệm vụ chat luôn có `onCancelRequested ==
   null`, nên `requestCancel()` (nút X gọi) không có gì để gọi. **Đã sửa
   tận gốc, xuyên suốt 3 lớp**:
   - `submitAndWait()` nhận thêm `onCancelRequested`, truyền xuống `submit()`.
   - `TranslationService.translate()`/`generateWithOptionalTranslation()`
     nhận thêm `isCancelled` (cùng khuôn mẫu đã có sẵn ở
     `generateResumableWithOptionalTranslation()` cho batch remote — chỉ
     là CHƯA từng nối cho chat/`generateWithOptionalTranslation()` như tài
     liệu phiên trước đã ghi nhận đúng là giới hạn thật) — kiểm tra ngay
     sau mỗi đoạn chunk nhận được, `break` sớm nếu đã bị huỷ.
   - `chat_screen.dart` thêm cờ `cancelRequested`, đặt lại `false` đầu mỗi
     lượt gửi, bật `true` trong `onCancelRequested`, truyền `isCancelled: ()
     => cancelRequested` vào `generateWithOptionalTranslation`.
   - Cơ chế huỷ THẬT SỰ dừng lệnh native: `break` khỏi `await for` khiến
     `LocalLlamaProvider.generateStream()` phát hiện consumer ngừng lắng
     nghe (nhánh `finally` đã có từ mục 5, phiên 12) → tự gọi
     `cancelGenerate` native — không cần thêm cơ chế huỷ mới ở tầng native.
   - **Giới hạn còn lại (không giấu)**: bước "sinh văn bản" ở GIỮA khi dịch
     thuật trung gian BẬT vẫn gọi `mainProvider.generate()` không
     streaming (đợi cả khối) — không có điểm dừng an toàn giữa chừng, huỷ
     lúc đó vẫn phải đợi bước đó xong rồi mới dừng ở bước dịch ngược. Đây
     là giới hạn có thật, không phải bug.

2. **Model lặp vô tận (log thật: model dịch trả `"8888888"`; ảnh chụp màn
   hình thật: Qwen 7B trả cả màn hình dấu `"(((((("`) — TRƯỚC ĐÂY KHÔNG
   CÓ GÌ PHÁT HIỆN/CHẶN**, model chạy tới hết `max_new_tokens` mới dừng
   (log thật: 1024 token trong 550 giây, máy nóng vô ích, pin tụt
   73%→18% trong 1 phiên). Đã thêm `_looksLikeRepetitionLoop()` trong
   `LocalLlamaProvider.generateStream()` (Dart, `local_provider.dart`) —
   đặt Ở ĐÚNG 1 nơi (listener `EventChannel`) để bảo vệ MỌI nơi gọi
   (chat/viết chương/dịch thuật) cùng lúc, không cần sửa riêng từng nơi:
   kiểm tra cửa sổ 200 ký tự cuối mỗi khi có token mới (từ ký tự thứ 60 trở
   đi), phát hiện (a) 1 ký tự chiếm > 85% cửa sổ, hoặc (b) 1 cụm 2-6 ký tự
   lặp khít cả cửa sổ — khớp đúng 2 dạng lỗi đã gặp thật. Phát hiện được
   thì dừng ngay: đóng stream + gọi `cancelGenerate` native + thêm 1 dòng
   cảnh báo rõ ràng vào cuối văn bản đã sinh (không mất phần hợp lệ đã có
   trước khi lặp bắt đầu).
3. **`repetitionPenalty` mặc định 1.05 — đúng như nghi vấn đã nêu ở lượt
   làm việc trước nhưng CHƯA áp dụng**: nâng mặc định lên 1.15
   (`settings_service.dart` + `generation_settings_screen.dart`, đồng bộ 2
   nơi). Đây là biện pháp GIẢM THIỂU, không phải sửa nguyên nhân gốc (vẫn
   chưa xác nhận chắc chắn gốc rễ là do tham số này hay yếu tố khác như
   nhiệt độ máy) — lớp phòng vệ ở mục 2 mới là lưới an toàn chắc chắn.

**Trạng thái**: cân bằng ngoặc (đã kiểm tra bằng đếm `{`/`}` toàn bộ 6 file
đã sửa). **CHƯA build/test thật trên thiết bị** — cần xác nhận qua build
CI + cài lại: (a) bấm "X" giữa lúc chat local đang stream thật sự dừng
sinh chữ thêm, không chỉ đổi trạng thái task; (b) cố tình dùng model/cấu
hình dễ lặp (nếu còn) để xác nhận dòng cảnh báo "Đã tự dừng" xuất hiện
thay vì chạy tới hết `max_new_tokens`; (c) `repetitionPenalty` mặc định
mới 1.15 không làm văn bản "cứng"/lặp cấu trúc câu quá mức ở model bình
thường (đánh đổi hợp lý, người dùng vẫn chỉnh lại được).

**CHƯA làm trong phiên này (ngoài phạm vi, cần log thật mới để làm tiếp)**:
`build.yml` copy QNN .so — cấu trúc hiện tại (5 file, có kiểm tra đủ/thiếu,
in cảnh báo rõ) trông đã đúng theo tài liệu MNN Chat tham khảo ở mục 46,
nhưng log runtime gần nhất (2026-08-23) vẫn báo thiếu cả 5 file — nhiều khả
năng do APK người dùng đang chạy được build TRƯỚC bản vá mục 46, hoặc
đường dẫn thật trong QNN SDK zip lệch với giả định `aarch64-android`/
`hexagon-v68/unsigned` đang dùng. Không sửa mù thêm lần nữa — cần đúng đoạn
log bước "Đặt file .so vào đúng chỗ..." của lần build MỚI NHẤT (có in cây
thư mục QNN SDK thật) mới xác định được chính xác cần đổi gì. Không nghiêm
trọng cấp bách vì QNN giờ chỉ là thử nghiệm tùy chọn (mục 1) — đường mặc
định GPU/OpenCL đã chạy tốt (log xác nhận `backend: opencl` thành công).

---

**Cập nhật (2026-08-25, phiên 14 — theo phản hồi log/mô tả mới nhất):**

1. **`LocalLlamaProvider.name` trước đây CỐ ĐỊNH "AI local (MNN + QNN)"
   bất kể model nào thật sự đang nạp** — đúng như người dùng phản ánh:
   không có cách nào nhìn vào khung chat để biết đang là Qwen hay
   OccultAI-Morpheus đang trả lời (đặc biệt dễ nhầm ngay sau khi vừa đổi
   model). Đã sửa: lấy tên thư mục model (basename của `modelPath`) làm
   tên hiển thị — ghi vào `providerLabel` của từng tin nhắn ngay lúc gửi
   (`chat_screen.dart` dòng `providerLabel: provider.name` đã có sẵn, chỉ
   cần sửa đúng 1 chỗ là `name` getter).
2. **Làm rõ hiểu lầm về "force stop"**: người dùng đúng — force stop giết
   hẳn tiến trình, dọn sạch RAM, không có luồng "mồ côi" nào sống sót qua
   được. Nhưng force stop KHÔNG thay đổi APK đã cài trên máy — lần mở lại
   sau force stop vẫn nạp lại ĐÚNG BỘ CODE CŨ đã build sẵn trong file APK
   (giống mở lại y hệt 1 quyển sách đã in — đóng sách lại không tự sửa
   được lỗi in ấn bên trong). Bug nút "X" không dừng được chat, bug lặp vô
   tận không bị chặn... là bug NẰM TRONG CODE — chỉ hết khi build lại
   APK từ mã nguồn đã sửa (`.zip` mới) rồi cài đè/cài lại, không phải khởi
   động lại app suông. Log mới nhất (2026-08-25 08:36) mà người dùng gửi
   cho thấy `repetition_penalty` gửi xuống native vẫn là `1.05` — CHƯA
   phải `1.15` mới sửa — xác nhận đúng: bản đang chạy là bản build TRƯỚC
   phiên 13 (hoặc do `novel.genRepetitionPenalty` đã lưu sẵn `1.05` cụ thể
   trong DB cho truyện đó từ trước, nên giá trị mặc định mới không ghi đè
   được — người dùng cần vào "Tham số sinh văn bản" chỉnh tay lại nếu đã
   từng lưu giá trị cũ cho truyện đang dùng).
3. **OccultAI-Morpheus-8B ra rác + nóng máy nhiều hơn hẳn Qwen dù cùng
   thời gian chờ**: log gửi kèm lần này chỉ có phiên nạp Qwen (thành công,
   chưa thấy đoạn sinh rác của OccultAI-Morpheus) nên chưa có bằng chứng
   log trực tiếp để kết luận nguyên nhân. Ghi nhận khả năng: (a) đúng lớp
   phòng vệ lặp vô tận thêm ở phiên 13 sẽ tự cắt sớm trường hợp này MỘT
   KHI đã build+cài bản mới — không sửa được "vì sao model đó lặp" (có thể
   do đặc thù bản lượng tử hoá/convert MNN của riêng file này bị lỗi, nằm
   ngoài phạm vi sửa được ở tầng app) nhưng sẽ ngăn được hậu quả (máy nóng
   vô ích, chờ vô ích); (b) nếu nghi ngờ file model bị hỏng khi convert,
   nên thử tải lại/convert lại file OccultAI-Morpheus-8B từ nguồn gốc để
   loại trừ khả năng lỗi nằm ở chính file .mnn.

---

**Cập nhật (2026-08-25, phiên 15 — xác nhận model-name fix hoạt động
đúng qua ảnh chụp thật; thêm cảnh báo trước khi thoát app lỡ tay):**

- **Xác nhận**: ảnh chụp màn hình gửi kèm cho thấy nhãn model đã đúng
  ("AI local — OccultAI-Morpheus-8B-v2-MNN-q4-chinh", "AI local —
  Orion-zhen-Qwen2.5-7B-Instruct-Uncensored-MNN-q4-chinh") — bản build
  người dùng đang chạy đã có bản vá phiên 14.
- **Bug/tình huống mới xác nhận thật qua log + mô tả người dùng**: vuốt
  gesture quay lại (back gesture) LỠ TAY ở màn gốc (`RootScreen` — không
  còn route nào để pop bên dưới, nên back ở đây luôn nghĩa là thoát app)
  trong lúc 1 lệnh generate() local đang chạy dở → lệnh đó thành "mồ côi"
  giống hệt kiểu lỗi đã ghi nhận ở mục 5/phiên 12, nhưng KHÔNG PHẢI do
  crash hay reload màn hình — mà do CHÍNH NGƯỜI DÙNG vô tình thoát app.
  Log xác nhận: `TU CHOI NAP MODEL MOI — slot 0 dang co 1 lenh generate()
  TU PHIEN TRUOC van con chay do (mo coi)` — lặp lại ở CẢ 2 lần thử nạp
  model khác nhau sau đó (OccultAI lẫn Qwen) — slot 0 bị khoá cứng, không
  nạp được BẤT KỲ model nào (không riêng model cũ) tới khi lệnh mồ côi tự
  chạy xong.
- **Đã thêm (theo đúng yêu cầu người dùng)**: `RootScreen` (`main.dart`)
  bọc trong `PopScope` — CHỈ chặn khi thật sự có tác vụ đang `running`
  (không làm phiền khi không có gì chạy, hoặc chỉ có tác vụ mới `queued`
  chưa động tới native). Chặn thì hiện hộp thoại xác nhận rõ hậu quả
  ("model có thể bị khoá tới khi lệnh cũ tự xong"), có 2 lựa chọn "Ở lại"
  / "Thoát vẫn". Nếu người dùng vẫn chọn thoát: gọi `requestCancel()` cho
  mọi tác vụ đang chạy/xếp hàng trước (cố gắng tốt nhất — không đảm bảo
  native kịp nhận trước khi tiến trình đóng) rồi mới `SystemNavigator.pop()`.
- **Giới hạn còn lại, ghi rõ không giấu**: lớp phát hiện "lặp vô tận"
  thêm ở phiên 13 nằm ở TẦNG DART (`local_provider.dart`, lắng nghe
  EventChannel) — MỘT KHI app đã thật sự thoát (Dart isolate/Flutter
  engine bị Android dọn), lớp này KHÔNG còn chạy được nữa, chỉ còn code
  Kotlin/C++ (không tự phát hiện lặp) tiếp tục chạy tới hết
  `max_new_tokens` nếu lệnh generate() gốc đã kịp thoát ra ngoài phạm vi
  PopScope chặn được (vd: app bị hệ thống Android tự kill vì thiếu RAM,
  không phải do người dùng bấm back). Hộp thoại xác nhận ở trên giảm
  được phần lớn trường hợp (lỡ tay vuốt back) nhưng KHÔNG loại bỏ hoàn
  toàn rủi ro mồ côi — muốn triệt để cần thêm 1 lớp phát hiện lặp vô tận
  Ở TẦNG NATIVE (Kotlin/C++, độc lập với Dart) — chưa làm trong phiên
  này, để dành việc kế tiếp nếu người dùng còn gặp lại tình huống khoá
  slot dù đã có hộp thoại xác nhận.

---

**Cập nhật (2026-08-25, phiên 16 — làm tiếp phần chặn lặp ở tầng gốc
(native) + hiện đúng trạng thái "tác vụ mồ côi" ở màn "Tác vụ nền", theo
đúng 2 yêu cầu của người dùng):**

1. **Phát hiện gốc rễ thật của TOÀN BỘ chuỗi lỗi "generate() mồ côi" từ
   trước tới giờ**: `cancelGenerate` (Kotlin) trước đây CHỈ gọi
   `currentJob?.cancel()` — huỷ được Job coroutine BỌC NGOÀI, nhưng lời
   gọi JNI thật sự chạy lâu (`MnnNative.nativeGenerate` → `llm->response()`,
   đồng bộ/chặn) thì KHÔNG CÓ CÁCH NÀO được báo phải dừng — coroutine
   cancellation của Kotlin không tự "ngắt" được 1 lời gọi JNI đang chạy dở.
   Đây là lý do THẬT SỰ vì sao mọi lệnh generate() (dù bị huỷ chủ động hay
   app bị thoát) đều chạy tới hết `max_new_tokens`/EOS mới dừng — không
   phải lỗi thiếu sót ở từng chỗ gọi riêng lẻ như các phiên trước tưởng.
2. **Sửa tận gốc (mnn_bridge.cpp)**: thêm `g_cancelRequested[slot]`
   (atomic, song song `g_generatingInProgress` đã có) + hàm JNI
   `nativeRequestCancel(slot)`. `JniStreamingBuf::xsputn` — điểm DUY NHẤT
   mọi token sinh ra đều đi qua trước khi tới Java — kiểm tra cờ này ở
   MỖI lần ghi token; nếu bật thì ném `GenerationStoppedException` để
   unwind ra khỏi `llm->response()` ngay lập tức (dùng exception vì đây
   là cách DUY NHẤT "ngắt" 1 lời gọi thư viện đồng bộ không tự hỗ trợ API
   huỷ giữa chừng). `nativeGenerate()` đã có sẵn khối `catch` bao quanh —
   thêm 1 nhánh `catch (const GenerationStoppedException&)` riêng, log rõ
   ràng "dừng sớm chủ động" (không phải lỗi/crash).
3. **Thêm LUÔN lớp phát hiện lặp vô tận Ở TẦNG NÀY** (không chỉ dừng ở
   nhận cờ huỷ) — bản C++ của `_looksLikeRepetitionLoop()` (Dart, phiên
   13), CÙNG logic (1 ký tự >85% cửa sổ, hoặc cụm 2-6 ký tự lặp khít),
   chạy trong chính `JniStreamingBuf::xsputn`. Khác biệt quan trọng với
   bản Dart: bản NÀY tiếp tục hoạt động dù Flutter engine/Dart isolate đã
   bị đóng (app đã thoát) — vì nó chạy trong cùng tiến trình native với
   chính lệnh generate() đang chạy, không phụ thuộc Dart còn sống hay
   không. Đây chính là lỗ hổng người dùng phát hiện ra ở phiên 15 (thoát
   app giữa chừng → lớp Dart chết theo, model vẫn lặp mà không ai chặn).
4. **`cancelGenerate` (Kotlin) giờ gọi CẢ HAI**: `currentJob?.cancel()`
   (dọn coroutine bọc ngoài, giữ nguyên như cũ) + `MnnNative.nativeRequestCancel(slot)`
   (mới — có tác dụng thật với `llm->response()` đang chạy). Nút "X" ở
   "Tác vụ nền" giờ mới thật sự dừng được sinh chữ giữa chừng, kể cả khi
   không phải do lặp vô tận.
5. **Trả lời câu hỏi "sao tác vụ nền không báo có bất cứ cái gì hết"**:
   đúng như nghi ngờ — `BackgroundTaskManager` (Dart) chỉ là 1 `List`
   sống trong RAM của PHIÊN HIỆN TẠI; đóng app = mất hết, không có cách
   nào tự biết về 1 lệnh mồ côi còn sống sót từ phiên TRƯỚC dưới native.
   Thêm hàm JNI `nativeIsGenerating(slot)` (đọc `g_generatingInProgress`)
   + method channel `isSlotGenerating` (Kotlin) + `LocalLlamaProvider.isSlotGenerating()`
   (Dart) để tầng UI hỏi THẲNG native — nơi duy nhất còn giữ đúng sự thật.
   `background_tasks_screen.dart` giờ tự hỏi cả 2 slot lúc mở màn (+ nút
   làm mới thủ công), hiện `MaterialBanner` cảnh báo rõ ràng nếu native
   báo bận NHƯNG Dart-side không có tác vụ nào đang `running` (đúng dấu
   hiệu mồ côi) — kèm nút "Huỷ tác vụ mồ côi" gọi thẳng
   `LocalLlamaProvider.requestCancelSlot()` (không cần instance provider
   cũ, chỉ cần đúng số slot).
6. **Trạng thái**: cân bằng ngoặc `{`/`}` đã kiểm tra lại trên cả 5 file
   sửa (2 Dart, 2 Kotlin/1 đã sửa, 1 C++). **CHƯA build/test thật trên
   thiết bị** (không có Android NDK/Flutter SDK trong môi trường chuẩn bị
   bản vá này) — đặc biệt cần chú ý khi build lần đầu: `GenerationStoppedException`
   kế thừa `std::runtime_error`, dùng `throw`/`catch` bình thường của C++,
   không cần cấu hình NDK gì thêm, nhưng nên xác nhận `ANDROID_STL` trong
   `CMakeLists.txt`/`build.yml` đang dùng bản STL có hỗ trợ exception đầy
   đủ (thường là mặc định `c++_shared`, không cần đổi gì nếu build trước
   đó vẫn dùng exception ở chỗ khác trong cùng file, như try/catch quanh
   `llm->response()` đã có sẵn từ trước).

---

**Cập nhật (2026-08-25, phiên 17 — log gửi kèm XÁC NHẬN cơ chế huỷ native
phiên 16 hoạt động thật; sửa tiếp 3 vấn đề người dùng phát hiện qua trải
nghiệm thật: chữ "Thoát vẫn" khó hiểu, thoát xong vẫn khoá slot = vô
nghĩa, chữ đã sinh biến mất sau khi thoát+mở lại):**

- **Xác nhận bằng chính log người dùng gửi**: `nativeRequestCancel: da dat
  co huy cho slot 0` lúc 16:46:58, rồi `nativeGenerate: DA DUNG SOM CHU
  DONG — nguoi dung/he thong yeu cau huy (cancelGenerate) (da sinh duoc
  1071 ky tu truoc do)` chỉ 6 giây sau — cơ chế huỷ native thêm ở phiên 16
  **hoạt động đúng như thiết kế**, không phải lý thuyết suông.
- **Bug thật phát hiện ra (giải thích vì sao "thoát vẫn" bị người dùng
  đúng là thấy "vô nghĩa")**: `main.dart` (phiên 15) gọi `requestCancel()`
  (chỉ đặt 1 cờ, KHÔNG đợi) rồi `SystemNavigator.pop()` NGAY LẬP TỨC —
  trong khi việc huỷ THẬT (native nhận lệnh, `llm->response()` thoát ra,
  và QUAN TRỌNG NHẤT: khối `finally` trong `chat_screen.dart` — nơi có
  `await db.upsertChatMessage(reply)`, CHỈ được gọi ĐÚNG 1 LẦN duy nhất ở
  cuối `_send()`, không hề lưu tăng dần trong lúc đang stream — chạy
  xong) đều xảy ra BẤT ĐỒNG BỘ, mất vài giây. App bị đóng TRƯỚC khi các
  bước đó kịp hoàn tất → (a) slot vẫn bị khoá (lệnh cũ chưa kịp nhận tín
  hiệu huỷ), (b) phần chữ đã hiện trên màn hình lúc đang sinh **CHƯA BAO
  GIỜ được ghi xuống DB** nên mất sạch khi mở lại — đúng cả 2 hiện tượng
  người dùng mô tả, CÙNG 1 GỐC.
- **Đã sửa (`main.dart`)**: xác nhận "Vẫn thoát" xong (đổi tên nút cho tự
  nhiên hơn — trước là "Thoát vẫn", đọc ngược khó hiểu) → hiện 1 hộp
  thoại nhỏ không tắt được ("Đang dừng AI và lưu phần đã sinh...") → gọi
  huỷ TRỰC TIẾP xuống native cho CẢ 2 slot (`LocalLlamaProvider.requestCancelSlot()`,
  nhanh hơn đường cũ vì không cần đợi consumer Dart nhận được chunk tiếp
  theo mới kích hoạt) → **CHỜ THẬT** bằng cách poll `manager.runningCount`
  mỗi 300ms, tối đa 10 giây (chỉ về 0 sau khi khối `finally` có
  `upsertChatMessage` đã chạy xong) → mới đóng hộp thoại + thật sự thoát.
- **Giới hạn còn lại, không giấu**: cơ chế này chỉ hoạt động khi người
  dùng thoát qua ĐÚNG con đường có `PopScope` chặn (back-gesture ở màn
  gốc). Nếu người dùng force-stop app từ màn hình đa nhiệm/Cài đặt hệ
  thống Android (bỏ qua hoàn toàn Flutter, giết tiến trình ngay lập tức),
  không có cách nào chặn được từ phía app — phần chữ đang sinh dở VẪN sẽ
  mất, và slot vẫn có thể bị khoá tạm thời (dù giờ đã có phòng vệ ở
  Tác vụ nền — mục 5, phiên 16 — để tự huỷ tay được khi mở lại).
- **Trả lời câu hỏi "sinh chữ chậm hơn phiên bản trước"**: log cho thấy
  lệnh generate() ĐẦU TIÊN sau khi nạp model mất 232 giây chỉ để sinh 13
  token — bất thường, nhiều khả năng là do MNN OpenCL backend đang tự
  "tuning" kernel lần đầu (biên dịch/đo thời gian các kernel GPU, chỉ xảy
  ra 1 lần cho tới khi cache tuning — đã có thư mục riêng qua
  `nativeSetCacheDir` — ổn định lại), KHÔNG liên quan tới code mới thêm ở
  phiên 13/16 (các phép kiểm tra lặp vô tận chỉ là so sánh ký tự đơn giản
  trên cửa sổ 200 byte, tốn vài micro-giây mỗi token, không thể gây chậm
  tới mức giây/token). Để xác nhận chắc chắn, cần so sánh THỜI GIAN CHO
  TỪNG TOKEN ở lệnh generate() THỨ 2, THỨ 3 trở đi trong CÙNG 1 phiên
  (sau khi cache tuning đã "nóng") — nếu vẫn chậm bất thường ở đó thì mới
  đáng nghi code, còn chậm chỉ ở LẦN ĐẦU sau khi cài lại APK thì nhiều
  khả năng là chi phí tuning 1 lần, không phải bug.
- **Trả lời "nhắn alo mà không trả lời được"**: log cho thấy model
  (OccultAI-Morpheus-8B) đã trả lời THẬT (13 token, không lỗi, không
  crash) — chỉ là câu trả lời "Tôi không có câu trả lời cho câu hỏi của
  bạn." Đây nhiều khả năng là ĐẶC ĐIỂM của chính model này (fine-tune
  hướng tới nội dung/phong cách khác, không được huấn luyện để xử lý tốt
  lời chào xã giao ngắn không có ngữ cảnh Story Bible) — không phải lỗi
  app, app chỉ đang chuyển tiếp đúng nguyên văn model trả về.

---

**Cập nhật (2026-08-25, phiên 18 — hoàn tất 3 việc đã làm dở cuối phiên
17: lưu tăng dần khi đang stream (chat + viết chương), nút khôi phục ở
màn hình tổng, cỡ chữ toàn app):**

1. **"Phần chữ đang sinh dở vẫn mất" — sửa tận gốc bằng lưu tăng dần**:
   trước đây `reply`/chương CHỈ ghi xuống máy đúng 1 lần ở cuối `_send()`/
   sau khi sinh XONG HẲN — chưa từng chạm ổ đĩa trong lúc đang stream.
   Thêm checkpoint trong `onChunk` (cả `chat_screen.dart` lẫn
   `chapter_editor_screen.dart`, 2 chỗ gọi AI trong màn viết chương):
   lưu khi có ≥200 ký tự mới HOẶC ≥2 giây trôi qua kể từ lần lưu gần
   nhất — cân bằng "mất ít nhất có thể" và "không ghi SQLite liên tục".
   Fire-and-forget (không `await` trong callback đồng bộ của stream).
2. **Nút khôi phục ở màn hình tổng**: `BackupRestoreScreen.novelId` đổi
   từ bắt buộc sang nullable — mở được từ AppBar màn "Truyện của bạn"
   (`NovelListScreen`, `main.dart`) ngay cả khi 0 truyện nào tồn tại; ẩn
   mục "Sao lưu 1 truyện" khi không có `novelId`, giữ nguyên "Sao lưu
   toàn app" + "Khôi phục từ file" (2 việc này vốn không phụ thuộc 1
   truyện cụ thể).
3. **Cỡ chữ toàn app** (không phải pinch-zoom thật — xem lý do đầy đủ ở
   `text_scale_service.dart`: pinch-gesture trực tiếp trên các ô nhập
   liệu rủi ro xung đột với cử chỉ đã có sẵn ở đó, đặc biệt màn viết
   chương vốn đã phức tạp): `TextScaleService` (`ValueNotifier<double>`,
   lưu qua SharedPreferences) + áp dụng qua `MediaQuery.textScaler` ở
   `builder` của `MaterialApp` (nơi DUY NHẤT cần sửa để có tác dụng ở MỌI
   màn hình cùng lúc) + 1 thanh trượt trong hộp thoại mở từ icon mới ở
   AppBar màn "Truyện của bạn".

---

**Cập nhật (2026-08-25, phiên 19 — log mới phát hiện vấn đề THỨ 3, KHÁC
với lặp nội dung: model "trì trệ" (stall) — sinh cực chậm dù nội dung
CHƯA CHẮC đã lặp):**

- **Bằng chứng từ log**: lớp chặn lặp native (phiên 16) hoạt động ĐÚNG —
  bắt được và dừng sạch sẽ (`DA DUNG SOM CHU DONG — phat hien lap vo tan
  ... da sinh duoc 60 ky tu`), khoá được giải phóng bình thường (không
  còn "mồ côi" nữa). NHƯNG phải mất **482 giây** chỉ để tích luỹ đủ 60 ký
  tự đầu tiên rồi mới bắt được — so sánh: model khác (Huihui 1.8B) CÙNG
  máy, CÙNG phiên, sinh gần 200 token chỉ trong 66 giây. Đây là lỗi KHÁC
  hẳn "lặp nội dung" — bản thân tốc độ SINH RA từng ký tự đã trì trệ bất
  thường, không phải nội dung ra rồi mới lặp.
- **Đã thêm lớp phòng vệ THỨ 3** (song song 2 lớp: cờ huỷ chủ động + phát
  hiện lặp nội dung, cả 2 thêm ở phiên 16): kiểm tra THỜI GIAN THẬT trong
  `JniStreamingBuf::xsputn` — quá 90 giây kể từ lúc bắt đầu generate() mà
  CHƯA tích được 80 ký tự thì coi là "trì trệ" (stall), dừng sớm luôn,
  không đợi tới khi đủ dữ liệu để phát hiện lặp (60 ký tự, nhưng trường
  hợp này 60 ký tự cũng mất tới 482 giây mới tới) hay đủ `max_new_tokens`.
  Thông báo cho người dùng khác hẳn 2 trường hợp kia — gợi ý "thử model
  khác, hoặc để máy nguội bớt rồi thử lại" thay vì nói chung chung.
- **Chưa biết nguyên nhân gốc của bản thân sự trì trệ này** (không giấu):
  có thể do (a) máy đang nóng sau khi chạy liên tiếp 2 model trong cùng
  phiên (Huihui rồi ngay lập tức OccultAI-Morpheus, không nghỉ), (b) đặc
  thù riêng của file OccultAI-Morpheus-8B (bản convert/lượng tử hoá có
  vấn đề, hoặc kiến trúc model này chạm phải 1 nhánh tính toán chậm bất
  thường trên backend OpenCL của máy này) — nghi ngờ (b) nhiều hơn vì đây
  không phải lần đầu model NÀY cụ thể có biểu hiện bất thường (đã ghi
  nhận "ra rác + nóng máy hơn hẳn" ở phiên 14). Lớp phòng vệ mới chỉ giới
  hạn THIỆT HẠI (không phải để hết 8+ phút chờ vô ích), không sửa được
  nguyên nhân gốc.

---

**Cập nhật (2026-08-25, phiên 20 — SỬA LẠI giả thuyết sai ở phiên 19,
theo đầu mối chính xác hơn từ người dùng):**

- **Rút lại giả thuyết "máy nóng"**: không đủ căn cứ, và đóng khung sai
  vấn đề (ngụ ý model "cảm nhận" được nhiệt độ). Người dùng chỉ ra đầu
  mối chính xác hơn nhiều: **chạy MỘT MÌNH thì bình thường, nhưng chạy
  NGAY SAU 1 model KHÁC (trong cùng phiên app) thì sinh rác — xảy ra với
  CẢ OccultAI-Morpheus LẪN Qwen 7B** (không phải đặc thù riêng 1 file
  model như nghi ngờ trước đó ở phiên 14/19). Đây là dấu hiệu kinh điển
  của trạng thái GPU/OpenCL sót lại giữa 2 lần nạp model trong CÙNG 1
  tiến trình — không phải máy nóng, không phải model cụ thể nào hỏng.
- **Tìm ra đúng chỗ nghi vấn (`mnn_bridge.cpp`, `nativeLoadModel`)**: dòng
  cũ `llmSlot.reset(Llm::createLLM(path));` có vấn đề THỨ TỰ tinh vi —
  C++ đánh giá `Llm::createLLM(path)` (khởi tạo model MỚI, cấp phát tài
  nguyên GPU/OpenCL) **TRƯỚC KHI** `reset()` huỷ model CŨ — nghĩa là
  trong lúc model mới khởi tạo, model cũ (nếu có) vẫn còn sống, tài
  nguyên GPU của nó chưa được giải phóng. Nếu backend OpenCL của MNN có
  bất kỳ trạng thái dùng chung (global/static, không tách riêng theo
  từng object `Llm` — rất phổ biến ở engine GPU vì lý do hiệu năng), model
  mới có thể vô tình "thừa hưởng" trạng thái/tài nguyên dở dang của model
  cũ — khớp đúng triệu chứng "tốt khi chạy 1 mình, hỏng khi chạy sau model
  khác".
- **Đã sửa**: tách thành 2 bước rõ ràng — huỷ HẲN model cũ trước
  (`llmSlot.reset();`, giải phóng sạch tài nguyên GPU), RỒI MỚI gọi
  `Llm::createLLM(path)` cho model mới. Đảm bảo không có 2 model cùng
  "sống" trên GPU cùng lúc dù chỉ trong khoảnh khắc ngắn.
- **Mức độ tin cậy, nói rõ không giấu**: đây là giả thuyết HỢP LÝ NHẤT
  dựa trên bằng chứng hiện có (khớp đúng mọi triệu chứng đã quan sát: tốt
  đơn lẻ / hỏng khi nối tiếp, xảy ra ở NHIỀU model khác nhau chứ không
  riêng 1 file) và là 1 thay đổi AN TOÀN, ĐÚNG THỰC HÀNH CHUẨN (dọn sạch
  tài nguyên GPU trước khi cấp phát tài nguyên GPU mới) dù có giải quyết
  triệt để hay không. KHÔNG có quyền truy cập vào mã nguồn nội bộ của
  MNN's OpenCL backend để xác nhận 100% đây chính xác là cơ chế rò rỉ
  trạng thái — nếu build mới vẫn còn hiện tượng này, bằng chứng đó sẽ thu
  hẹp lại: không phải do thứ tự huỷ/tạo object ở tầng app, mà có thể là
  vấn đề sâu hơn bên trong chính thư viện MNN (ngoài khả năng sửa được ở
  tầng code ứng dụng này).

---

**Cập nhật (2026-08-25, phiên 21 — thêm log chẩn đoán THẬT ở đúng tầng
nghi vấn, theo yêu cầu người dùng "sao không làm log bắt bug ở tầng
này" — trước đây phiên 20 chỉ SỬA theo giả thuyết, chưa có gì XÁC NHẬN
giả thuyết đó đúng/sai bằng số liệu thật):**

1. **`readVmRssKb()`** (mới, đọc `/proc/self/status` → `VmRSS`): bộ nhớ
   RAM thật tiến trình đang chiếm dụng. Trên hầu hết thiết bị Android,
   phần lớn buffer OpenCL/GPU cũng tính vào không gian địa chỉ chung của
   tiến trình, nên VmRSS tụt/tăng phản ánh khá tốt việc tài nguyên model
   có thật sự được giải phóng/cấp phát hay không (dù không hoàn hảo
   100% cho VRAM chuyên dụng riêng — nói rõ giới hạn của phép đo).
2. **`g_loadCountInProcess[slot]`** (mới, atomic int, KHÔNG reset khi đổi
   model, CHỈ reset khi tiến trình app bị kill/mở lại thật): đếm số lần
   đã nạp THÀNH CÔNG vào từng slot. Trả lời trực tiếp câu hỏi "lỗi có
   LUÔN xảy ra từ lần nạp thứ 2 trở đi trong slot đó không" bằng số liệu
   log thật, thay vì suy đoán từ trí nhớ.
3. **3 điểm log mới ở `nativeLoadModel`** (gắn nhãn `[CHAN DOAN DOI
   MODEL]` để dễ lọc): VmRSS TRƯỚC khi huỷ model cũ → VmRSS SAU khi huỷ
   (kèm số kB đã giảm — nếu số này gần 0/âm dù model cũ rõ ràng có dữ
   liệu, đó là bằng chứng cụ thể tài nguyên CHƯA được giải phóng thật) →
   VmRSS SAU khi tạo model mới (kèm số kB đã tăng).
4. **2 điểm log mới ở `JniStreamingBuf::xsputn`** (gắn nhãn `[CHAN DOAN
   TRI TRE]` / `[CHAN DOAN LAP VO TAN]`), ngay tại chỗ ném exception dừng
   sớm: ghi lại ĐÚNG lần nạp thứ mấy (từ `g_loadCountInProcess`) đã gây
   ra hiện tượng — nếu qua nhiều lần lỗi lặp lại, con số này LUÔN ≥ 2
   (không bao giờ là lần nạp ĐẦU TIÊN sau khi mở app), đó là bằng chứng
   củng cố mạnh cho giả thuyết "trạng thái sót lại giữa các lần nạp"
   (phiên 20) thay vì đặc thù riêng 1 file model hay máy nóng.
5. **Mục tiêu của phiên này KHÔNG PHẢI sửa thêm gì** — chỉ THU THẬP BẰNG
   CHỨNG. Lần tới nếu hiện tượng còn xảy ra, gửi kèm đúng đoạn log có 5
   nhãn `[CHAN DOAN ...]` ở trên sẽ cho biết chính xác: (a) fix thứ tự
   huỷ/tạo ở phiên 20 có thật sự giải phóng được bộ nhớ hay không (nhìn
   vào số kB giảm ở bước huỷ), và (b) lỗi có tương quan chặt với "không
   phải lần nạp đầu tiên" hay không — từ đó mới biết nên đào sâu tiếp
   theo hướng nào (vd: nếu VmRSS giảm bình thường mà vẫn lỗi → không phải
   RAM/GPU chưa giải phóng, mà có thể là trạng thái nội bộ khác của MNN
   như cache tuning OpenCL dùng chung file/thư mục giữa các model).

---

**Cập nhật (2026-08-25/26, phiên 22 — SỬA LỖI BUILD THẬT, xác nhận qua
log CI GitHub Actions người dùng gửi — Build APK #101 THẤT BẠI):**

- **Lỗi**: `lib/main.dart:267: Error: The method '_showTextScaleDialog'
  isn't defined for the type '_NovelListScreenState'`. Nguyên nhân: ở
  phiên 18, khi thêm hàm `_showTextScaleDialog()`, câu lệnh tìm-thay-thế
  đã khớp NHẦM vào đoạn `@override\n  Widget build(BuildContext context) {\n
  if (loading) {` — đoạn code này tồn tại Y HỆT ở CẢ 2 class
  (`_NovelGateScreenState` VÀ `_NovelListScreenState`, cả 2 đều có biến
  `loading` + kiểm tra tương tự) — công cụ sửa file chọn nhầm lần khớp
  ĐẦU TIÊN (`_NovelGateScreenState`), trong khi nút bấm gọi hàm này lại
  nằm ở `_NovelListScreenState` — 2 class hoàn toàn khác nhau nên biên
  dịch báo "method không tồn tại". Đây là lỗi tôi gây ra do không xác
  minh kỹ đích đến của thay-thế khi có nhiều đoạn code trùng cấu trúc
  trong cùng 1 file — bài học: khi 1 file có nhiều class với cấu trúc
  tương tự nhau (ở đây là nhiều màn hình `Stateful` đều có pattern
  `loading`/`build()`), luôn kiểm tra lại SỐ DÒNG THẬT SỰ của đoạn vừa
  sửa nằm trong class nào, không chỉ tin vào việc thay-thế "chạy thành
  công không báo lỗi".
- **Đã sửa**: cắt `_showTextScaleDialog()` khỏi `_NovelGateScreenState`
  (dòng ~72-165), chuyển đúng xuống `_NovelListScreenState` (dòng ~127+,
  ngay trước `build()` của chính nó, đúng nơi nút bấm ở AppBar gọi tới).
  Đã xác minh lại bằng `grep` số dòng: hàm định nghĩa và nơi gọi giờ cùng
  nằm giữa 2 mốc `class _NovelListScreenState` và `class RootScreen`.
- **Bài học quy trình (ghi để tránh lặp lại)**: từ phiên này trở đi, sau
  MỌI lần thêm method mới vào 1 file có nhiều class, chạy thêm bước xác
  minh: `grep -n "^class \|tên_method_mới"` rồi tự kiểm tra bằng mắt số
  dòng của method nằm giữa đúng cặp `class X {` / `class Y {` (class kế
  tiếp) mong muốn — không chỉ dựa vào việc lệnh sửa file không báo lỗi
  (một cú str_replace "thành công" không đồng nghĩa nó sửa ĐÚNG VỊ TRÍ
  nếu chuỗi khớp không đủ duy nhất trong ngữ cảnh nhiều class giống nhau).

---

**Cập nhật (2026-08-26, phiên 23 — BẰNG CHỨNG SỐ LIỆU THẬT đầu tiên từ
log VmRSS (phiên 21) — phát hiện quan trọng: fix thứ tự huỷ/tạo (phiên
20) KHÔNG giải quyết được rò rỉ bộ nhớ; + gỡ 2 hardcode bị người dùng
phát hiện đúng):**

## A. Phân tích log VmRSS — rò rỉ bộ nhớ THẬT SỰ tồn tại

- **Lần nạp thứ 1** (OccultAI-Morpheus-8B, slot trống hoàn toàn — tiến
  trình vừa mở): VmRSS trước huỷ = 221.100 kB, sau huỷ = 221.100 kB
  (giảm 0 — ĐÚNG, vì chưa có gì để huỷ). Nhưng generate() bị **TRÌ TRỆ**
  — chỉ 2 ký tự sau 90+ giây — **ngay ở lần nạp ĐẦU TIÊN**, phủ định 1
  phần giả thuyết "chỉ hỏng từ lần nạp thứ 2" (phiên 20/21): bản thân
  model này có vẻ có vấn đề NỘI TẠI (khớp lại với nghi ngờ ban đầu ở
  phiên 14), không chỉ do trạng thái sót lại.
- **Lần nạp thứ 2** (Qwen 2.5 1.5B, slot đã có OccultAI-Morpheus trước
  đó): VmRSS trước huỷ = **4.422.776 kB** (~4.4GB, khớp kích thước thật
  của OccultAI-Morpheus-8B q4 + embeddings). Sau khi gọi `llmSlot.reset()`
  (huỷ tường minh, fix phiên 20) → VmRSS = **2.799.740 kB** (~2.8GB) —
  **CHỈ giảm 1.623.036 kB (~1.6GB)**, còn kẹt lại **~2.58GB** so với mức
  nền lúc chưa nạp gì (221MB ở lần 1). Model Qwen 1.5B mới chỉ nặng
  ~800MB trên đĩa — không thể giải thích 2.58GB còn sót lại là "bình
  thường". → **BẰNG CHỨNG CỤ THỂ, ĐO ĐƯỢC: fix thứ tự huỷ-trước-tạo-sau ở
  phiên 20 KHÔNG giải quyết được rò rỉ bộ nhớ.** `llmSlot.reset()`
  (destructor của `Llm`) không giải phóng hết tài nguyên GPU/OpenCL đã
  cấp cho model cũ — đây gần như chắc chắn là hành vi BÊN TRONG thư viện
  MNN (hoặc chính GPU driver OpenCL của thiết bị giữ lại cache/pool), nằm
  ngoài khả năng sửa bằng cách sắp xếp lại lệnh C++ ở tầng wrapper này.
  Ngay sau đó, Qwen 1.5B (load thứ 2) → **LẶP VÔ TẬN** ("((((((") — khớp
  đúng giả thuyết "model B thừa hưởng trạng thái dở dang của model A".
- **Kết luận cập nhật (thay thế hoàn toàn phiên 19/20)**: có khả năng
  ĐANG TỒN TẠI CẢ 2 vấn đề riêng biệt, không loại trừ nhau: (1)
  OccultAI-Morpheus-8B tự nó có vấn đề nội tại (trì trệ ngay cả khi nạp
  đầu tiên, sạch sẽ), VÀ (2) rò rỉ tài nguyên GPU thật sự giữa các lần
  nạp trong cùng tiến trình (đo được bằng VmRSS, ~2.58GB kẹt lại) khiến
  model NẠP SAU (bất kể model gì) dễ bị hỏng theo. Đây là giới hạn THẬT
  của tầng code ứng dụng — sửa triệt để cần sửa/thay thế cách MNN quản lý
  bộ nhớ OpenCL nội bộ, ngoài phạm vi file wrapper `mnn_bridge.cpp` này.
- **Khuyến nghị thực tế cho người dùng** (trong lúc chưa có fix triệt
  để): nếu cần đổi model để dùng nghiêm túc (không chỉ thử nhanh), tốt
  nhất **thoát hẳn app (không chỉ chuyển màn hình) rồi mở lại** trước khi
  nạp model mới — đảm bảo tiến trình mới tinh, VmRSS về đúng mức nền,
  không kế thừa rò rỉ từ model trước.

## B. Gỡ 2 hardcode bị người dùng phát hiện đúng

1. **Prompt "biên tập viên viết truyện" ép cứng vào MỌI tin nhắn chat**
   (`chat_screen.dart` gọi `rag.buildSystemPrompt()` với `userInstruction`
   cố định) — đúng như người dùng nhận ra, kể cả gõ "alo" cũng bị ép
   khung "Bạn là trợ lý viết tiểu thuyết dài kỳ... Trả lời như một biên
   tập viên...". Đã thêm cờ `useNovelPersona` (lưu riêng theo từng
   truyện qua SharedPreferences), icon bật/tắt ngay trên AppBar màn chat
   — TẮT thì bỏ hẳn khung persona, chat tự do như trợ lý AI thường.
2. **Nút chỉnh cỡ chữ "biến mất" khi đã vào trong 1 truyện** — do trước
   đây gắn CỨNG vào 1 mình `NovelListScreen` (màn trước khi vào truyện),
   không có đường quay lại từ trong chat/chương. Tách hộp thoại ra hàm
   dùng chung `showTextScaleDialog()` (`text_scale_service.dart`), gọi
   được từ bất kỳ đâu — đã gắn thêm vào `chat_screen.dart`; các màn khác
   (chương, Bách khoa...) gắn thêm tương tự khi cần, không phải chép lại
   code.

---

**Cập nhật (2026-08-26, phiên 24 — TRA CỨU THẬT theo yêu cầu người dùng
"sao không tra cứu cách MNN/cộng đồng giải quyết vấn đề" — tìm được đầu
mối chính thức từ chính MNN, không còn đoán mù:**

## Kết quả tra cứu

Tìm kiếm changelog chính thức của thư viện MNN (alibaba/MNN, GitHub
Releases) cho thấy **bản 3.4.1** có đúng 1 mục thay đổi khớp gần như
nguyên văn với triệu chứng đã đo được ở phiên 23:

> **"LLM 资源管理优化: LLM 实例内置独立 Executor 并在所有公开方法中使用
> ExecutorScope，确保正确的资源作用域和及时释放，尤其是在 Python 绑定场
> 景中"**
> (dịch: "Tối ưu quản lý tài nguyên LLM: mỗi instance `Llm` giờ tự tạo
> `Executor` RIÊNG và dùng `ExecutorScope` ở MỌI public method, đảm bảo
> phạm vi tài nguyên đúng và giải phóng KỊP THỜI, đặc biệt trong các kịch
> bản dùng qua Python binding.")

Đây gần như chắc chắn xác nhận: `Llm` (lớp C++ app này đang bọc qua
`llm.hpp`) từng có (và theo release note, ĐÃ ĐƯỢC SỬA ở bản 3.4.1) đúng
kiểu lỗi "Executor dùng chung giữa các instance, không giải phóng đúng
lúc" — khớp triệu chứng đo được: model B thừa hưởng trạng thái/tài
nguyên còn sót của model A.

Cũng tìm thấy 1 dòng khác trong nhật ký phát hành app MNN Chat chính
thức, càng củng cố đây LÀ vấn đề CÓ THẬT mà chính đội MNN cũng từng vá:
**"Reuse the loaded runtime session when starting API service for the
same model to avoid extra reloads that could freeze or crash API
startup."** và **"Avoid deadlocks caused by partially initialized mmap
weights during model loading."** — cho thấy việc tái sử dụng
runtime/session giữa các lần nạp model là 1 mảng đã biết có nhiều vấn đề
tinh vi trong chính dự án gốc, không phải điều gì "lạ" hay đặc thù riêng
của app này.

## Vấn đề khi áp dụng vào project này

`build.yml` clone MNN bằng `git clone --depth 1` từ nhánh `master` —
LUÔN lấy đúng commit MỚI NHẤT tại THỜI ĐIỂM CHẠY BUILD, nhiều khả năng
đã SAU bản 3.4.1 (tức đã có fix). Nhưng vì `--depth 1` không giữ lại
tag/version rõ ràng trong log, KHÔNG CÓ CÁCH NÀO xác nhận trước đây build
nào đã dùng đúng commit gì — không thể kết luận "đã có fix mà vẫn còn
lỗi" hay "chưa từng có fix" chỉ từ log ứng dụng.

**Đã thêm bước CI mới** (`build.yml`, ngay sau bước clone MNN): in ra
`git rev-parse HEAD` + ngày commit + thử tìm `MNN_VERSION` trong
`include/MNN/MNNDefine.h` — để MỌI LẦN BUILD SAU đều có bằng chứng rõ
ràng đang dùng đúng commit MNN nào, đối chiếu được với ngày phát hành
3.4.1 khi cần điều tra tiếp (nếu vẫn còn rò rỉ dù build SAU ngày 3.4.1
phát hành, nghĩa là fix đó KHÔNG bao trùm hết trường hợp của app này —
rất có thể do buffer pool riêng của backend OpenCL, khác với `Executor`
chung được nhắc trong changelog).

## Giới hạn tra cứu, nói rõ không giấu

- Không truy cập được trực tiếp nội dung file mã nguồn `llm.hpp`/`llm.cpp`
  thật của MNN qua công cụ tìm kiếm hiện có (kết quả tìm kiếm chỉ trả về
  tóm tắt README/DeepWiki, không phải nội dung file thật) — nên KHÔNG thể
  khẳng định chắc chắn 100% class `Llm` có method public nào để chủ động
  gọi giải phóng/GC bộ nhớ giữa các lần nạp (nếu có, sẽ là cách sửa sạch
  hơn nhiều so với chỉ trông chờ destructor). Không đoán mù tên hàm/API
  cụ thể để tránh viết code gọi nhầm hàm không tồn tại, gây lỗi build.
- Không loại trừ khả năng phần rò rỉ còn lại (nếu build MỚI vẫn còn) nằm
  ở tầng THẤP HƠN `Executor` — cụ thể là bộ nhớ GPU do chính driver OpenCL
  của thiết bị (Adreno/Mali) tự giữ lại làm cache nội bộ, không phải do
  MNN — đây là hành vi driver thường thấy (giữ lại vùng nhớ đã cấp phát
  để tái sử dụng nhanh hơn ở lần sau), nằm hoàn toàn ngoài khả năng kiểm
  soát của cả MNN lẫn app này.

## Việc tiếp theo cần làm (khi có log build mới kèm commit hash)

1. Đối chiếu ngày commit MNN đã build với ngày phát hành 3.4.1 (khoảng
   tháng 3/2026 theo changelog) — nếu build SAU mốc đó mà vẫn rò rỉ, tức
   fix 3.4.1 không đủ, cần tìm hướng khác (nghi ngờ buffer pool OpenCL
   backend, không phải Executor chung).
2. Nếu build TRƯỚC mốc đó (không nên xảy ra với `--depth 1` từ `master`,
   nhưng vẫn nên xác nhận) — thử ép CMake pin về 1 tag cụ thể ≥ 3.4.1
   thay vì luôn lấy `master` mới nhất (đánh đổi: mất đi các fix MỚI HƠN
   nhưng đổi lại có 1 baseline ổn định, dễ so sánh/tái lập lỗi hơn).

## C. Cache autotuning OpenCL dùng chung giữa các model (2026-08-26)

Người dùng chỉ ra mâu thuẫn: ảnh chụp 23/8 cho thấy model 8B (OccultAI-
Morpheus) từng sinh văn bản đầy đủ, bình thường (chỉ "chậm hơn 7B"),
trong khi log đo được ngày 25-26/8 (mục A ở trên, và phiên 19/23) cho
thấy CHÍNH model đó đứng hình gần hoàn toàn (2-21 ký tự / 90-97 giây)
ngay ở LẦN NẠP ĐẦU TIÊN — tức không thể giải thích bằng giả thuyết "trạng
thái sót lại giữa 2 lần nạp" (mục A/B), vì lần nạp đầu tiên không có gì
để sót lại.

Kiểm tra code phát hiện: `MnnBridge.kt` gọi `nativeSetCacheDir(appContext
.cacheDir.absolutePath)` ĐÚNG 1 LẦN DUY NHẤT cho toàn bộ vòng đời app
(cờ `logDirSent`), và giá trị này được dùng thẳng làm `tmp_path` cho
MỌI model — tức cache autotuning kernel OpenCL của MNN (dò workgroup
size tối ưu, vốn có thể mất khá lâu ở lần dò đầu) bị DÙNG CHUNG giữa
tất cả model đã từng test, tích luỹ qua nhiều ngày. Nếu cache key nội
bộ của MNN không phân biệt đủ rõ giữa các kiến trúc khác nhau (8B vs
1.5B vs 7B — vocab/hidden-dim khác hẳn nhau), 1 lần load có thể vô tình
tái sử dụng entry autotuning của model khác, khiến MNN âm thầm chạy
sai/chậm workgroup config mà không crash — khớp với mọi log quan sát
được (luôn "khong crash", chỉ chậm bất thường). Timeline cũng khớp:
23/8 (cache còn sạch, ít model từng test) → 8B chạy ổn; 25-26/8 (sau
nhiều phiên test nhiều model) → 8B đứng hình.

**CHƯA CÓ BẰNG CHỨNG CHẮC CHẮN 100%** đây là nguyên nhân duy nhất — có
thể cộng hưởng với rò rỉ VmRSS thật ở mục A. Nhưng đây là thay đổi rẻ,
an toàn, tách bạch được nguyên nhân bằng log khách quan (không dựa cảm
quan người dùng) — đã sửa `mnn_bridge.cpp`:
- Thêm `sanitizeModelFolderName()` — lấy tên thư mục model, làm sạch
  ký tự không hợp lệ cho tên thư mục.
- Thêm `ensureDirExists()` — tạo thư mục kiểu "mkdir -p", log rõ nếu
  thất bại thay vì âm thầm rơi về cache dùng chung.
- `buildOptimizedOpenCLConfig()` giờ nhận thêm `rawModelPath`, dùng
  `tmp_path = "<cacheDir>/opencl_tuning/<tên_model_đã_làm_sạch>/"` thay
  vì `<cacheDir>` dùng chung cho mọi model như trước.
- Có log `buildOptimizedOpenCLConfig: tmp_path RIENG cho model nay = ...`
  ở mỗi lần load, để lần sau đối chiếu trực tiếp trong `native_debug.txt`
  xem đúng thư mục riêng có được dùng hay không — không cần đoán.

**Việc cần làm tiếp theo (khi có log build mới)**: so log elapsed/ký tự
của model 8B khi nạp đầu tiên (tiến trình sạch, cache thư mục riêng vừa
tạo lần đầu nên vẫn "lạnh") với con số cũ (~21 ký tự/97s). Nếu vẫn y hệt
mức cũ → loại trừ giả thuyết cache chéo, quay lại tập trung vào mục A/B
(rò rỉ VmRSS) hoặc bản thân model/GPU driver. Nếu cải thiện rõ rệt (đo
bằng số, không phải cảm quan) → xác nhận đúng nguyên nhân, giữ nguyên
fix này lâu dài.

## D. Kết quả đo thật của mục C, và 1 lỗi MỚI nghiêm trọng hơn phát hiện ra (2026-08-27)

Log build có fix mục C xác nhận: `buildOptimizedOpenCLConfig: tmp_path
RIENG cho model nay = ".../opencl_tuning/OccultAI-Morpheus-8B-v2-MNN-q4-chinh"
(tao thu muc THANH CONG)` — fix chạy đúng thiết kế. Nhưng kết quả đo:

- Lần nạp thứ 1 trong phiên: prompt dài (Story Bible + persona, 718 ký
  tự) — không tách được prefill/decode từ log, không dùng để so sánh.
- Lần nạp thứ 3 (cùng máy, cache autotuning đã "ấm" từ các lần trước —
  bằng chứng: `load()` chỉ mất **0,176 giây**, quá nhanh so với lần nạp
  đầu tiên từng thấy ~12 giây): prompt ngắn `"alo"` (5 ký tự) — vẫn đứng
  hình y hệt, chỉ sinh **7 ký tự trong 212 giây**.

→ **KẾT LUẬN CHÍNH THỨC: giả thuyết mục C (cache autotuning OpenCL dùng
chung/nhiễu) BỊ LOẠI HẲN.** Cache ấm, load nhanh, nhưng decode vẫn thảm
hại như cũ — bottleneck nằm ở chính bước sinh token, không phải ở bước
dò/nạp kernel. Giữ nguyên code mục C (không hại gì, và tách cache theo
model vẫn là vệ sinh tốt), nhưng KHÔNG coi đây là nguyên nhân của vụ
đứng hình nữa. Giả thuyết còn sống, mạnh nhất hiện tại: bảng embedding/
lm_head chưa lượng tử hoá (`embeddings_bf16.bin`, 1,05GB bf16, model
Qwen không có file này) — cần đọc/tính lại toàn bộ ~1GB đó ở MỖI token
sinh ra trên GPU di động, đúng kiểu nghẽn băng thông bộ nhớ. Hướng sửa
thật (nếu đúng): export lại model với `--embed_bit 4`, không phải sửa
code app.

### Lỗi MỚI, nghiêm trọng hơn: lệnh generate() thứ 2 treo VÔ THỜI HẠN, không hề được watchdog bắt

Ngay sau khi lệnh generate() thứ 1 (prompt "alo") bị watchdog 90s cắt
**sạch sẽ** (exception ném ra, bắt được, log đầy đủ, hàm trả về bình
thường — "khong crash"), người dùng gửi tin thứ 2 ngay lập tức (cùng
model, không đổi). Log cho thấy lệnh generate() thứ 2 này BẮT ĐẦU đầy đủ
(qua hết các bước init, set_config thành công) rồi gọi `llm->response()`
— và **KHÔNG BAO GIỜ QUAY LẠI**: không có dòng log nào tiếp theo (không
`[CHAN DOAN TRI TRE]`, không `onToken`, không gì cả) trong hơn **12
PHÚT**, cho tới khi người dùng thử nạp model khác và bị native từ chối
đúng như thiết kế mục 5.67 (tránh use-after-free) — đây là cách DUY NHẤT
lỗi này bị phát hiện, hoàn toàn gián tiếp.

**Nguyên nhân gốc (giả thuyết mạnh, chưa xác minh 100% vì không có mã
nguồn nội bộ MNN)**: cơ chế huỷ hiện tại của app là ném C++ exception
(`GenerationStoppedException`) từ TRONG `xsputn` — callback được MNN gọi
giữa chừng lúc `llm->response()` đang chạy. Đây KHÔNG phải cách huỷ
"sạch" đối với nội bộ MNN: exception này unwind ra khỏi `response()`
giữa chừng, rất có thể để lại KV-cache hoặc hàng đợi lệnh OpenCL dở
dang, không nhất quán. Lệnh generate() SAU trên CHÍNH object `Llm*` đó
(chưa được nạp lại) kế thừa đúng trạng thái hỏng này → treo vô thời hạn
khi cố dùng lại.

**Lỗ hổng thiết kế bị lộ ra thêm**: toàn bộ 3 lớp phòng vệ (watchdog trì
trệ, huỷ chủ động, phát hiện lặp) đều nằm BÊN TRONG `xsputn` — tức chỉ
được kiểm tra mỗi khi model THỰC SỰ ghi ra ít nhất 1 ký tự. Nếu
`llm->response()` treo hoàn toàn ngay từ đầu (0 ký tự, như log này), 3
lớp phòng vệ đó KHÔNG BAO GIỜ được gọi tới — không có bất kỳ bảo vệ nào
theo đúng nghĩa "thời gian thật, độc lập với việc đã sinh được chữ hay
chưa".

**Đã sửa** (`mnn_bridge.cpp`, an toàn/phòng thủ, KHÔNG cần biết chính
xác cơ chế MNN bên trong để vẫn có tác dụng):
- Cờ `g_slotNeedsFullReload[slot]` — set `true` ngay trong CẢ 2 nhánh
  catch bao quanh `llm->response()` (GenerationStoppedException lẫn
  exception khác) — vì bất kỳ lần nào bị ngắt giữa chừng đều đáng ngờ
  với nội bộ MNN, không chỉ riêng trường hợp trì trệ.
- `nativeGenerate()` kiểm tra cờ này NGAY ĐẦU HÀM (trước khi chạm tới
  `llm->response()`) — nếu slot đang bị đánh dấu, TỪ CHỐI NGAY LẬP TỨC
  với thông báo rõ ràng cho người dùng ("cần nạp lại model"), thay vì
  để lệnh đó tự treo rồi 12 phút sau mới phát hiện gián tiếp qua đường
  nạp model khác.
- `nativeLoadModel()` xoá cờ này sau khi tạo + nạp xong 1 object `Llm`
  hoàn toàn mới (không còn lý do nghi ngờ trạng thái cũ).
- Thông báo từ chối nạp model (khi slot còn lệnh generate mồ côi) giờ
  tính và in kèm **đã treo bao nhiêu giây** (dựa `g_generateStartTime`),
  thay vì chỉ nói chung chung — để lần sau không cần tự trừ 2 mốc log.

**Giới hạn thật của fix này, nói rõ không giấu**: đây CHỈ chặn được kịch
bản "lệnh thứ 2 sau lệnh thứ 1 vừa bị dừng-sạch" — vì lúc đó cờ
`g_generatingInProgress` đã kịp reset về false, lệnh thứ 2 mới có cơ hội
chạy tới và bị chặn bởi cờ MỚI này. Fix KHÔNG (và không thể, ở tầng app)
giải quyết trường hợp `llm->response()` tự nó treo vô thời hạn ngay từ
lệnh ĐẦU TIÊN (không có lệnh nào trước đó để đánh dấu) — trường hợp đó
vẫn phải đợi người dùng tự phát hiện qua việc thử nạp model khác, vẫn
không có watchdog thời gian thật độc lập với `xsputn`. Muốn giải quyết
triệt để cần 1 cơ chế giám sát ở luồng RIÊNG (không phụ thuộc callback
của MNN) có khả năng buộc kết thúc lệnh treo — rủi ro cao hơn nhiều
(huỷ cứng 1 luồng đang kẹt trong driver GPU có thể crash cả tiến trình),
CHƯA làm, cần bàn kỹ trước khi động vào.

## E. Nghi vấn máy ngủ sâu giữa chừng lúc "trì trệ" — CHƯA XÁC NHẬN, đã thêm log để xác nhận (2026-08-27)

Người dùng test lại nhiều lần liên tiếp cùng máy, phát hiện: **model
8B không hề nóng/giật lag khi bị watchdog CẮT SỚM (2-7 ký tự) — chỉ
nóng/giật lag khi sinh THÀNH CÔNG hoặc sinh RÁC (nhiều ký tự, chạy lâu)**.
Đây là bằng chứng vật lý quan trọng: nếu GPU thực sự phải tính toán liên
tục suốt cả quá trình "trì trệ" (như giả thuyết `embeddings_bf16.bin`
ngụ ý), máy phải nóng lên tương ứng — không nóng nghĩa là GPU **không hề
bận** trong phần lớn khoảng thời gian đó, tức đang bị KẸT/CHỜ, không
phải đang tính chậm.

Đối chiếu với 1 phát hiện CŨ đã có sẵn trong code, TỪ TRƯỚC cả phiên
debug này (xem `MnnBridge.kt`, khai báo `directWakeLock`): người dùng
từng phát hiện `std::chrono::steady_clock` (map tới `CLOCK_MONOTONIC`)
KHÔNG đếm thời gian máy ngủ sâu (suspend), trong khi timestamp log
(giờ tường, `system_clock`) VẪN đếm — chênh lệch giữa 2 mốc này (~379s
lúc đó) chính là thời gian máy đã ngủ sâu giữa chừng lúc đang sinh văn
bản. Đã sửa 1 phần (giữ `directWakeLock` đồng bộ, không qua post/Intent,
đóng khoảng hở lúc BẮT ĐẦU lệnh) — nhưng phép đo song song (steady vs
wall) **chỉ tồn tại ở nhánh THÀNH CÔNG** của `llm->response()` (log
`THOI GIAN THAT` / `THOI GIAN TUONG`), KHÔNG tồn tại ở nhánh bị watchdog
cắt — nghĩa là suốt từ đầu buổi debug này tới giờ, **mọi lần "trì trệ"
quan sát được chưa từng được đo bằng wall_clock**, không biết chắc có
đúng do ngủ sâu hay không, dù giả thuyết này khớp rất chặt với việc
không nóng máy.

**Đã sửa** (`mnn_bridge.cpp`, chỉ thêm log, không đổi hành vi): nhánh
watchdog trì trệ (trong `xsputn`) giờ đo thêm `wallStartTime_`
(`system_clock`) song song với `startTime_` (`steady_clock`, đã có sẵn),
in ra CẢ 2 mốc + chênh lệch ngay trong dòng log `[CHAN DOAN TRI TRE]` —
nếu lần "trì trệ" tiếp theo cho thấy STEADY chỉ ~90s (đúng bằng ngưỡng
watchdog) nhưng WALL lệch xa hẳn (như 1967s/119s đã thấy) → XÁC NHẬN
CHẮC CHẮN nguyên nhân là ngủ sâu giữa chừng, không cần đoán nữa. Nếu cả
2 mốc gần bằng nhau (steady ≈ wall) mà vẫn trì trệ hàng trăm/nghìn giây
→ loại hẳn giả thuyết ngủ sâu, quay lại các giả thuyết compute-bound cũ
(`embeddings_bf16.bin`...).

**Việc cần làm tiếp theo**: build lại, lặp lại đúng kịch bản gây trì
trệ (đặc biệt prompt Bible dài — nơi hiện tượng nóng máy rõ nhất), gửi
log — tìm đúng dòng `[CHAN DOAN TRI TRE] ... STEADY (ms)=... WALL
(ms)=...` để đọc kết quả trực tiếp, không cần tự trừ 2 mốc log khác
dòng nữa.

## F. XÁC NHẬN CHẮC CHẮN — máy ngủ sâu giữa chừng, và tìm ra nguyên nhân gốc tại sao WakeLock không có tác dụng (2026-08-27)

Log build có fix mục E trả về kết quả: `STEADY (ms)=137495, WALL
(ms)=1376108, CHENH LECH 1238613ms`. **Xác nhận chắc chắn, không còn là
giả thuyết**: máy đã ngủ sâu **~20,6 phút** giữa chừng lúc đang sinh văn
bản (bước "trì trệ" THẬT chỉ mất ~137,5 giây thời gian máy thức — vẫn
chậm, nhưng không phải hàng nghìn giây). Điều này giải thích được TOÀN
BỘ độ dao động khó hiểu đã thấy suốt buổi debug (1076s/1967s/119s/56s...
cho cùng 1 shape) — không phải do model/cache/GPU, mà do máy ngủ hay
không ngủ, ngủ bao lâu, mỗi lần test khác nhau hoàn toàn ngẫu nhiên.

Người dùng phản ánh đúng: **"mất luôn tính năng chạy ngầm"**. Xác nhận:
đây KHÔNG phải do các fix mục C/D vừa thêm (2 fix đó chỉ đụng tới
`mnn_bridge.cpp`, không hề đụng gì tới `MnnBridge.kt`/WakeLock) — đây là
1 lỗi CÓ SẴN từ trước, chỉ là giờ mới có số liệu để nhìn thấy rõ.

**Nguyên nhân gốc tìm được** (đọc kỹ `MnnBridge.kt`): `generate()` và
`loadModel()` chỉ gọi `acquireDirectWakeLock()` khi `pipelineDepth == 0`
— logic này TIN TƯỞNG rằng nếu `pipelineDepth > 0`, đã có 1 lệnh
`beginPipeline()` NGOÀI đang giữ sẵn WakeLock hộ. Nhưng `pipelineDepth`
chỉ được reset về 0 thủ công qua `cancelGenerate`, hoặc giảm dần qua
`endPipeline()` — và `endPipeline()` phía Dart (`chat_screen.dart`, khối
`finally`) CHỈ chạy được nếu lệnh native trước đó THẬT SỰ trả về (dù
thành công hay lỗi). Nếu 1 lệnh `generate()` bị TREO HOÀN TOÀN (đúng
kịch bản đã xác nhận thật ở mục D — lệnh #2 treo 12 phút không 1 dòng
log), phía Dart cũng bị `await` kẹt theo, khối `finally { endPipeline()
}` KHÔNG BAO GIỜ CHẠY được — `pipelineDepth` bị **rò rỉ, kẹt ở giá trị
dương VĨNH VIỄN** trong suốt phần đời còn lại của tiến trình. Từ đó trở
đi, MỌI lệnh `generate()`/`loadModel()` sau đó đều đi vào nhánh
`pipelineDepth > 0`, **bỏ qua hoàn toàn** `acquireDirectWakeLock()` — dù
không hề có WakeLock thật nào đang được giữ (cái WakeLock từ lệnh rò rỉ
gốc, nếu từng được giữ, cũng đã hết hạn từ lâu, tối đa 40 phút) — máy
được tự do ngủ sâu bất cứ lúc nào màn hình tắt.

Đúng log tối nay: `pipelineDepth=2` **ngay từ lần load MODEL ĐẦU TIÊN**
trong tiến trình (native side confirm "lan nap thu 1") — chứng tỏ có
ít nhất 2 lệnh rò rỉ từ TRƯỚC ĐÓ trong cùng phiên test kéo dài cả buổi
tối, chưa từng được dọn.

**Đã sửa** (`MnnBridge.kt`, cả `loadModel` lẫn `generate`): bỏ điều
kiện `pipelineDepth == 0` khỏi việc gọi `acquireDirectWakeLock()` — giờ
LUÔN gọi vô điều kiện, mỗi lần, bất kể `pipelineDepth`. An toàn tuyệt
đối vì đây là WakeLock KHÔNG đếm tham chiếu
(`setReferenceCounted(false)`) — gọi `acquire()` nhiều lần chỉ làm mới
hạn 40 phút, không cần `release()` thêm tương ứng, không có rủi ro giữ
WakeLock "thừa" mãi mãi. Logic bật/tắt Foreground Service (thông báo)
qua `pipelineDepth` giữ nguyên không đổi — chỉ tách riêng phần WakeLock
ra khỏi sự tin tưởng vào bộ đếm đó.

**Giới hạn thật, không giấu**: fix này chỉ đảm bảo WakeLock LUÔN được
giữ tươi cho MỌI lệnh — không sửa được gốc rễ việc `pipelineDepth` vẫn
có thể rò rỉ (vẫn cần dọn qua `cancelGenerate` hoặc khởi động lại app),
cũng không sửa được việc lệnh `generate()` có thể treo (mục D, vẫn còn
giới hạn thật đã ghi ở đó). Đây là 1 lớp phòng vệ ĐỘC LẬP, đúng đối
tượng gây ra triệu chứng cụ thể "mất chạy ngầm" — không phải sửa hết
mọi vấn đề còn lại trong hệ thống.

**XÁC NHẬN fix có tác dụng thật bằng số liệu (2026-08-28)**: log build
mới cho thấy `STEADY (ms)=140018, WALL (ms)=180173, CHENH LECH 40155ms`
— khoảng ngủ sâu giữa chừng giảm từ ~1.238.613ms (~20,6 phút, TRƯỚC fix)
xuống còn ~40.155ms (~40 giây, SAU fix) — giảm hơn 30 lần. Fix WakeLock
xác nhận có tác dụng thật.

Nhưng kết quả BÊN NGOÀI (bị watchdog cắt, lệnh sau bị từ chối) KHÔNG đổi
— vì đây luôn là 2 lớp vấn đề TÁCH BIỆT: máy ngủ sâu (đã sửa) khác hẳn
với việc bản thân tính toán chậm ngay cả lúc máy THỨC THẬT (140s máy
thức chỉ sinh được 2 ký tự — chưa sửa, không nằm trong phạm vi fix
WakeLock). Với cache-tuning đã loại (mục C/D) và ngủ sâu giờ chỉ còn dư
không đáng kể (~40s so với 140s steady), giả thuyết đứng vững nhất hiện
tại quay lại `embeddings_bf16.bin` (bảng embedding ~1GB chưa lượng tử
hoá, phải đọc lại mỗi bước) — đây là đặc điểm CỦA CHÍNH FILE MODEL, hướng
sửa thật (nếu đúng) là export lại model, không còn nằm trong phạm vi sửa
được ở `mnn_bridge.cpp`/`MnnBridge.kt` nữa.

## G. Convert lại model với `embed_bit=4` — KẾT QUẢ: LOẠI HẲN giả thuyết `embeddings_bf16.bin` (2026-08-28)

Đã convert lại đúng model 8B bằng notebook cập nhật (`--embed_bit 4`) —
output xác nhận đúng: `embeddings_int4.bin` (297MB, nén từ 1,05GB bf16
xuống int4), `config.json` tự trỏ đúng file mới. Convert chạy đúng thiết
kế, không có gì sai ở bước này.

So sánh STEADY (cùng điều kiện: Bible bật, prompt 724 ký tự, "xin chào",
lần nạp đầu tiên trong tiến trình):
- Model CŨ (bf16 embedding): STEADY=140.018ms, 2 ký tự.
- Model MỚI (int4 embedding): STEADY=138.750ms, 2 ký tự.

**Gần như giống hệt nhau (chênh <1%)** — đúng tiêu chí đã đặt ra trước khi
test ("nếu STEADY gần như không đổi → loại hẳn giả thuyết này"). **KẾT
LUẬN DỨT ĐIỂM: `embeddings_bf16.bin` KHÔNG phải nguyên nhân gây chậm.**
Không tiếp tục điều tra hướng này nữa. Khả năng cao nhất còn lại: bản
thân kiến trúc/kích thước 8B đơn giản quá nặng cho GPU của máy đang test
ở tầng tính toán cốt lõi — không phải lỗi có thể sửa bằng code app hay
convert lại model.

## H. Người dùng CHẤP NHẬN model chậm — chỉ gỡ lớp "trì trệ" (2026-08-28, đã sửa lại đúng phạm vi)

Người dùng xác nhận: chấp nhận model 8B chậm, không cần sửa tiếp phần tốc
độ, và muốn app **không tự cắt CHỈ VÌ CHẬM**. Yêu cầu ban đầu CHỈ nói tới
lớp "trì trệ" — lượt đầu tôi hiểu sai phạm vi, đã lỡ xoá luôn cả lớp "lặp
vô tận" (dù người dùng không yêu cầu); người dùng chỉnh lại ngay ("chặn
khi chậm khác chặn khi sinh rác/lặp từ"), đã phục hồi đúng lại.

**Trạng thái ĐÚNG hiện tại của `mnn_bridge.cpp` (`JniStreamingBuf::xsputn`)**:
1. Lớp "trì trệ" (mục 19, elapsed > 90s && chars < 80) — **ĐÃ XOÁ HẲN**,
   kể cả phần đo STEADY/WALL đi kèm (mục E/F) và 2 member
   `startTime_`/`wallStartTime_` không còn dùng. **Hệ quả cần biết**: mất
   luôn công cụ đo chênh lệch máy-ngủ-sâu (STEADY vs WALL) — muốn đo lại
   độ tin cậy của fix WakeLock (mục F) phải thêm lại đoạn đo đó RIÊNG,
   tách khỏi mọi hành vi tự cắt (chưa làm, chờ người dùng xác nhận có cần
   không).
2. Lớp "lặp vô tận" (`looksLikeRepetitionLoop()`, kiểm tra 1 ký tự chiếm
   >85% cửa sổ hoặc cụm 2-6 ký tự lặp khít) — **VẪN CÒN NGUYÊN**, hoạt
   động bình thường như trước giờ. KHÔNG bị đụng tới.
3. Lớp huỷ do người dùng chủ động bấm (`cancelGenerate`) — không đổi.

**Lưu ý quan trọng, tránh nhầm lẫn ở tầng khác**: `local_provider.dart`
(Dart) có 1 bộ phát hiện lặp vô tận RIÊNG, ĐỘC LẬP với bản native ở trên
(khác cơ chế: bản Dart tự gọi `cancelGenerate()` khi phát hiện, bản native
tự ném exception) — bộ này **chưa từng bị đụng tới trong suốt quá trình
trên**, vẫn hoạt động đầy đủ, không nằm trong phạm vi mục H này.

**Giới hạn thật còn lại của việc sinh chữ**: `max_new_tokens` (1024, do
MNN tự dừng), việc người dùng tự bấm huỷ, và lớp phát hiện lặp vô tận (cả
2 tầng, Dart lẫn native) — KHÔNG còn giới hạn THỜI GIAN nào (đây là phần
duy nhất đã bỏ). Cơ chế `g_slotNeedsFullReload` (mục D) áp dụng cho MỌI
lần bị ngắt giữa chừng (kể cả do lặp vô tận hoặc do người dùng huỷ), giữ
nguyên không đổi.

**Sửa thêm cùng ngày**: phép đo STEADY vs WALL (mục E/F) trước đây khai
báo TRONG khối `try` bao quanh `llm->response()`, nên chỉ đo được ở nhánh
THÀNH CÔNG. Đã chuyển `tSteadyStart`/`tWallStart` ra NGOÀI `try` và thêm
đúng phép đo đó vào CẢ 2 khối `catch` (huỷ/lặp vô tận, và lỗi khác) — giờ
đo được ở MỌI cách 1 lệnh `generate()` kết thúc, không riêng lúc thành
công nữa. Đây là công cụ DUY NHẤT còn lại để xác nhận fix WakeLock (mục
F) có thật sự ổn định hay không (câu hỏi "chạy ngầm đã khôi phục chưa"
vẫn đang bỏ ngỏ — mục F chỉ có 1 lần đo thành công, 1 lần đo sau đó
(362.715ms) chưa rõ có đúng bản có fix hay không).

Cũng dọn 1 nhánh code đã chết: `userMsg` trong catch `GenerationStoppedException`
từng có nhánh `else if (reason.find("tri tre"))` cho lớp trì trệ — nhánh
đó không còn chỗ nào ném exception với lý do đó nữa (đã bỏ ở trên), xoá
để tránh hiểu nhầm sau này là lớp trì trệ vẫn còn tồn tại đâu đó.

## I. Tra cứu kiến trúc model + 2 lỗi UX bắt người dùng làm thủ công (2026-08-29)

**Tra cứu kiến trúc**: xác nhận OccultAI/Morpheus-8B fine-tune từ
`nvidia/Llama-3.1-Nemotron-8B-UltraLong-1M-Instruct` — kiến trúc **Llama
3.1**, không phải Qwen. Giả thuyết "MNN tối ưu Qwen hơn do cùng hãng
Alibaba" **CHƯA kiểm chứng được** — không tìm thấy bằng chứng trực tiếp
nào (mọi kết quả tìm kiếm về hiệu năng Qwen-vs-kiến-trúc-khác đều là của
llama.cpp, không phải MNN). Muốn kiểm chứng thật cần 1 model Llama-kiến-
trúc cỡ nhỏ (~1.5-3B) test trên máy, so với Qwen 1.5B đã có sẵn — chưa có
dữ liệu đó.

### I.1 — Tự động nạp lại model, không bắt người dùng đổi qua lại thủ công

Trước đây: khi 1 lệnh `generate()` bị ngắt giữa chừng (huỷ/lặp vô tận),
native đánh dấu `g_slotNeedsFullReload[slot]=true` (mục D) — nhưng
`ensureLoaded()` phía Dart chỉ so `_loadedPath == modelPath` rồi bỏ qua
hẳn bước gọi `loadModel()` native, KHÔNG hề biết cờ này tồn tại. Kết quả
(xác nhận qua ảnh chụp thật): người dùng gửi lại tin nhắn bao nhiêu lần
cũng nhận đúng 1 thông báo "Cần nạp lại model..." lặp lại y hệt, không tự
hết — phải tự tay đổi sang model khác rồi đổi lại, hoặc khởi động lại
app, mới hết.

**Đã sửa, 3 tầng**:
- `mnn_bridge.cpp`: thêm JNI export `nativeNeedsFullReload(slot)` — đọc
  thẳng `g_slotNeedsFullReload[slot]`.
- `MnnNative.kt` + `MnnBridge.kt`: khai báo `external fun` tương ứng +
  case `"needsFullReload"` trong method channel (theo đúng khuôn mẫu
  `isLoaded`/`isSlotGenerating` đã có sẵn).
- `local_provider.dart`, `ensureLoaded()`: TRƯỚC khi quyết định bỏ qua
  bước `loadModel()` (do path khớp), hỏi thẳng native qua
  `needsFullReload` — nếu đang cần nạp lại, KHÔNG return sớm, chạy tiếp
  xuống gọi `loadModel()` thật (dù cùng `modelPath`) — native sẽ tạo
  `Llm` object mới, tự xoá cờ (đã có sẵn logic này từ mục D). Người dùng
  không cần biết/làm gì thêm — lần chat tiếp theo tự động nạp lại, chỉ
  chậm hơn đúng 1 lần bằng thời gian load model bình thường.

### I.2 — Tự dọn cache autotuning OpenCL, không để phình vô hạn

Kể từ khi tách cache theo từng model (mục C), thư mục
`<cacheDir>/opencl_tuning/` tích luỹ 1 thư mục con cho MỖI model từng
dùng qua, không có cơ chế dọn — xác nhận qua ảnh chụp Cài đặt Android:
"Bộ nhớ đệm" của app phình tới 1,66GB sau 1 buổi debug dùng nhiều bản
model 8B khác nhau (bf16 embedding, int4 embedding, Qwen...). Rà lại toàn
bộ codebase xác nhận không có chỗ nào khác trong app ghi vào `cacheDir`
ngoài đúng thư mục này — nhiều khả năng đây là nguồn chính, dù không loại
trừ hoàn toàn khả năng framework/thư viện khác ghi thêm gì đó nhỏ vào đó
mà code app không thấy được.

**Đã sửa** (`mnn_bridge.cpp`, hàm mới `pruneOpenCLTuningCacheIfNeeded()`,
gọi từ `buildOptimizedOpenCLConfig()` mỗi lần nạp model): tính tổng dung
lượng toàn bộ `opencl_tuning/`, nếu vượt hạn mức **500MB** thì tự xoá bớt
các thư mục con CŨ NHẤT (theo thời gian sửa đổi lần cuối, `mtime`) cho
tới khi dưới hạn mức — KHÔNG BAO GIỜ xoá thư mục của model đang chuẩn bị
dùng ngay trong lệnh nạp đó. Log rõ từng thư mục bị xoá + dung lượng, để
tra được sau này nếu cần.

**Đánh đổi cần biết**: model nào bị dọn cache sẽ phải tune lại từ đầu ở
lần dùng TIẾP THEO (chậm hơn 1 lần, như lần nạp đầu tiên của 1 model
mới) — đây là đánh đổi hợp lý giữa dung lượng và tốc độ, hạn mức 500MB
là số chọn tạm hợp lý (đủ vài model), có thể chỉnh nếu cần qua đúng 1
hằng số `kOpenCLTuningCacheCapBytes`.

## J. Không có API "nhẹ" để né nạp lại — đã tra cứu kỹ, và đã thêm log đo tách riêng từng bước (2026-08-29)

Người dùng hỏi thẳng: model đã nằm trong RAM (mmap), sao mỗi lần
`g_slotNeedsFullReload` kích hoạt vẫn phải "nạp lại" — có cách nào nhẹ
hơn không. Đã tra tài liệu chính thức MNN (mục "ChatMessage đa lượt"):
cách CHÍNH THỨC để tiếp tục hội thoại là gọi `response()` lại trên
**CÙNG 1 object**, không hề nạp lại gì — đúng như luồng chat bình thường
app đã làm. **Không tìm thấy** `reset()`/`clearHistory()` hay bất kỳ API
nào khác để dọn nhẹ trạng thái mà GIỮ NGUYÊN object/context OpenCL.

Lý do phải huỷ+dựng lại toàn bộ (`llmSlot.reset()` + `Llm::createLLM()`)
không phải vì trọng số (weights) cần đọc lại (chúng vẫn nằm nguyên trong
RAM nhờ `use_mmap`) — mà vì **context OpenCL** (hàng đợi lệnh GPU, kernel
đã biên dịch/tune) có thể ở trạng thái không nhất quán sau 1 lần bị ngắt
bất thường (mục D) — và MNN không có tài liệu nào xác nhận trạng thái đó
sẽ ra sao, nên huỷ+dựng lại là cách DUY NHẤT hiện biết chắc an toàn.

Số liệu cũ (từ nhiều log khác nhau) MÂU THUẪN nhau về thời gian `load()`
thật sự mất bao lâu khi "nạp lại" (0,176s tới ~12s, kể cả khi cache
autotuning đã ấm) — không đủ để trả lời "nhanh hơn bao nhiêu" nếu bỏ bớt
bước nào đó. **Đã thêm log đo tách riêng** (không đổi hành vi, chỉ thêm
chỉ số) cho từng bước:
- `mnn_bridge.cpp`, `nativeLoadModel()`: đo riêng `reset()`, `createLLM()`,
  `load()` (nhánh OpenCL mặc định) — in kèm số mili-giây ngay trong đúng
  dòng log đã có (không thêm dòng log mới, chỉ nối thêm vào cuối).
- `MnnBridge.kt`, `setupQnnEnvironmentOnce()`: đo cả 2 nhánh (bỏ qua vì
  đã chạy trong tiến trình này / chạy đầy đủ lần đầu) — để tách hẳn khỏi
  phần native, biết chắc có phải thủ phạm hay không (nghi vấn: nếu Android
  đã giết tiến trình app giữa các lần test dài — rất có thể xảy ra suốt
  buổi test kéo dài với nhiều khoảng tắt màn hình — biến static
  `qnnEnvSetupDone` sẽ reset về false, khiến 4-5 lần `System.load()` thất
  bại phải chạy lại mỗi lần, cộng thêm thời gian không liên quan gì tới
  `load()` model thật).

**Việc cần làm tiếp theo**: khi `g_slotNeedsFullReload` kích hoạt lần
sau, đọc đúng 3-4 con số mới trong log (`reset() mat ...ms`, `createLLM()
mat ...ms`, `load() mat ...ms`, và dòng `setupQnnEnvironmentOnce` cho
biết BỎ QUA hay CHẠY ĐẦY ĐỦ) — mới biết chính xác nên nhắm bỏ bớt bước
nào, thay vì đoán.

## L. Sửa TẬN GỐC — đổi mô hình sở hữu object sang shared_ptr, bỏ hẳn "TỪ CHỐI nạp model" (2026-08-30)

Log thật xác nhận đúng ca xấu nhất: lệnh generate() TREO THẬT SỰ (0 ký
tự, KHÔNG hề ném exception) khi đổi từ model 1.8B sang 8B — `g_slotNeedsFullReload`
chưa từng bật (vì không có exception), nên fix tự nạp lại (mục I.1) không
áp dụng được. 6,5 phút sau, người dùng thử đổi lại đúng model đó, native
từ chối với thông báo đã treo ~320 giây. Người dùng phản bác đúng: đề
xuất "đợi 180s rồi chỉ LOG cảnh báo" của phiên trước là vá víu, né tránh
gốc rễ thay vì giải quyết — yêu cầu sửa TẬN GỐC: nạp lại NGAY LẬP TỨC, dù
lệnh cũ có treo hay không, KHÔNG ĐƯỢC crash.

**Gốc rễ thật**: mọi lần "từ chối nạp model" (mục D và các mục sau) đều
xuất phát từ 1 nguyên nhân duy nhất — `g_slots` dùng `unique_ptr` (1 chủ
sở hữu). Huỷ object trong khi 1 luồng khác (lệnh generate mồ côi) vẫn có
thể đang cầm con trỏ tới nó → use-after-free thật → crash SIGSEGV (đã
từng xác nhận qua log CI, xem comment gốc trong code) — nên buộc phải TỪ
CHỐI thay vì mạo hiểm huỷ. Đây LÀ đánh đổi đúng đắn lúc đó, nhưng là giải
pháp NÔNG — xử lý triệu chứng (chặn crash bằng cách chặn luôn hành động),
không xử lý được nguyên nhân (đối tượng vẫn không thể huỷ an toàn khi
đang được dùng).

**Giải pháp gốc**: đổi `g_slots` từ `unique_ptr<Llm>` sang `shared_ptr<Llm>`.
Cơ chế đếm tham chiếu (reference counting) của `shared_ptr` giải quyết
ĐÚNG bài toán này theo cách kinh điển trong C++: mỗi lệnh `nativeGenerate()`
giờ tự giữ 1 BẢN SAO shared_ptr riêng (`slotShared()`, sống suốt cả hàm)
— khi `nativeLoadModel()` "thay thế" con trỏ trong `g_slots[slot]` bằng
object mới, object CŨ **không hề bị huỷ ngay** nếu vẫn còn ai đó (lệnh
mồ côi) giữ tham chiếu — chỉ thực sự giải phóng khi KHÔNG CÒN AI giữ nữa
(lệnh mồ côi tự trả về, dù trễ bao lâu, dù không bao giờ — trường hợp
"không bao giờ" thì object đó rò rỉ vĩnh viễn, nhưng đây CHÍNH XÁC là số
phận của nó ngay cả ở thiết kế CŨ khi treo mãi mãi — không tệ hơn).

**Đã sửa** (`mnn_bridge.cpp`):
- `g_slots`: `unique_ptr<Llm>` → `shared_ptr<Llm>`.
- Thêm `slotShared(slot)` — trả bản sao shared_ptr (khác `slotOrNull()`
  cũ, vẫn giữ nguyên cho 2 chỗ chỉ cần kiểm tra nhanh, không cần giữ sống
  lâu).
- `nativeGenerate()`: đổi sang giữ `llmKeepAlive` (shared_ptr) sống suốt
  hàm, thay vì mượn raw pointer tạm thời.
- **BỎ HẲN** khối "TỪ CHỐI NẠP MODEL MỚI" trong `nativeLoadModel()` — giờ
  LUÔN tiến hành nạp model mới ngay, chỉ còn ghi log thông tin nếu phát
  hiện có lệnh mồ côi (không còn ảnh hưởng gì tới việc nạp có thành công
  hay không).
- Thêm `g_slotEpoch[slot]` (tăng dần mỗi lần nạp model mới thành công) +
  sửa `LoadingGuard` nhận biết epoch: chỉ xoá cờ `g_generatingInProgress`
  nếu epoch lúc bắt đầu vẫn khớp epoch hiện tại — tránh trường hợp lệnh
  mồ côi (chạy rất trễ, cuối cùng cũng trả về) vô tình xoá NHẦM cờ đang
  thuộc về 1 lệnh MỚI hoàn toàn (chạy trên object mới sau khi đã nạp lại
  — nếu không có epoch, đây sẽ là 1 race condition thật, cho phép 2 lệnh
  generate() chạy chồng lên nhau trên cùng 1 object mới).
- Nạp model mới thành công giờ chủ động đặt lại `g_generatingInProgress[slot]
  = false` (object mới tinh, chưa có gì chạy trên nó) — không còn phụ
  thuộc vào việc lệnh cũ có bao giờ tự dọn cờ hay không.

**Đã sửa thêm** (`local_provider.dart`, `ensureLoaded()`): trước đây chỉ
hỏi `needsFullReload` (chỉ bật khi dừng SẠCH, có exception) — giờ hỏi
THÊM `isSlotGenerating` nếu `needsFullReload` là false. Logic: nếu Dart
CHUẨN BỊ bắt đầu 1 lượt chat MỚI mà native báo "đang generating", điều đó
CHỈ có thể là 1 lệnh mồ côi từ phiên trước (Dart chưa hề tự gửi lệnh nào
của lượt hiện tại) — coi như cần nạp lại y hệt `needsFullReload`. An toàn
để nạp lại ngay cả khi đang "generating" thật, nhờ đúng cơ chế shared_ptr
ở trên. Kết hợp 2 điều kiện này phủ được CẢ 2 trường hợp: dừng sạch (có
exception) VÀ treo thật (không exception) — không còn khoảng trống nào
giữa 2 cơ chế cũ (mục I.1) như trước.

**Rủi ro còn sót lại, nói rõ không giấu**: fix này giải quyết TRIỆT ĐỂ
rủi ro use-after-free ở tầng C++ (đối tượng, con trỏ) — đây là loại lỗi
hiểu rõ cơ chế, giải quyết dứt điểm bằng shared_ptr là đúng chuẩn. NHƯNG
**không loại trừ hoàn toàn** 1 rủi ro khác đã ghi nhận từ mục A/B: nếu
backend OpenCL của MNN có trạng thái TOÀN CỤC/static (không gắn với vòng
đời từng object `Llm` — nghi vấn chưa xác minh được, vì không có mã nguồn
nội bộ MNN) — có 2 object `Llm` "sống" cùng lúc (1 cũ mồ côi, 1 mới) về
lý thuyết vẫn CÓ THỂ đụng độ ở tầng GPU/driver, dù không còn đụng độ ở
tầng con trỏ C++ nữa. Trên thực tế, nếu lệnh cũ THẬT SỰ đang treo (không
còn phát lệnh GPU nào mới, chỉ đứng yên chờ), khả năng đụng độ này thấp —
nhưng chưa có cách kiểm chứng chắc chắn 100% nếu không có mã nguồn MNN
hoặc thiết bị thật để test kỹ. Cần theo dõi log các lần nạp lại sau khi
có lệnh mồ côi để xác nhận không có crash/hành vi lạ nào mới xuất hiện.

## M. Bug THẬT do chính mục L gây ra — `loadingGuard` kẹt vĩnh viễn sau lần nạp thành công đầu tiên (2026-08-31)

Log thật xác nhận: sau đúng 1 lần nạp model 8B thành công, **MỌI lần nạp
sau đó — bất kỳ model nào, cách bao lâu — đều bị từ chối** với thông báo
MỚI "BI TU CHOI — da co 1 lenh nap model khac cho slot 0 dang chay chua
xong", dù lần nạp trước đã trả về xong hơn 1 phút trước đó.

**Nguyên nhân**: mục L thêm cơ chế epoch cho CẢ 2 guard (`loadingGuard`
lẫn `generatingGuard`) giống hệt nhau — nhưng `nativeLoadModel()` (hàm SỞ
HỮU `loadingGuard`) lại chính là nơi TĂNG epoch (sau khi nạp xong, để bảo
vệ `generatingGuard` — xem mục L). Tới lúc `loadingGuard` kết thúc (cuối
hàm `nativeLoadModel`), epoch ĐÃ bị chính hàm đó tăng lên rồi → điều kiện
"epoch còn khớp" của `loadingGuard` LUÔN LUÔN SAI → cờ `g_loadingInProgress`
không bao giờ được xoá — kẹt vĩnh viễn ở `true` sau lần nạp THÀNH CÔNG
ĐẦU TIÊN. Epoch chỉ có ý nghĩa bảo vệ đúng cho `g_generatingInProgress`
(sống trong `nativeGenerate()` — hàm KHÁC, không tự tăng epoch) — áp
dụng y hệt kiểu đó cho `g_loadingInProgress` (sống trong CHÍNH hàm tăng
epoch) là sai về logic.

**Đã sửa**: `LoadingGuard` giờ cho phép `epochs == nullptr` — nghĩa là
"luôn xoá cờ vô điều kiện lúc kết thúc, không kiểm tra epoch gì cả".
`loadingGuard` (bảo vệ `g_loadingInProgress`) dùng `nullptr`.
`generatingGuard` (bảo vệ `g_generatingInProgress`) vẫn dùng đúng
`g_slotEpoch` như mục L.

### Phát hiện thêm — cần người dùng quyết định hướng đi, chưa tự ý làm

Đối chiếu kỹ log gây ra bug trên: lệnh generate() ĐẦU TIÊN (bắt đầu
02:45:23) **không hề treo chết** — chạy chậm thật (378,8 giây) nhưng
CUỐI CÙNG THÀNH CÔNG lúc 02:51:42. Log cho thấy `nativeSetLogDir`/
`nativeSetCacheDir` xuất hiện LẦN 2 lúc 02:46:36 — dấu hiệu rõ Activity/
màn hình app bị Android TÁI TẠO (không phải cả tiến trình chết hẳn, nhờ
`GenerationService` giữ lệnh cũ sống) — khiến trạng thái "đang gửi" phía
Dart (`sending`, `chat_screen.dart`) bị mất, cho phép người dùng gửi tin
thứ 2 dù tin đầu vẫn đang xử lý thật.

Nghĩa là: cơ chế `isSlotGenerating` (mục L) nếu chạy đúng thiết kế ở kịch
bản NÀY sẽ **huỷ ngang 1 lệnh đang chạy chậm nhưng SẼ THÀNH CÔNG**, không
phải lệnh chết — mất kết quả đã tính gần 6,5 phút. Đây là 1 đánh đổi CHƯA
được hỏi ý người dùng trước khi làm ở mục L.

Còn 1 rủi ro MỚI, CHƯA giải quyết, CHƯA xác minh: nếu Activity cũ bị huỷ,
callback JNI (`onTokenMethod`, đối tượng `callback`) mà lệnh cũ đang giữ
CÓ THỂ đã gắn với Activity đã chết — nếu lệnh cũ (chạy chậm nhưng không
chết) cuối cùng gọi lại vào callback đó, CÓ THỂ crash (khác hẳn rủi ro
use-after-free đã giải quyết ở mục L — đây là rủi ro JNI reference, chưa
từng xét tới). Chưa có cách kiểm chứng nếu không có thiết bị thật/mã
nguồn MNN.

**Việc cần làm tiếp theo**: hỏi người dùng — có muốn `isSlotGenerating`
tự động nạp lại NGAY CẢ KHI lệnh cũ chỉ đang chậm (không chết), chấp nhận
mất kết quả lệnh đó, hay chỉ muốn nạp lại khi THẬT SỰ chết/mồ côi (cần 1
cách phân biệt "chậm" và "chết" mà hiện chưa có, vì đã bỏ mọi giới hạn
thời gian theo yêu cầu mục H)? Chưa tự ý chọn hướng nào — cần xác nhận
trước khi sửa thêm.

## N. XÁC ĐỊNH ĐÚNG NGUYÊN NHÂN GỐC của mục M — không phải Android tái tạo Activity, mà là bấm BACK giữa lúc đang sinh chữ, và `chat_screen.dart` THIẾU PopScope so với các màn hình khác (2026-08-31)

Người dùng xác nhận trực tiếp: nguyên nhân KHÔNG phải Android tự tái tạo
Activity (suy đoán sai ở mục M) — mà là **tự tay bấm nút back** giữa lúc
model đang sinh văn bản. Người dùng còn chỉ ra 1 tính năng tưởng đã có
("vuốt back hỏi có thoát không") biến mất — soát code xác nhận ĐÚNG, đây
là 1 lỗ hổng thật, không phải hiểu nhầm.

**Xác nhận qua code**: `chapter_editor_screen.dart`, `document_screen.dart`,
`main.dart` đều ĐÃ dùng `PopScope(canPop: !busy, onPopInvokedWithResult:
...)` để chặn back + hiện SnackBar xác nhận khi đang có AI chạy — đúng
tính năng người dùng nhớ. Nhưng `chat_screen.dart` — màn hình xảy ra lỗi
— **HOÀN TOÀN KHÔNG CÓ `PopScope`** (chỉ có 1 dòng COMMENT nhắc tới từ
"PopScope" khi giải thích 1 fix khác, không phải widget thật). Đây là 1
điểm KHÔNG ĐỒNG BỘ giữa các màn hình, không phải Android gây ra.

**Cơ chế lỗi thật**: bấm back huỷ WIDGET `chat_screen.dart`, nhưng vòng
lặp `await for` trong hàm `_send()` (hàm `async`, KHÔNG gắn với vòng đời
widget trong Dart) **vẫn tiếp tục chạy tới hết**, chỉ là các `if (mounted)
setState(...)` bên trong tự động no-op (không ai thấy kết quả nữa). Vì
vòng lặp không bao giờ break sớm, cơ chế dọn dẹp có sẵn ở
`local_provider.dart` (`finally` sau `yield* controller.stream` — gọi
`cancelGenerate()` native nếu consumer huỷ giữa chừng TRƯỚC khi nhận
`done=true`) **không bao giờ được kích hoạt** — lệnh cứ chạy tự nhiên
(model 8B chậm, có thể mất nhiều phút) cho tới khi THẬT SỰ xong, trong
lúc đó slot bị coi là "đang bận" — khớp đúng với log mục M (lệnh đầu vẫn
chạy thật, không hề chết, chỉ là không ai biết).

**Đã sửa** (`chat_screen.dart`, chỉ file này): bọc `Scaffold` bằng
`PopScope(canPop: !sending, onPopInvokedWithResult: ...)` — đúng khuôn
mẫu đã có ở `chapter_editor_screen.dart`/`document_screen.dart`. Khi đang
`sending`, back bị chặn, hiện SnackBar "AI đang sinh văn bản — đợi xong
hoặc huỷ trước khi thoát" kèm nút "Huỷ & thoát". Bấm nút đó đặt
`cancelRequested = true` — dùng ĐÚNG cơ chế huỷ CÓ SẴN của màn hình này
(biến đã tồn tại từ trước, được `isCancelled: () => cancelRequested`
kiểm tra trong vòng lặp `_send()`) — khiến vòng lặp tự break đúng cách,
kích hoạt cơ chế dọn dẹp/gọi `cancelGenerate()` native đã có sẵn ở
`local_provider.dart`, thay vì bỏ mặc lệnh chạy ngầm vô chủ như trước.

**Kết hợp với mục M**: fix này giải quyết TẬN GỐC nguyên nhân phổ biến
nhất khiến `isSlotGenerating` từng gặp phải "lệnh cũ đang chạy" — vì giờ
back sẽ CHỦ ĐỘNG huỷ đúng cách thay vì để lệnh chạy ngầm rồi mới phát
hiện ra sau. Câu hỏi bỏ ngỏ ở mục M (nạp lại ngay hay chờ xác nhận chết
hẳn) vẫn còn giá trị cho các trường hợp KHÁC (force-kill app thật sự, lỗi
mạng, crash từng phần...) — nhưng tình huống CỤ THỂ người dùng gặp phải
(bấm back) giờ đã có đường xử lý đúng, không cần dựa vào `isSlotGenerating`
nữa cho đúng kịch bản này.

## O. Trả lời 3 câu hỏi cùng lúc — "mất chạy nền", tài liệu có đồng bộ không, và cache vẫn 1,8GB (2026-08-31)

### O.1 — KHÔNG phải mất chạy nền — là đúng tính năng "xác nhận thoát" đã có từ trước, cộng thêm 1 giới hạn thật mới phát hiện

Log xác nhận: `nativeRequestCancel` bắn ra cho **CẢ 2 slot cùng lúc**,
lặp lại 2 lần trong vài phút. Rà code chỉ có ĐÚNG 1 chỗ gọi huỷ cả 2 slot
cùng lúc: `main.dart`, `RootScreen`'s `PopScope.onPopInvoked` — tính năng
"Thoát khi AI đang chạy?" đã được thêm TỪ TRƯỚC (theo đúng 1 phản hồi
người dùng khác, đã ghi lại đầy đủ lý do trong comment) — cử chỉ back ở
màn hình GỐC (không còn gì để pop) → hỏi xác nhận → nếu chọn "Vẫn thoát"
→ huỷ cả 2 slot + đợi tối đa 10s cho lưu xong → mới thật sự thoát app.

Đây **không phải lỗi mất chạy nền** — là đúng thiết kế xác nhận thoát khi
người dùng CHỦ ĐỘNG bấm back tại màn gốc. Khả năng cao: cử chỉ "chuyển
sang ứng dụng khác" (vuốt home/đa nhiệm) bị nhầm với cử chỉ "back" (thoát
app) — 2 cử chỉ này dễ giống nhau trên điều hướng kiểu vuốt (gesture
navigation) hiện đại, đặc biệt nếu vuốt gần cạnh màn hình.

**Phát hiện thật, giá trị hơn**: model 8B trong log này SINH RA 0 KÝ TỰ
suốt từ lúc bắt đầu tới lúc bị huỷ (không phải chỉ chậm) — `nativeRequestCancel`
CÓ đặt cờ `g_cancelRequested`, nhưng cờ đó **CHỈ được kiểm tra bên trong
`xsputn`** (chỗ MNN gọi vào MỖI KHI thật sự ghi ra được ít nhất 1 ký tự —
xem `JniStreamingBuf::xsputn`). Nếu model sinh ra ĐÚNG 0 ký tự, `xsputn`
không hề được gọi lần nào → cờ huỷ không bao giờ được kiểm tra → lệnh
huỷ, dù đã đặt cờ đúng, **KHÔNG BAO GIỜ thật sự có tác dụng** — khớp
chính xác với log: 95 giây sau (rồi 23 giây sau nữa) vẫn báo "lenh
generate() TU PHIEN TRUOC van con chay do (mo coi)" dù đã yêu cầu huỷ từ
trước đó rất lâu.

**Đây là giới hạn CÙNG BẢN CHẤT với giới hạn đã ghi ở mục D/H** (không có
watchdog thời gian thật độc lập với `xsputn`) — áp dụng luôn cho cả
trường hợp NGƯỜI DÙNG chủ động huỷ, không chỉ trường hợp tự động phát
hiện trì trệ đã bỏ. **CHƯA có cách sửa AN TOÀN** — muốn huỷ thật 1 lệnh
đang kẹt cứng trong tính toán GPU (0 ký tự, không có điểm nào để code
tự kiểm tra cờ) cần buộc dừng 1 luồng đang chạy dở trong driver GPU — rủi
ro crash cả tiến trình, y hệt rủi ro đã từ chối làm ở mục D.

### O.2 — Cache 2048MB không giảm — bug THẬT trong chính fix trước, đã sửa

Log xác nhận: `pruneOpenCLTuningCacheIfNeeded` CÓ chạy, CÓ phát hiện đúng
2048MB vượt hạn mức 500MB, in ra "bat dau don thu muc CU NHAT" — nhưng
**không hề có dòng "DA XOA" nào sau đó**. Nguyên nhân: mục I.2 (khi thêm
tính năng này) loại trừ thư mục model HIỆN TẠI khỏi việc xoá ("không xoá
cache đang chuẩn bị dùng ngay bây giờ") — nhưng log này cho thấy người
dùng chỉ dùng ĐÚNG 1 model (`OccultAI-Morpheus-8B-v2-MNN-q4-chinh`) suốt
cả phiên — nên thư mục ĐÓ luôn là "hiện tại", luôn bị loại trừ, KHÔNG BAO
GIỜ bị xoá dù tự phình to bao nhiêu qua nhiều lần nạp/nhiều hình dạng
prompt khác nhau.

**Đã sửa**: bỏ hẳn luật loại trừ model hiện tại. Mất cache tuning của
CHÍNH model đang dùng chỉ khiến lần nạp TIẾP THEO phải dò lại từ đầu (chi
phí y hệt 1 lần nạp lạnh bình thường, không phải lỗi đúng nghĩa) — đánh
đổi hợp lý để cache có giới hạn thật, kể cả khi chỉ dùng 1 model duy nhất
suốt phiên. **Đã sửa thêm** (an toàn quan trọng): đảo thứ tự gọi — dọn
TRƯỚC, đảm bảo thư mục tồn tại (`ensureDirExists`) SAU — vì giờ có thể tự
xoá cả thư mục model hiện tại, nếu vẫn `ensureDirExists` trước rồi mới
dọn (thứ tự CŨ), thư mục vừa tạo xong có thể bị xoá ngay sau đó, khiến
`tmp_path` trỏ vào chỗ không tồn tại lúc `llmSlot->load()` thật sự dùng
tới.

### O.3 — Tài liệu: đã cập nhật đồng bộ ngay trong lần sửa này

2 phát hiện ở mục O.1/O.2 (giới hạn huỷ khi 0 ký tự, bug loại trừ model
hiện tại khỏi việc dọn cache) đều là phát hiện MỚI, chưa từng ghi trong
tài liệu trước đây — đã ghi lại đầy đủ ngay tại mục này, cùng lúc với
việc sửa code, để không bị lệch pha. CHƯA thử bỏ `llmSlot.reset()`/`createLLM()` (rủi ro tái
hiện lỗi treo 12 phút đã sửa ở mục D) — cần số liệu thật trước, và cần
người dùng chủ động xác nhận muốn đánh đổi rủi ro đó hay không.

## K. Luồng "dịch → sinh → dịch" (dịch thuật trung gian) không hiện tiến trình ở bước sinh văn bản chính (2026-08-29)

Người dùng phản ánh: bật "Dịch thuật trung gian", ngồi nhìn không thấy
tiến trình đang ở đâu, "ức chế quá". Rà lại `translation_service.dart`
phát hiện: hạ tầng báo tiến trình (`onStage` callback) **đã có sẵn và đã
được nối đúng ở cả 3 màn hình gọi** (`chat_screen.dart`,
`chapter_editor_screen.dart` qua biến `aiStage`,
`chapter_batch_service.dart` qua thông báo Android) — KHÔNG phải thiếu hạ
tầng, mà thiếu đúng 1 chỗ dùng nó.

**Nguyên nhân cụ thể**: `generateWithOptionalTranslation()` (hàm CHÍNH,
dùng bởi 8+ nơi gọi khác nhau — chat, tạo chương đơn lẻ, tóm tắt, dàn ý,
Story Bible, RAG, style...) có 3 bước (dịch vào → sinh bằng model chính →
dịch ra), nhưng bước GIỮA (sinh văn bản — thường là bước LÂU NHẤT, đặc
biệt với model chậm như 8B đang dùng, và từ khi bỏ watchdog trì trệ ở mục
H thì KHÔNG CÒN GIỚI HẠN THỜI GIAN nào) lại gọi `mainProvider.generate()`
— chờ CẢ KHỐI, không streaming, `onStage` chỉ gọi ĐÚNG 1 LẦN lúc bắt đầu
bước rồi im bặt cho tới khi xong hẳn. Đối chiếu: hàm SONG SONG
`generateResumableWithOptionalTranslation()` (dùng riêng cho vòng lặp tạo
chương hàng loạt) đã làm ĐÚNG từ trước — dùng `generateStream()` cho đúng
bước này — chỉ hàm ĐẦU (dùng ở NHIỀU nơi hơn) bị thiếu.

**Đã sửa** (chỉ `translation_service.dart`, không đụng màn hình nào —
mọi nơi gọi tự động được lợi vì đều đã nối `onStage` sẵn): đổi bước sinh
văn bản chính sang `generateStream()`, gọi lại `onStage` MỖI KHI nhận
được đoạn mới, kèm số ký tự đã sinh (`'Đang sinh văn bản... (đã sinh N ký
tự)'`) — số này tăng dần realtime, không còn đứng yên. Cố tình KHÔNG đẩy
nội dung thô (chưa dịch) qua `onChunk` (giữ đúng hợp đồng cũ: `onChunk`
chỉ nhận text ĐÃ DỊCH sang tiếng Việt, tránh người dùng thấy chữ nước
ngoài lạ giữa chừng gây khó hiểu) — chỉ dùng `onStage` (vốn đã hiển thị
dạng "⏳ ..." ở UI) để báo tiến trình.

**Lợi ích phụ**: trước đây bước này KHÔNG có cách nào huỷ giữa chừng (đã
ghi nhận là giới hạn thật ở phần khai báo hàm) — giờ dùng `generateStream()`
nên tự động hưởng luôn cơ chế `isCancelled` đã có sẵn trong file, huỷ
được giữa chừng bước sinh văn bản chính, không chỉ 2 bước dịch như trước.

## P. Chuyển thời điểm dọn cache autotuning OpenCL — từ "mỗi lần nạp" sang "chỉ khi đổi model / chỉ khi thoát app thật" (2026-09-01)

Theo yêu cầu người dùng, sau khi tự phát hiện (trả lời câu hỏi "nạp lạnh
có làm sinh chữ chậm hơn không") 1 hệ quả thật của fix mục O.2: log O.2
cho thấy 1 model DUY NHẤT có thể tự tạo ra tới 2048MB cache qua nhiều
hình dạng prompt khác nhau trong 1 phiên — nghĩa là sau khi mục O.2 bỏ
luật loại trừ "model hiện tại" khỏi việc dọn, nếu người dùng chỉ dùng
đúng 1 model suốt phiên, cache của CHÍNH model đó có thể lại vượt 500MB
NGAY TRONG PHIÊN, và bị dọn sạch giữa chừng nhiều lần — mỗi lần dọn xong
lại phải dò lại từ đầu (thêm chi phí ở prefill/vài token đầu, xem lý giải
ở mục O.1 — CHƯA đo trực tiếp xác nhận cache lạnh có làm CHẬM DECODE ổn
định hay không, chỉ có cơ sở lý thuyết cho rằng chủ yếu ảnh hưởng
prefill/vài token đầu, không phải throughput ổn định về sau).

**Đã sửa**: việc dọn (`pruneOpenCLTuningCacheIfNeeded`) không còn chạy ở
mỗi lần gọi `buildOptimizedOpenCLConfig()` (tức mỗi lần nạp, kể cả nạp
LẠI đúng model cũ trong cùng slot — ví dụ luồng tự-nạp-lại-sau-huỷ ở mục
I.1) nữa. Thêm `g_lastLoadedModelSubdir[slot]` theo dõi model đã nạp
thành công LẦN GẦN NHẤT trong từng slot — chỉ dọn khi model SẮP nạp khác
với model đó (đổi model thật, hoặc slot lần đầu nạp); nạp lại đúng model
cũ bỏ qua bước dọn.

Thêm 1 điểm dọn MỚI, độc lập, chỉ chạy đúng 1 lần lúc app thoát THẬT:
`nativeCleanupCacheOnExit()` (JNI mới, không nhận slot, không loại trừ gì
— app sắp đóng nên không còn "model đang dùng" nào cần bảo vệ) — Kotlin
(`MnnBridge.kt`, method `"cleanupCacheOnExit"`) gọi ĐỒNG BỘ (cố ý, không
tách thread nền) để đảm bảo dọn xong thật trước khi trả kết quả về Dart;
Dart (`LocalLlamaProvider.cleanupCacheOnExit()`) `await` lệnh này; nơi
gọi: `main.dart`, ngay TRƯỚC `SystemNavigator.pop()`, SAU khi đã huỷ +
đợi lưu xong 2 slot — cùng logic "CHỜ THẬT, không bắn cờ rồi thoát ngay"
đã áp dụng cho chính đoạn code exit này trước đó (mục N).

**Cập nhật (2026-09-01, cùng ngày) — đã khép nốt giới hạn còn lại, theo
lựa chọn PHƯƠNG ÁN (a) của người dùng**: đoạn trên ghi lại đúng lúc mới
xong phần "chỉ dọn khi có tác vụ đang chạy" — khi đó nhánh thoát NHANH
lúc KHÔNG có gì đang chạy (`runningCount == 0`, trường hợp PHỔ BIẾN NHẤT)
vẫn bỏ qua, để hệ thống tự pop, chưa gọi `cleanupCacheOnExit()`. Người
dùng chọn (a) — chấp nhận đánh đổi thêm 1 nhịp chờ bất đồng bộ ở MỌI lần
back tại màn gốc để khép luôn nhánh này.

**Đã sửa**: `PopScope.canPop` đổi từ điều kiện (`runningCount == 0`) sang
CỐ ĐỊNH `false` — chặn MỌI lần back ở màn gốc, không còn nhánh nào để hệ
thống tự xử lý pop nữa. Bên trong `onPopInvoked`, tách rõ 2 nhánh:
- `runningCount == 0`: KHÔNG hiện hộp thoại xác nhận (không có gì đang
  chạy để phải hỏi) VÀ KHÔNG hiện hộp "Đang dừng AI..." (không có gì để
  dừng, hiện ra chỉ gây khó chịu vô ích) — chỉ `await cleanupCacheOnExit()`
  rồi `SystemNavigator.pop()` thẳng. Đây chính là nhịp chờ mới thêm vào
  MỌI lần thoát bình thường — nhanh (chỉ I/O file, không đụng GPU/model),
  nhưng không còn "tức thời tuyệt đối" như trước.
- `runningCount > 0`: giữ nguyên toàn bộ luồng cũ (hỏi xác nhận → huỷ 2
  slot → poll tối đa 10s → dọn cache → pop) — không đổi gì so với bản ghi
  ở trên.

Không còn giới hạn nào bỏ ngỏ ở luồng thoát app nữa — mọi đường thoát qua
back tại màn gốc (có hoặc không có tác vụ đang chạy) đều gọi
`cleanupCacheOnExit()` trước khi thoát thật. Đường CHƯA phủ (chưa được
yêu cầu, chưa tự làm): thoát bằng vuốt-khỏi-danh-sách-đa-nhiệm hoặc bị hệ
điều hành tự kill (không đi qua back-gesture, không có cách nào Flutter
chặn được đường này để chạy code dọn dẹp có `await`) — vẫn ngoài phạm vi
mục này, đúng như trao đổi ở bản trả lời trước (hướng (b), chưa chọn).

## Q. Thêm điểm dọn cache thứ 2 — lúc app KHỞI ĐỘNG — khép nốt đường vuốt-khỏi-đa-nhiệm/OS-kill (2026-09-01)

Theo yêu cầu người dùng (hỏi vì sao nhiều app khác "vuốt xong / bị OS
kill là xoá sạch cache" được, trong khi mục P nói Flutter không chặn
được 2 đường đó). Trả lời: các app đó không làm qua back-gesture —
2 cơ chế thật khác hẳn:
- **Vuốt-khỏi-đa-nhiệm** (người dùng chủ động xoá task): Android gọi
  `Service.onTaskRemoved()` trên Service app đang chạy (kể cả foreground
  service như `GenerationService` sẵn có trong app này) — cơ chế native
  Kotlin, không qua Flutter/Dart. App CHƯA dùng hook này (đã kiểm tra:
  `GenerationService.kt` chưa override `onTaskRemoved()`).
- **OS tự kill vì thiếu RAM**: kill cứng, KHÔNG có callback nào đảm bảo
  chạy trước khi tiến trình chết — kể cả `onTaskRemoved()` cũng không áp
  dụng (chỉ dành cho "người dùng xoá task", khác kill-vì-thiếu-RAM).
- **Cách đa số app THẬT SỰ làm cho cả 2 trường hợp trên**: dọn dẹp lúc
  MỞ APP LẠI (`onCreate`/startup), không phải lúc thoát — cache cũ vẫn
  nằm nguyên trên đĩa ngay sau khi bị kill kiểu nào cũng vậy, chỉ được
  dọn ở lần mở tiếp theo. Đây là cách DUY NHẤT đảm bảo chạy được dù thoát
  kiểu gì (back, vuốt, OS kill, force-stop) — không phụ thuộc bắt đúng
  thời điểm thoát.

**Đã chọn và làm**: thêm điểm dọn lúc khởi động (không làm
`onTaskRemoved()` — vẫn để ngỏ nếu sau này cần phủ thêm case "vuốt lúc
đang có tác vụ chạy").

**Đổi tên hàm native**: `nativeCleanupCacheOnExit` → `nativeEnforceOpenCLCacheCap`
— tên cũ gắn chết với 1 thời điểm gọi (lúc thoát), gây hiểu lầm khi dùng
lại ở thời điểm khác (lúc khởi động); tên mới trung lập theo ĐÚNG VIỆC
hàm làm (giữ cache dưới hạn mức), không gắn thời điểm cụ thể. Cập nhật
đồng bộ ở cả 2 nơi gọi (`MnnBridge.kt`: nhánh method-channel
`"cleanupCacheOnExit"` lúc thoát, VÀ điểm gọi mới lúc khởi động).

**Điểm gọi mới**: `MnnBridge.kt`, trong `onMethodCallInner`, ngay sau
`nativeSetCacheDir()` (khối `if (!logDirSent)` — chỉ chạy ĐÚNG 1 lần mỗi
tiến trình, đúng lúc Dart gọi lệnh native đầu tiên của phiên).

**Phát hiện + sửa 1 race condition thật trước khi chốt** (không phải suy
đoán — soát lại chủ động): bản đầu định chạy điểm khởi động này trên
thread nền (`Thread { }.start()`) để không làm chậm lệnh gọi Dart đầu
tiên. Vấn đề: `onMethodCallInner` chạy tuần tự trên platform thread (mặc
định của `MethodChannel`) — nếu Dart gọi `loadModel` gần như ngay sau khi
mở app (thường gặp), lệnh đó được xử lý TRÊN PLATFORM THREAD trong khi
thread dọn NỀN (thread riêng, khác hẳn) vẫn có thể đang xoá — 2 thread
THẬT chạm cùng thư mục `opencl_tuning/` cùng lúc, có thể xoá nhầm đúng
lúc `tmp_path` của model đang nạp đang được dùng (khác bug đã sửa ở mục
O.2 — đó là sai THỨ TỰ trong 1 thread, đây là THẬT SỰ 2 thread chạy song
song). **Đã sửa**: bỏ hẳn thread nền, gọi ĐỒNG BỘ ngay trên platform
thread — vì `onMethodCallInner` xử lý tuần tự, gọi đồng bộ ở đây đảm bảo
dọn xong hẳn TRƯỚC KHI platform thread có thể xử lý bất kỳ lệnh gọi tiếp
theo nào (kể cả `loadModel`), loại hẳn race. Đánh đổi: lệnh gọi native
đầu tiên của phiên (thường vô hại, không nhất thiết là lệnh người dùng
đang sốt ruột chờ) chậm thêm đúng bằng thời gian quét+xoá cache — 1 lần
duy nhất mỗi phiên.

**Đường vẫn chưa phủ** (chưa được yêu cầu, chưa tự làm): `onTaskRemoved()`
— case vuốt-khỏi-đa-nhiệm LÚC ĐANG CÓ tác vụ generate() thật sự chạy dở
(hiện tại rơi đúng vào tình huống "mồ côi" đã ghi ở mục N/O, không tự huỷ
được) vẫn chưa có cách xử lý riêng — điểm dọn cache lúc khởi động mới
thêm chỉ giải quyết phần CACHE, không giải quyết phần "lệnh generate() mồ
côi" cho case vuốt-khỏi-đa-nhiệm.

## R. Sửa lỗi BUILD CI thật do chính mục P gây ra — dùng `kMaxSlots` TRƯỚC khi nó được khai báo (2026-09-01)

Log build CI thật (`Build APK #113`, thất bại sau 8m35s):
```
error: use of undeclared identifier 'kMaxSlots'
```
tại đúng 3 dòng mới thêm ở mục P (`g_lastLoadedModelSubdir[kMaxSlots]`
và 2 chỗ so sánh `slot < kMaxSlots`).

**Nguyên nhân thật**: `kMaxSlots` vốn khai báo ở dòng ~639 (ngay trước
phần hạ tầng đa-slot: `g_slots`, `g_cancelRequested`...). Mục P chèn
`g_lastLoadedModelSubdir` + phần dùng `kMaxSlots` vào NGAY TRƯỚC hàm
`buildOptimizedOpenCLConfig()` (dòng ~400) — SỚM HƠN dòng 639 rất nhiều.
C++ đọc file từ trên xuống, một tên phải được khai báo TRƯỚC lần dùng
đầu tiên trong toàn file — lỗi build đúng như log báo, không phải lỗi
ngẫu nhiên/lỗi môi trường CI.

**Đã sửa**: chuyển NGUYÊN dòng `constexpr int kMaxSlots = 2;` lên đầu
file (ngay sau `g_logDirBufForSignal`, TRƯỚC MỌI chỗ dùng nó trong toàn
file), xoá khai báo trùng ở vị trí cũ (dòng ~639, chỉ giữ lại phần
comment gốc của mục lịch sử ở đó — vẫn đúng ngữ cảnh, không liên quan gì
tới `kMaxSlots`). Đặt ở phạm vi file (không nằm trong `namespace { }`
nào) — `constexpr` ở phạm vi file vốn đã có internal linkage mặc định
giống hệt lúc còn trong `namespace { }`, chuyển ra ngoài không đổi hành
vi liên kết, chỉ đổi chỗ nhìn thấy được sớm hơn trong file.

**Bài học ghi lại cho lần sau (tự phê bình)**: khi chèn code mới dùng 1
hằng số/hàm đã có sẵn trong file, phải kiểm tra VỊ TRÍ khai báo của nó
(không chỉ kiểm tra nó CÓ tồn tại) trước khi chèn — file C++ đọc tuần tự
từ trên xuống, "có tồn tại trong file" không đồng nghĩa "nhìn thấy được
tại điểm mình sắp chèn". Lần sửa mục P trước đó CHỈ verify bằng cách đếm
ngoặc cân bằng (`braces: 0`) — cách đó không bắt được lỗi loại này (lỗi
thứ tự khai báo, không phải lỗi cú pháp/ngoặc), nên lọt qua tới tận CI.

## S. Rà soát toàn hệ thống lần nữa — Story Bible KHÔNG rỗng, nối dây đầy đủ; tìm và vá 1 tính năng mồ côi thật (2026-09-01)

Theo yêu cầu người dùng: "kiểm tra tính năng nào chưa có UI, chưa nối
dây, UI nào chỉ là vỏ rỗng, đặc biệt Bible".

**Kết luận Story Bible**: KHÔNG rỗng. Truy trực tiếp theo đường tới
prompt sinh chữ (`RagService.buildContext()`/`buildSystemPrompt()`,
gọi thật từ `chapter_editor_screen.dart`) — xác nhận cả 8 loại đều có
đường vào prompt AI thật: Character, WorldRule, GlossaryTerm,
PlotThread, PlotBeat, TimelineEvent (qua `buildContext`), StyleProfile
(qua `describeEntryWithFacts`, đường riêng vì phụ thuộc lựa chọn của
người dùng mỗi lượt sinh, không phải "mọi entry trong phạm vi" như 6
loại kia). `WritingGoal` không cần vào prompt AI (đúng thiết kế — chỉ là
mục tiêu năng suất cá nhân), có bảng `daily_word_log` ghi thật mỗi lần
lưu chương (`recordWordSnapshot()`, gọi từ `chapter_editor_screen.dart`
+ `chapter_batch_service.dart` cả 2 nhánh local/remote).

**Phương pháp rà soát** (để lần sau dùng lại): quét cơ giới (regex) mọi
hàm public trong `lib/services/*.dart` + `lib/screens/*.dart`, đếm số
lần tên hàm xuất hiện dạng lời gọi (`tenHam(`) trong TOÀN BỘ repo — nếu
số lần xuất hiện KHÔNG NHIỀU HƠN số nơi ĐỊNH NGHĨA, khả nghi mồ côi. Ra
4 ứng viên, xác minh tay từng cái: 3 cái là báo động giả (`describeCharacter`/
`describeRule`/`gistOf` — hàm closure cục bộ, gọi qua tear-off
`.map(tenHam)` nên regex không bắt được dạng `tenHam(`), 1 cái là THẬT.
Bổ sung: quét riêng UI có `onPressed` rỗng hoặc thông báo kiểu "chưa hỗ
trợ/sắp ra mắt" — không tìm thấy trường hợp nào.

**Tìm được 1 tính năng mồ côi thật**: `SettingsService.renameNovel(Novel)`
— hàm đổi tên/tác giả truyện, code đầy đủ, chạy được, nhưng
`NovelListScreen` (`main.dart`) trước đây chỉ có nút xoá, KHÔNG có
đường nào gọi tới hàm này — `createNovel`/`deleteNovel` (2 hàm anh em
ngay cạnh trong cùng file) đều có nút gọi thật, riêng `renameNovel` thì
không.

**Đã sửa**: thêm `_renameNovel(Novel novel)` trong `NovelListScreen`
(dialog y hệt phong cách `_createNovel()` — 2 ô Tên truyện/Tác giả —
nhưng ĐIỀN SẴN giá trị hiện tại). Đổi `trailing` của mỗi thẻ truyện từ 1
`IconButton` xoá đơn lẻ sang `PopupMenuButton` (2 mục: "Đổi tên"/"Xóa")
— đúng khuôn mẫu `PopupMenuButton` đã dùng sẵn ở `chapters_screen.dart`
(menu xuất file) và 4 màn khác trong app, không phát minh pattern UI
mới; đồng thời né lỡ tay bấm nhầm xoá (trước đây nút xoá lộ thiên ngay
cạnh vùng chạm mở truyện).

## T. Sự cố "Tạo lại tất cả ghi chú" ghi đè chương bằng cảnh báo lỗi nội bộ + chuỗi ~35 lệnh generate() chồng chéo trên cùng 1 slot — 6 nguyên nhân gốc và toàn bộ bản vá (2026-09-05)

### Triệu chứng ban đầu
Người dùng báo: bấm sinh 1 chương, chờ rất lâu (đối chiếu debug log: hơn 1 tiếng, từ 18:30 tới 19:51) mà chương không ra được 1 chữ nào. Test ban đầu ở khung chat (2 lần, đều tự huỷ giữa chừng) tưởng như không liên quan, nhưng chính là mồi lửa.

### Phương pháp xác định nguyên nhân
Đọc trực tiếp source thật (không suy đoán từ tên biến/hàm) đối chiếu từng dòng debug log theo mốc thời gian: `local_provider.dart` (`ensureLoaded`/`generateStream`), `MnnBridge.kt` (mutex, cancelGenerate, currentJob), `mnn_bridge.cpp` (vòng đời `g_slots` shared_ptr, exception handling trong `nativeGenerate`), `chapter_editor_screen.dart` (`_applyAllPendingRewrites`, `_generateRespectingTranslation`), `background_task_manager.dart`, `chapter_batch_service.dart`, `document_service.dart` (2 nơi ĐÃ có validation đúng, dùng làm chuẩn so sánh). Ban đầu nghi ngờ Story Bible/dịch tài liệu — đã loại trừ bằng grep trực tiếp (`story_bible_screen.dart` không hề gọi AI).

### 6 nguyên nhân gốc, đã xác nhận bằng code (không phải suy đoán)

1. **`_applyAllPendingRewrites` (chapter_editor_screen.dart) chỉ kiểm tra `cleaned.isEmpty`** trước khi ghi kết quả AI đè lên đoạn văn gốc — một cảnh báo lỗi nội bộ dạng `⚠️ [...]` (KHÔNG rỗng, KHÔNG ném exception, xem điểm 3 bên dưới) lọt qua, bị ghi thẳng vào chương coi như văn bản thật, rồi vòng lặp **chạy tiếp** sang ghi chú kế tiếp — không giống `chapter_batch_service.dart`/`document_service.dart` đã có `looksCorrupted` (kiểm tra tỉ lệ độ dài) từ trước. Đây là hàm DUY NHẤT trong 3 nơi xử lý-hàng-loạt thiếu lớp bảo vệ này.
2. **`ensureLoaded()` (local_provider.dart) coi MỌI lúc `isSlotGenerating=true` là "chắc chắn mồ côi từ phiên trước"** (bản vá mục I.1, 2026-08-29) rồi nạp đè model NGAY — giả định sai khi 2 tính năng cùng phiên gọi chung slot gần như đồng thời (chính là điểm 5 bên dưới): nạp đè lúc đó biến 1 lệnh THẬT, đang chạy bình thường (chỉ chậm — model 8B đã xác nhận vốn chậm, mục H) thành mồ côi thật.
3. **`g_slots[slot]` dùng `shared_ptr`** (mục L, 2026-08-30, cố tình để nạp lại không crash lệnh cũ) khiến lệnh mồ côi ở điểm 2 **tiếp tục chạy ngầm đến hết**, vẫn giữ nguyên `generateMutexes[slot]` (Kotlin) suốt thời gian đó — mọi lệnh generate() MỚI phải xếp hàng thật phía sau.
4. **`currentJob` (MnnBridge.kt) là 1 biến `Job?` duy nhất**, bị ghi đè mỗi lần có lệnh "generate" mới — `cancelGenerate()` chỉ huỷ được lệnh MỚI NHẤT, không đụng được tới các lệnh cũ hơn đang xếp hàng ở Mutex hay đang chạy ngầm. Không có cách nào trong app dọn được backlog này.
5. **`chapter_editor_screen.dart` (Viết tiếp/Đắp thịt/Kiểm tra nhất quán/Tạo lại tất cả ghi chú) gọi thẳng `TranslationService`/provider, hoàn toàn KHÔNG qua `BackgroundTaskManager`** — trong khi đó là nơi DUY NHẤT áp cap đồng thời=1 cho local model (mục 4.6/K). `chat_screen.dart` có tôn trọng cap này; 4 tính năng kia thì không — rời màn soạn chương lúc đang sinh (Future không tự huỷ theo vòng đời widget) rồi mở lại bấm tiếp, hoặc chat song song lúc đang soạn chương, đều có thể tạo 2 lệnh generate() thật đồng thời trên slot 0.
6. **`deleteAllPendingRewritesForChapter` xoá TOÀN BỘ hàng đợi ghi chú sau mỗi lượt "Tạo lại tất cả"**, kể cả ghi chú CHƯA kịp xử lý — giả định cũ (mọi ghi chú luôn kết thúc ở trạng thái cuối) không còn đúng sau khi thêm khả năng dừng sớm ở điểm 1.

Chuỗi nhân quả: 2 lần huỷ test ở khung chat (18:52, 18:59) bật `g_slotNeedsFullReload` → điểm 2 kích hoạt nạp đè → nếu đúng lúc đó "Tạo lại tất cả ghi chú" (hoặc 1 tính năng khác trong `chapter_editor_screen.dart`) đang chạy, điểm 2+3+4 biến nó thành mồ côi + không huỷ được → điểm 1 khiến vòng lặp KHÔNG dừng lại mà chạy tiếp qua toàn bộ ~35 ghi chú, mỗi ghi chú lại đụng đúng điểm 2 → tự nhân bản thành hàng chục lệnh chồng chéo, một số ghi rác `⚠️ [...]` thẳng vào chương.

### Toàn bộ bản vá

| Điểm gốc | File | Nội dung sửa |
|---|---|---|
| 1 | `chapter_editor_screen.dart` | `_applyAllPendingRewrites`: thêm kiểm tra `kAiFailureMarker`/tỉ lệ độ dài (giống `looksCorrupted` ở 2 nơi kia) — phát hiện là **dừng hẳn vòng lặp ngay**, giữ nguyên `status='pending'` (không đổi 'done'/'failed') |
| 6 | `chapter_editor_screen.dart` | Theo dõi `processedIds` — chỉ xoá khỏi hàng đợi ghi chú ĐÃ THỰC SỰ xử lý xong; ghi chú bị dừng giữa chừng (và các ghi chú sau nó chưa kịp chạy) được giữ nguyên để thử lại sau |
| — | `ai_provider.dart` | Hằng số dùng chung `kAiFailureMarker = '⚠️ ['` — 1 định nghĩa duy nhất cho cả nơi ghi (điểm 1) lẫn nơi quét (mục 4.17) |
| — (khắc phục hậu quả dữ liệu cũ) | `data_integrity_service.dart` + `data_integrity_screen.dart` *(mới)* | Xem mục 4.17 — tự quét + tự khôi phục chương đã lỡ bị ghi rác, không bắt người dùng tự dò tay |
| 2 | `local_provider.dart` | `ensureLoaded()`: khi `isSlotGenerating=true`, hỏi thêm `slotStalledMs` (thời gian từ **token cuối cùng**, không phải tổng thời gian chạy) — chỉ nạp đè khi thật sự không tiến triển gì quá `_stalledThreshold = 3 phút`; nếu vẫn đang tiến triển, để Mutex Kotlin tự xếp hàng, KHÔNG nạp đè |
| 2 | `mnn_bridge.cpp` | Thêm `g_lastProgressMs[slot]` (cập nhật mỗi token trong `JniStreamingBuf::xsputn`, khởi tạo lúc bắt đầu generate) + hàm JNI `nativeSlotStalledMs` — đo GAP-từ-token-cuối, cố tình KHÔNG dùng elapsed-time-từ-lúc-bắt-đầu (đúng lỗi khiến lớp trì trệ cũ ở mục H bị xoá vì cắt nhầm lệnh chậm-nhưng-sống) |
| 2 | `MnnNative.kt` / `MnnBridge.kt` | Khai báo `nativeSlotStalledMs`, expose qua case `"slotStalledMs"` trong `onMethodCall` |
| 4 | `MnnBridge.kt` | `currentJob: Job?` (1 biến) → `jobsPerSlot: Array<CopyOnWriteArrayList<Job>>` (danh sách theo slot) — mỗi lệnh "generate" tự đăng ký vào đúng slot, tự gỡ khi xong (`invokeOnCompletion`); `cancelGenerate` giờ huỷ **toàn bộ** Job của slot (kể cả Job còn đang chờ Mutex, Kotlin `Mutex.withLock` huỷ được ngay cả khi đang chờ khoá) |
| 5 | `chapter_editor_screen.dart` | `_generateRespectingTranslation` (điểm hội tụ chung của cả 4 tính năng) giờ bọc qua `BackgroundTaskManager.instance.submitAndWait` — dùng CHUNG 1 hàng đợi/cap với chat + tạo chương hàng loạt + xử lý tài liệu; thêm ticker hiện "⏳ Đang chờ — phía trước còn N tác vụ..." khi bị xếp hàng, tái dùng khuôn mẫu đã có ở `chat_screen.dart` |

### Cố tình CHƯA làm — ghi lại để không quên
- **Chưa gắn `requestId` riêng cho từng lệnh generate ở event channel** (token/done hiện chỉ gắn `slot`, không gắn ID lệnh cụ thể — nếu tương lai có 2 lệnh THẬT cùng sống trên CÙNG 1 slot, ví dụ lỗi tương tự lặp lại ở slot 1/dịch thuật hoặc ở 1 tính năng mới chưa qua `BackgroundTaskManager`, vẫn còn nguy cơ cross-talk lý thuyết y hệt sự cố này). Điểm 5 đã vá che được đường THỰC TẾ duy nhất gây ra sự cố hôm nay, nhưng KHÔNG phải vá tận gốc lỗ hổng thiết kế event channel — nếu sau này thêm tính năng mới gọi AI, PHẢI đi qua `BackgroundTaskManager` hoặc `_generateRespectingTranslation` có sẵn, không tự gọi thẳng provider.
- **Chưa build/test thật** — môi trường sửa lỗi không có Flutter/Android SDK, chỉ xác minh được bằng cách đối chiếu số ngoặc `{}`/`()` với bản gốc (cân bằng) và khớp field/hàm DB với model đã có. Bắt buộc chạy `build.yml` (GitHub Actions) hoặc build máy thật trước khi phát hành.
- `DataIntegrityService` chỉ quét theo TỪNG TRUYỆN (gọi từ `ChaptersScreen` của truyện đang mở) — chưa có màn "quét tất cả truyện cùng lúc" nếu người dùng có nhiều truyện đều nghi bị ảnh hưởng.

## U. Gõ Outline tự kích hoạt bão lệnh tóm tắt AI → cross-talk event channel gây báo sai "đã xong" + ký tự rác; bổ sung sửa Nhân vật/Luật thế giới (2026-09-06)

### Triệu chứng
Người dùng báo: bấm "Triển khai thành chương" ở màn "Đắp thịt cốt truyện" — báo đã xong nhưng chưa tạo được gì, nội dung sinh ra là ký tự rác. Log debug mới cho thấy `ensureLoaded` KHÔNG còn nạp đè model bừa bãi nữa (bản vá mục T hoạt động đúng — liên tục log "van dang tien trien... KHONG nap lai"), nhưng vẫn có **~33 lệnh `generateStream()` với prompt tóm tắt GIỐNG HỆT nhau** bắn liên tiếp cách nhau 1-15 giây trong 3 phút, xếp hàng đè lên đúng lúc lệnh "Đắp thịt" thật cần chạy.

### Nguyên nhân gốc — 2 lỗi riêng biệt cộng hưởng
1. **`_onOutlineChanged()` (chapter_editor_screen.dart) — debounce 800ms trên MỌI thay đổi `outlineCtrl`** — khi người dùng gõ outline (đúng màn hình trong ảnh chụp người dùng gửi), mỗi lần dừng gõ ≥800ms tự gọi `_save(silent:true)` → `_updateSummaryAndIndexInBackground()` → `SummaryService().summarizeChapter()` gọi THẲNG provider, **hoàn toàn không qua `BackgroundTaskManager`**, và **không có gì chặn việc gọi CHỒNG lên chính nó**. Gõ 1 outline trong vài phút (nhịp gõ tự nhiên tạo ra nhiều khoảng dừng ≥800ms) → hàng chục lệnh tóm tắt y hệt nhau (nội dung chương chưa đổi, chỉ outline đổi) dồn vào slot 0.
2. **Event channel token/done chỉ gắn `slot`, KHÔNG gắn ID riêng theo lệnh** — đây chính là hạn chế đã ghi rõ ở mục T ("cố tình chưa làm"), nay bị khai thác thật: khi ≥2 `generateStream()` cùng sống trên slot 0 (33 lệnh tóm tắt + 1 lệnh Đắp thịt thật), MỌI listener Dart đang mở đều nhận được TOÀN BỘ token/done phát sinh từ BẤT KỲ lệnh nào trong số đó — 1 lệnh tóm tắt ngắn xong trước gửi `done=true` khiến màn "Đắp thịt" tưởng CHÍNH NÓ đã xong (trong khi chưa nhận token thật nào), và token của các lệnh xen kẽ nhau tạo ra ký tự rác khi vô tình lọt vào cùng 1 buffer.

### Bản vá
| Nguyên nhân | File | Nội dung sửa |
|---|---|---|
| 2 | `MnnBridge.kt` | Đọc `requestId` (Dart tự sinh, Kotlin không cần hiểu ý nghĩa) từ tham số lệnh "generate", ECHO nguyên vẹn vào mọi event `token`/`done` gửi cho Dart |
| 2 | `local_provider.dart` | `generateStream()` tự sinh `requestId` duy nhất mỗi lần gọi, gửi kèm lệnh `generate`; listener lọc thêm theo `requestId` (không chỉ `slot`) — bỏ qua an toàn nếu `requestId` là `null` (tránh biến 1 lỗi đọc tham số nhỏ thành "không nhận được token nào") |
| 1 | `chapter_editor_screen.dart` | `_updateSummaryAndIndexInBackground()`: thêm cờ `_summarizing` (chặn gọi chồng) + `_lastSummarizedContent` (bỏ qua nếu nội dung chương chưa đổi so với lần tóm tắt gần nhất); bọc qua `BackgroundTaskManager.submitAndWait` giống 4 nơi gọi AI khác trong màn này |

Với bản vá điểm 2, sự cố "báo sai đã xong"/"ký tự rác" được chặn TẬN GỐC cho MỌI trường hợp có ≥2 lệnh generate() cùng sống trên 1 slot — không chỉ riêng trường hợp gõ outline hôm nay (bản vá điểm 1 chỉ chặn ĐÚNG nguồn gây ra sự cố LẦN NÀY, không đảm bảo không có nguồn khác tương tự chưa bị phát hiện).

### Việc khác đã làm trong cùng phiên (theo yêu cầu người dùng, không liên quan sự cố trên)
- **Thiếu chức năng sửa Nhân vật/Luật thế giới**: `_addCharacter()`/`_addRule()` (story_bible_screen.dart) trước đây CHỈ tạo mới — bấm vào 1 mục đã có chỉ mở được `_manageFactsSheet` (quản lý dữ kiện rời), không sửa được tên/vai trò/mô tả/phân loại gốc, nhập sai phải xoá tạo lại (mất luôn facts đã gắn). Đổi thành `_addOrEditCharacter({Character? existing})`/`_addOrEditRule({WorldRule? existing})`, `trailing` đổi từ nút Xoá đơn thành `PopupMenuButton` "Sửa"/"Xóa" (đúng khuôn mẫu đã dùng ở `NovelListScreen`, mục S).
- **Sửa lỗi đánh số mục trong chính tài liệu này**: mục 4.16 vừa thêm ở bản vá mục T (2026-09-05) trùng số với 1 mục ĐÃ ĐƯỢC comment trong `database_service.dart` (`_backupTables`) tham chiếu tới từ trước ("mục 4.16/5.77 tài liệu kiến trúc") nhưng CHƯA TỪNG thực sự được viết — comment nói dối chính nó, giống lỗi `recordWordSnapshot()` đã ghi ở mục N. Đã đổi mục của bản vá mục T thành **4.17**, và viết bổ sung **4.16 THẬT** mô tả tính năng "quy trình viết tiểu thuyết" (Dàn ý/Tuyến truyện/Mục tiêu/Quyển) đã có code từ lâu nhưng chưa từng được tài liệu hoá.

### Đã kiểm tra, CHƯA tìm thấy lỗi (cần người dùng xác nhận thêm)
Người dùng nghi ngờ "sao lưu truyện không backup outline của chương". Đã rà: cột `outline TEXT` có trong schema `chapters` (cả bản tạo mới lẫn migration v3→v4), `Chapter.toMap()`/`fromMap()` xử lý đúng, `exportNovelData`/`exportAllData` dùng `d.query('chapters')` (lấy TOÀN BỘ cột, gồm `outline`), `upsertChapter()` ghi qua `c.toMap()` (đầy đủ), `importNovelData`/`importAllData` phục hồi qua `Chapter.fromMap()`. Không tìm thấy đường nào làm rơi `outline` trong code hiện tại — nếu người dùng phục hồi từ 1 file backup XUẤT TỪ TRƯỚC KHI có cột này (trước migration v3→v4), file đó vốn dĩ không hề chứa outline nên không có gì để phục hồi (không phải lỗi code hiện tại). Cần file backup thật hoặc bước tái hiện cụ thể hơn để kết luận chắc chắn.

## V. Máy vẫn ngủ sâu giữa lúc sinh chương (~15 phút) dù WakeLock đã đúng chuẩn — TÁI DIỄN mục F, không phải lỗi mới (2026-09-07)

### Số liệu
`STEADY (ms)=158162, WALL (ms)=1074660, CHENH LECH=916498ms` (~15,3 phút ngủ sâu giữa chừng). Khác mục F: đây là **lệnh generate() ĐẦU TIÊN trong tiến trình vừa khởi động** ("lan nap thu 1") — KHÔNG PHẢI do `pipelineDepth` rò rỉ từ lệnh treo trước đó (nguyên nhân đã sửa ở mục F không áp dụng được ở đây, vì không có lệnh nào chạy trước nó trong tiến trình này). Đã đọc lại `MnnBridge.kt`: `acquireDirectWakeLock()` vẫn được gọi ĐÚNG, VÔ ĐIỀU KIỆN, ĐỒNG BỘ trước `scope.launch` (khớp bản vá mục F) — về mặt code, WakeLock 40 phút (`directWakeLockGrantMs`) THỪA SỨC che phủ 17,9 phút wall-clock của lệnh này.

### Kết luận
Code phía app đã làm ĐÚNG những gì API Android cho phép làm (PARTIAL_WAKE_LOCK giữ đồng bộ + Foreground Service đúng chuẩn). WakeLock chuẩn Android **không phải lúc nào cũng được hãng máy tôn trọng** — đây chính là giới hạn đã ghi nhận từ trước (mục 5, dòng ~402: máy test ASUS ZenUI từng bị chính hãng tự kill app nền bất kể đúng chuẩn hay không), và ĐÃ có sẵn cơ chế xin loại trừ (`local_optimization_screen.dart` → "Tối ưu AI local" → "Loại trừ khỏi tối ưu hoá pin"). Không có thêm gì sửa được ở tầng `MnnBridge.kt`/`GenerationService.kt` cho trường hợp NÀY — nếu người dùng CHƯA bấm nút loại trừ đó, đây gần như chắc chắn là nguyên nhân. Nếu ĐÃ loại trừ mà vẫn xảy ra, nghi vấn chuyển sang lớp quản lý pin RIÊNG của hãng máy (nằm NGOÀI mọi API chuẩn Android, mỗi hãng 1 kiểu cài đặt khác nhau — Xiaomi/MIUI "Tự khởi động" + "Tiết kiệm pin thông minh", Oppo/vivo "Bảo vệ nền", Asus "Power Master"...), cần biết đúng hãng máy mới hướng dẫn được vị trí cài đặt chính xác.

## W. SỬA LẠI mục V — không phải máy ngủ, mà "Cốt truyện đã diễn ra"/tóm tắt chương bị nhiễm rác lan ra MỌI lần "Đắp thịt" (2026-09-07)

### Mục V đã sai — bằng chứng phản bác
Mục V (cùng ngày, trước đó vài giờ) kết luận nguyên nhân là máy ngủ sâu giữa lúc sinh — dựa trên 1 log duy nhất có `CHENH LECH=916498ms`. Người dùng bật battery-optimization-exemption (xác nhận xanh), thử lại: `STEADY=136315ms, WALL=136315ms, khong chenh lech dang ke` — **máy hoàn toàn KHÔNG ngủ** — nhưng **vẫn dừng đúng ở "sinh duoc 60 ky tu" y hệt lần trước**. Đổi hẳn nội dung outline sang 1 outline bình thường — **vẫn y hệt**. Kết luận: máy ngủ ở mục V chỉ là trùng hợp, KHÔNG phải nguyên nhân. Ghi nhận công khai để không ai đọc mục V rồi đi sai hướng.

### Nguyên nhân thật
`looksLikeRepetitionLoop()` (mnn_bridge.cpp) có ngưỡng sàn cứng `accumulated_.size() < 60 → return false` — không thể báo lặp trước 60 ký tự dù model lặp từ ký tự đầu. Cả 2 lần đều dừng ĐÚNG tại mốc sớm nhất có thể → model gần như lặp ngay từ đầu, KHÔNG phải lặp sau 1 đoạn dài. Việc đổi outline không đổi được kết quả → rác không nằm ở outline (phần userPrompt), mà ở phần **systemPrompt CỐ ĐỊNH**.

Rà `StyleService.buildFleshOutPrompt()` → gọi `RagService.buildContext()` → dòng đầu tiên, LUÔN nhúng (không phụ thuộc outline/currentText) là `Novel.plotProgressSummary` ("Cốt truyện đã diễn ra — tóm tắt luỹ kế"). Rà `RagService.updateCumulativeStorySummary()` (hàm duy nhất ghi vào field này) → phát hiện **ĐÚNG lỗ hổng đã vá ở mục T** (`_applyAllPendingRewrites`): chỉ kiểm tra `trimmed.isNotEmpty` trước khi `db.updateNovelProgressSummary(...)`, không kiểm tra `kAiFailureMarker`. Trong cơn bão lệnh tóm tắt do gõ outline gây ra (mục U, TRƯỚC KHI vá `_summarizing`/`requestId`), rất có thể 1 trong các lượt gọi `updateCumulativeStorySummary` (được gọi ở cuối `_updateSummaryAndIndexInBackground`, mỗi lần tóm tắt "thành công") đã nhận về đúng chuỗi cảnh báo `⚠️ [Cần nạp lại model...]` và ghi thẳng vào `plotProgressSummary` — từ đó, **MỌI lần "Đắp thịt"/"Viết tiếp" sau đó đều nhúng rác này vào đầu prompt**, bất kể outline gõ gì — khớp 100% với triệu chứng quan sát được.

`Chapter.autoSummary` (tóm tắt riêng từng chương, dùng làm nguồn ngữ cảnh dự phòng khi không có Timeline/outline ưu tiên hơn — xem `gistOf()`) có **cùng lỗ hổng y hệt** ở `_updateSummaryAndIndexInBackground` (`widget.chapter.autoSummary = summary;` không kiểm tra `kAiFailureMarker`).

**Phát hiện phụ**: comment trong `rag_service.dart` nhắc người dùng "xoá tay ở tab 'Cốt truyện' trong Bách khoa" để sửa field này — tab đó **không tồn tại** trong `story_bible_screen.dart` (8 tab thật: Nhân vật/Luật thế giới/Văn phong/Thuật ngữ/Dàn ý/Tuyến truyện/Mục tiêu/Dòng thời gian). Comment nói dối chính nó — cùng dạng lỗi đã ghi ở mục N và mục U (4.16 trùng số). Chưa xây tab thay thế (xem "chưa làm" bên dưới) — dùng tạm công cụ ở mục 4.17 (nay mở rộng, xem dưới).

### Bản vá
| File | Nội dung sửa |
|---|---|
| `rag_service.dart` (`_doUpdateCumulativeStorySummary`) | Thêm kiểm tra `kAiFailureMarker` + tỉ lệ độ dài trước khi `updateNovelProgressSummary` — phát hiện rác thì GIỮ NGUYÊN bản tóm tắt cũ, không ghi đè |
| `chapter_editor_screen.dart` (`_updateSummaryAndIndexInBackground`) | Thêm kiểm tra `kAiFailureMarker` trước khi gán `chapter.autoSummary` |
| `data_integrity_service.dart` + `data_integrity_screen.dart` (mục 4.17) | Mở rộng quét thêm `Novel.plotProgressSummary` và `Chapter.autoSummary` (không chỉ `Chapter.content` như trước) — 2 nguồn này KHÔNG có lịch sử phiên bản riêng nên cách sửa là XOÁ SẠCH (ép AI tự tóm tắt lại từ đầu), không phải khôi phục bản cũ; xoá `plotProgressSummary` BẮT BUỘC reset kèm `plotProgressSummaryChapter` về null, nếu không các chương trước số đã lưu sẽ bị bỏ sót vĩnh viễn (logic gộp chỉ nhìn về phía trước) |

### Việc cần làm ngay (người dùng)
Mở "Kiểm tra dữ liệu bị lỗi" (icon 🩺 ở danh sách chương) — bản vá này giờ QUÉT ĐƯỢC đúng chỗ nghi ngờ đang chặn toàn bộ tính năng "Đắp thịt" của truyện hiện tại. Nếu thấy mục "Cốt truyện đã diễn ra..." trong danh sách, xử lý mục đó TRƯỚC — nó ảnh hưởng mọi chương, không riêng 1 chương.

### Vẫn CHƯA làm (ghi lại, không quên)
- Chưa xây tab "Cốt truyện" cho phép xem/sửa tay `plotProgressSummary` — comment code đã hứa nhưng chưa hiện thực hoá; hiện chỉ có đường "xoá sạch" qua công cụ quét, không có đường "sửa 1 phần".
- Chưa xác nhận CHẮC CHẮN 100% rác thực sự đã lọt vào `plotProgressSummary` của đúng truyện người dùng đang gặp lỗi (suy luận từ code + trùng khớp triệu chứng, chưa xem được dữ liệu thật) — bước xác nhận cuối cùng là người dùng tự mở công cụ quét ở trên.

## X. Vá thiếu đúng luồng quan trọng nhất: "Tạo hàng loạt qua đêm" — 3 lỗ hổng y hệt mục W nhưng KHÔNG tự động được che bởi bản vá ở màn soạn 1 chương (2026-09-07)

### Vì sao đây là mục nghiêm trọng nhất trong toàn bộ chuỗi sự cố T/U/W
Mục đích chính của app (theo đúng khẳng định của người dùng) là chạy **"Tạo hàng loạt" nhiều chương liên tục, không giám sát (qua đêm)** — `chapter_batch_service.dart`. Bản vá mục W chỉ sửa 2 hàm dùng CHUNG (`RagService._doUpdateCumulativeStorySummary` — tự động che được MỌI nơi gọi, kể cả batch) và 1 hàm CHỈ DÙNG RIÊNG cho màn soạn 1 chương (`chapter_editor_screen.dart _updateSummaryAndIndexInBackground`) — **`chapter_batch_service.dart` có 1 bản SAO RIÊNG của logic tương tự, không tự động thừa hưởng bản vá ở màn soạn tay**. Rà lại phát hiện đúng 3 chỗ:

1. **`looksCorrupted` (2 nơi — nhánh sequential VÀ nhánh parallel/remote)**: chỉ so `resultTrimmed.length < outline.length * 0.5` — KHÔNG kiểm tra `kAiFailureMarker`. Nếu outline đủ dài, chuỗi cảnh báo lỗi nội bộ (~180 ký tự) không bị coi là "quá ngắn", **lọt qua trót lọt và bị ghi thẳng vào chương** trong lúc chạy qua đêm không ai giám sát — hậu quả nặng hơn hẳn so với soạn tay (không ai nhận ra ngay để dừng).
2. **`_finalizeChapterMemory` → `chapter.autoSummary = summary;`**: không kiểm tra gì cả trước khi ghi — bản sao riêng của đúng lỗi đã vá ở `chapter_editor_screen.dart`.

### Bản vá
Thêm `resultTrimmed.contains(kAiFailureMarker)` vào `looksCorrupted` ở CẢ 2 nhánh (sequential + parallel); thêm kiểm tra `kAiFailureMarker`/rỗng trước `chapter.autoSummary = summary` trong `_finalizeChapterMemory`. `rag.updateCumulativeStorySummary()` gọi từ đây ĐÃ được che sẵn nhờ vá ở tầng dùng chung (mục W) — không cần sửa thêm.

### Đã rà soát để không tái diễn kiểu "vá 1 nơi, quên nơi dùng chung logic khác"
Grep toàn bộ project mọi nơi thực sự ghi `chapter.autoSummary =` hoặc gọi `db.updateNovelProgressSummary(` — xác nhận ĐÚNG 3 nơi (rag_service.dart, chapter_batch_service.dart, chapter_editor_screen.dart), cả 3 đã có kiểm tra sau đợt vá này. Bài học ghi lại: **mỗi khi vá 1 lỗ hổng "ghi rác không kiểm tra", phải grep toàn project tìm MỌI nơi ghi cùng 1 field, không chỉ vá đúng nơi vừa phát hiện triệu chứng** — nơi phát hiện ra triệu chứng chưa chắc là nơi duy nhất có lỗ hổng.

## Y. Chuyển từ "bắt tự kiểm tra/dọn tay" sang TỰ ĐỘNG bỏ qua rác khi đọc — theo đúng phản hồi người dùng (2026-09-07)

### Vấn đề với hướng tiếp cận cũ (mục 4.17/T/W/X)
Toàn bộ hướng xử lý trước đó (`DataIntegrityService`) chỉ CHẶN GHI rác mới + cho phép người dùng CHỦ ĐỘNG mở 1 màn hình quét rồi bấm dọn rác cũ. Người dùng phản hồi thẳng: dù không còn phải tự mò tìm bằng mắt (đã cải thiện so với bản đầu), vẫn đang bị bắt tự làm 1 việc thủ công (mở màn hình, bấm nút) TRƯỚC KHI dùng tiếp được — với người chỉ muốn bấm "Đắp thịt"/chạy batch mà không cần biết gì về khái niệm "dữ liệu bị lỗi", đây vẫn là gánh nặng không công bằng đặt lên người dùng cho lỗi do app gây ra.

### Hướng sửa đúng: tự động bỏ qua rác NGAY LÚC ĐỌC, không chờ ai dọn
Thay vì chỉ chặn ghi (mục W/X) rồi yêu cầu dọn tay dữ liệu ĐÃ lỡ ghi trước đó, `RagService` giờ tự động COI RÁC NHƯ KHÔNG TỒN TẠI ở mọi nơi ĐỌC `autoSummary`/`plotProgressSummary` để dùng làm ngữ cảnh:
- Thêm `_safeSummaryOrExcerpt(Chapter c)` — dùng chung cho `indexChapter()`, "Chương liên quan (truy xuất ngữ nghĩa)", "Tóm tắt các chương gần nhất", và `gistOf()` trong `updateCumulativeStorySummary` — nếu `autoSummary` dính `kAiFailureMarker`, tự động fallback về trích đoạn nội dung thật (`_excerpt(c.content)`), y hệt như chưa từng có `autoSummary`.
- `buildContext()`: đọc `novel.plotProgressSummary` — nếu dính rác, tự động BỎ QUA HẲN mục "Cốt truyện đã diễn ra" (không nhúng gì), thay vì nhúng rác vào mọi prompt sinh chương như trước.
- `_doUpdateCumulativeStorySummary()`: bản tóm tắt cũ dùng làm nền cho lần tự cập nhật KẾ TIẾP cũng tự động bỏ qua nếu dính rác, tránh đưa rác vào chính prompt đang cố tạo ra bản tóm tắt MỚI sạch.

**Quan trọng — cố tình KHÔNG tự xoá trong DB ở các hàm ĐỌC này**: chỉ bỏ qua khi dùng, giữ nguyên dữ liệu gốc trong DB. Lý do: (1) hàm đọc không nên kiêm luôn việc ghi/xoá dữ liệu — tách biệt trách nhiệm rõ ràng; (2) nếu rác chỉ dính 1 đoạn nhỏ lẫn trong 1 bản tóm tắt dài phần lớn vẫn dùng được, tự động xoá SẠCH ngay lúc đọc (thay vì chỉ bỏ qua) sẽ làm mất luôn phần còn dùng được đó mỗi lần đọc — trong khi CHỈ BỎ QUA khi dùng làm ngữ cảnh không mất gì, và công cụ quét ở mục 4.17 vẫn còn nguyên cho ai MUỐN dọn sạch hẳn (dùng cho gọn dữ liệu về lâu dài, không còn là điều kiện bắt buộc phải làm trước khi dùng tiếp).

### Kết quả
Người dùng không cần mở màn hình nào, không cần bấm nút nào — lần "Đắp thịt"/"Tạo hàng loạt" TIẾP THEO sẽ tự động không còn nhúng "Cốt truyện đã diễn ra" bị nhiễm rác (nếu đúng đây là nguyên nhân của sự cố mục W) mà không cần bất kỳ thao tác thủ công nào trước đó.


## Z. "Không thể tạo chương truyện" — lệnh tóm tắt nền rơi vào lặp vô tận 40 phút, chiếm slot model LOCAL, chặn đứng "Đắp thịt"/"Viết tiếp" thật (2026-09-08)

### Triệu chứng
Người dùng báo: không tạo được chương. Đối chiếu debug log (`debug_log.txt` +
`native_debug.txt`, 2026-09-08): sau khi model nạp thành công (backend
OpenCL, đúng đường mặc định `backendPreference=0`, xem mục 2.2/5.53), có
đúng 2 lệnh `generateStream()`:
1. 11:02:38 — prompt "xin chào" (8 ký tự), sinh 7 token trong ~148s, có
   nghi vấn ngủ sâu ngắn (~59s, cùng cơ chế đo STEADY/WALL đã ghi ở mục
   E/F/V) — không phải nguyên nhân chính, chỉ là 1 khoảng trễ nhỏ.
2. 11:05:23 — prompt hệ thống khớp **NGUYÊN VĂN** với
   `SummaryService.summarizeChapter()`
   ("Bạn là biên tập viên tóm tắt tiểu thuyết. Chỉ trả lời bằng đoạn tóm
   tắt, không thêm lời dẫn hay tiêu đề.") — xác nhận chắc chắn đây là lệnh
   tóm tắt chương chạy NỀN (kích hoạt qua `_save()` →
   `_updateSummaryAndIndexInBackground()`, xem mục 4.16/`chapter_editor_screen.dart`),
   KHÔNG phải lệnh "Đắp thịt"/"Viết tiếp" người dùng bấm trực tiếp. Lệnh
   này treo tới 11:45:55 (~40,5 phút) mới bị chính tầng Dart
   (`local_provider.dart`) tự phát hiện "LẶP VÔ TẬN" sau 329 ký tự và gọi
   `cancelGenerate()`. **Tầng native (`mnn_bridge.cpp`) không hề bắt được
   trong suốt 40 phút đó** — không có dòng `[CHAN DOAN LAP VO TAN]` nào
   trong native log.

### Nguyên nhân gốc — 3 lỗ hổng cộng hưởng, đã xác nhận bằng code

1. **`looksLikeRepetitionLoop()` (`mnn_bridge.cpp`) so khớp lặp theo BYTE
   thô của UTF-8, không phải theo KÝ TỰ** — 2 mẫu lỗi gốc dùng để thiết kế
   thuật toán này ("((((("/"8888888") đều là ASCII 1-byte/ký tự, nhưng
   app viết tiếng Việt có dấu, đa số ký tự chiếm 2-3 byte/ký tự. Hệ quả:
   (a) model lặp đúng 1 ký tự tiếng Việt duy nhất → không byte nào trong
   2-3 byte cấu thành ký tự đó chiếm nổi 85% → điều kiện "1 ký tự áp đảo"
   không bao giờ khớp; (b) model lặp 1 cụm ngắn 2-6 KÝ TỰ tiếng Việt → quy
   ra byte dễ vượt quá trần "period ≤ 6 byte" → điều kiện "cụm lặp khít"
   cũng không khớp. Tầng native — vốn phải là lớp phản ứng NHANH NHẤT
   (chạy ngay trong `xsputn`, mỗi token, ném exception tức thời) — gần
   như vô hiệu với đúng loại lặp phổ biến nhất của app này.
2. **Chỉ còn tầng Dart (`local_provider.dart`) làm việc** — thuật toán
   phía Dart so khớp theo `String` (UTF-16), với ký tự tiếng Việt dựng
   sẵn (precomposed) thông thường thì 1 code unit = đúng 1 ký tự, nên
   KHÔNG dính lỗi byte-vs-ký-tự ở trên — nhưng phải đợi vòng
   JNI → Kotlin → EventChannel → Dart, cộng cửa sổ tích luỹ riêng (≥60 ký
   tự), cộng tốc độ sinh chữ vốn đã rất chậm trên máy test (mục F/G/H) —
   329 ký tự "rác" mất tới 40 phút thời gian thực mới tích luỹ đủ để kết
   luận.
3. **`TranslationService.generateWithOptionalTranslation()`, nhánh dịch
   thuật TẮT (mặc định) + không có `onChunk`** (đúng nhánh
   `SummaryService`/`RagService.updateCumulativeStorySummary` dùng) gọi
   thẳng `mainProvider.generate()` (đợi cả khối) — **hoàn toàn bỏ qua**
   tham số `isCancelled` dù hàm đã khai báo sẵn, vì `generate()` không có
   điểm dừng giữa chừng nào để kiểm tra. 2 nơi gọi nhánh này không có bất
   kỳ cách nào tự thoát sớm.

Chuỗi nhân quả: `_save()` (gõ outline/lưu chương) kích hoạt lệnh tóm tắt
nền → model suy biến thành lặp ở nhiệt độ thấp (`temperature: 0.3`,
`repetitionPenalty` mặc định dùng chung 1.05 — thấp so với mức cần để bù
cho nhiệt độ thấp) → lỗ hổng 1 khiến tầng native không cắt được ngay →
lỗ hổng 3 khiến lệnh này không có đường thoát sớm nào khác ngoài chờ lỗ
hổng 2 (tầng Dart, chậm) → suốt 40 phút đó, lệnh tóm tắt vẫn đang
"running" trong `BackgroundTaskManager` (cap=1 cho model LOCAL, mục
5.67 — cố tình giữ nguyên để tránh crash heap corruption 2 lệnh
`generate()` chồng lên nhau) → **bất kỳ lệnh "Đắp thịt"/"Viết tiếp" nào
người dùng bấm trong 40 phút đó chỉ xếp hàng chờ** (`aiStage` hiện "⏳
Đang chờ — phía trước còn 1 tác vụ AI khác...", xem
`_generateRespectingTranslation`), không hề chạm được tới native — đúng
triệu chứng "không thể tạo chương truyện" đã báo.

### Bản vá

| Lỗ hổng | File | Nội dung sửa |
|---|---|---|
| 1 | `mnn_bridge.cpp` (`JniStreamingBuf::looksLikeRepetitionLoop`) | Thêm `splitUtf8Units()` — tách chuỗi UTF-8 thành từng KÝ TỰ thật (gộp byte tiếp diễn) trước khi so khớp; áp dụng lại NGUYÊN 2 tiêu chí cũ (1 đơn vị >85%, cụm 2-6 đơn vị lặp khít) trên dãy ký tự thay vì dãy byte. Không đổi hành vi với 2 mẫu ASCII gốc ("((((("/"8888888" — mỗi ký tự vẫn đúng 1 byte = 1 đơn vị) |
| 3 | `translation_service.dart` (`generateWithOptionalTranslation`, nhánh dịch thuật tắt) | Bỏ nhánh gọi thẳng `mainProvider.generate()`; LUÔN đi qua `generateStream()` + kiểm tra `isCancelled` mỗi token (dùng `onChunk?.call(...)` null-safe) — hành vi KHÔNG đổi với nơi gọi chưa truyền `isCancelled` (mặc định null) |
| — | `summary_service.dart` (`summarizeChapter`) | Tăng `repetitionPenalty` riêng cho tác vụ này lên `1.2` (không đụng cài đặt người dùng); thêm `isCancelled: () => stopwatch.elapsed > Duration(minutes: 3)` |
| — (cùng lỗ hổng, chưa xác nhận có dính đúng sự cố hôm nay hay không — vá theo bài học mục X) | `rag_service.dart` (`_doUpdateCumulativeStorySummary`) | Thêm `isCancelled: () => stopwatch.elapsed > Duration(minutes: 4)` (trần rộng hơn vì `maxTokens: 900` so với 300) |

**Cố tình KHÔNG đụng tới**: mọi lệnh `generateStream()`/`generate()` mà
người dùng TRỰC TIẾP đang xem chạy (chat, "Đắp thịt"/"Viết tiếp"/"Kiểm
tra nhất quán"/"Tạo lại tất cả ghi chú", "Tạo chương hàng loạt qua đêm")
— các nơi này KHÔNG truyền `isCancelled` thời gian, giữ nguyên không giới
hạn thời gian đúng quyết định đã thống nhất ở mục H. Bản vá lỗ hổng 3 chỉ
mở khả năng dùng `isCancelled`, không tự áp đặt nó cho ai chưa chủ động
truyền vào.

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa build/test thật** (đúng thông lệ đã ghi ở mục T/mọi mục khác —
  môi trường sửa lỗi không có Flutter/Android SDK). Đã tự kiểm tra cân
  bằng ngoặc `{}/()/[]` cho cả 2 file Dart lẫn file C++ (có xử lý riêng
  raw string `R"(...)"`/comment khối của C++), nhưng đây KHÔNG thay thế
  được việc chạy `build.yml` (GitHub Actions) thật trước khi phát hành.
- Nhánh dịch thuật trung gian BẬT của `generateWithOptionalTranslation()`
  (khi người dùng bật tính năng mục 4.8) không nằm trong phạm vi bản vá
  lỗ hổng 3 — nhánh đó vốn đã dùng `generateStream()` + `isCancelled` từ
  trước (không dính lỗ hổng 3), nhưng 2 bước `translate()` (dịch
  prompt/dịch kết quả, dùng model dịch nhỏ ở slot 1) trong CÙNG hàm vẫn
  chưa có `isCancelled` — chưa xác nhận model dịch nhỏ có cùng rủi ro lặp
  vô tận hay không, chưa vá.
- Ngưỡng "3 phút"/"4 phút" cho `isCancelled` là số ước lượng hợp lý dựa
  trên `maxTokens` (300/900) và tốc độ chậm nhất đã đo (mục F/G/H), CHƯA
  đo thật trên máy — nếu model/máy chậm hơn mức đã biết, 1 lượt tóm tắt
  BÌNH THƯỜNG (không lặp) có thể bị cắt oan; cần người dùng xác nhận qua
  build thật, chỉnh `Duration` nếu cần.
- Bản vá lỗ hổng 1 (native) tăng khả năng bắt lặp cho VIỆT NGỮ nói chung
  (áp dụng cho MỌI lệnh generate, không riêng tóm tắt) — đây là lớp phòng
  vệ NHANH quan trọng nhất trong 3 lớp, vì nó giúp cả lệnh "Đắp thịt"
  người dùng đang trực tiếp xem cũng được cắt gần như tức thời nếu lặp,
  thay vì phải đợi tầng Dart chậm hơn — nhưng vẫn CHƯA đo lại bằng số
  liệu thật (cần lặp lại đúng kịch bản gây lặp, xem log có xuất hiện dòng
  `[CHAN DOAN LAP VO TAN]` ở tầng native hay không, và đo thời gian từ
  lúc bắt đầu lặp tới lúc bị cắt — kỳ vọng còn vài giây thay vì vài chục
  phút).
- **Không sửa nguyên nhân khiến model rơi vào lặp lúc đầu** — tăng
  `repetitionPenalty` lên 1.2 chỉ giảm khả năng xảy ra, không loại trừ
  hẳn; đổi model hoặc tinh chỉnh sampler sâu hơn (vd bật lại `n_gram`/
  `ngram_factor`/`penalty_window` — hiện chỉ đặt 1 LẦN qua `config.json`
  lúc nạp model, KHÔNG nằm trong 5 khoá JSON gửi lại mỗi lần `generate()`,
  xem mục 4.7) nằm ngoài phạm vi bản vá này.

### Phát hiện phụ — cảnh báo QNN trong native log, KHÔNG phải nguyên nhân sự cố trên
`native_debug.txt` cùng phiên cho thấy cả 4 file `.so` QNN thật
(`libQnnSystem`/`libQnnHtp`/`libQnnHtpPrepare`/`libQnnHtpV68Stub`) đều
`dlopen` thất bại ("not found"), và `libQnnHtpV68Skel.so` được xác nhận
KHÔNG tồn tại trong thư mục `lib/arm64` của APK — đúng như comment trong
chính native log yêu cầu kiểm tra lại bước copy ở `build.yml`. Đối chiếu
`build.yml` (`HEXAGON_ARCH=68`, đúng khớp Hexagon 780/v68 của máy test,
mục 1): bước "Đặt file .so vào đúng chỗ Android tự nhận" CÓ cố gắng `cp`
đủ 5 file QNN vào `jniLibs/arm64-v8a`, có in cảnh báo "THIẾU ..." (không
làm fail cả workflow) nếu `cp` lỗi — nghĩa là nếu file thật sự thiếu
trong APK đã cài, nhiều khả năng đúng các dòng "THIẾU ..." đã in ra trong
log GitHub Actions của lần build tạo ra APK này (cần người dùng tự mở lại
log build đó, bước "Đặt file .so vào đúng chỗ Android tự nhận", để xác
nhận file nào thiếu — chưa có log build đó ở đây để xác nhận chắc chắn
tại sao `cp` lỗi, ví dụ SDK QNN đổi cấu trúc thư mục giữa các phiên bản).
**Không liên quan tới sự cố "không thể tạo chương truyện"** — log xác
nhận `backendPreference=0` (đường mặc định) đã nạp thành công thẳng qua
OpenCL (`success: true, backend: opencl`), đúng thiết kế mục 2.2/5.53 (QNN
giờ chỉ là thử nghiệm CÓ THỂ BẬT THỦ CÔNG qua `backendPreference=3`,
không nằm trên đường mặc định) — dù build.yml có thiếu file QNN, người
dùng KHÔNG bị ảnh hưởng trừ khi chủ động bật thử nghiệm NPU đó.


## AA. Vá mục Z chưa đủ — "Viết tiếp"/"Đắp thịt" ghi thẳng cảnh báo lỗi (kAiFailureMarker) vào chương như văn xuôi thật (2026-09-09)

### Triệu chứng
Người dùng báo tiếp tục không tạo được chương SAU KHI đã áp dụng bản vá
mục Z. Đối chiếu debug log 2026-09-09: prompt hệ thống khớp
`StyleService().buildFleshOutPrompt()` ("Bạn là người viết tiểu thuyết
dài kỳ, nhận một outline sơ sài...") — đây LÀ lệnh "Đắp thịt" thật, không
phải tóm tắt nền như sự cố mục Z.

**Tin tốt, xác nhận bản vá mục Z hoạt động đúng**: log native lần này CÓ
dòng `[CHAN DOAN LAP VO TAN]` — tầng native bắt được lặp ngay khi vừa đủ
60 ký tự (mức sàn tối thiểu của thuật toán), tốn ~2 phút 20s (do máy vẫn
chậm — không phải lỗi phát hiện), thay vì phải đợi 40 phút như mục Z. Cải
thiện đúng như kỳ vọng khi vá lỗ hổng byte-vs-ký-tự.

**Nhưng chương vẫn không tạo được, vì lý do KHÁC hẳn**: khi native ném
`GenerationStoppedException` (nhánh lặp vô tận), code CÓ SẴN từ trước (2
comment "ĐÃ THÊM 2026-08-27") gửi thêm 1 chuỗi cảnh báo qua `onToken`:
`"\n\n⚠️ [Đã dừng: phát hiện lặp vô tận ở tầng gốc (native)...]"` — tức
kết quả cuối cùng KHÔNG rỗng, KHÔNG phải lỗi/exception ở tầng Dart (return
bình thường), mà là **~60 ký tự rác + nguyên văn cảnh báo này**.

`ai_provider.dart` đã định nghĩa sẵn `kAiFailureMarker = '⚠️ ['` chính để
nhận diện đúng loại kết quả này, và **đã được dùng đúng** ở 2 nơi từ
2026-09-05: "Tạo lại tất cả ghi chú" (`chapter_editor_screen.dart`, nhánh
`_processAllPendingRewrites`) và `ChapterBatchService` (cả bước viết
chương lẫn bước tóm tắt). NHƯNG **`_continueWithAI()` ("Viết tiếp") và
`_fleshOutOutline()` ("Đắp thịt") — 2 nút người dùng bấm nhiều nhất —
CHƯA TỪNG được vá cùng kiểu**: kết quả trả về được `setState()` ghi
THẲNG vào `contentCtrl.text` không qua bất kỳ kiểm tra nào. Vì cả 2 hàm
đều dùng `onChunk` để hiện chữ dần lên UI (giống chat), người dùng còn
tận mắt thấy cảnh báo lỗi được "gõ" dần vào đúng vị trí lẽ ra là chương
mới.

### Nguyên nhân gốc
Bản vá mục Z (2026-09-08) chỉ xử lý việc **BẮT lặp sớm hơn / không treo
máy** — chưa từng đụng tới bước **XỬ LÝ kết quả sau khi bị bắt** ở 2 điểm
vào chính của UI. 2 lớp bảo vệ độc lập, không lớp nào thay được lớp kia:
- Mục Z: tầng native/Dart — ngăn treo máy hàng chục phút.
- Mục AA (mục này): tầng UI — ngăn văn bản rác/cảnh báo bị ghi vào chương
  như thể là văn xuôi thật.

### Bản vá
`lib/screens/chapter_editor_screen.dart`: thêm kiểm tra
`cleaned.contains(kAiFailureMarker)` (rập khuôn đúng logic đã có ở
`_processAllPendingRewrites`/`ChapterBatchService`) vào CẢ `_continueWithAI()`
và `_fleshOutOutline()`, ngay sau khi `_generateRespectingTranslation()`
trả về:
- Nếu dính → lùi `contentCtrl.text` về lại `baseText` gốc (xoá phần rác
  vừa hiện dần lên qua `onChunk`), hiện SnackBar giải thích + gợi ý bấm
  lại (model tự nạp lại nhờ `needsFullReload`/`ensureLoaded()` đã có sẵn
  từ trước — xem `local_provider.dart` dòng ~207-274), KHÔNG ghi gì vào
  chương.
- Nếu không dính → giữ hành vi cũ, ghi `cleaned` (đã `trim()`) vào
  `contentCtrl.text`.

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa build/test thật** — chỉ tự kiểm tra cân bằng ngoặc.
- `_checkConsistency()` (nút "Kiểm tra nhất quán") CHƯA được vá cùng kiểu
  — nếu dính `kAiFailureMarker`, người dùng sẽ thấy cảnh báo đó hiện ra
  như 1 "cảnh báo tính nhất quán" (gây hiểu lầm nhẹ), nhưng KHÔNG ghi
  rác vào nội dung chương (chỉ set `consistencyWarning`, không đụng
  `contentCtrl.text`) — mức độ nghiêm trọng thấp hơn hẳn, tạm chưa vá.
- `chat_screen.dart` cũng chưa vá — nhưng ở đó cảnh báo hiện ra như 1 tin
  nhắn chat (tự giải thích được, không lẫn vào "tác phẩm"), mức độ
  nghiêm trọng thấp hơn hẳn so với việc lẫn vào văn xuôi 1 chương truyện
  — tạm chưa vá.
- **Phát hiện phụ, có thể là 1 phần nguyên nhân khiến model dễ lặp ở
  đúng truyện này**: log lệnh "Đắp thịt" cho thấy `repetition_penalty`
  gửi xuống native là **1.05** — trong khi `settings_service.dart` đã
  nâng mặc định lên **1.15** từ trước (comment tại đó: "mặc định cũ 1.05
  quá thấp — log thật cho thấy model rơi vào lặp vô tận"). Mặc định mới
  1.15 CHỈ áp dụng khi cột `genRepetitionPenalty` của truyện là NULL —
  truyện đang dùng để test rất có thể đã được tạo/lưu cấu hình TỪ TRƯỚC
  khi mặc định đổi, nên vẫn giữ giá trị CŨ 1.05 trong DB. Chưa vá (không
  tự động ghi đè giá trị người dùng đã lưu — có thể là họ tự chọn 1.05
  có chủ đích); gợi ý người dùng tự kiểm tra/tăng "Phạt lặp từ" trong
  "Cài đặt sinh văn bản" (`GenerationSettingsScreen`) riêng cho truyện
  này ngay bây giờ, không cần chờ build lại app.


## AB. Rà soát TOÀN BỘ codebase 1 lần cho hết lỗ hổng "kết quả AI ghi thẳng không kiểm tra `kAiFailureMarker`" (2026-09-09, chủ động — không đợi log mới)

### Vì sao làm mục này
Sau mục Z (native/timeout) và mục AA (2 nút "Viết tiếp"/"Đắp thịt"),
người dùng đúng lý khi hỏi "cứ 1 lỗi mà lặp lại chưa xong" — 3 lần vá
liên tiếp đều đúng-nhưng-không-đủ vì mỗi lần chỉ vá ĐÚNG nơi lộ triệu
chứng qua log, không grep hết toàn bộ project cùng lúc (dù mục X đã tự
ghi rõ bài học này từ 2026-09-07). Mục này liệt kê **TOÀN BỘ** nơi trong
codebase nhận kết quả `generate()`/`generateStream()`/
`generateWithOptionalTranslation()` rồi lưu vào đâu đó lâu dài, kiểm tra
từng nơi 1 lượt, không chờ log mới báo tiếp.

### Đã rà — danh sách đầy đủ mọi nơi gọi generate (12 nơi)

| # | Nơi gọi | Ghi vào đâu | Trạng thái TRƯỚC rà soát này |
|---|---|---|---|
| 1 | `chapter_editor_screen.dart` `_continueWithAI()` | `contentCtrl.text` (chương) | Đã vá mục AA |
| 2 | `chapter_editor_screen.dart` `_fleshOutOutline()` | `contentCtrl.text` (chương) | Đã vá mục AA |
| 3 | `chapter_editor_screen.dart` `_checkConsistency()` | `consistencyWarning` (không phải nội dung chương) | Chưa vá — mức nhẹ, đã ghi rõ ở mục AA |
| 4 | `chapter_editor_screen.dart` `_processAllPendingRewrites()` | đoạn văn bị bôi đen | Đã có từ 2026-09-05 |
| 5 | `chapter_editor_screen.dart` `_updateSummaryAndIndexInBackground()` | `chapter.autoSummary` | Đã có từ 2026-09-07 |
| 6 | `chapter_batch_service.dart` bước viết chương | `chapter.content` | Đã có (dòng ~178/336) |
| 7 | `chapter_batch_service.dart` `_finalizeChapterMemory()` | `chapter.autoSummary` | Đã có từ 2026-09-07 |
| 8 | `rag_service.dart` `_doUpdateCumulativeStorySummary()` | `novel.plotProgressSummary` | Đã có từ 2026-09-07 |
| 9 | `document_service.dart` xử lý tuần tự (LOCAL) | `chunk.resultText` | **THIẾU — đã vá mục này** |
| 10 | `document_service.dart` xử lý song song (REMOTE) | `chunk.resultText` | **THIẾU — đã vá mục này** |
| 11 | `story_bible_screen.dart` "Học văn phong từ mẫu" | `StyleProfile.profileDescription` | **THIẾU — đã vá mục này (nghiêm trọng nhất, xem dưới)** |
| 12 | `story_bible_screen.dart` "Gợi ý điểm nút cốt truyện" | `PlotBeat` (nhiều dòng) | Lọc theo `"|"` vô tình loại được `kAiFailureMarker`, nhưng KHÔNG loại được 1 dòng hợp lệ bị lặp — **đã thêm chặn sớm mục này** |
| 13 | `story_bible_screen.dart` "Gợi ý sự kiện mốc thời gian" | `TimelineEvent` (qua hộp thoại xác nhận) | Có hộp thoại xác nhận (người dùng tự bỏ chọn được) nên mức nhẹ hơn, nhưng **đã thêm chặn sớm mục này** cho gọn, đỡ gây hiểu lầm |
| — | `chat_screen.dart` | tin nhắn chat (không phải "tác phẩm") | Chưa vá — mức nhẹ nhất, cảnh báo tự giải thích được khi hiện ra như 1 tin nhắn |
| — | `benchmark_service.dart` | không lưu gì, chỉ đo tốc độ | Không cần vá — không có nơi lưu |
| — | `StyleService.fleshOutOutline()` (method riêng, KHÁC `_fleshOutOutline()` của màn soạn chương) | — | **Xác nhận: KHÔNG còn nơi nào gọi hàm này (dead code)** — `chapter_batch_service.dart` từng gọi, đã đổi sang logic khác (comment "ĐÃ SỬA: trước dùng StyleService.fleshOutOutline()..." tự xác nhận). Không xoá (tránh rủi ro không cần thiết khi chưa build/test thật), chỉ ghi nhận ở đây để không ai nhầm đây là đường sống. |

### Vì sao #11 (học văn phong) nghiêm trọng nhất trong các lỗ hổng MỚI tìm được hôm nay
`StyleProfile.profileDescription` bị `StyleService.buildFleshOutPrompt()`
nhúng vào system prompt của **MỌI LẦN "Đắp thịt" sau này** có chọn đúng
văn phong đó ("Viết đúng theo văn phong sau: $styleDescription") — trước
khi vá, 1 lần lặp vô tận lúc "học văn phong" sẽ lưu thẳng
`"⚠️ [Đã dừng: ...]"` làm `profileDescription` vĩnh viễn, âm thầm làm
hỏng MỌI chương viết sau đó dùng văn phong này — **cùng mức nghiêm
trọng** với lỗ hổng `plotProgressSummary` đã vá ở mục Y/rag_service.dart,
chỉ là chưa từng bị phát hiện qua log vì tính năng này ít được dùng hơn
"Đắp thịt"/"Viết tiếp".

### Bản vá
- `document_service.dart` (2 nơi, tuần tự lẫn song song): thêm
  `resultTrimmed.contains(kAiFailureMarker)` vào điều kiện `looksCorrupted`
  — trước đây CHỈ dựa vào tỉ lệ độ dài kết quả/nguồn (< 15%), không đáng
  tin cho riêng hành động "Tóm tắt" (kết quả ngắn hơn nguồn là ĐÚNG bản
  chất tóm tắt, không phải dấu hiệu lỗi).
- `story_bible_screen.dart` "Học văn phong": thêm kiểm tra
  `kAiFailureMarker`/rỗng trước `db.upsertStyleProfile(...)`, báo SnackBar
  rõ ràng thay vì lưu rác. Cần thêm `import '../services/ai_provider.dart';`
  (trước đây file này chưa import trực tiếp, chỉ có qua
  `translation_service.dart` — KHÔNG tự động lộ `kAiFailureMarker` ra vì
  Dart không tự re-export qua `import` thường).
- `story_bible_screen.dart` "Gợi ý điểm nút"/"Gợi ý sự kiện mốc": thêm
  chặn sớm `raw.contains(kAiFailureMarker)` ngay sau khi nhận kết quả,
  báo lỗi rõ thay vì để lọt vào danh sách gợi ý.

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa build/test thật** — chỉ tự kiểm tra cân bằng ngoặc từng file.
- `_checkConsistency()` và `chat_screen.dart` CỐ TÌNH chưa vá (đã đánh giá
  mức độ nghiêm trọng thấp hơn hẳn, giải thích ở bảng trên) — không phải
  bỏ sót, là quyết định có cân nhắc, ghi rõ ra đây để không ai tưởng nhầm
  đây là lỗ hổng còn sót chưa biết.
- Đây là lần rà soát THEO ĐÚNG NHỮNG GÌ CODE ĐANG GỌI TỚI AI PROVIDER —
  không phải rà theo mọi khả năng lý thuyết. Nếu sau này thêm tính năng
  sinh văn bản MỚI (không có trong bảng 12 nơi trên), tính năng đó cần tự
  áp dụng đúng mẫu `kAiFailureMarker` này, không tự động thừa hưởng.


## AC. NGUYÊN NHÂN GỐC THẬT của việc "1.05" cứ tái diễn — không phải ở tầng sinh chương, mà ở `story_models.dart` + thiếu 1 migration DB (2026-09-10, sau khi người dùng yêu cầu đọc lại đúng lịch sử phiên 13-15)

### Vì sao mục này tồn tại
Log 2026-09-10 cho thấy CÙNG kịch bản mục AA (native bắt lặp đúng ở "Đắp
thịt", lần này không có nghi vấn ngủ sâu — "khong chenh lech dang ke" —
nên bản vá mục AA (kiểm tra `kAiFailureMarker` trước khi ghi vào chương)
CHẮC CHẮN đã chặn được việc ghi rác vào chương). Nhưng người dùng đúng khi
chỉ ra: đây KHÔNG PHẢI lần đầu — đọc lại lịch sử ở "## 7. Việc cần làm
ngay khi bắt đầu phiên mới" (phiên 13-15, 2026-08-23 → 2026-08-25) cho
thấy **CHÍNH XÁC bug này đã xảy ra ở khung CHAT trước đây**, và
`repetitionPenalty` mặc định 1.05 → 1.15 đã được "sửa" từ phiên 13 —
nhưng log phiên 14 (2026-08-25) VẪN thấy 1.05, và giờ log 2026-09-10 (hơn
2 tuần sau) **VẪN THẤY ĐÚNG 1.05**. 3 lần độc lập cùng 1 giá trị không
đổi, dù code "đã sửa" — nghĩa là bản sửa đó chưa từng thật sự có hiệu lực,
ở BẤT KỲ novel nào, không chỉ riêng novel cũ.

### Nguyên nhân thật (xác nhận bằng code, truy hết chuỗi gọi)
Bản sửa phiên 13 chỉ đổi ĐÚNG 1 chỗ:
`settings_service.dart` → `loadGenerationConfig()`:
`repetitionPenalty: novel?.genRepetitionPenalty ?? 1.15`.

Nhưng đây là **dead code, không bao giờ thật sự chạy tới `?? 1.15`**:
`novel?.genRepetitionPenalty` có kiểu `double?` chỉ vì `novel` (biến kiểu
`Novel?`) có thể null (novel không tồn tại) — **KHÔNG PHẢI** vì cột
`gen_repetition_penalty` trong DB có thể null. Field `genRepetitionPenalty`
trên class `Novel` là `double` (non-nullable) — `Novel.fromMap()` (đọc từ
DB) VÀ constructor mặc định (tạo novel mới) đều tự quy đổi mọi trường hợp
null/thiếu thành 1 con số double CỤ THỂ **TRƯỚC KHI** `settings_service.dart`
kịp thấy — và cả 2 nơi đó (constructor mặc định dòng 150, `fromMap()` dòng
238 — TRƯỚC khi vá mục này) đều còn hardcode **1.05**, chưa từng được đồng
bộ theo bản "nâng mặc định lên 1.15" ở phiên 13. Hệ quả: `novel?.genRepetitionPenalty`
KHÔNG BAO GIỜ null (miễn `novel` tồn tại) → `?? 1.15` ở
`settings_service.dart` vĩnh viễn không chạy tới, cho MỌI novel — cũ hay
MỚI TẠO SAU NÀY đều vẫn nhận 1.05 nguyên vẹn.

Thêm 1 lớp khiến novel CŨ chắc chắn kẹt 1.05: `_migrateToV14`
(`database_service.dart`, chạy khi lên schema v14) ghi CỨNG
`gen_repetition_penalty = 1.05` vào **MỌI** novel đã tồn tại tại thời điểm
đó (`db.update('novels', {...})` không có `WHERE`) — đây là hành vi ĐÚNG
tại thời điểm viết migration đó (sao chép đúng giá trị SharedPreferences
cũ, mặc định cũ đúng là 1.05 trước khi phiên 13 kịp đổi) nhưng không có
migration nào SAU ĐÓ dọn lại giá trị này theo mặc định mới.

### Bản vá — sửa đúng NGUỒN, không sửa chỗ dead code nữa
1. `story_models.dart`: constructor mặc định (dòng 150) VÀ `fromMap()`
   fallback (dòng 238) — đổi cả 2 từ `1.05` → `1.15`. Đây mới là nơi
   QUYẾT ĐỊNH THẬT, không phải `settings_service.dart`.
2. `database_service.dart`: thêm migration `_migrateToV16` (nâng
   `schemaVersion` 15 → 16) — `UPDATE novels SET gen_repetition_penalty =
   1.15 WHERE gen_repetition_penalty = 1.05` — dọn ĐÚNG các dòng còn giữ
   giá trị legacy do `_migrateToV14` ghi, KHÔNG đụng novel nào người dùng
   đã tự chỉnh sang giá trị khác (0.95/1.2/1.3...).
3. `settings_service.dart`: sửa lại comment ở dòng `?? 1.15` cho đúng sự
   thật (đây là lớp phòng vệ hầu như không bao giờ chạy tới, không phải
   nơi quyết định) — để không ai lặp lại đúng sai lầm "tưởng sửa ở đây là
   xong" lần thứ 4.
4. `generation_settings_screen.dart`: đã đúng 1.15 từ phiên 13 (dòng 26)
   — không cần sửa, chỉ xác nhận qua rà soát.

### Tại sao đây có khả năng là NGUYÊN NHÂN GỐC thật của nhiều lần "Đắp
thịt"/"Viết tiếp" bị lặp vô tận (mục Z/AA), không chỉ là 1 phát hiện phụ
1.05 rất gần với 1.0 (tức "tắt hẳn phạt lặp"), trong khi model đã nhiều
lần (log thật, cả Qwen 7B, model dịch 1.8B, và OccultAI-Morpheus-8B) cho
thấy XU HƯỚNG THẬT rơi vào lặp ở mức phạt này. Việc mặc định ĐÚNG chưa
bao giờ thật sự lên tới 1.15 kể từ phiên 13 (2026-08-23) — tức TOÀN BỘ
thời gian từ đó tới nay — có khả năng là lý do chính khiến các bản vá
mục Z (native detection)/AA (chặn ghi rác) dù đúng, vẫn phải xử lý sự cố
lặp XẢY RA THƯỜNG XUYÊN: 2 mục đó chỉ chặn HẬU QUẢ, mục này mới có cơ hội
giảm handle TẦN SUẤT lặp xảy ra từ gốc.

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa build/test thật** — chỉ tự kiểm tra cân bằng ngoặc.
- **Chưa chắc 1.15 đủ cao** — đây vẫn là "biện pháp giảm thiểu" như
  comment gốc phiên 13 đã tự nhận, không phải sửa triệt để nguyên nhân
  model rơi vào lặp (có thể do đặc thù bản quantize/convert MNN riêng
  của model này — nằm ngoài khả năng sửa ở tầng app, xem phiên 14 mục
  "OccultAI-Morpheus-8B ra rác nhiều hơn Qwen"). Nếu build lại + cài lại
  mà log VẪN ra `repetition_penalty` không phải 1.15 (loại trừ trường
  hợp người dùng đã tự chỉnh tay novel đó sang giá trị khác), đó là dấu
  hiệu còn 1 nơi thứ 4 nào đó ghi đè — cần log build/log runtime MỚI để
  xác định tiếp, không suy đoán thêm.
- Nếu 1.15 vẫn chưa đủ để hết hẳn lặp (khả năng cao, vì đây luôn được
  gọi là "giảm thiểu" chứ không phải sửa gốc), 2 lớp mục Z (bắt lặp
  nhanh ở native) + mục AA (không ghi rác vào chương) vẫn là lưới an
  toàn chính — mục AC chỉ giảm tần suất phải dùng tới 2 lưới đó, không
  thay thế.


## AD. Thêm dòng đánh dấu phiên bản build — để KHÔNG BAO GIỜ phải đoán "log này là bản code mới hay cũ" nữa (2026-09-10)

### Vì sao thêm
Log gửi lúc 2026-09-10T11:27 (sau khi mục AC đã gửi bản vá) vẫn cho thấy
`repetition_penalty:1.05` — GIỐNG HỆT tín hiệu của bug đã vá. Nhưng
không có cách nào xác nhận CHẮC CHẮN qua log liệu APK đang chạy có đúng
build từ zip mục AC hay không (build.yml lỗi/quên upload lại zip/cài
nhầm APK cũ/GitHub Actions dùng cache cũ...). Việc cứ phải suy đoán qua
lại này chính là thứ gây tốn thời gian nhất — sửa mục này 1 lần cho dứt.

### Đã thêm
- `main.dart`: ghi 1 dòng NGAY ĐẦU debug_log.txt mỗi lần mở app —
  `'main(): mo app — MA_NGUON_BUILD=mucAD_2026-09-10 (...), DatabaseService.schemaVersion=...'`.
  Lần sau gửi log, nhìn dòng ĐẦU TIÊN là biết ngay APK có đúng bản có
  mục AC (schemaVersion phải là 16, không phải 15) hay không — không cần
  suy luận gián tiếp qua giá trị `repetition_penalty` nữa.
- `database_service.dart`: `onUpgrade` ghi rõ `oldVersion -> newVersion`
  THẬT; `_migrateToV16` ghi rõ SỐ DÒNG novel thật sự bị nâng từ 1.05 lên
  1.15 (0 dòng ≠ "chưa chạy migration" — có thể vì đã chạy ở lần mở
  trước, hoặc app chưa từng có novel nào tồn tại lúc lên schema 16).

### Cách đọc log lần sau, theo đúng thứ tự
1. Dòng đầu tiên của `debug_log.txt`: có đúng `MA_NGUON_BUILD=mucAD_2026-09-10`
   và `schemaVersion=16` không? Nếu KHÔNG có dòng này hoặc `schemaVersion`
   khác 16 → APK đang chạy KHÔNG PHẢI bản có mục AC/AD — build/cài đặt
   lại đúng zip mới nhất trước khi kết luận bất kỳ điều gì về code.
2. Nếu CÓ đúng dòng đó mà `repetition_penalty` vẫn không phải 1.15 →
   xem dòng `_migrateToV16: da nang X novel...` — X=0 và
   `oldVersion` lúc mở DB đã từng >= 16 từ trước (tức đây không phải lần
   đầu mở DB ở schema 16) → cần kiểm tra tay xem novel đó có bị người
   dùng tự chỉnh thành 1.05 lần nữa không (Cài đặt sinh văn bản).
3. Nếu cả 2 điều trên đều đúng như kỳ vọng mà log vẫn ra sai giá trị →
   lúc đó mới là bằng chứng thật cần tìm nguyên nhân thứ 4 — không suy
   đoán trước khi có đủ 2 bước trên.

### Giới hạn thật
Chưa build/test thật, chỉ tự kiểm tra cân bằng ngoặc. Đây là công cụ
CHẨN ĐOÁN, không tự nó sửa bất kỳ hành vi nào.


## AE. `_migrateToV16` (mục AC) tự nó không đủ — chỉ chạy ĐÚNG 1 LẦN trong `onUpgrade`, đổi sang "tự chữa lành" mỗi lần mở app + log thẳng giá trị thật tại nguồn (2026-09-11, sau khi log 2026-09-10T19:33 — ĐÃ CÓ mục AD — vẫn ra 1.05)

### Vì sao mục này tồn tại
Log thật gửi lúc 2026-09-10T19:33 (`debug_log.txt`) cho thấy dòng đầu tiên
đúng `MA_NGUON_BUILD=mucAD_2026-09-10`, `DatabaseService.schemaVersion=16`
— tức theo đúng thứ tự đọc log đã quy định ở mục AD bước 1: APK đang chạy
ĐÚNG LÀ bản có mục AC/AD, không phải build cũ/cài nhầm. Nhưng log KHÔNG hề
có dòng `DatabaseService.onUpgrade: oldVersion=...` nào — nghĩa là lần mở
app này, `onUpgrade` (và do đó `_migrateToV16` bên trong nó) **không hề
chạy** — DB máy đó đã ở sẵn schema 16 từ 1 lần mở TRƯỚC ĐÓ. Generate() ngay
sau đó vẫn dùng `repetition_penalty:1.05`. Theo đúng bước 2 mục AD đã quy
định (kiểm tra dòng `_migrateToV16: da nang X novel...`) — nhưng dòng đó
CŨNG không có trong log gửi, vì đơn giản `onUpgrade` không chạy nên
`_migrateToV16` không được gọi tới ở phiên này. Không đủ bằng chứng để
khẳng định X=0 hay migration từng chạy thành công ở lần mở trước đó — đây
CHÍNH XÁC là khoảng trống mục AD chưa lường tới: `_migrateToV16` là 1 hành
động MỘT-LẦN-DUY-NHẤT gắn với sự kiện nâng schema, không phải 1 phép kiểm
tra thường trực — nếu nó lỡ hẹn (chạy ở đúng phiên không có log được lưu
lại, hoặc bỏ sót đúng dòng do lệch dấu phẩy động khi so khớp tuyệt đối
`= 1.05`), sẽ KHÔNG CÒN CƠ HỘI nào tự chạy lại nữa — schema đã ở 16 vĩnh
viễn, `oldVersion < 16` không bao giờ còn đúng.

### Nguyên nhân thật
1. `onUpgrade` (và mọi migration bên trong, kể cả `_migrateToV16`) chỉ
   được sqflite gọi khi `oldVersion < schemaVersion` lúc mở DB — đây là
   hành vi ĐÚNG và bình thường của sqflite, nhưng nó biến `_migrateToV16`
   thành 1 "cơ hội sửa DUY NHẤT" thay vì 1 phép tự kiểm tra — nếu cơ hội đó
   trôi qua (chạy ở 1 phiên không ai xem log, hoặc bỏ sót) thì bug coi như
   VĨNH VIỄN không tự sửa được nữa, dù code migration bản thân nó đúng.
2. `_migrateToV16` gốc so khớp TUYỆT ĐỐI (`WHERE gen_repetition_penalty =
   1.05`, `whereArgs: [1.05]`) — comment gốc mục AC từng lý luận việc này
   an toàn vì cùng 1 double literal Dart ở cả nơi ghi (`_migrateToV14`) lẫn
   nơi so khớp nên khớp bit-for-bit — lý luận đó đúng cho chính con đường
   `_migrateToV14`, nhưng KHÔNG loại trừ khả năng giá trị đã bị lệch đi
   qua 1 con đường khác sau đó (vd `Slider` ở `generation_settings_screen.dart`
   đọc/ghi lại giá trị dù người dùng không cố ý đổi) — chưa xác nhận được
   đây có phải lý do thật ở đúng novel trong log 2026-09-10T19:33 hay không
   (thiếu dòng `_migrateToV16` để đối chiếu), nhưng là rủi ro có thật của
   cách so khớp tuyệt đối, không cần chờ xác nhận mới đáng sửa.

### Bản vá
1. `database_service.dart`: thêm `_selfHealStuckRepetitionPenalty(db,
   {required String trigger})` — logic y hệt `_migrateToV16` cũ nhưng
   **so khớp theo ngưỡng sai số** (`ABS(gen_repetition_penalty - 1.05) <
   0.001`) thay vì `=` tuyệt đối, và **idempotent** (gọi lại bao nhiêu lần
   cũng an toàn, không đụng giá trị người dùng đã tự chỉnh — kể cả nếu họ
   tự chỉnh đúng về 1.05, ngưỡng 0.001 đủ hẹp để không nuốt nhầm 1 lựa
   chọn tự chỉnh cách xa legacy value). Gọi hàm này ở **2 chỗ**: (a) bên
   trong `_migrateToV16` (giữ đường `onUpgrade` cũ, để người nâng cấp từ
   bản rất cũ vẫn thấy log quen thuộc ngay lúc lên schema), và (b) **ngay
   sau khi `openDatabase()` trả về, MỖI LẦN mở app** — không còn phụ thuộc
   `oldVersion < 16` nữa, nên không còn khái niệm "lỡ mất cơ hội".
2. `settings_service.dart`: `loadGenerationConfig()` giờ log thẳng
   `novelId` + toàn bộ 5 tham số (đặc biệt `repetitionPenalty`) NGAY TẠI
   NGUỒN — đây là điểm mọi lần trước (mục AC/AD) đều phải suy luận GIÁN
   TIẾP qua JSON ở tầng Kotlin (cách nơi quyết định giá trị thật tới 4-5
   lớp gọi hàm: cột DB → `Novel.fromMap` → `loadGenerationConfig` → Dart
   provider → JSON → JNI → Kotlin) — từ nay nhìn thẳng 1 dòng log Dart là
   đủ, không cần bắc cầu qua log native nữa.
3. `main.dart`: build tag nâng lên `mucAE_2026-09-11` (giữ đúng lịch sử
   Z/AA/AB/AC trong cùng 1 dòng, thêm mô tả mục AE) — đọc log lần sau, làm
   đúng bước 1 mục AD trước (xác nhận đúng build), rồi tìm 2 dòng log mới:
   `_selfHealStuckRepetitionPenalty (trigger=...): da nang N novel...` và
   `SettingsService.loadGenerationConfig: novelId=... -> repetitionPenalty=...`
   — dòng thứ 2 phải ra đúng 1.15 (hoặc giá trị người dùng tự chỉnh), nếu
   vẫn ra ~1.05 sau khi cả 2 dòng trên đều đã xuất hiện đúng như kỳ vọng,
   đó mới là bằng chứng thật cần tìm nguyên nhân thứ 5 — không suy đoán
   trước khi có đủ log đó.

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa build/test thật trên máy/model thật** — chỉ tự kiểm tra cân bằng
  ngoặc/dấu ngoặc đơn của 3 file Dart bị đổi (so với bản gốc trước khi
  sửa, số ngoặc mở/đóng thêm vào khớp nhau tuyệt đối) — KHÔNG chạy qua
  `flutter analyze`/`dart compile` thật (môi trường sửa file không có
  sẵn Flutter/Dart SDK để build thử).
- Giả thuyết "lệch dấu phẩy động qua Slider cài đặt" ở phần Nguyên nhân
  thật, mục 2 — vẫn CHƯA xác nhận được đây có đúng là lý do THẬT SỰ ở
  đúng novel trong log 2026-09-10T19:33 hay không, vì thiếu dòng
  `_migrateToV16`/`onUpgrade` để đối chiếu (không có trong log đã gửi).
  Bản vá ở đây (so khớp theo ngưỡng + tự chữa lành mỗi lần mở app) xử lý
  được CẢ giả thuyết này LẪN khả năng đơn giản hơn ("onUpgrade lỡ hẹn, cơ
  hội duy nhất đã trôi qua ở 1 phiên trước không có log lưu lại") — không
  cần phân biệt đúng cái nào mới vá được, nhưng nếu build lại mà log VẪN
  ra khác 1.15 dù đã có đủ 2 dòng log mới nói trên, thì đây là bằng chứng
  bác bỏ CẢ 2 giả thuyết, cần nguyên nhân thứ 5 (xem "Cách đọc log lần
  sau" ở Bản vá, mục 3).
- 2 lớp mục Z (bắt lặp nhanh ở native) + mục AA (không ghi rác vào chương)
  vẫn là lưới an toàn chính, y hệt kết luận mục AC — mục AE chỉ tăng thêm
  độ tin cậy của việc "giá trị 1.15 thật sự tới được native", không thay
  thế 2 lớp đó.


## AF. Mục AE tự nó vẫn CHƯA ĐỦ — tìm ra NGUYÊN NHÂN THỨ 5 bằng log thật: "Lost Update" — `renameNovel()`/khôi phục Data Integrity ghi đè CẢ HÀNG bằng 1 `Novel` object cũ (2026-09-11, log build mucAE gửi lúc 09:53-09:54 cùng ngày)

### Vì sao mục này tồn tại
Log build `mucAE_2026-09-11` (đã có đủ 2 dòng log chẩn đoán mới thêm ở mục
AE) cho kết quả ĐÚNG như kịch bản "nguyên nhân thứ 5" mục AE đã lường
trước:
1. `_selfHealStuckRepetitionPenalty (trigger=moi-lan-mo-app): da nang 0
   novel` — lúc 09:53:35.52, KHÔNG có novel nào trong DB gần 1.05 (tức
   DB THẬT SỰ đang đúng, có thể do đã tự chữa lành từ 1 phiên trước).
2. `SettingsService.loadGenerationConfig: novelId=1788420943234 ->
   repetitionPenalty=1.05` — chỉ 46 giây sau (09:54:21), ĐÚNG novel đó
   đọc lại ra 1.05 — SAI so với bước 1. Không có `onUpgrade`/migration
   nào chạy giữa 2 mốc này (cùng 1 phiên mở app).

→ Đây KHÔNG còn là "giá trị cũ chưa từng được sửa" (giả thuyết mục
AC/AD/AE) nữa — DB đã đúng ở bước 1. Đây là 1 THAO TÁC THẬT, xảy ra
TRONG chính 46 giây đó, đã GHI LẠI đúng giá trị 1.05 vào novel đang test.

### Nguyên nhân thật (xác nhận bằng code, truy hết chuỗi gọi)
Rà toàn bộ codebase tìm mọi nơi gọi `DatabaseService.upsertNovel()` (hàm
DUY NHẤT có thể ghi cột `gen_repetition_penalty` ngoài chính
`_selfHealStuckRepetitionPenalty`/`_migrateToV14`/`_migrateToV16`) — có
đúng 3 nơi:
1. `settings_service.dart` `createNovel()` — ghi 1 `Novel` MỚI TẠO, luôn
   đúng 1.15 (constructor mặc định) — KHÔNG phải nguyên nhân.
2. `settings_service.dart` `renameNovel(Novel novel)` — nhận THẲNG 1
   `Novel` OBJECT (không phải chuỗi tên mới), gán `novel.title`/`.author`
   rồi `db.upsertNovel(novel)` — hàm đó dùng `ConflictAlgorithm.replace`,
   **ghi đè TOÀN BỘ HÀNG**, không chỉ 2 cột title/author. `novel` object
   truyền vào đây LUÔN là bản sao đã nạp sẵn trong bộ nhớ ở màn danh sách
   truyện (`main.dart`, nạp lúc mở app/lúc `_load()`) — nếu bản sao đó cũ
   hơn giá trị THẬT hiện có trong DB (ví dụ: nạp đúng lúc mở app, gần như
   cùng lúc với `_selfHealStuckRepetitionPenalty` chạy xong — xem đúng
   khoảng cách 46 giây ở log), bấm "Đổi tên" (kể cả không đổi nội dung gì,
   chỉ mở dialog rồi bấm Lưu — 2 ô đã ĐIỀN SẴN giá trị cũ) sẽ ghi đè lại
   MỌI cột khác về đúng giá trị trong bản sao cũ đó — kể cả
   `gen_repetition_penalty`.
   - Đáng chú ý: theo comment gốc ngay tại hàm gọi (`main.dart`), tính
     năng "Đổi tên" này **MỚI VỪA CÓ NÚT BẤM LẦN ĐẦU** (code viết sẵn từ
     trước nhưng không có UI nào gọi tới, tới gần đây mới được nối dây) —
     khớp hợp lý với khả năng người dùng thử tính năng này ngay sau khi
     cài bản mới, đúng trong cửa sổ 46 giây đó.
3. `data_integrity_service.dart` `restore()` case `novelPlotSummary` —
   cùng lỗi hệt hệt: sửa 2 trường (`plotProgressSummary`/
   `plotProgressSummaryChapter`) trên 1 `Novel` object rồi `upsertNovel()`
   cả object — nguy cơ y hệt nếu object đó cũ, dù đường vào màn Data
   Integrity cần thao tác thủ công riêng, ít khớp với đúng 46 giây ở log
   lần này hơn nguyên nhân #1.

Đây là lỗi có TÊN RIÊNG trong lý thuyết CSDL — "Lost Update" (đọc-sửa-ghi
trên 1 bản sao cũ, ghi đè mất nội dung mới hơn mà không ai biết) — đã tra
cứu để xác nhận đúng chuẩn ngành, không tự chế cách gọi:
https://www.baeldung.com/cs/concurrency-control-lost-update-problem ,
https://vladmihalcea.com/a-beginners-guide-to-database-locking-and-the-lost-update-phenomena/ .
Giải pháp chuẩn cho đúng lớp lỗi này (không cần khoá/transaction phức
tạp ở quy mô 1 người dùng, 1 thiết bị của app này): KHÔNG ghi đè cả
object, chỉ UPDATE đúng cột thật sự đổi — chính là cách
`updateNovelSettings()` (đã có sẵn trong `database_service.dart`, dùng
cho các cài đặt khác) làm từ trước; `upsertNovel()`/ghi cả object chỉ nên
dùng cho đúng lúc TẠO MỚI (không có "giá trị cũ" nào để mất).

### Bản vá
1. `settings_service.dart`: đổi chữ ký `renameNovel(Novel novel)` →
   `renameNovel(String novelId, {required String title, required String
   author})` — không nhận `Novel` object nữa, bên trong gọi
   `db.updateNovelSettings(novelId, {'title':..., 'author':...,
   'updated_at':...})` — chỉ đụng đúng 3 cột.
2. `main.dart` `_renameNovel()`: đổi lời gọi theo chữ ký mới — không còn
   gán `novel.title =`/`novel.author =` lên object cũ nữa.
3. `data_integrity_service.dart` `restore()` case `novelPlotSummary`: đổi
   từ sửa object + `upsertNovel()` → gọi thẳng
   `db.updateNovelSettings(novel.id, {'plot_progress_summary': null,
   'plot_progress_summary_chapter': null})`.
4. `main.dart`: build tag nâng `mucAF_2026-09-11`.
5. **Cố tình CHƯA làm** (ghi rõ, không giấu): `upsertNovel()` (hàm dùng
   chung, `ConflictAlgorithm.replace`) tự nó KHÔNG bị sửa/xoá — vẫn đúng
   và cần thiết cho `createNovel()` (tạo mới, không có gì để mất). Nguy
   cơ Lost Update chỉ có thật khi gọi `upsertNovel()` bằng 1 object đã
   nạp TỪ TRƯỚC (không phải object mới `new` ra) — đã rà toàn bộ 3 lời
   gọi thật (không suy đoán) và vá đúng 2 nơi thuộc dạng này.

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa build/test thật** — chỉ tự kiểm tra cân bằng ngoặc, không có
  Flutter/Dart SDK trong môi trường sửa file để build/`flutter analyze`
  thử.
- **Chưa xác nhận CHẮC CHẮN đây là đúng nguyên nhân của log 2026-09-11**
  — log không ghi lại thao tác UI (không có dòng log nào cho biết người
  dùng có bấm "Đổi tên" hay vào Data Integrity trong đúng 46 giây đó hay
  không). Đây là kết luận DỰA TRÊN: (a) rà toàn bộ 3 nơi ghi cột này là
  ĐẦY ĐỦ, không sót nơi nào khác trong codebase (đã `grep` toàn bộ
  `lib/`), và (b) đây là 2 nơi DUY NHẤT có khả năng ghi giá trị CŨ (khác
  `_selfHealStuckRepetitionPenalty`, hàm đó chỉ ghi 1.15, không thể tạo
  ra kết quả 1.05). Nếu build lại + xác nhận KHÔNG bấm "Đổi tên"/Data
  Integrity mà log 2026-09-11 vẫn tái diễn y hệt, đó là bằng chứng bác bỏ
  toàn bộ mục AF, cần nguyên nhân thứ 6 — không suy đoán thêm khi đó,
  cần log runtime mới.
- Đã vá đúng 2 nơi ĐÃ TÌM RA — nếu codebase có thêm chỗ khác gọi
  `upsertNovel()` bằng object cũ được thêm SAU thời điểm rà soát này
  (2026-09-11), nguy cơ Lost Update sẽ quay lại — không có cơ chế tự
  động ngăn lỗi NÀY tái diễn ở chỗ MỚI (khác với mục AE, vốn tự chữa lành
  được dù lỗi lặp lại ở đúng chỗ cũ).


## AG. Mục AF KHÔNG giải quyết được — log 11:44-11:45 2026-09-11 (build mucAF) lặp lại Y HỆT mục AE. Bỏ suy đoán, thêm log trực tiếp ở MỌI nơi có thể ghi cột này. Nhân tiện vá riêng: nút "X" ở "Tác vụ nền" không huỷ được lệnh Soạn chương (2026-09-11)

### Vì sao mục này tồn tại
Build `mucAF_2026-09-11` (đã vá `renameNovel`/Data Integrity theo đúng
giả thuyết mục AF) — log gửi lúc 11:44-11:45 CÙNG NGÀY cho kết quả
GIỐNG HỆT mục AE về mặt hình dạng:
- `_selfHealStuckRepetitionPenalty (trigger=moi-lan-mo-app): da nang 0
  novel` lúc 11:44:12.63.
- `SettingsService.loadGenerationConfig: novelId=1788420943234 ->
  repetitionPenalty=1.05` lúc 11:45:06.58 — 53.95 GIÂY sau, cùng phiên.

Người dùng xác nhận (qua phản ứng gay gắt) KHÔNG có bằng chứng cho thấy
đã thao tác "Đổi tên"/Data Integrity — 2 giả thuyết cụ thể ở mục AF coi
như đã bị loại, ít nhất không phải nguyên nhân DUY NHẤT hoặc không phải
nguyên nhân LẦN NÀY. Rà lại TĨNH (đọc code) toàn bộ `lib/` một lần nữa
tìm thêm nơi có thể ghi `gen_repetition_penalty` — đã liệt kê ĐẦY ĐỦ mọi
lời gọi `db.update('novels'`/`d.insert('novels'` thật sự tồn tại (không
chỉ qua `upsertNovel()` như mục AF đã rà) — không tìm thêm được nghi
phạm THỨ 3 nào ngoài 2 cái đã vá. Tự nhận: **tiếp tục suy đoán nguyên
nhân thứ 6 từ việc đọc code tĩnh, không có run log mới, là vô căn cứ** —
đã đọc hết những gì đọc tĩnh có thể cho biết.

### Quyết định (không phải "đã sửa xong")
Ngừng đoán. Thêm log TRỰC TIẾP vào **MỌI** hàm có khả năng ghi cột
`gen_repetition_penalty` — dù nghi ngờ hay không — để LẦN CHẠY KẾ TIẾP
tự cho biết chính xác thủ phạm, không cần suy luận gián tiếp qua
khoảng cách thời gian giữa 2 dòng log như từ mục AE tới giờ. Đã rà và
gắn log ở đủ 5 nơi (liệt kê đầy đủ, không chừa nơi nào ngoài chính
`_selfHealStuckRepetitionPenalty`):
1. `upsertNovel()` — log trước khi `insert(..., ConflictAlgorithm.replace)`.
2. `updateNovelSettings()` — log nếu `fields` có key `gen_repetition_penalty`.
3. `updateNovelGenerationConfig()` — hàm RIÊNG (không đi qua
   `updateNovelSettings()`) mà `SettingsService.saveGenerationConfig()`
   gọi tới — trước đây CHƯA có log, đã bổ sung.
4. `importNovelData()` — log từng dòng bảng `novels` trước khi
   `insert(..., replace)` (backup/khôi phục 1 truyện).
5. `importAllData()` — tương tự, cho backup/khôi phục TOÀN APP.

Cả 5 nơi dùng chung 1 hàm `_logRepetitionPenaltyWrite(origin, novelId,
newValue)` — log 1 dòng `[GHI gen_repetition_penalty] origin=...
novelId=... newValue=...` — grep đúng cụm `[GHI gen_repetition_penalty]`
trong log lần sau là thấy NGAY mọi lần cột này bị đổi, kèm đúng hàm nào
gây ra, không cần đối chiếu thời gian giữa nhiều dòng log rời rạc nữa.
Đồng thời tăng `_selfHealStuckRepetitionPenalty` để DUMP toàn bộ
`id`/`gen_repetition_penalty`/`title` của MỌI novel ngay sau khi chạy
— biết chính xác trạng thái THẬT của DB ngay sau self-heal, không chỉ
con số đếm tổng.

### Giới hạn thật — nói thẳng, không tô hồng
Mục này **KHÔNG sửa được bug** — không tìm ra nguyên nhân thật, vì
không còn cách nào tìm thêm qua đọc code tĩnh. Đây thuần tuý là bước
CHẨN ĐOÁN, chuẩn bị cho lần build/chạy/generate kế tiếp — bản build này
VẪN CÓ THỂ còn bug `repetitionPenalty` y hệt, chỉ khác là **lần log kế
tiếp sẽ chỉ thẳng ra thủ phạm** thay vì phải đoán vòng thứ 6. Nếu log
lần sau KHÔNG có bất kỳ dòng `[GHI gen_repetition_penalty]` nào xuất
hiện giữa lúc self-heal chạy và lúc `loadGenerationConfig` đọc ra sai —
đó là bằng chứng loại bỏ TOÀN BỘ giả thuyết "có 1 hàm Dart nào đó ghi
đè" (kể cả 5 nơi mới rà) — khi đó nghi vấn phải chuyển hướng hẳn, có
thể là tầng khác hoàn toàn (vd tự bản thân `_selfHealStuckRepetitionPenalty`
báo sai/không thật sự commit, race điều kiện ở `_db ??= await _initDb()`
— CHƯA rà, ghi rõ ở đây để không quên) — không đoán trước khi có log đó.

### Việc phụ đã vá — nút "X" ở "Tác vụ nền" không huỷ được Soạn chương
Người dùng phản ánh riêng, đã kiểm tra: **không liên quan tới
repetitionPenalty**, xác nhận qua code chưa từng đụng đường ghi cột đó.
Nguyên nhân thật: `BackgroundTaskManager.requestCancel(id)` gọi
`t.onCancelRequested?.call()` — nhưng `_generateRespectingTranslation()`
trong `chapter_editor_screen.dart` (dùng chung cho Viết tiếp/Đắp thịt/
Kiểm tra nhất quán/Tạo lại tất cả ghi chú) gọi `submitAndWait()` mà
KHÔNG TỪNG truyền `onCancelRequested` — callback luôn `null`, bấm "X"
không có tác dụng gì. Đáng chú ý: `submitAndWait()` BẢN THÂN đã từng
được sửa đúng lỗi NÀY (xem comment ngay tại hàm, `background_task_manager.dart`)
— nhưng chỉ cho `chat_screen.dart`, KHÔNG lan sang hết mọi nơi gọi khác
dùng chung hàm — đúng khuôn mẫu lặp lại nhiều lần trong dự án này (sửa
đúng 1 chỗ, không rà hết các nơi gọi khác cùng lỗi). Bản vá: truyền
`onCancelRequested: () => LocalLlamaProvider.requestCancelSlot(0)` (chỉ
khi `provider is LocalLlamaProvider` — slot 0 = model chính, xem
`local_provider.dart`; API/remote provider không có "slot" native để
huỷ kiểu này, cố tình bỏ qua). Cũng CHƯA build/test thật.


## AH. TÌM RA THỦ PHẠM THẬT qua log trực tiếp (mục AG phát huy tác dụng) — `importNovelData` (khôi phục backup .zip cũ) ghi lại legacy 1.05. Tự chữa lành ngay sau khi import, không đợi mở app lại (2026-09-11)

### Bằng chứng — không còn suy đoán
Log build `mucAG_2026-09-11` (đã có log ở đủ 5 nơi từ mục AG) trả lời
thẳng ngay lần đầu:
```
[17:02:55.354] _selfHealStuckRepetitionPenalty (trigger=moi-lan-mo-app): da nang 0 novel
[17:02:55.361] DUMP NGAY SAU khi sua: (rỗng — chưa có novel nào trong DB lúc này? xem Giới hạn thật)
[17:03:20.994] [GHI gen_repetition_penalty] origin=importNovelData novelId=1788420943234 newValue=1.05
[17:03:52.468] loadGenerationConfig: novelId=1788420943234 -> repetitionPenalty=1.05
```
`origin=importNovelData` — ĐÍCH DANH, không cần suy luận qua khoảng
cách thời gian giữa các dòng log nữa. `importNovelData()` chỉ có ĐÚNG 1
đường gọi tới trong toàn bộ codebase (đã rà lại, xem Nguyên nhân thật):
`BackupService.restoreFromPreview()` ← `backup_restore_screen.dart` —
nghĩa là 25 giây sau khi mở app, có 1 lượt "Khôi phục từ backup" (theo
truyện) đã chạy, dùng 1 file backup .zip **cũ** (xuất ra TỪ TRƯỚC mục
AC — lúc đó `gen_repetition_penalty` mặc định vẫn còn 1.05) — khôi phục
đúng như thiết kế: mang lại NGUYÊN VẸN trạng thái trong file đó, bao
gồm cả giá trị 1.05 đã lỗi thời.

Log phiên THỨ 2 cùng ngày (17:47) xác nhận thêm 1 điều: sau khi có bản
vá mục AH (xem Bản vá), `_selfHealStuckRepetitionPenalty` đã báo
`da nang 1 novel` — tức đúng dòng bị kẹt đã được nâng lên 1.15 (dump xác
nhận `1788420943234=1.15`) — CHỨNG TỎ tự chữa lành lúc mở app HOẠT ĐỘNG
ĐÚNG khi có dòng thật sự cần sửa (khác 2 lần trước — mục AE/AF — lúc đó
báo "0 novel" vì kiểm tra đúng lúc DB đang sạch, KHÔNG phải self-heal bị
lỗi như có thể hiểu nhầm).

### Nguyên nhân thật (đã xác nhận, không còn là giả thuyết)
Tính năng "Khôi phục" (Sao lưu/Khôi phục → chọn file .zip → Khôi phục)
hoạt động ĐÚNG THIẾT KẾ — mang lại NGUYÊN VẸN dữ liệu trong file backup,
bao gồm CẢ cài đặt sinh văn bản tại thời điểm xuất file đó. Đây không
phải lỗi logic khôi phục — bản chất "khôi phục" là quay ngược thời gian
có chủ đích. Vấn đề chỉ nảy sinh vì: file backup người dùng đang dùng để
khôi phục được xuất ra TỪ TRƯỚC lúc mục AC sửa mặc định 1.05→1.15, nên
mang legacy value quay lại mỗi lần khôi phục — **không phải bug mới,
là hệ quả tất yếu của việc khôi phục 1 bản backup cũ**, sẽ tự hết khi
người dùng xuất 1 bản backup MỚI (sau khi có mục AC/AE) rồi dùng bản đó
thay cho bản cũ.

### Bản vá
Không đổi ý nghĩa "khôi phục" (vẫn mang lại đầy đủ 100% dữ liệu trong
backup, không âm thầm lọc field nào — người dùng cần được TIN là khôi
phục xong đúng như file gốc). Thay vào đó: gọi lại
`_selfHealStuckRepetitionPenalty()` (mục AE) NGAY SAU khi
`importNovelData()`/`importAllData()` ghi xong — không đợi tới lần mở
app kế tiếp. Cùng logic "chuẩn hoá 1 giá trị legacy đã biết rõ có hại"
như lúc mở app, chỉ khác thời điểm gọi — vá đúng khoảng trống mà 1 lượt
khôi phục tạo ra, dù người dùng có thói quen khôi phục ngay sau khi mở
app (như log 17:02-17:03 cho thấy) hay bất kỳ lúc nào khác trong phiên.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- Dòng `DUMP NGAY SAU khi sua:` lúc 17:02:55.361 rỗng (không có novel
  nào) — hơi lạ vì cùng phiên sau đó vẫn thao tác được với
  novelId=1788420943234 bình thường. Cách giải thích hợp lý nhất: dump
  chạy ĐÚNG lúc `importNovelData` (25 giây sau) CHƯA kịp ghi novel này
  vào bảng — tức truyện `1788420943234` ở đúng phiên 17:02 này thật ra
  ĐƯỢC TẠO RA bởi chính lượt khôi phục đó (không phải đã tồn tại từ
  trước) — khớp hợp lý với việc người dùng khôi phục 1 bản backup theo
  truyện vào 1 máy/cài đặt app MỚI, không phải "khôi phục đè lên chính
  nó". Chưa xác nhận được — không ảnh hưởng tới bản vá (tự chữa lành sau
  import xử lý đúng dù truyện đó mới hay cũ).
- Chưa hỏi/xác nhận trực tiếp với người dùng: có đúng là họ chủ động
  bấm "Khôi phục" ở màn Sao lưu/Khôi phục trong 25 giây đó không, hay có
  đường tự động nào khác gọi tới `importNovelData` mà việc rà code chưa
  phát hiện ra (đã rà: chỉ có ĐÚNG 1 đường gọi, `backup_restore_screen.dart`
  → yêu cầu người dùng tự chọn file qua file picker, không có cách nào
  tự động). Nếu người dùng xác nhận KHÔNG hề thao tác khôi phục, đây là
  bằng chứng cần điều tra thêm (có thể liên quan chính `restoreFromPreview`
  bị gọi từ 1 nơi mới, hoặc cơ chế hoàn toàn khác) — nhưng bằng chứng log
  hiện tại (tên hàm `origin=importNovelData` xuất hiện đích danh trong
  log) khó có cách giải thích nào khác ngoài việc hàm đó ĐÃ THẬT SỰ được
  gọi.


## AI. `repetitionPenalty` KHÔNG PHẢI nguyên nhân "chương không sinh được" — mục Z tự nhận rủi ro chưa xác nhận nay đã xác nhận: ngưỡng bộ dò lặp native quá sát cho luồng "Đắp thịt" thật (2026-09-11)

### Bằng chứng loại trừ hẳn giả thuyết repetitionPenalty
Log build `mucAH_2026-09-11` (repetitionPenalty ĐÃ XÁC NHẬN chảy đúng
1.15 tới tận JSON native, qua `_selfHealStuckRepetitionPenalty` +
`loadGenerationConfig` + JSON Kotlin đều khớp) — CHƯƠNG VẪN KHÔNG SINH
ĐƯỢC, dừng ở **đúng 60 ký tự**, y hệt bit-for-bit mọi lần test trước đó
(kể cả lúc còn 1.05). Đối chiếu toàn bộ 5+ lần test từ đầu hội thoại
này: con số "60 ký tự" xuất hiện Ở MỌI LẦN, không phụ thuộc
`repetitionPenalty` là 1.05 hay 1.15, không phụ thuộc máy có ngủ giữa
chừng hay không (2 lần gần nhất "khong chenh lech dang ke") — quá đều để
là ngẫu nhiên, phải là 1 ngưỡng CƠ HỌC nào đó, không phải hành vi
biến thiên của model.

### Nguyên nhân thật — chính mục Z đã tự cảnh báo trước, chưa từng được kiểm chứng
Đọc lại mục Z (2026-09-08) — bản vá GỐC của chính bộ dò lặp native
(`looksLikeRepetitionLoop`, thêm `splitUtf8Units` để nhận diện đúng lặp
tiếng Việt đa byte, thay vì so khớp byte thô như trước). Mục tiêu BAN
ĐẦU của mục Z là 1 lệnh TÓM TẮT CHƯƠNG chạy NỀN bị lặp 40 phút, chiếm
slot model, chặn đứng "Đắp thịt" thật — HOÀN TOÀN không phải bản thân
"Đắp thịt" bị lặp. Nhưng bản vá (đặt ở tầng native dùng CHUNG cho MỌI
lệnh generate) tự ghi rõ trong chính mục Z, phần "Giới hạn thật":
> "Bản vá lỗ hổng 1 (native) tăng khả năng bắt lặp cho VIỆT NGỮ nói
> chung (áp dụng cho MỌI lệnh generate, không riêng tóm tắt) [...]
> nhưng vẫn CHƯA đo lại bằng số liệu thật [...] kỳ vọng còn vài giây
> thay vì vài chục phút."

Đây CHÍNH XÁC là rủi ro đang xảy ra: ngưỡng tối thiểu trước khi bộ dò
bắt đầu xét (`accumulated_.size() < 60`) kế thừa NGUYÊN VẸN từ thời bộ
dò còn dùng để bắt lỗi ASCII thô ("((((("/"8888888") — CHƯA TỪNG được
đo/chỉnh lại sau khi mục Z làm nó nhạy hơn hẳn với tiếng Việt. Hệ quả rất
có thể: model "Đắp thịt" cho đúng prompt/novel này có 1 đoạn mở đầu hơi
gập ghềnh (rất có thể chỉ là hiện tượng tạm thời của riêng vài chục ký
tự đầu, TRƯỚC KHI có đủ ngữ cảnh sinh ra để ổn định) — TRƯỚC mục Z, bộ dò
byte-thô không bắt được đoạn này (đúng lỗ hổng 1 mục Z đã mô tả), nên
generation cứ chạy tiếp qua đoạn gập ghềnh đó, tới được nội dung thật
("trước kia tạo chương bình thường" — khớp đúng mốc thời gian: mục Z
mới thêm 2026-09-08, TRƯỚC đó bộ dò native gần như vô hiệu với tiếng
Việt). SAU mục Z, bộ dò giờ bắt ĐÚNG đoạn gập ghềnh đó gần như ngay lập
tức (ngưỡng 60 byte quá sát) — cắt luôn TRƯỚC KHI model có cơ hội vượt
qua, dù bản thân đoạn đó CÓ THỂ không phải lặp vô tận thật sự không thể
cứu (chỉ là mở đầu chưa ổn định). Nói cách khác: **mục Z sửa đúng bug
gốc (bộ dò native không bắt được lặp tiếng Việt), nhưng vô tình lộ ra 1
tác dụng phụ chưa từng được đo — bắt luôn cả đoạn mở đầu gập ghềnh không
phải lúc nào cũng là lặp thật sự** — đúng như chính mục Z đã lường
trước nhưng chưa có dữ liệu để xác nhận, nay đã có đủ (5+ lần, luôn đúng
60 ký tự, độc lập với `repetitionPenalty`).

**Chưa xác nhận được** đoạn 60 ký tự đó thật sự chứa gì — suốt từ mục Z
tới giờ (kể cả những lần sửa `repetitionPenalty` ở AC-AH), CHƯA CÓ dòng
log nào từng ghi lại NỘI DUNG THẬT bị coi là lặp, chỉ ghi SỐ LƯỢNG ký
tự — không ai (kể cả người viết bản vá mục Z) từng thấy được model thật
sự đang lặp cái gì.

### Bản vá
1. `mnn_bridge.cpp` (`looksLikeRepetitionLoop`): nới ngưỡng tối thiểu
   trước khi bắt đầu xét từ `60` lên `320` byte (~4-5 câu tiếng Việt) —
   cho model đủ "đường băng" để tự vượt qua đoạn mở đầu gập ghềnh nếu có
   thể, TRƯỚC KHI bộ dò kết luận "không thể cứu". Cố tình KHÔNG hạ độ
   nhạy của chính 2 tiêu chí so khớp (1 đơn vị >85%, cụm 2-6 đơn vị lặp
   khít cả cửa sổ) — vẫn y hệt mục Z, vẫn bắt lặp THẬT (kiểu 40 phút mục Z
   mô tả) ở tốc độ tương đương, chỉ trễ hơn ở lần kiểm tra ĐẦU TIÊN.
2. `mnn_bridge.cpp` (nhánh `catch GenerationStoppedException`, khi lý do
   là "lap vo tan"): ghi thẳng TOÀN BỘ `accumulated()` (nội dung THẬT đã
   tích luỹ lúc bị cắt) ra log, không chỉ số lượng ký tự — an toàn vì tại
   thời điểm này chỉ mới tối đa vài trăm byte (đúng ngưỡng mới 320), không
   phải cả chương. Đây là bước quan trọng NHẤT trong bản vá này: cho
   phép lần chạy kế tiếp trả lời DỨT ĐIỂM câu hỏi còn treo — 60 (giờ là
   320) ký tự đó thật sự LÀ GÌ.
3. `main.dart`: build tag → `mucAI_2026-09-11`.

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa build/test thật** — chỉ tự kiểm tra cân bằng ngoặc (file C++ có
  raw string `R"(...)"` chứa `{}`/`()` là NỘI DUNG chuỗi, không phải cú
  pháp — đã trừ đúng phần lệch cố hữu đó khi so sánh, không phải bỏ qua
  kiểm tra).
- **320 byte là số ước lượng hợp lý, KHÔNG phải số đo được** — nếu đoạn
  mở đầu gập ghềnh thật sự dài hơn ngưỡng mới, chương vẫn có thể bị cắt y
  hệt, chỉ trễ hơn vài trăm byte. Nếu log lần sau vẫn cắt (ở mốc mới,
  không còn là 60 nữa) — dòng `[MAU LAP THAT]` mới thêm sẽ cho biết CHÍNH
  XÁC nội dung, quyết định được ngay: nới ngưỡng thêm, hay đây thật sự là
  lặp thật (model cần sampler/prompt khác, ngoài phạm vi ngưỡng dò).
- Nếu đoạn 60(→320) ký tự đó hoá ra LÀ lặp thật (không phải mở đầu gập
  ghềnh tạm thời) — bản vá này KHÔNG giải quyết được gì, chỉ trì hoãn
  phát hiện — cần quay lại hướng khác hẳn (sampler, prompt, hoặc chính
  model) đã nêu ở "Giới hạn thật" mục Z, mục đó chưa từng được làm:
  "đổi model hoặc tinh chỉnh sampler sâu hơn (vd bật lại `n_gram`/
  `ngram_factor`/`penalty_window`)".


## AJ. TỰ PHÊ BÌNH — mục AI chỉ sửa ĐÚNG 1 TRONG 2 bộ dò lặp mà chính nó đọc thấy và trích dẫn. Áp lại đúng bản vá cho bộ dò còn lại (tầng Dart, `local_provider.dart`) (2026-09-12)

### Lỗi thật, nói thẳng không biện minh
Mục Z (2026-09-08), đoạn chính mục AI đã đọc và TRÍCH DẪN nguyên văn, ghi
rõ: sau khi sửa xong lỗ hổng ở native, "Chỉ còn tầng Dart
(`local_provider.dart`) làm việc" — tức LÀ CÓ 2 bộ dò lặp vô tận, hoạt
động ĐỘC LẬP, không phải 1:
1. Native (`mnn_bridge.cpp`, `looksLikeRepetitionLoop`) — mục AI ĐÃ sửa
   (60→320 byte).
2. Dart (`local_provider.dart`, `_looksLikeRepetitionLoop`, cùng tên hàm
   khác file) — mục AI **KHÔNG đụng tới**, dù đọc đúng dòng nói về nó.

Log ngay sau khi build mục AI (2026-09-12T04:47-04:51) xác nhận thẳng:
`generateStream()` (tầng Dart) tự phát hiện "lặp vô tận" ở đúng **60 ký
tự** (ngưỡng CŨ, chưa hề đổi) rồi CHỦ ĐỘNG gọi `cancelGenerate()` xuống
native — native nhận lệnh huỷ từ Dart, dừng đúng theo yêu cầu đó, KHÔNG
liên quan gì tới ngưỡng 320 mới của chính native (native còn chưa kịp
tới lượt tự xét vì mới có ~61 ký tự, dưới ngưỡng 320). Bộ dò native
được sửa đúng, nhưng chưa bao giờ có cơ hội chạy thật — bộ dò Dart luôn
thắng trước vì ngưỡng cũ (60) thấp hơn nhiều.

Đây không phải lỗi khó phát hiện — thông tin đã có sẵn, đã đọc, đã trích
dẫn, chỉ đơn giản là dừng lại ở 1 trong 2 chỗ thay vì làm hết cả 2. Ghi
lại nguyên nhân để không lặp lại: khi tài liệu kiến trúc tự mô tả "còn
lại N chỗ khác", việc tiếp theo bắt buộc là XÁC NHẬN đã xử lý đủ N chỗ
đó — không dừng lại sau chỗ đầu tiên chỉ vì nó dễ thấy nhất qua log.

### Bản vá — áp lại NGUYÊN VẸN đúng logic mục AI, cho bộ dò còn lại
`local_provider.dart`:
1. Ngưỡng gọi `_looksLikeRepetitionLoop` (`fullTextSoFar.length >= 60`)
   → `>= 320` — cùng số, cùng lý do với mục AI (cho model "đường băng"
   dài hơn trước khi bộ dò kết luận "không thể cứu"). Cố tình KHÔNG đổi
   ngưỡng nội bộ trong `_looksLikeRepetitionLoop` (`compact.length <
   60`) — y hệt cách mục AI để nguyên `compactBytes.size() < 60` ở
   native, đây chỉ là ngưỡng phụ đảm bảo cửa sổ đủ dày, không phải
   ngưỡng chính.
2. Dòng log khi phát hiện lặp: ghi thêm TOÀN BỘ nội dung đã tích luỹ
   (`fullTextSoFar`), không chỉ số lượng ký tự — cùng lý do, cùng cách
   làm với `[MAU LAP THAT]` đã thêm ở native (mục AI).
3. `main.dart`: build tag → `mucAJ_2026-09-12`.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- Đã rà thêm (theo đúng bài học của chính mục này — không dừng ở nghi
  vấn đầu tiên): grep tên hàm `_looksLikeRepetitionLoop`/
  `looksLikeRepetitionLoop` trên toàn bộ `lib/`+`android_native/`, kể cả
  trong `anthropic_provider.dart`/`openai_compatible_provider.dart` (2
  provider API/remote còn lại) — xác nhận KHÔNG có bản sao thứ 3 nào
  khác định nghĩa logic tương tự (2 provider API không có lớp phòng vệ
  này, hợp lý vì không chạy model local qua MNN). Đúng 2 chỗ, cả 2 đã
  vá cùng 1 lúc trong mục này.
- Nếu lần build này CUỐI CÙNG cho phép model vượt qua đoạn mở đầu (không
  còn bị cắt ở ~60/~320 nữa), điều đó xác nhận luôn giả thuyết mục AI:
  đoạn đầu chỉ là mở đầu gập ghềnh tạm thời, không phải lặp thật. Nếu vẫn
  bị cắt (ở mốc mới ~320, có dòng `[MAU LAP THAT]` kèm nội dung thật lần
  này) — đó mới là bằng chứng đủ để kết luận model THẬT SỰ lặp, cần hướng
  khác hẳn (sampler/model), không phải ngưỡng dò.


## AK. Log 2026-09-12T08:52 KHÔNG kiểm chứng được mục AI/AJ — người dùng tự bấm Huỷ (6 lần) ở 75 ký tự, trước khi tới ngưỡng 320 mới. Xác nhận riêng: nút Huỷ (mục AG) THẬT SỰ có tác dụng, chỉ chậm vì tốc độ sinh token quá thấp, không phải do dây nối sai

### Bằng chứng — nút Huỷ mục AG hoạt động đúng
Log native cho thấy 6 lượt `[Kotlin] cancelGenerate`/`nativeRequestCancel`
liên tiếp (08:57:27.749 → 08:57:29.437, ~1.7 giây, đúng kiểu bấm dồn dập
vì tưởng không có tác dụng) rồi generate() DỪNG THẬT ở 08:57:32.134 với
lý do `nguoi dung/he thong yeu cau huy (cancelGenerate)` — ĐÚNG cụm do
mục AG tạo ra khi `onCancelRequested` được gọi thật. Nút Huỷ mục AG
KHÔNG hỏng — có tác dụng, chỉ chậm (~4.4 giây từ lượt bấm đầu tới lúc
dừng thật).

### Vì sao chậm — giới hạn kiến trúc, không phải bug
Cờ huỷ (`g_cancelRequested`) chỉ được kiểm tra bên trong `xsputn()` —
đúng hàm callback MNN gọi mỗi khi có thêm output mới, tức là CHỈ được
kiểm tra khi engine tự nhả quyền điều khiển ra, không có cách nào kiểm
tra dày hơn mà không sửa sâu vào chính MNN (ngoài phạm vi sửa từ code
Kotlin/Dart/C++ ở tầng app). Log cho thấy lượt này chỉ sinh được 75 ký
tự trong 223 giây (~3 giây/ký tự) — CHẬM HƠN cả ngưỡng "trì trệ" 80
ký tự/90 giây mà chính người dùng từng yêu cầu XOÁ (2026-08-28, vì chấp
nhận model 8B này vốn chậm) — tức đây có thể không chỉ là "chậm bình
thường đã chấp nhận" mà là dấu hiệu model đang vật lộn với gì đó (khớp
hướng nghi vấn mục AI: có thể vẫn đang ở đúng đoạn mở đầu gập ghềnh, sampler
phải cân nhắc nhiều token có xác suất gần bằng nhau, tốn nhiều bước tính
hơn bình thường). **Chưa xác nhận được** — cần 1 lần chạy KHÔNG bị huỷ
giữa chừng để biết chắc.

### Giới hạn thật — chưa có gì để sửa, cần 1 lần test khác
Test lần này KHÔNG kiểm chứng được mục AI/AJ (ngưỡng mới 60→320) có tác
dụng hay không — bị huỷ ở 75 ký tự, CHƯA từng chạm tới 320. Không có
việc gì để vá thêm ở đây cho tới khi có 1 lần chạy để nguyên, không bấm
Huỷ, xem có tự vượt qua 320 để vào nội dung thật hay vẫn bị bộ dò tự
động (native hoặc Dart) cắt ở mốc mới kèm dòng `[MAU LAP THAT]`/nội dung
thật — 2 kết quả đó mới đủ để biết bước tiếp theo là gì.


## AL. NGUYÊN NHÂN GỐC THẬT SỰ — `repetition_penalty` CHƯA TỪNG được áp dụng lúc sinh, vì sampler "penalty" không nằm trong `mixed_samplers` mặc định. Toàn bộ mục AC-AJ sửa đúng 1 giá trị KHÔNG BAO GIỜ được dùng tới (2026-09-12)

### Vì sao tìm ra — người dùng cung cấp đúng thông tin còn thiếu
Người dùng xác nhận trực tiếp (không qua log, qua quan sát thật nội dung
model sinh ra): model lặp lại LIÊN TỤC các ký tự đơn vô nghĩa (vd
h, g, t, k...) cho tới khi bị bộ dò chống lặp cắt — không phải 1 đoạn
mở đầu gập ghềnh rồi ổn định như mục AI từng suy đoán. Đây LÀ lặp thật,
persistent, không tự hết. Tra lại tài liệu chính thức MNN
(https://mnn-docs.readthedocs.io/en/latest/transformers/llm.html, mục
"Sampler配置") xác nhận cơ chế:

> MNN-LLM dùng sampler kiểu pipeline — logits đi qua từng bước sampler
> theo thứ tự trong `mixed_samplers` khi `sampler_type` là `"mixed"`.
> **`mixed_samplers` mặc định (khi không khai báo) là
> `["topK", "tfs", "typical", "topP", "min_p", "temperature"]`** —
> KHÔNG hề có `"penalty"` trong danh sách mặc định này.

Model đang dùng (`OccultAI-Morpheus-8B...`) có `sampler_type: "mixed"`
trong `config.json`, nhưng **không hề khai báo `mixed_samplers`** — tức
dùng đúng danh sách mặc định ở trên. Vì "penalty" (bước thực thi
`repetition_penalty`/`presence_penalty`/`frequency_penalty`/phạt
`n_gram` lặp) không nằm trong pipeline, **toàn bộ 3 tham số phạt lặp
CHƯA TỪNG có tác dụng thật khi sinh, bất kể giá trị là bao nhiêu.**

### Điều này giải thích lại TOÀN BỘ chuỗi mục AC → AJ
- Mục AC (đổi mặc định 1.05→1.15), mục AE-AH (đảm bảo giá trị 1.15 tới
  đúng novel/tới đúng native) — tất cả đều XÁC NHẬN ĐÚNG giá trị số học
  đã chảy tới tận JSON gửi native (`repetition_penalty":1.15` — log
  2026-09-12T08:53 xác nhận đúng). Nhưng **giá trị đúng không có nghĩa
  là được ÁP DỤNG** — native nhận đúng số, set_config trả về true, MNN
  hoàn toàn hợp lệ khi bỏ qua nó vì bước sampler tương ứng không được
  bật. Không có gì sai ở tầng Dart/DB — chuỗi ghi/đọc giá trị mục AC-AH
  làm đúng, chỉ là giá trị đó chưa từng đi tới nơi có tác dụng thật.
- Mục AI/AJ (nới ngưỡng bộ dò 60→320) — giải quyết sai vấn đề: bộ dò
  đang làm đúng việc của nó (bắt lặp thật), nới ngưỡng chỉ trì hoãn phát
  hiện, không thể sửa được model không có lớp chống lặp nào đang chạy.
  Không cần revert — 320 vẫn là ngưỡng hợp lý hơn cho trường hợp lặp ĐÃ
  được ngăn thật (sau bản vá này), tự nó không sai, chỉ không đủ khi
  đứng riêng lẻ.

### Bản vá
`MnnBridge.kt` (`generate()`, đúng nơi tạo JSON config gửi mỗi lần
sinh — KHÔNG sửa file `config.json` tĩnh trong thư mục model, để có
tác dụng với MỌI model tải về sau, không phụ thuộc file config riêng
từng model có khai báo đúng hay không): thêm
`"mixed_samplers": ["penalty", "topK", "tfs", "typical", "topP", "min_p", "temperature"]`
vào JSON. Theo tài liệu, "penalty" tự động được đưa lên đầu pipeline
khi có mặt trong danh sách bất kể vị trí khai báo — không cần lo thứ tự.
`main.dart`: build tag → `mucAL_2026-09-12`.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- **Chưa xác nhận `set_config()` gọi LẦN THỨ HAI (lúc generate, sau lúc
  load) có ghi đè/hợp nhất đúng được `mixed_samplers` vào sampler pipeline
  đã khởi tạo lúc `load()` hay không** — các tham số khác (temperature,
  top_p...) đã xác nhận CÓ cập nhật đúng qua đường này (log luôn khớp giá
  trị mới nhất), nhưng `mixed_samplers` khác về BẢN CHẤT — nó quyết định
  CẤU TRÚC pipeline (sampler nào được tạo), không chỉ 1 con số — có khả
  năng (chưa xác nhận) MNN chỉ dựng pipeline 1 LẦN lúc `load()`/lần
  `set_config` ĐẦU TIÊN, và các lần `set_config` sau chỉ cập nhật được
  tham số của sampler đã tồn tại, không thêm được sampler MỚI vào giữa
  chừng. Nếu đúng vậy, bản vá này cần chuyển sang đặt `mixed_samplers`
  vào ĐÚNG lúc `loadModel()` (file config.json tĩnh của model, hoặc JSON
  set_config lúc load) thay vì lúc generate — log lần sau (xem model có
  còn lặp ký tự đơn hay không) sẽ xác nhận trực tiếp đúng giả thuyết nào.
- Nếu bản vá NÀY thật sự có tác dụng (model không còn lặp ký tự đơn) —
  đây gần như chắc chắn là nguyên nhân gốc thật sự của toàn bộ chuỗi
  "không tạo được chương" từ đầu hội thoại — không chỉ mục AC-AJ.


## AM. Mục AL gây TREO — `set_config()` lần 2 lúc generate (thêm sampler mới vào pipeline đã dựng) không an toàn. Chuyển `mixed_samplers` sang lúc load (2026-09-12)

### Bằng chứng
Log gửi ngay sau khi build mục AL: mọi bước đều đúng như kỳ vọng
(`mixed_samplers` có mặt trong JSON, `set_config` trả về `true`) —
nhưng dừng hẳn ở dòng `CHUAN BI goi llm->response()`, **không có bất kỳ
dòng log nào tiếp theo**, kể cả sau thời gian dài. Khác hẳn MỌI lần test
trước (luôn có dòng kết thúc — xong/bị cắt/bị huỷ) — đây là dấu hiệu
`llm->response()` bị TREO THẬT, không sinh được token nào để kích hoạt
bất kỳ log/kiểm tra nào khác (kể cả nút Huỷ mục AG — cờ huỷ cũng chỉ
được kiểm tra khi có token mới, xem mục AK).

### Nguyên nhân — đúng nghi vấn đã tự ghi ở "Giới hạn thật" mục AL
Mục AL đặt `mixed_samplers` vào `set_config()` gọi LÚC GENERATE — tức
SAU KHI `load()` đã dựng xong pipeline sampler từ config lúc nạp model.
Tra thêm tài liệu chính thức MNN (release notes 3.5.0, mục "Sampler
Pipeline Refactor") xác nhận: pipeline sampler được thiết kế để dựng từ
cấu hình lúc khởi tạo, không phải để THÊM MỘT SAMPLER MỚI vào giữa
chừng qua 1 lệnh set_config thứ hai — hành vi này không được tài liệu
mô tả rõ, và log thật cho thấy nó không an toàn (treo, không phải bị
bỏ qua êm đẹp như kỳ vọng ban đầu).

### Bản vá
Chuyển `mixed_samplers` sang đặt tại `mnn_bridge.cpp`, trong CHÍNH JSON
gọi `set_config()` TRƯỚC `llmSlot->load()` — đúng thời điểm pipeline
sampler được dựng LẦN ĐẦU, cho cả 3 nhánh backend (OpenCL — nhánh THẬT
SỰ đang dùng theo mọi log; QNN; CPU fallback). Bỏ hẳn `mixed_samplers`
khỏi JSON phía Kotlin lúc generate — không giữ đồng thời 2 nơi khi rủi
ro gây treo chưa hiểu hết hoàn toàn.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc `(){}[]`.
- **Chưa chắc chắn đặt lúc load có hết treo hay không** — đây là suy
  luận hợp lý nhất (đúng cách tài liệu MNN mô tả: cấu hình trước, load
  sau), nhưng chưa có bằng chứng runtime xác nhận. Nếu build mucAM vẫn
  treo y hệt ở đúng chỗ này, đó là bằng chứng bác bỏ giả thuyết "set_config
  lần 2 là nguyên nhân" — khi đó nghi vấn chuyển sang chính bản thân
  sampler "penalty" (vd cần `penalty_window` > 0, hiện đang là 0 trong
  config.json của model, chưa từng thử đổi) hoặc phiên bản MNN thật sự
  được build (dù `git clone --depth 1` luôn lấy HEAD master, build.yml
  KHÔNG in ra ngày commit, chỉ in hash — chưa đối chiếu được hash đó với
  đúng ngày phát hành 3.5.0 để loại trừ hẳn khả năng lệch phiên bản).
- Nếu mucAM hết treo NHƯNG lặp ký tự đơn vẫn tái diễn — xác nhận "penalty"
  sampler có chạy nhưng không đủ mạnh/không đúng cách chặn lặp cho model
  này — bước tiếp theo là thử tăng thêm `penalty_window` (hiện = 0) lên
  1 giá trị dương, hoặc bật `n_gram`/`ngram_factor` (hiện gần như vô
  hiệu: n_gram=8 nhưng ngram_factor=1.0 = không phạt thêm).
- Nếu mucAM hết treo VÀ hết lặp ký tự đơn — xác nhận dứt điểm toàn bộ
  chuỗi nguyên nhân từ mục AL, đây là bản vá đúng.


## AN. Mục AM không build được — lỗi cú pháp C++ (2026-09-12)

GitHub Actions build #129 thất bại thật ở bước biên dịch (không phải
runtime): `buildOptimizedOpenCLConfig()` cộng thẳng 2 chuỗi ký tự thô
liền nhau (`R"(...)" + R"(...)"`) — C++ không có `operator+` cho
`const char[N] + const char[M]` (mảng phân rã con trỏ, cộng 2 con trỏ vô
nghĩa). Bản gốc (trước mục AM) hợp lệ vì literal đầu cộng thẳng với
`tmpPathPart` (`std::string`) ngay sau; chèn thêm 1 literal mới vào
giữa phá vỡ điều đó. Sửa: bọc `std::string(...)` quanh literal đầu tiên
— mọi phép + phía sau có 1 bên là `std::string`, hợp lệ trở lại, nội
dung JSON không đổi. Chưa xác nhận build lại có qua được bước biên dịch
hay không (không có Flutter/NDK trong môi trường sửa file) — đây là lỗi
CÚ PHÁP thuần tuý, tự tin cao hơn các bản vá suy đoán hành vi runtime
trước đó, nhưng vẫn cần build thật để xác nhận dứt điểm.


## AO. Build qua được (mục AN đúng) — nhưng lặp vẫn xảy ra: model sinh "#" rồi lặp "F" vô hạn ngay từ ký tự thứ 2. Thêm log xác nhận nội dung config OpenCL thật (2026-09-13)

### Bằng chứng
Log 2026-09-13T02:38-02:52: build `mucAN` chạy được, không còn treo/lỗi
build. Dòng `[MAU LAP THAT]` (thêm ở mục AI) LẦN ĐẦU cho thấy nội dung
thật: model sinh đúng 1 dấu `#` rồi lặp `F` liên tục cho tới khi bị cắt
(315-347 ký tự, ~14.4 phút — STEADY=WALL, máy không ngủ). Ngưỡng mới
320 (mục AI/AJ) có tác dụng thật — trước kia cắt ở 60, giờ cắt ở
315-347 — nhưng KHÔNG hề ngăn được việc LẶP BẮT ĐẦU: toàn bộ nội dung
tích luỹ đã cắt CHỈ có "#" + hàng loạt "F", không có đoạn văn xuôi hợp
lệ nào trước đó — nghĩa là model rơi vào lặp NGAY TỪ KÝ TỰ THỨ 2, chỉ
là giờ mất lâu hơn để tích đủ số ký tự cho bộ dò kết luận.

### Vấn đề còn treo lơ lửng — chưa xác nhận được
Không có bằng chứng trực tiếp trong log này cho biết `"penalty"` trong
`mixed_samplers` (mục AL, chuyển sang lúc load ở mục AM) có thật sự
được gửi vào `set_config()` lúc `load()` hay không — dòng log cũ
(`buildOptimizedOpenCLConfig: slot 0 dang doi model...`) không in ra
NỘI DUNG chuỗi JSON thật, chỉ in tên hàm. Nếu penalty THẬT SỰ đã chạy
mà vẫn lặp y hệt kiểu cũ (# rồi F ngay lập tức) — nghĩa là
`repetition_penalty: 1.15` không đủ mạnh để thắng 1 phân bố xác suất
cực kỳ lệch (model gần như chắc chắn 100% chọn "F" sau "#F") — đây là
dấu hiệu vấn đề GỐC RỄ hơn sampler: có thể do lượng tử hoá q4 quá mạnh,
`precision: "low"`/`memory: "low"` trong config.json của model, hoặc
chính model này (thử nghiệm/ít người dùng) có xu hướng lỗi này với
prompt dài — KHÔNG chắc còn nằm trong phạm vi sửa được bằng tinh chỉnh
sampler nữa.

### Bản vá — chỉ thêm log, CHƯA đổi thêm tham số nào
Cố tình KHÔNG vội tăng thêm `penalty_window`/`ngram_factor`/
`repetition_penalty` trong cùng lượt này — mỗi lần test tốn ~15-20 phút
(build+cài+chờ), đổi nhiều biến 1 lúc sẽ không biết biến nào có tác
dụng. Chỉ thêm 1 dòng log tại `nativeLoadModel` (nhánh OpenCL, nhánh
THẬT đang dùng): in ra NGUYÊN VĂN chuỗi JSON gửi vào `set_config()`
ngay trước khi gửi — lần chạy kế tiếp sẽ biết chắc `mixed_samplers` có
mặt hay không, khép lại nghi vấn còn treo ở mục AM.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- Đây là bước CHẨN ĐOÁN THUẦN TUÝ — không kỳ vọng bản build này hết lặp
  (không đổi tham số nào có thể ảnh hưởng hành vi sinh). Mục đích DUY
  NHẤT là xác nhận 1 dữ kiện còn thiếu, để bước tiếp theo (dù là tăng
  `penalty_window`, đổi model, hay hướng khác hẳn) dựa trên bằng chứng
  thay vì suy đoán thêm.
- Nếu log kế tiếp xác nhận `mixed_samplers` CÓ mặt đúng trong config gửi
  đi mà vẫn lặp y hệt — hướng tiếp theo hợp lý nhất: thử
  `penalty_window` > 0 (hiện = 0, ý nghĩa thật sự trong bản MNN đang
  build vẫn CHƯA xác nhận được — có thể là "không giới hạn", có thể là
  "vô hiệu"), hoặc chấp nhận đây là giới hạn của chính model/lượng tử
  hoá này, cần thử model khác để đối chứng.


## AP. NGUYÊN NHÂN GỐC THẬT SỰ CỦA TOÀN BỘ CHUỖI "lặp ký tự đơn" (mục AC→AO) — thiếu khuôn chat Llama 3 mà chính model yêu cầu. Xác nhận bằng thực nghiệm chéo qua màn Chat (2026-09-13)

### Cách tìm ra — người dùng phản biện đúng, buộc quay lại kiểm chứng thay vì kết luận vội
Sau mục AO (nghi ngờ "có thể là giới hạn model/lượng tử hoá, không sửa
được bằng tham số nữa"), người dùng phản biện: "nếu do model thì sao
trước đó dùng cho khung chat thì bình thường?" — đúng, và là câu hỏi
lẽ ra phải tự đặt ra sớm hơn. Kiểm chứng lại bằng thực nghiệm CHÉO (không
suy đoán): yêu cầu người dùng dán 1 đoạn văn bản DÀI (~2500+ ký tự,
chính là đoạn giải thích của tôi ở lượt trước, hoàn toàn không liên quan
viết truyện) vào THẲNG màn Chat. Kết quả: Chat — vốn "trước giờ bình
thường" — **CŨNG lặp "F" liên tục ngay khi nhận prompt dài**, y hệt
"Đắp thịt". Đây là bằng chứng KHÔNG THỂ CHỐI CÃI: lỗi không nằm ở màn
hình nào, không nằm ở model/lượng tử hoá tự nó, mà nằm ở ĐIỂM CHUNG của
cả 2 đường gọi khi prompt đủ dài.

### Nguyên nhân thật — tra trang model chính thức
`https://huggingface.co/OccultAI/Morpheus-8B-v1` (base:
`nvidia/Llama-3.1-Nemotron-8B-UltraLong-1M-Instruct` — bản fine-tune
RIÊNG cho ngữ cảnh cực dài) ghi rõ trong cảnh báo đầu trang:
> "Adjust your system prompt accordingly, and use Llama 3 chat
> template."

Model này được huấn luyện để nhận đúng khuôn hội thoại Llama 3
(`<|begin_of_text|>`, `<|start_header_id|>role<|end_header_id|>`,
`<|eot_id|>`) — không phải văn bản thô nối liền. Xác nhận qua chính code:
`mnn_bridge.cpp` gọi `llm->response(promptStr, &streamingOut, nullptr, -1)`
— nhận NGUYÊN VĂN 1 chuỗi, KHÔNG có tham số vai trò (system/user/
assistant) nào — MNN không tự áp khuôn chat, bên gọi (app) phải tự ghép
đúng token đặc biệt vào TRƯỚC khi gửi. `local_provider.dart` (dùng
CHUNG cho mọi luồng — chat, viết chương, dịch) trước giờ chỉ ghép
`'$systemPrompt\n\n$userPrompt'` — không hề có ranh giới hệ thống/người
dùng/trợ lý nào cả.

**Vì sao câu ngắn "có vẻ" ổn còn câu dài thì sụp:** không có token ranh
giới, model phải TỰ ĐOÁN đâu là chỗ nó nên bắt đầu trả lời — với input
ngắn, không gian đoán sai nhỏ, model còn "gồng" ra được câu trả lời tạm
chấp nhận được; với input dài/phức tạp (Bible + outline + văn phong +
hướng dẫn dồn 1 khối, hoặc bất kỳ đoạn dài nào dán vào chat), không gian
đoán sai lớn hơn hẳn, model mất phương hướng và sụp thành lặp 1 token có
xác suất cao nhất (khớp đúng lý thuyết chung: dùng sai/thiếu chat
template gây "suy giảm chất lượng nghiêm trọng, âm thầm", càng rõ khi
input phức tạp).

### Vì sao đây khác về CHẤT so với mọi mục AC→AO trước
Toàn bộ chuỗi AC-AO tìm và sửa các vấn đề THẬT nhưng đều là PHỤ:
- AC-AH: `repetitionPenalty` không tới đúng nơi/giá trị — thật, đã sửa
  xong, nhưng không phải nguyên nhân của "lặp".
- AI-AJ: ngưỡng bộ dò quá sát — thật, đã sửa, chỉ trì hoãn phát hiện.
- AL-AO: sampler "penalty" chưa từng chạy — RẤT có thể vẫn thật (chưa
  xác nhận dứt điểm qua log mục AO), nhưng ngay cả khi đúng và đã sửa,
  KHÔNG đủ để cứu 1 model bị mất phương hướng vì thiếu khuôn chat —
  không có mức phạt lặp nào cứu được model đã "không biết nó đang ở
  đâu trong cuộc hội thoại".

Mục AP mới là nguyên nhân Ở TẦNG ĐÚNG — không phải tham số sampler, mà
là ĐỊNH DẠNG ĐẦU VÀO cơ bản nhất, ảnh hưởng MỌI lệnh generate (chat,
viết chương, dịch, tóm tắt nền) dùng `LocalLlamaProvider`.

### Bản vá
`local_provider.dart` (`generateStream()`, đúng nơi ghép prompt cuối
cùng gửi native — sửa CHUNG 1 chỗ, áp dụng cho MỌI luồng gọi): thay
`'$systemPrompt\n\n$userPrompt'` bằng đúng khuôn Llama 3 Instruct:
```
<|begin_of_text|><|start_header_id|>system<|end_header_id|>

{systemPrompt}<|eot_id|><|start_header_id|>user<|end_header_id|>

{userPrompt}<|eot_id|><|start_header_id|>assistant<|end_header_id|>

```
(bỏ khối system nếu `systemPrompt` rỗng — đúng trường hợp
`useNovelPersona=false` ở chat). `main.dart`: build tag → `mucAP_2026-09-13`.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- **Áp CỨNG khuôn Llama 3 — chỉ đúng cho MODEL NÀY.** Nếu người dùng sau
  này đổi sang model khác dùng khuôn chat khác (ChatML `<|im_start|>`,
  Alpaca, Gemma...), đoạn code này cần đổi theo hoặc chuyển thành cấu
  hình theo từng model (mỗi local model đã có sẵn 1 dòng trong DB —
  có thể thêm cột `chat_template` sau này) — CHƯA làm ở mức tổng quát
  đó, ngoài phạm vi đủ bằng chứng để sửa ngay bây giờ.
- **Chưa xác nhận `<|begin_of_text|>` có gây trùng BOS token hay không**
  — nếu tokenizer của model tự động thêm BOS khi encode (hành vi phổ
  biến), việc gõ thẳng chuỗi `<|begin_of_text|>` vào văn bản có thể tạo
  ra 2 BOS liên tiếp nếu tokenizer coi đây là văn bản thường (không nhận
  diện là token đặc biệt) thay vì 1 token duy nhất — cần log thật (số
  token đầu vào thực tế) để xác nhận, chưa có cách kiểm tra tĩnh.
- Nếu bản vá NÀY thật sự hết lặp — xác nhận dứt điểm đây mới là nguyên
  nhân gốc thật của toàn bộ chuỗi "không tạo được chương" từ đầu hội
  thoại, không phải bất kỳ mục AC-AO nào trước đó (dù các mục đó vẫn là
  sửa lỗi thật, chỉ không phải lỗi CHÍNH).


## AQ. Thay hardcode Llama 3 (mục AP) bằng giải pháp TỔNG QUÁT — bật `use_template`, để MNN tự đọc đúng khuôn của TỪNG model (2026-09-13)

### Vì sao đổi — góp ý đúng của người dùng
Người dùng chỉ ra: hardcode khuôn Llama 3 thẳng vào code (mục AP)
"chẳng khác nào hardcode" — đúng, và sẽ hỏng ngay khi người dùng thêm 1
model khác dùng khuôn chat khác (ChatML, Alpaca, Gemma...). Tra lại tài
liệu chính thức MNN (đầy đủ, bản 3.2.2) xác nhận CÓ giải pháp tổng quát
sẵn có, không cần app tự biết/đoán khuôn của từng model.

### Cơ chế thật của MNN (xác nhận qua tài liệu chính thức + ví dụ thật)
`llmexport.py` — công cụ DUY NHẤT, CHÍNH THỨC để xuất model sang định
dạng MNN — tự động trích khuôn chat GỐC của model nguồn (đọc
`chat_template` trong `tokenizer_config.json` của HuggingFace) và ghi
sẵn vào `llm_config.json` (file LUÔN đi kèm mọi model MNN, kể cả model
đang dùng — "llm_config.json (5187 byte)" thấy trong mọi log từ đầu hội
thoại) ở trường `prompt_template`. Ví dụ thật (từ chính các model MNN
công khai trên HuggingFace):
- Llama-3.2-1B-Instruct-MNN: `"<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n%s<|eot_id|>..."`
- SmolLM2-135M-Instruct-MNN: `"<|im_start|>system\n...<|im_end|>\n<|im_start|>user\n%s<|im_end|>\n<|im_start|>assistant\n"`
- Qwen-VL-Chat-MNN: `"\n<|im_start|>user\n%s<|im_end|>\n<|im_start|>assistant\n"`

Mỗi model — mỗi khuôn khác nhau, ĐÚNG cho model đó, không cần app biết
trước. MNN có cờ `use_template` (không có trong bảng tham số chính thức
nhưng xác nhận tồn tại qua ví dụ triển khai thật — PlayTranslate, 1 app
dịch thuật dùng MNN, ghi rõ `"use_template": false` để CHỦ ĐỘNG bỏ qua
cơ chế này cho 1 model không có chat_template) — khi bật, MNN tự đọc
`prompt_template` của model đang nạp và tự bọc đúng khuôn quanh nội
dung gửi vào, không cần app tự ghép token đặc biệt nào.

### Bản vá
1. `mnn_bridge.cpp`: thêm `"use_template": true` vào JSON `set_config()`
   gọi lúc LOAD (cả 3 nhánh OpenCL/QNN/CPU — cùng nơi mục AM đặt
   `mixed_samplers`).
2. `local_provider.dart`: BỎ hoàn toàn đoạn hardcode khuôn Llama 3 (mục
   AP) — quay lại gửi thẳng `'$systemPrompt\n\n$userPrompt'` như bản gốc,
   để MNN tự bọc khuôn đúng cho model đang nạp.
3. `main.dart`: build tag → `mucAQ_2026-09-13`.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- **`use_template` không có trong bảng tham số chính thức của tài liệu
  MNN 3.2.2** — chỉ xác nhận tồn tại qua 1 ví dụ triển khai thật bên
  ngoài (PlayTranslate). Có rủi ro (dù thấp) là tham số này không tồn
  tại/bị đổi tên ở đúng bản MNN mà `build.yml` build (luôn là HEAD mới
  nhất của master, xem mục AO) — nếu vậy, MNN sẽ ÂM THẦM bỏ qua tham số
  lạ (hành vi phổ biến khi parse JSON config), không gây lỗi build/crash,
  chỉ đơn giản là không có tác dụng — cần log thật (hoặc quan sát kết
  quả sinh) để xác nhận.
- **`prompt_template` chỉ có 1 chỗ `%s`** — không phân biệt riêng
  system/user. Cách app đang làm (gộp `systemPrompt + "\n\n" + userPrompt`
  thành 1 khối rồi để MNN bọc khối đó vào đúng vị trí `%s`) là cách dùng
  hợp lý nhất với cơ chế 1-chỗ-trống này, nhưng nếu model có
  `prompt_template` với 1 system message CỐ ĐỊNH bọc sẵn trong khuôn (như
  ví dụ SmolLM2 ở trên), hệ thống prompt động của Bible/RAG app tự tạo
  có thể bị đặt SAI VỊ TRÍ (vào đúng chỗ user, không phải system thật) —
  chưa có cách tổng quát nào xử lý trường hợp này, ngoài phạm vi sửa
  ngay bây giờ.
- Nếu bản vá NÀY hết lặp — xác nhận đúng hướng tổng quát, không cần
  hardcode theo từng model. Nếu KHÔNG hết lặp (vd do đúng rủi ro
  `use_template` không tồn tại/bị bỏ qua âm thầm ở bản MNN thật) — quay
  lại cách hardcode mục AP vẫn còn nguyên trong lịch sử git, có thể khôi
  phục làm giải pháp tạm trong lúc chờ xác nhận thêm.


## AR. Thay mục AQ (đoán `use_template`+gộp chuỗi) bằng giải pháp ĐÚNG CHUẨN MNN — tham số `system_prompt` riêng biệt, xác nhận qua app chính thức MnnLlmChat (2026-09-13)

### Vì sao đổi tiếp — người dùng phản biện đúng lần thứ 2
Sau mục AQ, người dùng hỏi thẳng: "MNN Chat và công nghệ MNN chả lẽ
không tính đến chuyện này, có thực sự tra cứu kỹ chưa?" — đúng, mục AQ
mới chỉ suy luận từ 1 field `prompt_template` (dạng `%s`) tìm thấy tình
cờ, CHƯA tra tới app CHÍNH THỨC của chính đội MNN. Tra tiếp, tìm ra:

1. `apps/Android/MnnLlmChat` — app Android CHÍNH THỨC do đội MNN xây,
   README_CN.md ghi rõ lịch sử cập nhật: "Đã thêm trang Cài đặt, cho
   phép tuỳ chỉnh sampler type, **system prompt**, max new token...".
   → MNN có tham số CẤU HÌNH riêng tên `system_prompt` — không phải nhét
   chung vào 1 chuỗi rồi hy vọng khuôn `%s` xử lý đúng.
2. Release notes MNN (bản gần đây): "Tokenizer Refactor: ... minja →
   jinja template engine migration ... aligned with HuggingFace
   Transformers implementation" — xác nhận MNN đã chuyển hẳn sang dùng
   **Jinja thật** (không phải template `%s` đơn giản như ví dụ
   `llm_config.json` cũ tìm thấy ở mục AQ, có thể từ bản MNN trước khi
   nâng cấp này). Jinja thật xử lý ĐÚNG cấu trúc `messages` có role
   (system/user/assistant) theo đúng `chat_template` gốc của từng model
   — kể cả các trường hợp phức tạp (model không cần system, hay có system
   cố định sẵn) mà 1 chỗ trống `%s` đơn giản không thể diễn đạt đúng.

### Bản vá
Tách hẳn `systemPrompt` ra khỏi việc ghép chuỗi `prompt`:
1. `local_provider.dart`: gửi `'prompt': userPrompt` (CHỈ nội dung
   người dùng/tự động, không tự ghép `\n\n` với systemPrompt nữa) +
   `'systemPrompt': systemPrompt` (field mới, riêng biệt).
2. `MnnBridge.kt`: đọc `systemPrompt`, đưa vào `configJson` dưới khoá
   `system_prompt` (đúng tên tham số chính thức của MNN) — CHỈ khi
   không rỗng, tránh ghi đè bằng chuỗi rỗng cho các lệnh không cần.
3. `mnn_bridge.cpp`: **không cần sửa** — tầng này đã tổng quát sẵn,
   chuyển tiếp NGUYÊN VẸN bất kỳ JSON nào Kotlin gửi vào
   `llm->set_config(configStr)`, tự động bao gồm `system_prompt` mới mà
   không cần biết trước field đó tồn tại.
4. `main.dart`: build tag → `mucAR_2026-09-13`.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- **Chưa xác nhận `set_config()` gọi LÚC GENERATE (sau lúc load, cùng
  lệnh gọi `set_config` mang `temperature`/`top_p`/giờ thêm
  `system_prompt`) có áp dụng đúng `system_prompt` MỖI LẦN gọi lại
  (system prompt đổi theo từng novel/RAG context) hay chỉ đọc 1 LẦN lúc
  load — giống hệt nghi vấn chưa giải quyết ở mục AL/AM về việc set_config
  lần 2 có thay đổi được cấu trúc pipeline hay không. Khác ở chỗ:
  `system_prompt` nhiều khả năng chỉ là 1 GIÁ TRỊ (không phải cấu trúc
  pipeline mới như sampler), nên rủi ro treo thấp hơn hẳn — nhưng vẫn cần
  log thật để xác nhận nó THẬT SỰ đổi theo từng lần gọi, không bị "đóng
  băng" từ lúc load.
- Vẫn giữ nguyên `use_template: true` (mục AQ) — cần thiết để MNN áp
  dụng chat_template nói chung; `system_prompt` là tham số BỔ SUNG cho
  đúng nội dung system, không thay thế cờ đó.
- Nếu bản vá NÀY hết lặp — xác nhận đây là cách làm ĐÚNG CHUẨN, tổng
  quát cho mọi model, không cần biết trước khuôn chat cụ thể của model
  nào. Nếu vẫn lặp — quay lại nghi vấn ở mục AO (bản MNN thật đang build
  có hỗ trợ đầy đủ các tham số này hay không, do build luôn lấy HEAD mới
  nhất của master, chưa đối chiếu được hash commit cụ thể).


## AS. REVERT mục AR — bằng chứng chéo model (Qwen 7B) chỉ đích danh nguyên nhân hồi quy thật. Sửa luôn nhận diện SAI kiến trúc model ở mục AP (2026-09-13)

### Bằng chứng quyết định — từ chính người dùng, đối chiếu với phân tích độc lập của DeepSeek
Người dùng đưa log/tài liệu cho 1 AI khác (DeepSeek) phân tích song song, rồi đối chiếu
kết quả. Cả 2 hướng hội tụ về cùng 1 kết luận, nhờ 1 quan sát mấu chốt của chính người
dùng: **model Qwen2.5-7B-Instruct-Uncensored-MNN — kiến trúc, khuôn chat HOÀN
TOÀN KHÁC model 8B đang debug — trước kia vẫn sinh văn đúng Bible với prompt dài,
CÙNG NGÀY hôm nay (2026-09-13, đúng ngày mục AP→AQ→AR) cũng ra rác.**

Đây là bằng chứng mạnh nhất có thể có cho loại lỗi này: 1 hồi quy xảy ra ĐỒNG THỜI trên
2 model khác kiến trúc, khác khuôn chat, chỉ chung đúng 1 điểm — cùng đi qua
`generateStream()`, cùng bị đổi bởi các mục sửa trong ngày. Điều này **loại trừ hẳn** giả
thuyết "sai khuôn chat riêng cho model 8B" (mục AP) làm nguyên nhân CHÍNH — vì Qwen
dùng khuôn ChatML, không liên quan gì tới việc model 8B là Llama hay Hunyuan.

### Nguyên nhân thật — mục AR, không phải AP
Duy nhất 1 thay đổi trong ngày ảnh hưởng ĐỀU tới mọi model: mục AR (tách `systemPrompt`
ra khỏi `prompt`, gửi qua field cấu hình riêng `system_prompt`). Giả thuyết khớp nhất:
**MNN bản đang build (`git clone --depth 1` HEAD master, chưa đối chiếu được hash cụ
thể — xem mục AO) không thực sự đọc field `system_prompt` này** (dù tham số này có
thật, xác nhận qua changelog MnnLlmChat — nhưng "có tồn tại trong 1 số bản MNN" khác
với "được bản ĐANG BUILD hỗ trợ đúng"). Hệ quả: toàn bộ Story Bible + văn phong +
hướng dẫn (nội dung `systemPrompt`) bị ÂM THẦM MẤT HẲN khỏi request — model chỉ còn
nhận đúng outline trơ trọi, mất hết ngữ cảnh, sụp thành lặp — xảy ra NHƯ NHAU ở mọi
model, đúng khớp bằng chứng chéo.

### Sửa luôn 1 lỗi khác — nhận diện SAI kiến trúc model ở mục AP
Người dùng gửi ảnh `llm_config.json` THẬT của model 8B — xác nhận kiến trúc là
**`hunyuan_v1_dense`** (Tencent Hunyuan), với token đặc biệt riêng
(`<|hy_begin_of_sentence|>`, `<|hy_User|>`, `<|hy_Assistant|>`...) — **KHÔNG PHẢI
Llama 3** như mục AP từng khẳng định. Nguồn gốc sai lầm: mục AP dựa vào 1 kết quả tìm
kiếm web (trang HuggingFace "OccultAI/Morpheus-8B-v1" nói "use Llama 3 chat
template") — rất có thể kết quả tìm kiếm đó khớp NHẦM sang 1 model trùng tên/tương tự,
không phải đúng model thật trên máy người dùng. Bài học: **khi có file cấu hình THẬT
trên máy, luôn ưu tiên đọc trực tiếp file đó hơn tin vào kết quả tìm kiếm web** — nhất là
với tên model dễ trùng/dễ nhầm như "Morpheus"/"8B".

May mắn: sai lầm này không gây hậu quả thật, vì mục AQ đã thay thế hoàn toàn cách
hardcode của mục AP bằng `use_template: true` (tổng quát, không cần biết trước kiến trúc
model) trước khi build nào thật sự chạy với khuôn Llama 3 sai đó.

### Bản vá
1. `local_provider.dart`: revert mục AR — gộp lại `systemPrompt + "\n\n" + userPrompt`
   thành 1 chuỗi gửi qua field `prompt` duy nhất (giống hệt trước mục AP), đảm bảo ngữ
   cảnh KHÔNG BAO GIỜ bị mất dù MNN có đọc được field `system_prompt` riêng hay
   không.
2. `MnnBridge.kt`: bỏ hẳn việc đọc/forward `systemPrompt`/`system_prompt` — dọn code
   chết, không để lại nhánh không còn được gọi tới.
3. **Cố tình GIỮ NGUYÊN** `use_template: true` (mục AQ, đặt lúc LOAD trong
   `mnn_bridge.cpp`) — đây là cờ tổng quát, không đổi giữa mục AQ (lúc Qwen còn CHƯA
   xác nhận hỏng) và mục AR (lúc hỏng), không phải điểm chung gây hồi quy chéo model.
   Nếu MNN áp dụng đúng, nó sẽ tự bọc khuôn đúng (Hunyuan cho model 8B, ChatML cho
   Qwen, hay bất kỳ khuôn nào) quanh CHÍNH nội dung gộp này.
4. `main.dart`: build tag → `mucAS_2026-09-13`.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- **Chưa build/test lại với Qwen 7B để xác nhận revert này THẬT SỰ khôi phục hành vi
  đúng** — đây là bước xác nhận quan trọng nhất, quyết định giả thuyết mục AS đúng hay
  sai.
- Nếu revert NÀY hết lặp (cả 2 model) — xác nhận đúng dứt điểm: `system_prompt` field
  không được MNN bản build hỗ trợ, và `use_template` (khi có nội dung gộp đầy đủ) là đủ
  để giải quyết vấn đề — không cần biết trước kiến trúc/khuôn của bất kỳ model nào.
- Nếu vẫn lặp — bác bỏ giả thuyết mục AS, cần quay lại xem xét `use_template` tự nó có
  hoạt động hay không (nghi vấn gốc từ mục AQ, chưa từng được xác nhận trực tiếp), hoặc
  các nghi phạm tầng thấp hơn mà phân tích DeepSeek đề cập (thread_num, precision,
  memory trong OpenCL config) — dù các nghi phạm đó khó khớp với bằng chứng "prompt
  ngắn luôn ổn, dài mới hỏng" bằng giả thuyết mất system_prompt.


## AT. Mục AS KHÔNG đủ — model 8B/Hunyuan vẫn lặp F, người dùng tự mắt thấy nhưng log trống vì lỗ hổng: chỉ ghi nội dung khi bộ dò TỰ ĐỘNG phát hiện, không ghi khi người dùng tự Huỷ. Sửa lỗ hổng log (2026-09-14)

### Bằng chứng
Log build `mucAS_2026-09-13` (đã revert mục AR, gộp lại prompt đầy đủ 3388 ký tự — xác
nhận đúng qua log) — người dùng tự bấm Huỷ ở giây thứ ~150 (56 ký tự), log ghi
`nguoi dung/he thong yeu cau huy` — KHÔNG có dòng `[MAU LAP THAT]`. Người dùng xác
nhận trực tiếp: **tự mắt thấy nhiều chữ F lặp trên màn hình trước khi bấm Huỷ** — tức
model 8B/Hunyuan VẪN lặp y hệt, dù mục AS đã khôi phục đầy đủ ngữ cảnh.

### 2 phát hiện tách biệt
1. **Lỗ hổng log (đã sửa ngay)**: dòng ghi nội dung thật (thêm ở mục AI) có điều kiện
   `if (reason chứa "lap vo tan")` — CHỈ chạy khi bộ dò tự động phát hiện, bỏ sót hoàn
   toàn trường hợp người dùng tự bấm Huỷ. Đây chính xác là lúc CẦN thấy nội dung nhất —
   người dùng chỉ bấm Huỷ SAU KHI tự mắt thấy bất thường. Đã bỏ điều kiện lọc, ghi nội
   dung ở MỌI trường hợp dừng sớm.
2. **Mục AS chưa giải quyết được vấn đề cho model 8B/Hunyuan** — dù giả thuyết (system_prompt
   field không được đọc) có cơ sở thật và bằng chứng chéo model mạnh, việc gộp lại
   prompt đầy đủ KHÔNG ngăn được model này lặp F. Đây là bằng chứng TRỰC TIẾP (không
   phải suy luận) — quan trọng hơn suy luận gián tiếp trước đó.

### Câu hỏi còn treo — CHƯA có câu trả lời, cần 1 thực nghiệm cụ thể
Toàn bộ hội thoại, từ đầu tới giờ, **CHƯA CÓ LẦN NÀO** người dùng thực sự đổi sang model
Qwen 7B để test với code hiện tại (mọi lần test đều dùng đúng model 8B/Hunyuan
`OccultAI-Morpheus-8B-v2-MNN-q4-chinh`, xem lại toàn bộ `modelPath` trong log từ đầu hội
thoại). Bằng chứng "Qwen 7B trước kia ổn" (dẫn tới mục AS) là TRÍ NHỚ của người dùng về
hành vi CŨ, không phải 1 lần test THẬT với code hiện tại. Đây là khoảng trống lớn nhất
hiện tại: **chưa biết liệu vấn đề chỉ riêng model 8B/Hunyuan, hay ảnh hưởng cả Qwen 7B
với code bây giờ.**

### Bản vá
`mnn_bridge.cpp`: bỏ điều kiện lọc theo lý do dừng — ghi `[NOI DUNG LUC DUNG SOM]` +
toàn bộ nội dung tích luỹ ở MỌI trường hợp dừng sớm (tự động phát hiện lặp HAY người
dùng tự Huỷ). `main.dart`: build tag → `mucAT_2026-09-14`.

### Việc cần làm tiếp — thực nghiệm, không phải suy đoán thêm
**Đổi sang model Qwen 7B, thử "Đắp thịt" với prompt dài y hệt, dùng đúng bản build
mucAT này.** Đây là thực nghiệm sạch nhất, chưa từng làm, cho biết dứt điểm:
- Qwen 7B vẫn ổn → xác nhận vấn đề CHỈ riêng model 8B/Hunyuan (có thể `use_template`
  không thực sự áp dụng đúng khuôn Hunyuan cho model này — hướng tiếp theo: hardcode
  RIÊNG khuôn Hunyuan CHỈ khi phát hiện `model_type: hunyuan_v1_dense` trong
  `llm_config.json`, không áp dụng cho model khác).
- Qwen 7B CŨNG lặp → bác bỏ hẳn giả thuyết "riêng model 8B" và giả thuyết mục AS —
  vấn đề nằm ở tầng chung hơn (backend OpenCL, `thread_num`/`precision`/`memory`, hoặc
  `use_template` không hoạt động ở bất kỳ model nào) — quay lại các nghi phạm DeepSeek
  từng nêu, đã bị gác lại vì khớp kém hơn giả thuyết system_prompt tại thời điểm đó.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- Log lần sau, dù dừng bằng cách nào, sẽ luôn có nội dung thật — không còn phải đoán
  "có lặp hay không" từ việc người dùng tự mô tả lại nữa.


## AU. Test đúng 1 biến — tắt `use_template` (nghi vấn còn lại duy nhất). Đồng thời thêm cơ chế dự phòng cho `build.yml`: build bằng MNN mới nhất trước, chỉ rơi xuống bản ổn định nếu lỗi (2026-09-14)

### Bối cảnh — 2 việc riêng biệt trong cùng 1 lượt

**Việc 1 — build #133 thất bại thật, không do code app:** lỗi ở bước CMake cấu
hình CHÍNH KHO MNN (`test/CMakeLists.txt`, thiếu dấu đóng ngoặc, hết file) —
file của bên thứ ba (alibaba/MNN), xảy ra TRƯỚC khi chạm tới code app.
`build.yml` dùng `git clone --depth 1` từ `master`, luôn lấy đúng HEAD tại
thời điểm build — lợi thật (luôn có tính năng mới, ví dụ chính "penalty"
trong `mixed_samplers` chỉ có từ bản 3.5.0) nhưng cũng phụ thuộc vào việc
master không lỗi tạm thời đúng lúc build chạy.

Theo đúng yêu cầu người dùng ("không đánh đổi bản mới nhất, làm fallback"):
đã thêm cơ chế dự phòng ở `build.yml` — vẫn ưu tiên build bằng bản vừa clone
(master); CHỈ KHI build đó thất bại mới xoá sạch, clone lại đúng 1 tag ổn
định đã biết (**3.6.0**, phát hành chính thức 2026-06, ngay TRƯỚC bản 3.6.1
đang lỗi ở build #133 — đã có sẵn "penalty" trong sampler pipeline từ bản
3.5.0, đủ mới cho mọi tính năng app đang dùng — mục AL/AQ), rồi build lại
đúng 1 lần với bản đó. Ghi rõ ra biến môi trường + log CI bản MNN THẬT SỰ
được dùng để build (`master-HEAD` hay `tag-3.6.0-fallback`) — không còn mù
mờ giữa 2 khả năng khi có sự cố sau này.

**Việc 2 — đối chiếu phân tích độc lập, phát hiện lỗ hổng thật trong lập
luận mục AS:** mục AS tự ghi rõ "cố tình giữ nguyên `use_template: true`"
với lý do "không đổi giữa lúc Qwen còn ổn và lúc hỏng" — nhưng thực ra
**KHÔNG có bằng chứng Qwen từng được test riêng ở đúng giai đoạn chỉ có mục
AQ** (bằng chứng "Qwen từng ổn" chỉ là trí nhớ người dùng về trạng thái
CHUNG trước mục AP, không phải 1 lần test tách biệt xác nhận đúng biến
`use_template`). Đây là lỗ hổng thật trong lập luận, không phải chuyện nhỏ
— đúng theo quy tắc mục 0 (đọc hết, không dừng ở đoạn khớp giả thuyết đầu
tiên).

### Bản vá
1. `mnn_bridge.cpp`: tắt hẳn `use_template` (`true` → `false`) ở cả 4 chỗ
   (OpenCL, QNN, CPU x2) — quay về ĐÚNG trạng thái "trước mục AP", nơi Qwen
   7B chắc chắn hoạt động tốt theo xác nhận trực tiếp của người dùng. Đây
   là biến DUY NHẤT còn khác biệt (mục AC-AH/AI-AJ/AL-AM đều đã có mặt từ
   trước mục AP, không đổi giữa 2 mốc thời gian này).
2. `build.yml`: thêm cơ chế dự phòng build MNN như mô tả ở Việc 1.
3. `main.dart`: build tag → `mucAU_2026-09-14`.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật cả 2 thay đổi — chỉ tự kiểm tra cân bằng ngoặc (C++)
  và tự parse thử bằng thư viện `yaml` Python (`build.yml`, xác nhận cú
  pháp hợp lệ, KHÔNG xác nhận được logic runtime của GitHub Actions).
- Nếu tắt `use_template` mà model 8B/Hunyuan hết lặp — xác nhận đúng nghi
  vấn, và mở ra câu hỏi mới: nếu MNN áp dụng SAI cách khi bật cờ này
  (không phải "không hỗ trợ", mà "hỗ trợ nhưng áp dụng lỗi"), tính năng
  `use_template` có thể cần tránh dùng hẳn với bản MNN hiện tại, dù đây là
  cơ chế TỔNG QUÁT đúng đắn về mặt kiến trúc (mục AQ) — đánh đổi giữa
  "đúng nguyên tắc nhưng có thể lỗi thật" và "không tổng quát nhưng chắc
  chắn an toàn" cần cân nhắc thêm dựa trên kết quả.
- Nếu vẫn lặp dù đã tắt `use_template` — loại trừ hẳn giả thuyết này, cần
  quay lại các nghi phạm tầng thấp hơn (thread_num, precision/memory trong
  OpenCL config) mà phân tích DeepSeek từng nêu — dù các nghi phạm đó khớp
  kém hơn với bằng chứng "prompt ngắn luôn ổn, dài mới hỏng" so với các giả
  thuyết đã thử, đây sẽ là hướng còn lại khi mọi giả thuyết về prompt/
  template/sampler đều đã bị loại trừ bằng thực nghiệm trực tiếp.
- Cơ chế dự phòng `build.yml` chưa test qua 1 lần build thật nào — logic
  bash (`&&` chaining, `set +e`/`set -e`, biến môi trường `$GITHUB_WORKSPACE`/
  `$QNN_SDK_ROOT`) đã được rà kỹ nhưng GitHub Actions có thể có hành vi
  runtime khác biệt tinh vi chưa lường hết được.


## AV. GIẢI PHÁP TỔNG QUÁT THẬT — app tự đọc đúng khuôn chat của TỪNG model từ `llm_config.json` ngay trên máy, không hardcode theo tên model nữa (2026-09-15)

### Vì sao đổi hướng — người dùng chỉ đúng vấn đề gốc của cách tiếp cận cũ
Sau khi có bằng chứng 8B vẫn lặp F và 7B "viết bậy" (2 ảnh chụp màn hình
thật — 8B tự bịa cấu trúc kiểu web đọc truyện tương tác "Đến chương 4/Trở
lại chương 2"; 7B tự bịa 1 nhân vật "Túy Tinh" không hề có trong Bible),
hướng đề xuất là hardcode khuôn ChatML cho Qwen (nhận diện qua tên model
chứa "qwen"). Người dùng hỏi thẳng: *"chả lẽ sau này thêm model khác thì
lại lên đây code và lên GitHub build lại?"* — đúng, đây là vấn đề CĂN BẢN
của cách hardcode theo tên model (mục AP đã hardcode Llama 3, sai hẳn;
hướng hardcode ChatML/Hunyuan theo tên vừa đề xuất tuy đúng hơn nhưng vẫn
cùng lỗi thiết kế: chỉ ăn đúng những model đã biết trước).

### Giải pháp — không đoán, tự đọc thẳng từ máy
Nhắc lại phát hiện đã có từ mục AQ (đọc tài liệu chính thức MNN): công cụ
`llmexport.py` — công cụ DUY NHẤT để xuất BẤT KỲ model nào sang định dạng
MNN — tự động trích đúng khuôn chat GỐC của model đó (từ `chat_template`
trong `tokenizer_config.json` của HuggingFace) và ghi sẵn vào
`llm_config.json` (file LUÔN đi kèm mọi model MNN, đúng riêng cho model
đó) ở trường `prompt_template` — dạng có 1 chỗ trống `%s`. File này đã
NẰM SẴN trên máy người dùng, trong đúng thư mục model — app không cần
đoán, không cần biết trước, chỉ cần ĐỌC.

### Bản vá
`local_provider.dart` (class `LocalLlamaProvider`, có sẵn field
`modelPath` — biết chính xác đang dùng model nào tại runtime):
1. `_readPromptTemplateForModel()`: đọc `$modelPath/llm_config.json`,
   parse JSON, lấy `prompt_template` nếu có (dạng chứa `%s`). Cache theo
   `modelPath` — chỉ đọc file 1 lần/model, không đọc lại mỗi lần
   generate(). Ghi log rõ tìm thấy khuôn gì (hoặc không tìm thấy) cho
   ĐÚNG model đang test — không còn phải suy đoán.
2. `_buildFinalPrompt()`: ghép `systemPrompt + userPrompt` thành 1 khối
   (như trước), rồi nếu đọc được `prompt_template`, thay `%s` bằng khối
   đó — MNN sẽ nhận đúng chuỗi đã có khuôn đúng của model, không cần tự
   áp `use_template` (mục AU vẫn để `false` — không đổi gì ở native, chủ
   động kiểm soát việc áp khuôn hoàn toàn ở tầng Dart, dễ log/xác minh
   hơn để MNN tự làm ngầm).
3. `generateStream()`: gọi `_buildFinalPrompt()` thay vì tự ghép thô như
   mục AS.

**Thêm model mới giờ KHÔNG cần sửa code/build lại app** — chỉ cần thư mục
model đó có `llm_config.json` đúng chuẩn (mọi model xuất bằng
`llmexport.py` đều có).

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật — chỉ tự kiểm tra cân bằng ngoặc.
- **Chỉ đọc được khuôn dạng `%s` đơn giản (`prompt_template`)** — nếu 1
  model chỉ có khuôn Jinja đầy đủ (`jinja.chat_template`, phức tạp hơn
  nhiều: vòng lặp, điều kiện, nhiều vai trò riêng biệt) mà KHÔNG có sẵn
  bản rút gọn `prompt_template`, hàm này KHÔNG tự dựng được — viết 1 bộ
  thông dịch Jinja đầy đủ bằng Dart ngoài phạm vi sửa hiện tại. Khi đó
  lùi về ghép thô (an toàn, không tệ hơn trước mục AV, chỉ là không có
  khuôn). Model 8B (Hunyuan) và model 7B (Qwen) đang dùng — CHƯA xác nhận
  file `llm_config.json` thật của chúng có trường `prompt_template` rút
  gọn hay chỉ có `jinja.chat_template` — log mới (dòng
  `_readPromptTemplateForModel`) sẽ cho biết ngay.
- Nếu cả 2 model đều có `prompt_template` và bản vá này giải quyết được
  cả lặp (8B) lẫn nội dung không liên quan Bible (7B) — xác nhận đây là
  hướng đúng, tổng quát, không cần sửa gì thêm khi có model mới.
- Nếu 1 hoặc cả 2 model KHÔNG có `prompt_template` (chỉ có Jinja đầy đủ)
  — cần cân nhắc bước tiếp theo: viết thông dịch Jinja tối giản (chỉ đủ
  xử lý cấu trúc if/for cơ bản của các khuôn chat phổ biến, không cần đầy
  đủ chuẩn Jinja2) hoặc quay lại hardcode CÓ Ý THỨC cho 1 số kiến trúc phổ
  biến nhất làm phương án dự phòng khi không đọc được template tự động.


## AW. Sửa lỗi THẬT — "Hủy" tạo chương hàng loạt không dừng được lúc đang sinh 1 chương (2026-09-16)

### Triệu chứng người dùng báo
"Tạo chương hàng loạt: nhấn Hủy/quay lại cỡ nào cũng không dừng, kể cả sau
khi thoát app — tác vụ nền báo trống nhưng máy vẫn tạo sinh." Người dùng mô
tả là TỆ HƠN trước.

### Nguyên nhân THẬT — tìm bằng đọc code, không đoán
`ChapterBatchService._generateBatchSequential` (nhánh model LOCAL) nhận sẵn
tham số `isCancelled` và CÓ kiểm tra nó — nhưng CHỈ ở đầu vòng `for`, tức
GIỮA 2 chương. Lời gọi `generateWithOptionalTranslation(...)` cho chương
ĐANG chạy không hề truyền `isCancelled` xuống, dù chính hàm đó
(`translation_service.dart`) đã khai báo sẵn tham số này và tự kiểm tra sau
M��I CHUNK stream — cơ chế y hệt nút "X" ở `chat_screen.dart`, nơi đã hoạt
động đúng từ trước.

Hậu quả: bấm Hủy trong lúc 1 chương đang sinh không có tác dụng gì cho tới
khi chương đó tự chạy xong hẳn — có thể hàng chục phút nếu rơi vào lặp vô
tận (xem mục AY) hoặc máy ngủ giữa chừng (log native có ca lệch STEADY/WALL
~15 phút). Vì `generateStream()` (`local_provider.dart`) chỉ gọi
`cancelGenerate()` xuống native khi CHÍNH NÓ bị huỷ giữa chừng — không ai
huỷ nó do thiếu `isCancelled` này — lệnh generate() native tiếp tục chạy
M�� CÔI, khớp đúng "vuốt tắt app / tác vụ nền báo trống nhưng máy vẫn tạo
sinh".

### Bản vá
`chapter_batch_service.dart`, `_generateBatchSequential`: truyền
`isCancelled: isCancelled` xuống `generateWithOptionalTranslation(...)`;
thêm kiểm tra `isCancelled` NGAY SAU lời gọi đó để dừng sạch vòng lặp
(`break`, không tăng `done`, không lưu phần dở dang) thay vì rơi vào nhánh
`looksCorrupted` — tránh báo nhầm huỷ chủ động thành lỗi model qua
`ChapterBatchAnomalyException`.

### Không phải bug — hành vi CỐ Ý, đã xác nhận qua đọc code
"Vuốt tắt app vẫn chạy tạo sinh": `GenerationService` là Foreground
Service, KHÔNG override `onTaskRemoved()` — mặc định sẽ sống sót qua việc
vuốt khỏi đa nhiệm, đúng thiết kế "chạy qua đêm" đã đầu tư từ mục
5.61/5.66/5.71. Sau bản vá này, nút Hủy trong app đã có tác dụng thật nên
không cần vuốt tắt để "ép dừng" nữa — xem thêm mục AZ (nút Hủy trên
notification) cho đường tắt khi không muốn mở lại app.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật.
- Không sửa gì hành vi "sống sót qua vuốt tắt" — đó là thiết kế cố ý, mục
  AZ chỉ thêm đường tắt để dừng, không đổi việc nó có tự dừng khi vuốt hay
  không.

## AX. Mẫu prompt CỐ ĐỊNH theo model_type (họ kiến trúc) — lớp dự phòng khi model chỉ có Jinja đầy đủ (2026-09-16)

### Bối cảnh — nối tiếp giới hạn đã tự ghi ở mục AV
M��c AV đã tự nêu giới hạn: nếu model KHÔNG có `prompt_template` rút gọn
(chỉ có `jinja.chat_template` đầy đủ), `_readPromptTemplateForModel()`
không tự dựng được, phải lùi về ghép thô. Log runtime thật (2026-09-16, cả
2 model OccultAI-Morpheus-8B và Orion-zhen-Qwen2.5-7B-Uncensored) xác nhận
ĐÚNG kịch bản này: cả 2 đều báo "KHONG co prompt_template dang %s".

### Quyết định hướng đi — người dùng chỉ định rõ
Đã cân nhắc dựng bộ thông dịch Jinja tối giản trong Dart (rủi ro cao, phạm
vi lớn, dễ sai với các khuôn phức tạp) — người dùng chỉ định thẳng: "Chọn
mẫu cố định dựa trên loại kiến trúc mô hình." Chọn hướng: đọc `model_type`
từ CHÍNH `llm_config.json` của model (không đoán theo tên thư mục/tên
model), khớp theo TIỀN TỐ để tự đúng với biến thể cùng họ kiến trúc.

### Bản vá
`local_provider.dart`: thêm `_fixedTemplatesByModelTypePrefix` — bảng tra
CỐ ĐỊNH, chỉ gồm 2 kiến trúc đã đối chiếu THẬT với
`chat_template.jinja`/`tokenizer_config.json` chính thức trên HuggingFace:
- `qwen2` → ChatML (`<|im_start|>user\n%s<|im_end|>\n<|im_start|>assistant\n`)
  — khớp ví dụ `llm_config.json` mẫu chính thức của MNN cho Qwen2
  (mnn-docs.readthedocs.io).
- `hunyuan` → `<|hy_begin▁of▁sentence|><|hy_User|>%s<|hy_Assistant|>` —
  khớp đúng `chat_template.jinja` chính thức Tencent Hunyuan trên
  HuggingFace.

CỐ Ý KHÔNG thêm `llama` — model_type "llama" dùng CHUNG cho cả Llama 2 và
Llama 3 (2 khuôn chat khác nhau hoàn toàn), không đủ căn cứ chọn đúng bản
nào chỉ từ `model_type` — đúng bài học mục AP (hardcode Llama 3 sai, hoá
ra model là Hunyuan).

`_readPromptTemplateForModel()`: nối thêm lớp dự phòng THỨ 2 (sau
`prompt_template` trực tiếp, vẫn ưu tiên cao nhất khi có sẵn) — đọc
`model_type`, khớp tiền tố với bảng trên; không khớp gì thì `template` vẫn
`null`, lùi về ghép thô y hệt hành vi cũ trước mục này (KHÔNG regression
cho model chưa nằm trong bảng).

### Giới hạn thật, chưa xác nhận — không giấu
- **Chưa xác nhận `model_type` có thật sự tồn tại trong 2 file
  `llm_config.json` thật của người dùng hay không** — chưa được xem nội
  dung 2 file đó. Tra cứu vài ví dụ `llm_config.json` thật xuất bằng
  `llmexport.py` (QwQ-32B, Llama-3.2, SmolLM2 trên kho HuggingFace
  taobao-mnn) cho thấy: KHÔNG file nào có trường `model_type` — nhưng CẢ
  3 đều đã có sẵn `prompt_template` trực tiếp (ưu tiên cao nhất, không
  cần tới lớp dự phòng này). Gợi ý: 2 model uncensored người dùng đang
  dùng (khả năng convert bằng đường khác, không qua `llmexport.py` chuẩn
  từ checkpoint HuggingFace) có thể KHÔNG có cả `prompt_template` LẪN
  `model_type` — nếu vậy, lớp dự phòng này vô hại nhưng cũng vô tác dụng
  cho đúng 2 model này. Cách xác nhận chắc nhất: xem trực tiếp nội dung 2
  file `llm_config.json` đó, hoặc đơn giản hơn — tự thêm thẳng trường
  `prompt_template` vào 2 file đó (không cần code/build gì).
- Chưa build/test thật.

## AY. Bật thật n_gram/ngram_factor/penalty_window ở live generate config — bước tiếp theo mục AI đã tự đề ra (2026-09-16)

### Bối cảnh — lặp vô tận tái diễn, xác nhận là lặp THẬT
M��c AI (2026-09-11) đã nghi ngờ ngưỡng bộ dò lặp 60→320 ký tự có thể đang
cắt sớm cả đoạn mở đầu gập ghềnh bình thường, không hẳn lặp thật — và tự
ghi rõ hướng tiếp theo NẾU tái diễn thật: "tinh chỉnh sampler sâu hơn (vd
bật lại n_gram/ngram_factor/penalty_window)". Log + ảnh chụp màn hình
2026-09-16 xác nhận: đây LÀ lặp thật (hàng trăm ký tự "F" liên tục, tầng
native tự phát hiện và dừng, không phải đoạn mở đầu gập ghềnh).

### Tra cứu lại — tự sửa 1 giả thuyết SAI trước khi đưa vào code
Giả thuyết ban đầu: `penalty_window=0` nghĩa là TẮT penalty. Tra tài liệu
MNN chính thức (mnn-docs.readthedocs.io/en/latest/transformers/llm.html)
xác nhận NGƯỢC LẠI: `penalty_window=0` nghĩa là áp dụng cho TOÀN BỘ lịch
sử (không phải tắt). Đã sửa giả thuyết trước khi viết code, không đưa
thông tin sai vào bản vá hay vào phần giải thích cho người dùng.

Phát hiện đúng: `ngram_factor` mặc định `1.0` = "không phạt thêm" — dù
`n_gram=8` đã có trong config tĩnh của model (và `"penalty"` đã có trong
`mixed_samplers` từ lâu, xem mục AL), hệ số nhân thêm cho ngram lặp dài là
TRUNG TÍNH, chưa từng có tác dụng escalate thật.

### Bản vá
`MnnBridge.kt`, JSON config gửi vào `set_config()` lúc generate — CÙNG
CHỖ `repetition_penalty` đang cập nhật ổn định mỗi lần generate() từ
trước tới giờ, KHÔNG đụng `mixed_samplers`/cấu trúc sampler (tránh đúng
bẫy treo máy mục AL): thêm `penalty_window=0` (tường minh), hạ `n_gram`
8→4, tăng `ngram_factor` 1.0→1.3.

### Giới hạn thật, chưa xác nhận — không giấu
- **CHƯA build/test thật trên máy** — đây là bản vá kém chắc chắn nhất
  trong các thay đổi ngày 2026-09-16:
  - Không đo được thực tế 4/1.3 có đủ mạnh để chặn lặp sớm hơn hay
    không, hay cần giá trị khác (cần thử trên máy thật với chính 2 model
    đang dùng).
  - Nếu build xong thấy đúng triệu chứng mục AL tái diễn (set_config xong
    nhưng `llm->response()` không sinh được token nào, log dừng ngay sau
    dòng "CHUAN BI goi llm->response()"), bỏ 3 dòng này trước để xác nhận
    đúng nguyên nhân — dù về logic đây LÀ loại thay đổi KHÁC với mục AL
    (mục AL thêm CẤU TRÚC `mixed_samplers` mới ở set_config LẦN 2, đây
    chỉ đổi GIÁ TRỊ tham số của 1 sampler đã có sẵn trong pipeline từ lúc
    load).

## AZ. Nút "Hủy" trên chính notification hệ thống — không cần mở lại app (2026-09-16)

### Vì sao cần
Sau mục AW, nút Hủy TRONG app đã có tác dụng thật — nhưng nếu Activity đã
bị Android dọn hẳn (đúng lúc Foreground Service vẫn sống, xem mục AW phần
"không phải bug"), người dùng vẫn phải MỞ LẠI app rồi mới bấm Hủy được.
Thêm nút hành động ngay trên notification — KHÔNG đổi hành vi
persist-after-swipe của mục AW, chỉ thêm đường tắt để dừng mà không cần mở
lại app.

### Bản vá
- `MnnBridge.kt`: tách thân xử lý `"cancelGenerate"` cũ thành hàm dùng
  chung `performFullCancel(slot)`; thêm `companion object { var
  currentInstance }` theo dõi instance `MnnBridge` đang sống gần nhất.
  Đổi `kLog`/`logDir` từ `private` (cấp file) sang `internal` (cấp
  module) — **lỗi biên dịch THẬT tự bắt được khi soát lại code, không
  phải giả thuyết**: `private` ở top-level trong Kotlin chỉ nhìn thấy
  trong đúng file khai báo, `CancelGenerationReceiver.kt` (file khác) gọi
  vào sẽ không build được nếu không sửa.
- `CancelGenerationReceiver.kt` (file mới): `BroadcastReceiver` nhận
  action từ nút bấm trên notification, gọi `performFullCancel` cho cả 2
  slot (chính + dịch) qua `MnnBridge.currentInstance`.
- `GenerationService.kt`: thêm action "Hủy" vào notification qua
  `addAction(...)`, `PendingIntent.getBroadcast(...)` trỏ vào receiver
  trên, dùng `FLAG_IMMUTABLE` (bắt buộc từ Android 12/API 31 trở lên).
- `build.yml`: đăng ký `<receiver>` trong Manifest bằng đúng cơ chế patch
  Python đã dùng để đăng ký `<service>` của `GenerationService` — đã CHẠY
  THỬ THẬT đoạn script này với 1 Manifest giả lập trước khi đưa vào, xác
  nhận ra XML hợp lệ (không chỉ đọc bằng mắt).

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật trên máy thật — môi trường soát lỗi không có
  `dart`/`flutter`/`kotlinc`, chỉ kiểm được: cân bằng ngoặc, đối chiếu
  chữ ký hàm bằng mắt/grep, và chạy thử ĐƯỢC riêng đoạn script Python vá
  Manifest (phần duy nhất có thể chạy thử thật trong môi trường này).
- Nếu `configureFlutterEngine` chạy lại (xoay màn hình không khai báo
  `configChanges`, Activity bị Android tái tạo) sẽ tạo `MnnBridge`
  instance MỚI, `currentInstance` trỏ sang instance mới đó. Job coroutine
  còn đang CHỜ (chưa chạm tới native, đang xếp hàng ở Mutex) thuộc
  instance CŨ sẽ không huỷ được qua đường notification này (`jobsPerSlot`
  là state riêng của từng instance, không phải cấp module). Cờ huỷ
  NATIVE (`nativeRequestCancel`) vẫn luôn bắn đúng bất kể qua instance
  nào — phần quan trọng nhất (dừng `generate()` đang chạy thật dưới
  native) không bị ảnh hưởng bởi giới hạn này, chỉ các Job còn xếp hàng
  chờ mutex là ngoại lệ hẹp.

## BA. REVERT mục AY — đo thật trên máy cho thấy chậm hơn 2.21 lần, không hề giảm được lặp (2026-09-17)

### Bằng chứng đo được — không phải suy đoán
Đối chiếu 2 lần native tự bắt lặp vô tận, CÙNG model
(OccultAI-Morpheus-8B-v2), CÙNG lượng output tại thời điểm dừng ("da sinh
duoc 320 ky tu truoc do" — giống hệt nhau):
- TRƯỚC mục AY (log 2026-09-16, chưa gửi `penalty_window`/`n_gram`/
  `ngram_factor` ở generate-time): STEADY=341842ms cho 320 ký tự ≈ 1068
  ms/ký tự.
- SAU mục AY (log 2026-09-17, đã gửi `penalty_window=0`, `n_gram=4`,
  `ngram_factor=1.3`): STEADY=755620ms cho 320 ký tự ≈ 2361 ms/ký tự.
- **Chậm hơn 2.21 lần** — và lặp vẫn xảy ra Y HỆT (vẫn dừng ở đúng 320 ký
  tự, không sớm hơn chút nào). Giả thuyết ban đầu của mục AY (hạ `n_gram`
  xuống sẽ giúp bộ phạt bắt được lặp SỚM HƠN, tức sinh ra ÍT rác hơn trước
  khi bộ dò 320 ký tự tự bắt) — **SAI trên thực tế đo được**: không giảm
  được tí rác nào, chỉ tốn thêm thời gian tính toán mỗi token.

### Giải thích hợp lý nhất (chưa đọc được mã nguồn C++ thật của MNN để xác nhận 100%)
`penalty_window=0` = xét toàn bộ lịch sử. Hạ `n_gram` từ 8 xuống 4 khiến
nhiều cụm ngắn hơn hẳn đủ điều kiện so khớp lặp — với lịch sử phát triển
dài dần (tới `max_new_tokens=1024`) và phải quét toàn bộ lịch sử mỗi
token, chi phí tính penalty mỗi token tăng vọt, mà không hề ngăn được
việc model chọn token bị lặp (bản chất lặp ở đây rất có thể đến từ chỗ
khác — prompt/model, không phải do bộ phạt chưa đủ mạnh).

### Hệ quả phụ nghiêm trọng hơn cả bản thân việc chậm
Cờ huỷ NATIVE chỉ được kiểm tra "ở lần ghi token TIẾP THEO". Token chậm
gấp 2.21 lần nghĩa là khoảng cách giữa 2 lần kiểm tra cờ huỷ cũng giãn ra
tương ứng — RẤT CÓ THỂ là một phần nguyên nhân khiến nút Hủy (cả trong
app lẫn trên notification, mục AZ) có cảm giác "bấm không ăn thua" trong
lúc model đang kẹt ở pha này, dù bản thân cơ chế huỷ không hề hỏng.

### Bản vá
`MnnBridge.kt`: bỏ hẳn 3 dòng `put("penalty_window", 0)` /
`put("n_gram", 4)` / `put("ngram_factor", 1.3)` khỏi config JSON gửi lúc
generate — quay về ĐÚNG trạng thái trước mục AY (model dùng lại default
tĩnh trong `config.json`: `n_gram=8`, `ngram_factor=1.0`,
`penalty_window=0` — các giá trị này không đổi, chỉ khác là không còn bị
ép lại qua `set_config()` lúc generate nữa).

### Còn treo lại, chưa có hướng thay thế đã kiểm chứng
- Việc bắt sớm lặp vô tận vẫn CHỈ dựa được vào bộ dò 320 ký tự sẵn có
  (mục AI/AJ) — chưa có cách nào khác đã ĐO THẬT là có tác dụng.
- Nghi vấn thật đáng chú ý hơn: log 2026-09-17 cho thấy model 8B lặp cả ở
  PROMPT dạng "ghép thô" (không có `prompt_template` lẫn `model_type`
  khớp — xem mục AX) LẪN trong khung chat (người dùng xác nhận, đối chiếu
  đúng thời điểm 06:06:20→06:12:48 model 8B bị huỷ thủ công giữa chừng
  trong khi model 7B (đã có template ChatML khớp đúng qua mục AX) chạy
  BÌNH THƯỜNG cùng phiên) — hướng đáng điều tra tiếp là prompt/template
  của riêng model 8B, không phải bộ phạt lặp.

## BB. Vá lỗ hổng quan sát (observability) — không bắt người dùng tự đoán/chứng minh nữa (2026-09-17)

### Lý do — phản hồi thẳng của người dùng, ghi lại nguyên vẹn để tự nhắc
Người dùng chỉ ra đúng 2 việc:
1. Ở mục BA, tôi tự SUY DIỄN "prompt 2564 ký tự = tạo chương, prompt 617 ký
   tự = chat" chỉ dựa vào ĐỘ DÀI prompt — **suy diễn sai**: người dùng xác
   nhận đang test tính năng TẠO CHƯƠNG, và CẢ 2 model (7B lẫn 8B) đều lặp
   ký tự F ở đúng tính năng này — không phải chỉ 8B như tôi kết luận nhầm.
2. Ở phần nút Hủy trên notification, tôi yêu cầu người dùng tự đi tìm 1
   dòng log cụ thể để "chứng minh" — trong khi lẽ ra hệ thống phải TỰ GHI
   LẠI đủ để không cần vòng lặp hỏi-đáp này.

### Nguyên nhân gốc của cả 2 việc — THIẾU LOG, không phải thiếu suy luận
Trước mục này, log KHÔNG hề ghi lại `stage`/tên tính năng ở
`beginPipeline`/`updateStage` (chỉ dùng để đổi chữ trên notification, không
ghi ra `native_debug.txt`) — nên không có cách nào PHÂN BIỆT ĐÚNG 1 lệnh
generate() thuộc tính năng nào từ log, buộc phải đoán qua độ dài prompt
(sai, như mục này vừa xác nhận). Tương tự, khi phát hiện lặp vô tận, log chỉ
ghi 120 ký tự đầu/cuối prompt (không đủ để tự kiểm tra prompt có tự chứa nội
dung lặp/trùng lặp hay không), và nút Hủy trên notification không có bất kỳ
phản hồi nào NGOÀI 1 dòng log — người dùng buộc phải mở file log mới biết
có "ăn" hay không.

### Bản vá — 3 chỗ, đều chỉ thêm log/phản hồi, không đổi logic nghiệp vụ
- `MnnBridge.kt`, case `"beginPipeline"`/`"updateStage"`: thêm `kLog(...)`
  ghi lại nguyên văn `stage` — từ nay log tự trả lời "lệnh generate() này
  thuộc tính năng nào" (vd `beginPipeline: stage="💬 Chat đang xử lý..."`
  hay `updateStage: stage="Đang viết: Chương 5 (2/5)..."`), không cần đoán
  theo độ dài prompt nữa.
- `MnnBridge.kt`, case `"generate"`: log thêm `stageLabel` vào đúng dòng log
  đầu tiên của case này.
- `mnn_bridge.cpp`, nhánh dừng sớm do lặp vô tận: thêm dòng log ghi TOÀN BỘ
  prompt đã gửi (không chỉ 120 ký tự đầu/cuối như log thường) — CHỈ ở nhánh
  hiếm này (dừng sớm), an toàn vì không phải ghi mỗi lần generate() bình
  thường. Mục đích: lần sau gặp lại lặp vô tận, có ngay bằng chứng để tự
  kiểm tra xem CHÍNH prompt (Story Bible do `RagService.buildContext` dựng)
  có tự chứa nội dung lặp/trùng lặp hay không — nghi vấn thật đang treo,
  xem phần dưới.
- `CancelGenerationReceiver.kt`: thêm `Toast` hiện NGAY khi nhận broadcast
  — không phụ thuộc log, không phụ thuộc còn instance `MnnBridge` sống hay
  không. Bấm nút mà KHÔNG thấy Toast này = broadcast chưa tới nơi (lỗi ở
  bước đăng ký, không phải ở logic huỷ); thấy Toast mà máy vẫn tiếp tục
  sinh chữ = broadcast tới nơi rồi nhưng phần huỷ có vấn đề khác — tách
  bạch được 2 loại lỗi mà không cần mở file log nào.

### Đã đọc kỹ nhưng CHƯA tìm ra bug cụ thể — nói thật, không bịa
Đã đọc toàn bộ `RagService.buildContext()` (730 dòng) tìm lỗi khiến prompt
tự chứa nội dung lặp/trùng lặp (nghi vấn: Story Bible/Luật thế giới có mục
trùng lặp, ghép 2 lần...) — KHÔNG tìm thấy chỗ nào nhân đôi dữ liệu trong
code (mỗi phần chỉ `addSection` đúng 1 lần, `allWorldRules`/`allCharacters`
là SELECT đơn giản, không JOIN gây nhân bản dòng). Không có nghĩa là không
có vấn đề — có nghĩa là CHƯA TÌM RA được bằng đọc code, cần dump prompt
THẬT (vừa thêm log ở trên) mới kiểm tra tiếp được, không đoán thêm ở đây.

### Giới hạn thật, chưa xác nhận — không giấu
- 3 log/Toast mới đều CHƯA build/test thật trên máy.
- Chưa lý giải được vì sao CẢ 2 model (kể cả 7B, có template ChatML đúng
  qua mục AX) đều lặp riêng ở tính năng tạo chương — hướng nghi vấn hiện
  tại (nội dung Story Bible/outline tự lặp) chưa có bằng chứng trực tiếp,
  chỉ là suy luận hợp lý nhất còn lại sau khi loại trừ sampler (mục BA) và
  template (chỉ giải thích được phần 8B, không giải thích được phần 7B).

## BC. Sửa lỗi THẬT — nút "Huỷ & thoát" ở `chapter_editor_screen.dart` chỉ giả vờ huỷ (2026-09-17)

### Log mục BB (vừa thêm) đã tự trả lời được, không cần đoán nữa
Nhờ log mới ghi lại `stage` (mục BB), lần này thấy rõ: lệnh generate() 8B
thất bại (11:17:41→11:32:22, lặp vô tận) là qua nhánh `beginPipeline:
stage="Đang sinh văn bản..."` — KHỚP ĐÚNG nhánh "tắt dịch thuật" của
`generateWithOptionalTranslation` (translation_service.dart dòng 197-199),
tức tính năng "Đắp thịt" ĐƠN LẺ ở `chapter_editor_screen.dart` (KHÔNG phải
tạo chương hàng loạt — không thấy "Đang tạo chương hàng loạt..." hay "Đang
viết: Chương..." nào trong log này). 7B cùng loại lệnh (11:33:32→11:37:06)
chạy xong bình thường — **cùng 1 tính năng, cùng 1 kiểu prompt, chỉ khác
model** → lại một lần nữa chỉ có 8B lặp, không có bằng chứng cho "cả 2
model đều lặp ở tạo chương" trong đúng log này (khác với lời người dùng
mô tả ở lượt trước — có thể do lần đó là 1 tình huống/model khác, hoặc mục
BA đã cải thiện phần đó; không đủ dữ liệu để khẳng định thêm).

### Log cũng cho thấy nút Hủy THẬT SỰ có tác dụng — mâu thuẫn với cảm giác "vô dụng", cần đào tiếp mới ra lý do
`[Kotlin] performFullCancel: da huy 1 job...` xuất hiện 2 lần (11:32:20.578
và 11:32:21.480, cách nhau ~0.9s) rồi `nativeGenerate` DỪNG THẬT lúc
11:32:22.621 — tức khoảng 2 giây sau khi bấm huỷ lần đầu, native đã dừng.
Đây KHÔNG phải "vô dụng" — nút hoạt động đúng, nhanh. Vậy cảm giác "vô
dụng" của người dùng phải xuất phát từ chỗ KHÁC — đọc tiếp code UI mới ra.

### Nguyên nhân THẬT của phần còn lại — tìm bằng đọc code, không đoán
`chapter_editor_screen.dart` có nút "Huỷ & thoát" (hiện ra khi người dùng
vuốt back lúc đang chạy AI — đúng khớp "quẹt quay lại rồi nhấn nút hủy và
thoát" người dùng mô tả). Đọc thân hàm `onPressed` của nút này: **CHỈ**
`setState(() { generating = false; fleshingOut = false; checking = false;
_cancelApplyRewrites = true; applyingRewrites = false; })` rồi
`Navigator.pop()` — không hề gọi `BackgroundTaskManager.instance
.requestCancel(id)` nào cả. Trong 5 cờ đó, CHỈ `_cancelApplyRewrites` là cờ
THẬT có nơi kiểm tra định kỳ (`if (_cancelApplyRewrites) break;` trong
vòng lặp áp dụng rewrite) — 4 cờ còn lại (`generating`/`fleshingOut`/
`checking`) chỉ dùng để MỞ KHOÁ giao diện, KHÔNG có nơi nào đọc lại để
quyết định dừng generate() thật. Cơ chế huỷ THẬT cho đúng luồng này ĐÃ CÓ
SẴN từ mục AG (`_generateRespectingTranslation` đã nối `onCancelRequested`
→ `LocalLlamaProvider.requestCancelSlot(0)`) — nhưng phải được KÍCH HOẠT
bằng `BackgroundTaskManager.instance.requestCancel(_currentGenTaskId)`, và
nút "Huỷ & thoát" này chưa từng gọi nó dù `_currentGenTaskId` đã lưu sẵn
đúng id cần dùng (biến này TRƯỚC ĐÓ không được đọc ở bất kỳ đâu khác trong
file — xác nhận bằng grep toàn file, không chỉ đọc lướt).

Đối chiếu: `chat_screen.dart` có nút "Huỷ & thoát" CÙNG TÊN, CÙNG Ý TƯỞNG
(comment ở đó còn ghi "xem chapter_editor_screen.dart" như tham khảo) —
nhưng bản đó gọi ĐÚNG `cancelRequested = true` (cờ thật, được `_send()`
kiểm tra mỗi vòng `await for`). Vậy chapter_editor_screen.dart mới là bản
CÓ lỗi, không phải chat_screen.dart.

### Bản vá
`chapter_editor_screen.dart`, nút "Huỷ & thoát": thêm
`if (_currentGenTaskId != null) { BackgroundTaskManager.instance
.requestCancel(_currentGenTaskId!); }` NGAY TRƯỚC đoạn `setState` reset cờ
UI — tái dùng ĐÚNG cơ chế đã có sẵn (mục AG), không tạo đường huỷ mới.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật.
- `document_screen.dart` dùng cùng khuôn `PopScope` chặn back nhưng KHÔNG
  có nút "Huỷ & thoát" nào (chỉ chặn, không cho lựa chọn huỷ) — không dính
  lỗi này vì không có gì để hỏng, nhưng cũng có nghĩa người dùng màn đó
  không có cách huỷ nào khi lỡ bấm back lúc đang xử lý tài liệu — NGOÀI
  PHẠM VI sửa lần này (người dùng không báo lỗi ở màn đó).
- Dòng log "[MUC BB - TOAN BO PROMPT...]" người dùng dán lại BỊ CẮT NGẮN
  giữa dòng — đã đọc lại `nativeLog()` (ghi thẳng bằng `std::ofstream <<`,
  không qua hàm nào có giới hạn độ dài/NUL-terminate) xác nhận ĐÂY KHÔNG
  PHẢI lỗi ghi log — nhiều khả năng chỉ là lúc copy/dán bị cắt. CHƯA kiểm
  tra được nội dung đầy đủ prompt để xác nhận/loại trừ nghi vấn Story
  Bible tự lặp (mục BB) — cần người dùng dán lại TOÀN VẸN dòng đó từ
  chính file `native_debug.txt`.

## BD. Bỏ hardcode thật — thông dịch Jinja THẬT bằng `jinja_minimal` thay bảng mẫu cố định (2026-09-17)

### Người dùng chỉ ra đúng — bảng mẫu cố định (mục AX) vẫn là hardcode
Người dùng hỏi thẳng: "dùng nội dung như vậy thì chẳng khác nào hardcode"
sau khi tự tay mở `llm_config.json` thật của model 8B và dán cho xem. Đúng
— và file đó là bằng chứng cụ thể: `model_type: "llama"` — HuggingFace
dùng CHUNG giá trị "llama" cho cả Llama 2 và Llama 3 (2 khuôn chat khác hẳn
nhau) — bảng mẫu cố định theo model_type (mục AX) **không thể** phân biệt
được 2 trường hợp này một cách an toàn, nên đã CỐ TÌNH không thêm entry
"llama" vào bảng đó — nghĩa là 8B vẫn rơi thẳng xuống ghép thô dù mục AX đã
tồn tại.

### Giải pháp thật — model đã tự cung cấp câu trả lời, chỉ cần đọc đúng
Chính file đó có sẵn `jinja.chat_template` — khuôn Jinja ĐẦY ĐỦ, CHÍNH XÁC,
do chính công cụ export ghi ra lúc xuất model (xác nhận đây là khuôn Llama 3
thật: cấu trúc `<|start_header_id|>`/`<|eot_id|>`/`<|begin_of_text|>` khớp
đúng template chính thức Meta công bố). Vấn đề DUY NHẤT trước giờ là app
chưa từng thông dịch được cú pháp Jinja đầy đủ (vòng lặp, `set`, filter
`trim`/`tojson`/`join`/`reject`, hàm `raise_exception`...) — không phải
thiếu dữ liệu.

### Bản vá — thêm gói `jinja_minimal`, không tự viết trình thông dịch
Cân nhắc 3 gói Jinja cho Dart:
- `jinja` (ykmnkmi) — tổng quát, cho web, KHÔNG rõ có tắt auto-escape HTML
  dễ dàng không.
- `dinja` — port từ chính `minja` của llama.cpp (rất hấp dẫn vì cùng gốc
  với hệ sinh thái llama.cpp/GGUF), NHƯNG tài liệu chính thức của gói TỰ
  NHẬN có cơ chế "Input Marking"/tự động escape `< > &` (dành cho chống
  XSS) — không hợp với việc gửi văn bản truyện thuần cho model.
- **`jinja_minimal`** (đã chọn) — bản port Dart của `@huggingface/jinja`,
  chính thư viện HuggingFace dùng để render chat template (transformers.js),
  không phải Jinja cho web — không có lý do để tự escape ký tự cho mục đích
  vốn không phải HTML.

Kiến trúc mới (`local_provider.dart`), 4 lớp ưu tiên (mỗi lớp chỉ dùng khi
lớp trên không có/thất bại):
1. `prompt_template` dạng %s trực tiếp — không đổi, vẫn ưu tiên cao nhất.
2. **`jinja.chat_template` — render THẬT bằng `jinja_minimal`** (mới, tổng
   quát thật — không cần biết trước kiến trúc là gì).
3. Bảng mẫu cố định theo model_type (mục AX) — GIỮ LẠI làm lưới an toàn
   cuối, dùng khi model không có cả 2 lớp trên, hoặc khi render Jinja thất
   bại/bị nghi hỏng lúc chạy.
4. Ghép thô — không đổi, lưới an toàn cuối cùng.

`_tryRenderJinja` có `_looksCorruptedByEscaping` — kiểm tra thô: nếu bản
gốc không có sẵn `&lt;`/`&gt;`/`&amp;`/`&#39;`/`&quot;` mà bản render lại
xuất hiện, coi là NGHI NGỜ bị tự động escape sai chỗ, rơi xuống lớp dự
phòng tiếp theo thay vì gửi prompt có thể đã hỏng.

### Giới hạn thật, chưa xác nhận — không giấu
- **CHƯA build/test thật** — sandbox không có Dart/Flutter để biên dịch.
  Chữ ký chính xác của `Template(...)`/`.render(...)` trong `jinja_minimal`
  dựa trên ví dụ ngắn tìm được qua tìm kiếm, CHƯA tự tay chạy thử. Nếu build
  báo lỗi biên dịch ở `_tryRenderJinja`, đó là lỗi API, không phải lỗi
  logic — cần gửi lại nguyên văn lỗi để sửa đúng theo API thật của gói.
- CHƯA xác nhận được `jinja_minimal` có thật sự KHÔNG tự escape HTML hay
  không — suy luận từ việc nó port từ `@huggingface/jinja` (thư viện vốn
  phải xử lý đúng các mẫu như `<tool_call>`, `<|im_start|>` dưới dạng văn
  bản thô, nên về logic không thể tự escape mà vẫn đúng chức năng), nhưng
  đây là suy luận, không phải đọc trực tiếp source code gói đó. Lưới chắn
  `_looksCorruptedByEscaping` là biện pháp phòng ngừa cho đúng khoảng trống
  chưa xác nhận này.
- `jinja_minimal` là gói RẤT MỚI (0 lượt thích, ~266 lượt tải lúc tra cứu)
  — rủi ro về độ trưởng thành/số ca đã kiểm thử thấp hơn 1 gói phổ biến.
  Đổi lại là gói ĐÚNG mục đích (chat template, không phải HTML) thay vì
  gói tổng quát hơn nhưng không rõ hành vi escape.
- Bảng mẫu cố định (mục AX) KHÔNG bị xoá — vẫn hữu ích làm lưới an toàn
  lớp 3, đặc biệt cho model không có `jinja.chat_template` lẫn
  `prompt_template` (chỉ có `model_type` suông).

## BE. Sửa lỗi cấu trúc prompt THẬT — tách riêng vai trò system/user khi render Jinja, không gộp làm 1 turn nữa (2026-09-19)

### Bằng chứng — ảnh chụp màn hình người dùng gửi
Hỏi "xin chào" đơn giản trong khung chat. Model KHÔNG trả lời câu đó mà
PARAPHRASE LẠI CHÍNH system prompt (mô tả vai trò "trợ lý viết", nhắc tới
"Story Bible") — bản model Hunyuan 1.8B còn dịch gần nguyên văn câu "Dưới
đây là dữ liệu Story Bible liên quan tới đoạn đang viết..." sang tiếng
Hoa — rồi mới rơi vào lặp "FFFF". XẢY RA GIỐNG HỆT ở 2 model HOÀN TOÀN
khác kiến trúc (Llama 8B và Hunyuan 1.8B) — bằng chứng rõ ràng đây là lỗi
CẤU TRÚC PROMPT dùng chung cho mọi model, không phải lỗi riêng của model
nào, và KHÔNG liên quan gì tới sampler (mục AY/BA) hay template đúng/sai
(mục AX/BD) — cả 2 việc đó đã đúng ở đây rồi mà vẫn xảy ra.

### Nguyên nhân THẬT
`_buildFinalPrompt` gộp `systemPrompt` + `userPrompt` thành 1 CHUỖI DUY
NHẤT (`combined`) rồi nhét NGUYÊN KHỐI vào ĐÚNG 1 turn `"user"` khi render
Jinja. Từ góc nhìn model: toàn bộ đoạn mô tả vai trò dài + Story Bible +
câu "xin chào" ngắn ngủn ở cuối đều là "1 điều người dùng vừa gõ" — không
có ranh giới nào phân biệt "bối cảnh/chỉ dẫn nền" với "điều cần trả lời
thật". Model (nhất là loại nhỏ/quantize nặng) dễ coi khối văn bản dài,
đọc như chỉ dẫn đó là thứ cần PHẢN HỒI/XÁC NHẬN LẠI thay vì nhận ra "xin
chào" mới là câu hỏi thật cần trả lời.

Thiết kế "gộp làm 1" này vốn có từ TRƯỚC mục BD rất lâu — mục BD (thông
dịch Jinja thật) đã CỐ TÌNH giữ nguyên nó ("giữ nguyên thiết kế cũ — không
đổi hành vi gộp, chỉ đổi cách BỌC nó cho đúng khuôn model") vì lúc đó
không có bằng chứng nó là vấn đề — giờ đã có bằng chứng rõ ràng.

### Bản vá
`local_provider.dart`, `_tryRenderJinja`: nhận RIÊNG `systemPrompt` và
`userPrompt` (không gộp trước khi truyền vào nữa) — dựng `messages` với 2
turn tách biệt khi `systemPrompt` không rỗng (`role: system` chứa đúng
`systemPrompt`, `role: user` chứa ĐÚNG `userPrompt` gốc), khớp đúng cách
khuôn Llama 3 đang dùng đã hỗ trợ sẵn (`{%- if messages[0]['role'] ==
'system' %}`). CÁC LỚP DỰ PHÒNG KHÁC (mẫu %s, bảng cố định theo
model_type, ghép thô) VẪN gộp `combined` như cũ — các mẫu đó chỉ có 1 chỗ
trống %s, không có khái niệm vai trò riêng để tách.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật trên máy.
- Chưa xác nhận được liệu tách vai trò có giải quyết TRIỆT ĐỂ hiện tượng
  "kết quả giống hệt nhau đến từng câu chữ" người dùng mô tả hay chỉ giảm
  bớt — đây có thể là 2 hiện tượng liên quan nhưng không hoàn toàn trùng
  nhau (xem thêm ghi chú ở cuối phiên làm việc 2026-09-19).
- Không áp dụng được cho 3 lớp dự phòng còn lại (mẫu %s/bảng cố định/ghép
  thô) — nếu 1 model rơi vào 1 trong 3 lớp đó (không có `jinja.chat_template`),
  vẫn gộp system+user như cũ, có thể vẫn gặp hiện tượng tương tự. Chưa có
  bằng chứng nào cho thấy trường hợp này đã thật sự xảy ra, không sửa khi
  chưa có bằng chứng.

## BF. Đồng bộ hàng đợi local/remote — mỗi nhiệm vụ tự mang đúng loại provider của mình (2026-09-19)

### Giới hạn thật đã tự ghi từ trước (v14), giờ mới sửa triệt để
`BackgroundTaskManager` là 1 singleton toàn app — nhiệm vụ từ NHIỀU truyện
khác nhau (mỗi truyện có thể chọn provider khác nhau: local hoặc remote)
có thể cùng nằm trong hàng đợi. Trước mục này, giới hạn đồng thời (cap)
được tính DUY NHẤT 1 lần mỗi khi lên lịch, dựa theo provider của "truyện
đang mở trên máy" tại đúng thời điểm đó — áp dụng CHUNG cho toàn bộ hàng
đợi. Hậu quả 2 chiều (ghi chú cũ chỉ nhận ra 1 chiều):
- Nhiệm vụ REMOTE của truyện B có thể bị tính NHẦM cap=1 (giới hạn của
  LOCAL) chỉ vì truyện A (đang mở) dùng model local — dù 2 việc không
  liên quan.
- **NGUY HIỂM HƠN** (chưa từng được ghi nhận trước đây): nhiệm vụ LOCAL
  của truyện A cũng có thể bị tính NHẦM cap RỘNG HƠN (theo cấu hình
  remote) nếu truyện đang mở lại là 1 truyện KHÁC dùng remote — vì cap là
  1 SỐ DUY NHẤT áp dụng chung cho `runningCount` tổng, không tách theo
  loại nhiệm vụ. Đây chính là loại lỗi có thể dẫn lại đúng "heap
  corruption" mà toàn bộ kiến trúc `BackgroundTaskManager` được dựng lên
  để tránh (mục 5.67).

### Bản vá
`BackgroundTask` giờ mang thêm field `isLocalProvider` — gắn NGAY LÚC NỘP
nhiệm vụ (nơi gọi — chat/tạo chương/xử lý tài liệu/tóm tắt... — luôn biết
chắc mình sắp dùng provider nào tại đúng thời điểm submit). `_scheduleNext()`
đếm RIÊNG 2 bộ "đang chạy": local và remote, so với cap CỦA ĐÚNG LOẠI ĐÓ
(`_localCap = 1` cố định; `_remoteCap()` theo cấu hình truyện đang mở, như
cũ). Nhiệm vụ remote nộp sau 1 nhiệm vụ local đang bị chặn (cap local đầy)
giờ chạy NGAY nếu cap remote còn chỗ — không còn xếp hàng oan uổng phía
sau loại tài nguyên hoàn toàn khác.

Cập nhật cả 5 nơi gọi `submit()`/`submitAndWait()` truyền đúng
`isLocalProvider: provider is LocalLlamaProvider`: `chat_screen.dart`,
`chapter_batch_service.dart`, `document_service.dart`,
`chapter_editor_screen.dart` (2 nơi). Tham số đặt `required` (không cho
giá trị mặc định ngầm) — buộc mọi nơi gọi phải tự khai báo rõ, tránh lặp
lại đúng kiểu lỗi "âm thầm sai" đã sửa lần này.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật.
- Cap REMOTE vẫn tra theo "truyện đang mở trên máy" (không theo từng
  task) — nếu 2 truyện khác nhau CÙNG chạy remote nhưng đặt cấu hình
  max-parallel KHÁC NHAU, cap áp dụng chung vẫn lấy theo truyện đang mở.
  Nhỏ hơn hẳn lỗi đã sửa (lẫn local/remote) và không nguy hiểm (local vẫn
  luôn tách riêng hoàn toàn, không bị ảnh hưởng).

## Đã kiểm chứng và LOẠI BỎ — giả thuyết "thread_num: 68 là race condition GPU, đổi thành 4" (2026-09-19)

### Nguồn — không phải tôi tự nghĩ ra
Người dùng dán 1 văn bản (trình bày như thư xin lỗi của "Claude") đề xuất
đổi `"thread_num": 68` (trong `buildOptimizedOpenCLConfig()`,
`mnn_bridge.cpp`) thành `4`, với lý do: 68 là số workgroup GPU khuyến nghị
riêng cho Snapdragon 8 Gen 2/3, máy test (Adreno 660) không nằm trong danh
sách đó → gây race condition khi prefill prompt dài → sinh KV-cache rác →
lặp ký tự.

### Kiểm chứng — TRƯỚC KHI sửa bất kỳ dòng code nào
1. Đối chiếu trích dẫn "mục 5.11 xác nhận Adreno 660 không nằm trong danh
   sách" với chính tài liệu này — **không có mục nào tên "5.11"**, và mục
   thật sự khai sinh giá trị 68 (mục 54, 2026-07-31) KHÔNG hề nhắc tới
   Snapdragon 8 Gen 2/3 hay Adreno 660 gì cả — chỉ ghi "giá trị cụ thể tài
   liệu MNN chỉ định riêng cho suy luận OpenCL". Trích dẫn trong văn bản
   dán vào là BỊA.
2. Tra cứu tài liệu MNN CHÍNH THỨC (mnn-docs.readthedocs.io mục Session
   API, MNN GitHub Wiki, và header `MNNForwardType.h` qua bản mirror Rust
   FFI — 3 nguồn độc lập khớp nhau tuyệt đối) — xác nhận: field này
   (`threadOrGpuMode`) khi dùng backend GPU/OpenCL **KHÔNG PHẢI SỐ LUỒNG**
   — nó là 1 BITMASK ghép từ 2 nhóm cờ:
   ```
   MNN_GPU_TUNING_NONE=1, HEAVY=2, WIDE=4, NORMAL=8, FAST=16
   MNN_GPU_MEMORY_BUFFER=64, MEMORY_IMAGE=128
   ```
   `68 = 64 + 4` = `MNN_GPU_MEMORY_BUFFER | MNN_GPU_TUNING_WIDE` — chính
   MNN gọi `TUNING_WIDE` là **"Default"** (mặc định khuyến nghị chung, áp
   dụng mọi thiết bị OpenCL, không riêng chip nào) — hoàn toàn KHÔNG có
   khái niệm "68 workgroup" hay "race condition theo số luồng" nào cả.

### Kết luận
Giả thuyết này **sai từ gốc** — hiểu nhầm bản chất tham số. Đổi 68 thành 4
sẽ chỉ đổi thành `MNN_GPU_TUNING_WIDE` ĐƠN LẺ (mất luôn cờ chọn chế độ bộ
nhớ BUFFER, không set cờ MEMORY nào) — đây là thay đổi CHIẾN LƯỢC CẤP PHÁT
BỘ NHỚ GPU (buffer vs image, ảnh hưởng hiệu năng), không có cơ chế hợp lý
nào để nó sửa được lỗi ĐÚNG/SAI của việc sinh token (repetition). KHÔNG áp
dụng bản vá này.

### Việc thật vẫn còn treo — nói thẳng, không giấu
Sau khi loại trừ: sampler (mục AY/BA), template/vai trò prompt (mục
AX/BD/BE), và giờ là cấu hình OpenCL — VẪN CHƯA XÁC ĐỊNH ĐƯỢC nguyên nhân
gốc thật của việc lặp ký tự khi sinh văn bản dài, dù đã liên tục thu hẹp
phạm vi nghi vấn qua nhiều vòng có bằng chứng. Đây là giới hạn thật của
tiến trình debug tới thời điểm này, không phải đã giải quyết xong.

## BG. Sửa lỗi SnackBar "Huỷ & thoát" kẹt màn hình, đè lên tận màn hình khác (2026-09-19)

### Bằng chứng — ảnh chụp màn hình người dùng gửi
SnackBar "AI đang chạy — đợi xong hoặc huỷ tác vụ trước khi thoát..." hiện
đè lên tận màn hình "Cài đặt AI" — khác hẳn màn "Soạn chương" nơi nó được
kích hoạt — dù đã bấm "Huỷ & thoát" nhiều lần.

### Nguyên nhân THẬT — 2 lỗi cộng dồn, tìm bằng đọc code
1. SnackBar này KHÔNG đặt `duration` — khác các SnackBar còn lại trong
   cùng file (đều có `duration: Duration(seconds: 8)`). Không đặt thì
   dùng mặc định Flutter (~4 giây) — NHƯNG mỗi lần người dùng thử back
   thêm 1 lần lúc đang bận, `onPopInvokedWithResult` gọi `showSnackBar`
   THÊM 1 lần, THAY THẾ bản cũ và LÀM MỚI đồng hồ đếm — bấm dồn dập liên
   tục (rất tự nhiên khi thấy màn hình "không phản ứng") thì never hết
   hạn được.
2. Nút "Huỷ & thoát" KHÔNG có gì chặn bấm nhiều lần — mỗi lần bấm đều gọi
   `Navigator.of(context).pop()` một lần nữa. Bấm dồn dập 2-3 lần có thể
   pop LIÊN TIẾP 2-3 màn hình lên trên, đưa người dùng đi xa hơn hẳn màn
   ngay trước đó — đúng khớp việc người dùng thấy mình ở tận "Cài đặt AI".

### Bản vá
`chapter_editor_screen.dart`: thêm `duration: const Duration(seconds: 8)`
cho SnackBar này (khớp các SnackBar khác trong file); gọi
`ScaffoldMessenger.of(context).hideCurrentSnackBar()` trước khi hiện bản
mới (tránh chồng chất); thêm cờ `_cancelAndExitHandled` chặn xử lý logic
huỷ+pop nhiều lần nếu nút bị bấm dồn dập (reset cờ mỗi khi
`onPopInvokedWithResult` được gọi lại từ đầu).

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật.
- Chưa xác nhận 100% đây là TOÀN BỘ nguyên nhân "SnackBar đè lên màn hình
  khác" — có khả năng `ScaffoldMessenger` dùng chung ở cấp gốc app (không
  scope riêng theo từng route) cũng góp phần khiến SnackBar "sống sót"
  qua điều hướng route bình thường, không chỉ riêng vụ bấm dồn dập — đây
  là hành vi MẶC ĐỊNH của Flutter (`ScaffoldMessenger` độc lập với
  `Navigator`), không hẳn là lỗi cần sửa thêm, nhưng cần theo dõi tiếp
  nếu vẫn tái diễn sau bản vá này.

## BH. XÁC NHẬN THẬT (không còn là giả thuyết) — lỗi lặp ký tự là do OpenCL/Adreno 660, không phải app (2026-09-19)

### Bằng chứng — người dùng tự kiểm tra trên máy thật
Theo gợi ý dựa trên alibaba/MNN issue #4836 (OpenCL sinh rác đa ngôn ngữ
trên Intel Iris Xe, đã tự loại trừ `thread_num`/`precision` — cùng 2 biến
dự án này từng nghi ngờ và cũng đã loại trừ), người dùng chuyển "Tối ưu AI
local" → "Ép CPU" và thử lại đúng tác vụ từng lặp. Kết quả:
- **KHÔNG còn lặp ký tự** ở bất kỳ model nào đã thử.
- **CPU còn NHANH HƠN** GPU (kể cả so với lúc GPU chưa kịp lặp).

### Vì sao GPU chậm hơn CPU không phải nghịch lý
2 lý do cộng lại, không phải 1:
1. Sinh từng token (decode) trong LLM là tác vụ **giới hạn bởi băng thông
   bộ nhớ** (phải đọc qua toàn bộ trọng số model cho MỖI token, batch=1),
   không phải giới hạn bởi sức tính toán thuần — đây là đặc điểm chung của
   suy luận LLM, không riêng máy này. GPU di động không có lợi thế băng
   thông bộ nhớ vượt trội so với CPU trên CÙNG 1 SoC (dùng chung bus
   LPDDR) như với các tác vụ đồ hoạ/ảnh — nên ưu thế "song song" của GPU
   không phát huy nhiều ở đây.
2. MNN nổi tiếng tối ưu tay (assembly ARM NEON) rất kỹ cho CPU — trong khi
   đường OpenCL trên đúng chip Adreno 660 đang có lỗi tương thích thật
   (mục dưới), nên KHÔNG CHỈ sai kết quả mà rất có thể còn chạy kernel
   không tối ưu/lệch tuning — vừa sai vừa chậm cùng lúc không hề mâu thuẫn.

### Nguồn gốc lỗi — không phải app, là chính engine MNN
`alibaba/MNN` issue #4836 (mở 8/9/2026, còn rất mới): backend OpenCL sinh
ký tự rác đa ngôn ngữ, KHÔNG báo lỗi/crash, trên Intel Iris Xe — người báo
lỗi ĐÃ TỰ loại trừ `thread_num` (cả 4 lẫn 68) và `precision` (cả low lẫn
normal), xác nhận CPU và Vulkan trên CÙNG máy/model đều ra đúng, chỉ riêng
OpenCL sai. Nghi vấn chính thức: lỗi tương thích giữa kernel OpenCL của
MNN với driver GPU cụ thể — đúng lớp lỗi khớp với Adreno 660 trên máy test
ở đây (GPU khác hãng, cùng loại lỗi: OpenCL riêng biệt bị, CPU/Vulkan thì
không).

### Bản vá — CHỈ thêm thông tin, KHÔNG đổi hành vi mặc định
`local_optimization_screen.dart`: cập nhật đoạn mô tả "Tự động (GPU tối
ưu)" — ghi rõ phát hiện đã XÁC NHẬN THẬT này, khuyến nghị chuyển "Ép CPU"
nếu gặp lặp ký tự. **CỐ TÌNH KHÔNG đổi** logic auto-detect
(`backendPreference == 0` vẫn đi thẳng OpenCL như cũ) — vì:
- Không có cách đáng tin cậy để tự động phát hiện ĐÚNG dòng GPU Adreno
  660 tại runtime mà không thêm nhiều code mới (đọc GL renderer string,
  cần context OpenGL/Vulkan đã khởi tạo).
- Phát hiện này mới xác nhận trên ĐÚNG 1 máy — chưa có bằng chứng lỗi này
  xảy ra trên MỌI Adreno 660, hay có ảnh hưởng gì tới các dòng Adreno
  khác (740, 750...) mà GPU ở đó CÓ THỂ vẫn nhanh/đúng hơn CPU thật — đổi
  mặc định cho TẤT CẢ người dùng dựa trên 1 ca dữ liệu là quá tay, rủi ro
  làm chậm lại những máy không hề dính lỗi này.

### Còn treo lại
- Nên cân nhắc báo lại phát hiện này lên đúng issue #4836 (hoặc mở issue
  riêng ghi rõ "Adreno 660 / Snapdragon 888") cho nhóm MNN — ngoài phạm vi
  sửa trong app, nhưng có giá trị cho cộng đồng.
- Nếu sau này build lại MNN bằng bản mới hơn (build.yml đang clone
  `master` HEAD mỗi lần build) và bản mới có vá lỗi OpenCL này, có thể
  không còn cần "Ép CPU" nữa — chưa có cách tự động phát hiện "bản MNN này
  đã vá hay chưa", người dùng cần tự thử lại theo thời gian.

## BI. GHIM phiên bản MNN về 3.5.0 — đảo ngược ưu tiên "luôn lấy master mới nhất" (2026-09-19)

### Người dùng chỉ ra đúng góc nhìn tôi bỏ sót — không phải tôi tự nghĩ ra
Sau mục BH (xác nhận OpenCL là thủ phạm qua test Ép CPU), người dùng phản
biện đúng: nếu đây là lỗi tương thích OpenCL/Adreno 660 CỐ HỮU (tồn tại từ
lâu), lẽ ra phải có RẤT NHIỀU báo cáo tương tự trải dài nhiều năm, không
phải chỉ 1 issue 11 ngày tuổi. Người dùng còn nhớ rõ: **tháng trước GPU vẫn
sinh chữ bình thường trong khung chat, sau này mới bắt đầu ra rác** — đây
chính là lý do người dùng liên tục yêu cầu đọc kỹ tài liệu kỹ thuật để tìm
ra sự khác biệt, mà trước đó chưa được nhìn đúng góc.

### Kiểm tra — đối chiếu changelog CHÍNH THỨC alibaba/MNN theo mốc thời gian
- **MNN 3.5.0** (phát hành 2026-04): chưa có 2 thay đổi bên dưới.
- **MNN 3.6.0** (phát hành 2026-06): changelog chính thức ghi rõ mục "GPU
  多后端深度优化" (tối ưu sâu đa backend GPU) thêm MỚI cho OpenCL: **"GEMM/
  GEMV 启发式调度"** (heuristic scheduling cho GEMM/GEMV — chính là phép
  tính lõi của MỌI bước forward pass sinh token) và **"int4
  image1d_buffer_t 优化"** (tối ưu MỚI riêng cho kiểu lượng tử hoá int4 —
  TẤT CẢ model app này dùng đều là q4/int4).
- **alibaba/MNN issue #4836** (mở 2026-09-08, SAU cả 3.6.0): OpenCL sinh
  ký tự rác đa ngôn ngữ, không báo lỗi/crash, trên GPU khác hãng (Intel) —
  xác nhận đây là lỗi THẬT, MỚI xuất hiện gần đây trong chính MNN, khớp
  đúng mốc thời gian người dùng nhớ lại.

### Nguyên nhân gốc của việc "chưa từng bị phát hiện" — chính build.yml
`git clone --depth 1 https://github.com/alibaba/MNN.git` (không ghim
branch/tag) — MỖI LẦN build có thể lấy 1 COMMIT MNN HOÀN TOÀN KHÁC, tuỳ
đúng thời điểm bấm nút, hoàn toàn ngoài kiểm soát. Cơ chế fallback trước
đây (mục cũ, quyết định theo đúng yêu cầu người dùng LÚC ĐÓ: "không đánh
đổi bản mới nhất") CHỈ kích hoạt khi **build LỖI HẲN** (không biên dịch
được) — KHÔNG kích hoạt khi build THÀNH CÔNG nhưng SINH SAI KẾT QUẢ LÚC
CHẠY (đúng chính xác triệu chứng lặp ký tự). Tệ hơn: bản fallback đó chính
là **tag 3.6.0** — đúng bản đang bị nghi mang lỗi!

### Bản vá
`build.yml`: đảo ngược hoàn toàn thứ tự ưu tiên.
- Bước clone: `git clone --depth 1 --branch 3.5.0 ...` (ghim CỨNG, không
  còn lấy `master` mặc định) — build giờ TÁI LẬP ĐƯỢC (reproducible),
  không còn phụ thuộc "đúng lúc build thì MNN đang ở commit nào".
- Fallback (chỉ khi 3.5.0 build LỖI HẲN — hiếm, vì là bản phát hành chính
  thức đã qua kiểm thử): lùi sang `master` HEAD, có cảnh báo rõ trong log
  ("CANH BAO co the dinh loi opencl-int4") — đây là giải pháp CUỐI CÙNG để
  ít nhất có bản chạy được, không phải xác nhận đã hết lỗi lặp ký tự.

### Giới hạn thật, chưa xác nhận — không giấu
- **CHƯA build/test thật trên máy** — đây là thay đổi CHƯA ĐƯỢC KIỂM CHỨNG
  bằng cách build lại và thử generation thật. Cần build lại rồi thử đúng
  tác vụ từng lặp (kể cả khi dùng GPU, không chỉ CPU) để xác nhận 3.5.0 có
  thật sự hết lặp hay không — đây là GIẢ THUYẾT có bằng chứng thời gian
  khớp nhau rất mạnh (changelog + issue + trí nhớ người dùng), nhưng CHƯA
  PHẢI đã kiểm chứng bằng thực nghiệm trên đúng máy/model đang lặp.
- Nếu 3.5.0 build được nhưng VẪN lặp: loại được luôn giả thuyết version
  MNN, quay lại nghi vấn commit CỤ THỂ nào đó nằm giữa quãng
  3.5.0→3.6.0→hiện tại trên `master` — lúc đó cần bisect thủ công (thử
  từng tag/commit ở giữa) thay vì đoán tiếp.
- Nếu 3.5.0 THẬT SỰ hết lặp: xác nhận chắc chắn — lúc đó nên cân nhắc dùng
  lại GPU (nhanh hơn CPU) thay vì tiếp tục "Ép CPU", VÀ nên báo phát hiện
  này lên đúng issue #4836 hoặc mở issue mới ghi rõ "int4 image1d_buffer_t
  + Adreno 660" cho nhóm MNN.

## BJ. Tính năng MỚI — Trích xuất Story Bible từ chat và tài liệu (2026-09-20)

### Yêu cầu người dùng
"Khung chat tư vấn về bible rồi tự cập nhật vào bible, hoặc người dùng up
tài liệu bible vào rồi tự cập nhật vào bible" — 2 luồng nhập liệu (chat tư
vấn + tài liệu tải lên) đều cần có đường trích xuất thành entry Story
Bible có cấu trúc (Nhân vật/Luật thế giới/Thuật ngữ/Tuyến truyện).

### Đã đọc kỹ trước khi viết — xác nhận chưa tồn tại
Đọc `document_service.dart`, `rag_service.dart`, toàn bộ schema DB
(`characters`, `world_rules`, `glossary_terms`, `plot_threads`,
`bible_facts`) — xác nhận: `bible_facts` chỉ là bảng phụ (facts con của 1
Character/WorldRule ĐÃ CÓ SẴN), KHÔNG phải cơ chế trích xuất tự động từ
văn bản thô. Tính năng người dùng yêu cầu CHƯA hề tồn tại trước mục này.

### Thiết kế — cố ý KHÔNG tự động ghi thẳng vào Bible
LLM trích xuất có thể sai/bịa — đúng loại rủi ro đã thấy xuyên suốt cả đợt
điều tra lặp ký tự (mục AY-BI). Nếu ghi thẳng, 1 lần trích sai làm hỏng dữ
liệu Bible gốc, khó hoàn tác. Luồng: **trích xuất (LLM) → người dùng tự
xem lại, chọn, sửa nếu cần → mới ghi vào DB thật**.

### Bản vá — 2 file mới, nối vào 2 màn hình có sẵn
- `lib/services/bible_extraction_service.dart` (mới): gọi
  `AIProvider.generate()` (interface CHUNG, hoạt động với cả model local
  lẫn API remote — đúng tinh thần đồng bộ mục BF) với prompt yêu cầu trả
  về ĐÚNG 1 khối JSON theo khuôn `{characters, world_rules, glossary,
  plot_threads}`. `_parseJsonLoose()` phòng hờ trường hợp model kèm
  markdown fence/câu dẫn thừa (model local nhỏ hay quantize nặng thường
  không tuân thủ tuyệt đối "chỉ trả JSON").
- `lib/screens/bible_extraction_review_screen.dart` (mới): màn hình xem
  lại DÙNG CHUNG cho cả 2 nguồn — danh sách checkbox, bấm giữ để sửa
  tên/nội dung trước khi lưu, chỉ ghi DB đúng những mục đã chọn qua 4 hàm
  `upsert*` có sẵn (`upsertCharacter`/`upsertWorldRule`/
  `upsertGlossaryTerm`/`upsertPlotThread`).
- `chat_screen.dart`: thêm nút "Trích vào Bible" dưới mỗi tin nhắn CỦA TRỢ
  LÝ đã sinh xong (ẩn lúc đang generate dở).
- `document_screen.dart`: thêm nút "Trích vào Bible" vào hàng hành động
  của mỗi tài liệu — gộp `originalText` của các chunk (bản GỐC, không phải
  bản đã dịch/tóm tắt — tài liệu Story Bible người dùng tự viết thường
  không cần dịch).

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật.
- Tài liệu DÀI: chỉ trích được từ 6000 ký tự đầu (giới hạn đặt trong
  `BibleExtractionService` để tránh prompt khổng lồ cho 1 tác vụ trích
  xuất đơn giản) — tài liệu dài hơn KHÔNG được trích hết trong 1 lần, cần
  người dùng tự lặp lại (chưa làm tính năng tự chia nhỏ + gộp kết quả
  nhiều lần, ngoài phạm vi lần này).
- Chất lượng trích xuất phụ thuộc HOÀN TOÀN vào model đang chọn — model
  nhỏ/quantize nặng (đã thấy dễ lặp/hiểu sai trong suốt cuộc điều tra
  trước) có thể trả JSON sai khuôn hoặc trích nhầm — `_parseJsonLoose` chỉ
  cứu được lỗi ĐỊNH DẠNG (thừa chữ/markdown), không cứu được lỗi NỘI DUNG
  (model bịa dữ kiện không có trong văn bản gốc) — đây là lý do CHÍNH của
  việc bắt buộc người dùng tự xem lại trước khi lưu, không phải chỉ là
  thận trọng thừa.
- Chưa có cách phát hiện TRÙNG LẶP với entry Bible đã có sẵn (vd trích ra
  "nhân vật A" trong khi Bible đã có sẵn nhân vật A với tên hơi khác) — sẽ
  tạo entry MỚI riêng biệt, người dùng cần tự gộp/xoá trùng thủ công nếu
  có.

## BK. Mở rộng bộ dò lặp vô tận — bắt được lặp CỤM TỪ, không chỉ ký tự đơn (2026-09-20)

### Bằng chứng — log + ảnh chụp người dùng gửi
Model (Qwen3-8B, backend CPU đã ép, prompt tối giản "xin chào" không Story
Bible — do toggle "tắt Story Bible" trong chat đang tắt) sinh: "Chào bạn!
...Hãy cho tôi biết nhé! Hãy cho tôi biết nhé! [lặp lại ~60 lần]" — KHÔNG
bị bộ dò lặp tự động bắt, người dùng phải tự huỷ thủ công sau ~2 phút.

### Nguyên nhân THẬT
Bộ dò lặp cũ (cả Dart `local_provider.dart` lẫn native `mnn_bridge.cpp`)
chỉ có 2 tiêu chí: (a) 1 ký tự đơn chiếm >85% cửa sổ, (b) 1 cụm NGẮN (2-6
ký tự) lặp khít. Cụm "Hãy cho tôi biết nhé!" (bỏ khoảng trắng ~17 ký tự)
**dài hơn hẳn trần 6 ký tự cũ** — không khớp tiêu chí (b); đồng thời đủ đa
dạng ký tự nên không khớp tiêu chí (a) — lọt qua cả 2 lớp.

### Bản vá — cả 2 tầng (Dart + native), cùng 1 logic
M�� trần period từ 6 lên `min(60, kích_thước_cửa_sổ / 3)` — vẫn AN TOÀN với
văn xuôi thật vì phép kiểm giữ nguyên yêu cầu **TOÀN BỘ** cửa sổ phải khớp
đúng 1 cụm lặp lại đó (không phải chỉ 1 đoạn nhỏ tình cờ trùng nhau) — văn
bản tự nhiên gần như không bao giờ có cả trăm ký tự liên tiếp là ĐÚNG 1
khối nhỏ lặp lại nguyên vẹn, kể cả khi dùng lại vài cụm từ quen thuộc.

`mnn_bridge.cpp`: xác nhận đây là hàm THUẦN so khớp chuỗi (`const`, không
đụng `sampler`/`set_config`/`mixed_samplers`) — tách biệt hoàn toàn khỏi
đúng phần từng gây treo máy ở mục AL/AM, an toàn để mở rộng.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật.
- KHÔNG giải quyết được NGUYÊN NHÂN gây lặp (model tự rơi vào vòng lặp) —
  chỉ giúp PHÁT HIỆN SỚM HƠN, dừng lãng phí thời gian/pin sớm hơn. Nguyên
  nhân gốc (vì sao model — kể cả với prompt tối giản, trên CPU, không
  Story Bible — vẫn có xu hướng lặp) vẫn CHƯA xác định được, xem thêm mục
  BN.

## BL. Cải thiện tiếp Trích xuất Bible — tài liệu dài trích HẾT, cảnh báo trùng lặp + grounding (2026-09-20)

Tiếp nối mục BJ, theo đúng phản hồi người dùng ("đã là giới hạn tại sao
không khắc phục") — 3 cải thiện THẬT, không chỉ ghi vào mục giới hạn:

1. **Tài liệu dài**: `extractFromChunks()` mới — nhận TỪNG CHUNK RIÊNG
   BIỆT (tài liệu đã được chia nhỏ sẵn từ lúc import), trích HẾT các
   chunk tuần tự (không còn cắt cụt 6000 ký tự đầu rồi bỏ phần sau), tự
   gộp + lọc trùng kết quả giữa các chunk. `document_screen.dart` có
   thanh tiến trình "Đang trích xuất đoạn X/Y" (dùng `StatefulBuilder`).
2. **Cảnh báo trùng lặp**: đối chiếu tên mục trích được với Bible ĐÃ CÓ
   SẴN trong DB (qua `allCharacters`/`allWorldRules`/`allGlossaryTerms`/
   `allPlotThreads`) — khớp gần đúng thì cảnh báo rõ tên entry cũ, mặc
   định BỎ CHỌN (an toàn hơn, buộc người dùng chủ động xem xét).
3. **Cảnh báo grounding**: kiểm tra `title` có xuất hiện trong CHÍNH văn
   bản gốc không — không thấy thì cảnh báo (không tự động bỏ chọn, vì
   model có thể diễn đạt lại tên hợp lệ mà vẫn không khớp y hệt — cảnh báo
   THAM KHẢO, không phải bằng chứng tuyệt đối).

### Giới hạn thật còn lại
- Chưa build/test thật.
- Tài liệu RẤT DÀI (nhiều chục chunk) sẽ mất tương ứng nhiều lượt gọi
  model tuần tự — có thể chậm, chưa làm song song (an toàn hơn, tránh làm
  phiền GPU/CPU local vốn chỉ cho phép 1 nhiệm vụ đồng thời, mục AW/BF).
- So khớp trùng lặp chỉ dựa tên CHÍNH XÁC (không phân biệt hoa/thường) —
  chưa xử lý được biến thể tên (vd "Thuỷ" vs "Thủy").

## BM. Sửa lỗi thật — nút "AI gợi ý" (Dàn ý) chặn cứng vào 1 trường KHÔNG CÓ Ô NHẬP (2026-09-20)

### Bằng chứng — ảnh chụp + rà soát code
Bấm "AI gợi ý" ở tab Dàn ý báo: "Truyện chưa có mô tả — vào Cài đặt truyện
để thêm mô tả trước" — người dùng xác nhận: KHÔNG có mục "mô tả" nào trong
Cài đặt. Rà soát TOÀN BỘ codebase xác nhận đúng: `Novel.description`
KHÔNG CÓ Ô NHẬP LIỆU NÀO trong toàn app — dễ nhầm với `Volume.description`
(mô tả của TỪNG QUYỂN/HỒI, CÓ ô nhập ở `chapters_screen.dart`) — cùng tên
field, khác hẳn ý nghĩa. Thông báo cũ trỏ người dùng tới nơi không tồn
tại, chặn đứng tính năng vĩnh viễn không có cách tự gỡ.

### Bản vá
`story_bible_screen.dart`, `_suggestBeatsWithAI`: bỏ hẳn việc chặn cứng.
`novel.description` giờ chỉ là NGỮ CẢNH TUỲ CHỌN — trống thì đổi câu dẫn
trong prompt thành "hãy tự suy luận bối cảnh/cốt truyện dựa HOÀN TOÀN vào
Story Bible bên dưới" (đã có sẵn nhân vật/luật thế giới/tuyến truyện được
ghép vào từ trước, không phụ thuộc mỗi `description`). Neo tìm kiếm ngữ
nghĩa (`buildContext`) lùi về dùng `novel.title` nếu `description` trống,
thay vì chuỗi rỗng.

### Giới hạn thật
- Chưa build/test thật.
- Chưa thêm UI để NHẬP `novel.description` (nếu người dùng vẫn muốn có
  trường này) — ngoài phạm vi sửa lần này, chỉ gỡ chặn, không thêm tính
  năng mới.

## BN. Cập nhật nghiên cứu — lỗi OpenCL trên MNN là vấn đề DÀI HẠN, không chỉ riêng 3.6.0 (2026-09-20)

Tra thêm GitHub issues của alibaba/MNN, phát hiện thêm bằng chứng làm rõ
hơn (không phủ định) mục BH/BI:
- **Issue #4836** (OpenCL sinh rác) vẫn CÒN MỞ, test cả trên commit MỚI
  HƠN 3.6.0 (master ngày 2026-09-04) — nghĩa là (nếu đúng) vấn đề CHƯA
  được vá xong tính tới thời điểm đó, không phải chỉ ở đúng 3.6.0.
- **Issue #4802** (~8/2026): OpenCL crash khi biên dịch kernel fp16 buffer
  — lỗi OpenCL KHÁC, cùng khoảng thời gian gần đây.
- **Issue #2907** (6/2024): người dùng khác báo OpenCL VÀ Vulkan đều CHẬM
  HƠN CPU trên Android — độc lập xác nhận thêm cho lời giải thích "CPU có
  thể nhanh hơn GPU" đã đưa cho người dùng ở mục BH.
- **Issue #1736** (10/2021, MNN bản 1.2.2 — rất cũ): "Wrong result Android
  openCL" — CPU đúng, OpenCL sai — ĐÚNG LOẠI LỖI đang gặp, nhưng từ **5
  năm trước**.

### Ý nghĩa — điều chỉnh lại kết luận mục BI cho chính xác hơn
Việc OpenCL cho kết quả sai/chậm hơn CPU trên GPU di động (đặc biệt
Android) là hiện tượng **TÁI DIỄN NHIỀU LẦN xuyên suốt lịch sử MNN**
(2021, 2024, 2026), KHÔNG PHẢI chỉ là 1 regression mới của riêng 3.6.0.
Ghim về 3.5.0 (mục BI) vẫn là bước hợp lý (loại bỏ được đúng 2 thay đổi cụ
thể nghi vấn của 3.6.0), nhưng KHÔNG có gì đảm bảo GPU sẽ hoàn toàn ổn
định ngay cả ở 3.5.0 — đây là điểm yếu MANG TÍNH HỆ THỐNG của backend
OpenCL trong MNN trên phần cứng di động, không phải 1 lỗi đơn lẻ có thể
"tìm đúng version rồi hết".

### Khuyến nghị điều chỉnh
Coi "Ép CPU" là lựa chọn MẶC ĐỊNH đáng tin cậy cho máy này về lâu dài, thay
vì chỉ là giải pháp tạm trong lúc chờ vá OpenCL — CPU chưa từng cho kết quả
sai trong toàn bộ log đã xem qua suốt cuộc điều tra.

## BO. Rà soát lại tính năng Trích xuất Bible (mục BJ/BL) — xác nhận đã nối đúng, sửa tiếp giới hạn "biến thể tên có dấu" tự ghi ở mục BL (2026-09-23)

### Vì sao mục này tồn tại
Người dùng hỏi lại đúng câu hỏi gốc ("khung chat tư vấn bible + tài liệu
tự cập nhật — đã làm chưa") — rà soát lại từ đầu, đối chiếu TRỰC TIẾP với
code (không chỉ tin nội dung mục BJ/BL đã ghi), theo đúng quy tắc bắt buộc
ở mục 0.

### Đã xác nhận — tính năng ĐÃ hoạt động đúng như mục BJ/BL mô tả
Đọc lại toàn bộ `bible_extraction_service.dart`,
`bible_extraction_review_screen.dart`, phần nối vào `chat_screen.dart`
(nút "Trích vào Bible" dưới tin nhắn trợ lý) và `document_screen.dart`
(nút tương tự + thanh tiến trình theo chunk) — đối chiếu chữ ký hàm/tên
field với `ai_provider.dart`, `database_service.dart`,
`story_models.dart`, `document_service.dart`: KHỚP ĐÚNG toàn bộ, không có
chỗ gọi sai tên hàm/tham số. Kiểm tra cân bằng ngoặc `{}()[]` cả file —
không lỗi cú pháp rõ ràng (vẫn CHƯA build thật — xem "Giới hạn thật" cuối
mục này).

### Bản vá — đúng 1 trong các giới hạn TỰ GHI ở mục BL, giải quyết thật
Mục BL tự ghi: "So khớp trùng lặp chỉ dựa tên CHÍNH XÁC (không phân biệt
hoa/thường) — chưa xử lý được biến thể tên (vd 'Thuỷ' vs 'Thủy')". Đây là
2 cách gõ CÙNG 1 âm tiết tiếng Việt, chỉ khác vị trí đặt dấu thanh trên
cặp nguyên âm "uy" (kiểu cũ đặt dấu ở nguyên âm đầu, kiểu mới đặt ở
nguyên âm cuối) — `_normalizedTitle` cũ (chỉ lowercase+trim) không bắt
được.

Thêm bảng `_vietnameseFold` (67 mục — đủ toàn bộ nguyên âm có dấu tiếng
Việt: a/ă/â, e/ê, i, o/ô/ơ, u/ư, y, cộng `đ`) gấp mỗi ký tự về đúng chữ
cái gốc (bỏ dấu thanh + dấu phụ) trước khi so sánh. `_normalizedTitle` giờ
lowercase → gấp dấu → gộp khoảng trắng thừa. Áp dụng ở CẢ 2 nơi đang dùng
hàm này:
- `_dedupeWithinResults` (gộp entry trùng trong CÙNG 1 lượt trích) — đã tự
  động hưởng lợi vì dùng chung hàm.
- `_flagGroundingAndDuplicates`: đối chiếu trùng lặp với Bible đã có sẵn
  VÀ kiểm tra grounding (đổi `sourceLower` thành `sourceFolded` — cũng gấp
  dấu toàn bộ văn bản gốc trước khi kiểm tra `contains`, tránh báo động
  giả "không tìm thấy trong văn bản gốc" khi model trích ra tên ĐÚNG nhưng
  gõ dấu khác kiểu so với chính văn bản).

`title` gốc hiển thị cho người dùng ở màn xem lại KHÔNG đổi — bảng gấp dấu
chỉ dùng nội bộ để so sánh, không ghi vào DB.

### Giới hạn thật, chưa xác nhận — không giấu
- Chưa build/test thật (như mọi mục trước — môi trường soạn tài liệu này
  không có Flutter/Dart SDK lẫn mạng để tải về, xem mục 0).
- Chỉ gấp dấu THANH (sắc/huyền/hỏi/ngã/nặng) và dấu phụ (ă/â/ê/ô/ơ/ư/đ) —
  KHÔNG xử lý được biến thể tên KHÁC bản chất: viết tắt ("Thủy" vs "T."),
  tên đầy đủ vs biệt danh ("Nguyễn Thị Thủy" vs "Thủy"), hay lỗi chính tả
  thật (gõ nhầm chữ cái, không phải nhầm dấu) — những trường hợp này vẫn
  cần người dùng tự nhận ra qua màn xem lại, không có cách nào tự động hoá
  an toàn (dễ gộp nhầm 2 nhân vật khác tên thật thành 1).
- 2 giới hạn còn lại tự ghi ở mục BL (tài liệu rất dài chạy tuần tự không
  song song; "chưa build/test thật") vẫn y nguyên, chưa đụng tới trong mục
  này — mục này CHỈ sửa đúng 1 giới hạn "biến thể tên có dấu" đã nêu ở
  trên, không tự nhận đã giải quyết những giới hạn khác.

## BP. Sửa lỗi build THẬT lần đầu tiên xác nhận qua GitHub Actions (build #142) — DatabaseService() sai + CheckboxListTile không có onLongPress (2026-09-23)

### Bối cảnh
Đây là lần ĐẦU TIÊN tính năng Trích xuất Bible (mục BJ/BL/BO) được build
thật. Người dùng chạy CI thật (GitHub Actions, "Build APK #142") và dán
nguyên log lỗi — bằng chứng THẬT, không phải suy đoán từ đọc code bằng
mắt hay kiểm tra cân bằng ngoặc thủ công (cách đã dùng ở mục BO — xác
nhận KHÔNG đủ, cân bằng ngoặc không bắt được lỗi kiểu/API).

### Lỗi 1 (gốc, gây ra 8/10 dòng lỗi còn lại) — DatabaseService() không tồn tại
Log: "Couldn't find constructor 'DatabaseService'" ở cả
`bible_extraction_review_screen.dart:36` và
`bible_extraction_service.dart:261`. `DatabaseService` (xem
`database_service.dart` dòng 16-18) dùng khuôn mẫu singleton: constructor
không tên là `_internal()` — RIÊNG TƯ, không có constructor không tên
công khai để gọi `DatabaseService()`. Cách dùng ĐÚNG, thống nhất ở MỌI
file khác trong `lib/` (hơn 10 chỗ: `backup_service.dart`,
`settings_service.dart`, `chat_screen.dart`...): `DatabaseService.instance`.

2 file mới ở mục BJ là 2 chỗ DUY NHẤT trong toàn project gọi sai —
NGUYÊN NHÂN: lúc viết mã đã đối chiếu đúng tên HÀM
(`allCharacters`, `upsertCharacter`...) và tên FIELD model, nhưng KHÔNG
đối chiếu cách khởi tạo chính `DatabaseService` — lỗ hổng thật trong quy
trình rà soát, không phải lỗi đánh máy ngẫu nhiên.

Hệ quả dây chuyền — giải thích 8 lỗi còn lại: vì `DatabaseService()`
không resolve được, trình biên dịch coi biến `db` là kiểu lỗi thay vì
`DatabaseService`, kéo theo `db.allCharacters(novelId)` v.v. cũng sai
kiểu, khiến hàm generic `_firstWhereOrNull<T>` không suy luận được `T` là
`Character`/`WorldRule`/`GlossaryTerm`/`PlotThread` — nên `c.name`,
`r.title`, `g.term`, `p.name` đều báo lỗi getter không tồn tại. Chỉ cần
sửa đúng 1 chỗ gốc ở mỗi file thì cả chuỗi lỗi generic phía sau tự hết —
không cần sửa riêng từng dòng `.name`/`.title`/`.term`.

### Lỗi 2 (độc lập) — CheckboxListTile không có tham số onLongPress
Log: "No named parameter with the name 'onLongPress'" ở
`bible_extraction_review_screen.dart:190`. `ListTile` có `onLongPress`
nhưng `CheckboxListTile` (widget Flutter Material gốc) THÌ KHÔNG — nhầm
API giữa 2 widget khác nhau. Sửa bằng cách bọc `CheckboxListTile` trong
`GestureDetector(onLongPress: ...)` thay vì truyền thẳng tham số không
tồn tại — giữ nguyên hành vi bấm giữ để sửa (`_editEntry`).

### Đã sửa
- `bible_extraction_service.dart` dòng 261: `DatabaseService()` →
  `DatabaseService.instance`.
- `bible_extraction_review_screen.dart` dòng 36: tương tự.
- `bible_extraction_review_screen.dart`: bọc `CheckboxListTile` trong
  `GestureDetector(onLongPress: () => _editEntry(e), child: ...)`.
- Grep toàn bộ `lib/` xác nhận hết sạch `DatabaseService()` gọi sai kiểu,
  và đối chiếu mọi lệnh gọi `XxxService(...)` khác trong 2 file này với
  cách các file khác trong project gọi cùng class — khớp, không sót lỗi
  cùng loại.

### Giới hạn thật — không giấu
- Vẫn CHƯA có xác nhận build tiếp theo THÀNH CÔNG — mục này sửa đúng 10
  dòng lỗi log đã thấy, nhưng môi trường soạn tài liệu vẫn không có
  Flutter/Dart SDK để tự build lại kiểm chứng; cần người dùng chạy CI lần
  nữa và dán log (dù thành công hay lỗi tiếp) để xác nhận thật.
- Mục BO trước đó tự nhận đã "đối chiếu chữ ký hàm/tên field... khớp
  đúng" — ĐÚNG một phần (tên hàm/field khớp thật) nhưng KHÔNG đủ, vì bỏ
  sót cách khởi tạo `DatabaseService`. Rút kinh nghiệm ghi lại ở đây: đối
  chiếu API phải bao gồm CẢ cách lấy instance của service, không chỉ tên
  hàm gọi trên instance đó.

## BQ. 3 việc trong 1 phiên: (1) sửa THẬT lỗ hổng bộ dò lặp qua bằng chứng log+ảnh chụp, có test biên dịch chạy thật; (2) thêm provider OpenRouter; (3) chat lần đầu có trí nhớ nhiều lượt (2026-09-23)

### Bối cảnh
Người dùng báo "lỗi vẫn tiếp tục như vậy" kèm ẢNH CHỤP MÀN HÌNH thật (chat
với prompt "xin chào", model trả lời lặp/lạc đề nghiêm trọng về đăng ký
tài khoản "24pay.biz") VÀ 2 file log thật (`debug_log.txt` tầng Dart,
`native_debug.txt` tầng Kotlin/C++) của đúng phiên đó, cộng 2 yêu cầu
tính năng mới: thêm provider OpenRouter, và "khi đổi model thì [model
mới] bắt đầu ở chỗ model cũ dừng lại — áp dụng cho sinh truyện/chat/dịch
thuật".

### (1) Lỗ hổng THẬT trong chính bộ dò lặp — không phải repetition_penalty
Đối chiếu log: `repetition_penalty=1.15` VÀ `"penalty"` trong
`mixed_samplers` ĐÃ được gửi đúng xuống native ở cả 2 lần chạy (OpenCL
lẫn CPU ép buộc) — nghĩa là chuỗi truyền tham số (mục AL→AV) không phải
nơi lỗi lần này. Đọc thẳng `mnn_bridge.cpp`/`looksLikeRepetitionLoop()`
(bộ dò lặp tầng native, chặn sớm khi model lặp — mục Z/AI/AJ/BK) VÀ bản
song song ở `local_provider.dart` (tầng Dart) — phát hiện bộ dò này có 2
tiêu chí (a) 1 ký tự chiếm >85% cửa sổ, (b) 1 cụm ngắn lặp CHU KỲ tối đa
60 ký tự — CẢ HAI đều không bắt được kiểu lặp trong ảnh chụp: model lặp
NGUYÊN VẸN 1 câu văn dài >200 ký tự (vượt hẳn trần 60 của tiêu chí (b)),
xen giữa là các đoạn diễn giải lại (paraphrase) chứ không phải 1 chu kỳ
ngắn lặp đều — người dùng phải tự bấm Huỷ sau 1557 ký tự vì bộ dò không
tự dừng.

Thêm tiêu chí (c): tách TOÀN BỘ văn bản đã tích luỹ thành từng câu (theo
`. ! ? \n`), so câu HOÀN CHỈNH gần nhất với tối đa 8 câu hoàn chỉnh trước
đó (chỉ tính câu ≥25 ký tự sau chuẩn hoá, tránh báo giả với câu ngắn kiểu
"Vâng." lặp tự nhiên) — bắt được lặp CẢ CÂU bất kể dài bao nhiêu, không
bị trần 60 giới hạn như tiêu chí (b). Áp cho CẢ 2 tầng (native + Dart,
đúng quy ước đồng bộ 2 tầng đã có từ mục Z/AJ).

**Tự bắt lỗi CHÍNH MÌNH qua test biên dịch chạy thật (g++, có sẵn trong
môi trường soạn dù không có Flutter/Dart SDK) — không chỉ đọc code bằng
mắt như mục BO đã rút kinh nghiệm là KHÔNG đủ:** bản đầu tiên của tiêu
chí (c) có lỗi thật — khi 2 dấu kết câu đứng liền nhau (vd ".\n", cực kỳ
phổ biến vì model hay xuống dòng ngay sau khi hết câu), việc tách câu
sinh ra 1 MẢNH RỖNG ở cuối danh sách; lấy thẳng phần tử cuối làm "câu
hoàn chỉnh gần nhất" sẽ vớ đúng mảnh rỗng đó (luôn dưới ngưỡng 25 ký tự)
→ hàm LUÔN trả về `false`, VÔ HIỆU HOÀN TOÀN kể cả khi có lặp thật ngay
trước đó. Phát hiện lỗi này bằng cách trích đúng hàm vừa viết ra 1 file
`.cpp` độc lập, biên dịch bằng `g++ -std=c++17 -Wall -Wextra`, chạy thử
với dữ liệu MÔ PHỎNG SÁT nội dung ảnh chụp thật — lần chạy đầu KHÔNG bắt
được lặp (sai). Sửa bằng cách LỌC trước danh sách câu hoàn chỉnh xuống
còn các câu ĐỦ DÀI (≥25 ký tự) rồi mới so phần tử cuối cùng của danh sách
ĐÃ LỌC — chạy lại 4 tình huống test (đúng ảnh chụp thật; văn bình thường
không lặp; câu ngắn lặp tự nhiên kiểu hội thoại; lặp cách nhau 1 câu xen
giữa) → CẢ 4 ĐỀU ĐÚNG. Sau đó trích lại hàm THẬT từ chính file đã sửa
(bằng script Python so khớp ngoặc, không gõ tay lại — tránh sai khác giữa
bản test và bản thật) và chạy lại bộ test đó lần nữa trên đúng code đã
commit — vẫn PASS cả 4.

Giới hạn thật — không giấu: đây là lớp phòng vệ CẮT LỖ SỚM HƠN (dừng sau
~1-2 lần lặp thay vì 1557 ký tự), KHÔNG phải sửa NGUYÊN NHÂN GỐC khiến
model lặp/lạc đề ngay từ đầu — câu hỏi "vì sao repetition_penalty=1.15 đã
tới nơi mà vẫn lặp nguyên câu" vẫn CHƯA có lời giải thật (2 khả năng chưa
loại trừ được, không đủ bằng chứng để chọn 1: (a) giá trị 1.15 thật sự
không đủ mạnh cho model merge/uncensored này, hoặc (b) lệnh `set_config`
THỨ HAI lúc generate — chỉ gửi giá trị số, không kèm lại `mixed_samplers`
— có thể (hoặc không) làm MNN reset pipeline sampler đã thiết lập lúc
load; không có mã nguồn MNN trong repo này để xác minh trực tiếp, và môi
trường soạn không có mạng để tải về kiểm tra). Cũng nhận thấy (KHÔNG sửa
lần này, ngoài phạm vi): lần chạy OpenCL trong log chỉ sinh được 156 ký
tự sau 173 giây (~0.9 ký tự/giây — CHẬM HƠN CPU ép buộc ở lần chạy ngay
sau đó, ngược đời), cache tuning OpenCL phồng tới 2048MB (vượt hạn mức
500MB, phải tự dọn) — dấu hiệu cache tuning có thể đang build lại từ đầu
thay vì tái sử dụng đúng, đáng điều tra riêng ở phiên sau.

### (2) Thêm provider OpenRouter (openrouter.ai)
`openrouter_provider.dart` — BỌC lại `OpenAICompatibleProvider` đã có
(cùng chuẩn request/response, chỉ khác base URL cố định sẵn
`https://openrouter.ai/api/v1`), không viết lại logic request/stream/
timeout. modelId để người dùng tự nhập (không hardcode — OpenRouter có
hàng trăm model, đổi liên tục). Nối vào `settings_service.dart`
(`_buildProvider()`) và `settings_screen.dart` (thêm lựa chọn trong
dropdown "Thêm API provider", ẩn ô Base URL vì đã cố định, hiện hộp gợi ý
định dạng modelId, sửa nhãn hiển thị trong danh sách provider đã lưu).
Giới hạn thật: KHÔNG gửi kèm 2 header khuyến nghị (không bắt buộc)
`HTTP-Referer`/`X-Title` — cố tình bỏ qua để giữ nguyên vẹn
`OpenAICompatibleProvider` không cần sửa. Chưa build/test thật.

### (3) "Đổi model giữa chừng thì tiếp tục đúng chỗ" — rà cả 3 nơi, chỉ 1 nơi THẬT SỰ thiếu
Rà code (không đoán) cả 3 luồng người dùng nêu:
- **Sinh truyện (Viết tiếp/Đắp thịt, `chapter_editor_screen.dart`)**: ĐÃ
  ĐÚNG sẵn — `provider` lấy MỚI qua `currentProvider()` mỗi lần bấm,
  `baseText` (nội dung ĐANG CÓ trong ô soạn, bất kể model nào viết ra)
  được chụp lại TRƯỚC khi sinh và nối `$baseText\n\n$textSoFar` ngay
  trong `onChunk` — kể cả bị Huỷ giữa chừng, phần đã sinh vẫn nằm lại
  trong ô soạn vì `onChunk` đã ghi liên tục. Đổi model giữa 2 lần bấm
  "Viết tiếp" (hoặc bấm lại sau khi Huỷ) đã tự động nối đúng mạch, không
  cần sửa gì.
- **Dịch thuật (`document_service.dart`)**: ĐÃ ĐÚNG sẵn — mỗi
  `DocumentChunk` có `resultText` riêng, `effectiveResume` bỏ qua chunk
  đã có `resultText`, `provider` cũng lấy MỚI mỗi lần chạy — đổi model
  giữa chừng tự động xử lý tiếp đúng từ chunk CHƯA xong, chunk model cũ
  đã dịch giữ nguyên.
- **Khung chat (`chat_screen.dart`)**: **THIẾU THẬT, không liên quan gì
  tới việc đổi model** — rà `rag.buildSystemPrompt()`/`buildContext()`
  (`rag_service.dart`) xác nhận CHỈ đụng tới Story Bible, KHÔNG hề tham
  chiếu `messages`/`sessionId`; grep toàn bộ file xác nhận biến `messages`
  (danh sách tin nhắn UI) CHƯA TỪNG được đưa vào prompt gửi model — MỖI
  tin nhắn là 1 lượt hoàn toàn độc lập, model không biết gì đã nói trước
  đó trong CHÍNH cuộc trò chuyện, dù cùng 1 model suốt hay đổi model giữa
  chừng. Đây là lý do thật khiến người dùng thấy "mất mạch khi đổi model"
  — thực ra mất mạch ở MỌI tin nhắn, đổi model chỉ là lúc dễ nhận ra
  nhất.

  Đã sửa: thêm `_buildRecentHistoryContext()` — chèn vài lượt GẦN NHẤT
  (giới hạn ngân sách 3000 ký tự, nhất quán cách `RagService` giới hạn
  Story Bible qua `loadRagBudget`, tránh đẩy model local cửa sổ ngữ cảnh
  nhỏ vượt sức) vào `systemPrompt` — CỐ Ý không đổi interface
  `AIProvider.generate*()` (chỉ nhận `systemPrompt`/`userPrompt` dạng
  chuỗi, không có mảng nhiều lượt thật) để tránh phải sửa cả 4 provider
  (Local/Anthropic/OpenAI-compatible/OpenRouter) — rủi ro cao, ngoài phạm
  vi yêu cầu lần này; có thể làm đúng chuẩn hơn (mảng `messages` nhiều
  lượt thật) ở 1 phiên sau riêng, nếu cần. Mỗi lượt lịch sử hiện rõ model
  nào đã trả lời (dùng lại field `providerLabel` đã có sẵn trên
  `ChatMessageRecord`, trước đây chỉ hiện trên UI, giờ đưa cả vào prompt)
  — đúng tinh thần câu hỏi gốc của người dùng.

### Giới hạn thật của mục (3) — không giấu
- Chưa build/test thật (như mọi mục, môi trường soạn không có Flutter/Dart
  SDK).
- Ngân sách 3000 ký tự là ước lượng hợp lý theo cùng logic RAG đã có,
  CHƯA đo thật xem có làm chậm phản hồi đáng kể hay tràn cửa sổ ngữ cảnh
  model local hay không.
- Vẫn là lịch sử dạng VĂN BẢN THÔ chèn vào `systemPrompt`, không phải
  format "nhiều lượt hội thoại thật" (multi-turn messages array) mà một
  số model/API hỗ trợ tốt hơn — đủ dùng, nhưng chưa phải giải pháp lý
  tưởng nếu muốn làm kỹ hơn sau này.

## BR. Tra cứu web THẬT về nguyên nhân gốc lỗi lặp — người dùng chỉ đúng: lẽ ra phải tra từ đầu (2026-09-23/24)

### Người dùng chỉ ra đúng — không phải tôi tự nhận ra
Bị hỏi thẳng "sao không tra web mà cứ đoán mò" — ĐÚNG, phiên trước tôi có
sẵn công cụ tìm kiếm web nhưng không dùng cho câu hỏi "vì sao
repetition_penalty=1.15 không cản được lặp", chỉ ghi "chưa xác nhận
được, không có mã nguồn MNN" rồi dừng lại — trong khi mã nguồn MNN là mã
nguồn MỞ, tra được thật. Tra lại ngay, kết quả khác hẳn hướng đang nghi.

### Phát hiện 1 — đây là lỗi THẬT, đang MỞ, ngay trên GitHub chính thức của MNN, không phải lỗi riêng của app này
`alibaba/MNN` issue **#4891** ("使用Qwen3-1.7B进行连续推理，出现概率重复回答" —
dùng Qwen3-1.7B suy luận liên tục, ra câu trả lời lặp theo xác suất),
đăng **18/9/2026** (6 ngày trước đúng sự cố "xin chào"/24pay.biz của
người dùng), **CÒN ĐANG MỞ, chưa có bình luận/fix từ MNN**. Người báo lỗi
dùng ĐÚNG cấu trúc config.json giống hệt app này (`penalty_window: 0,
n_gram: 8, ngram_factor: 1.0`...), test trên CẢ CPU LẪN OPENCL, và ghi rõ:
**"使用repetition_penalty=1.2依旧重复"** (dùng repetition_penalty=1.2 VẪN
lặp). Đây là bằng chứng THẬT, không phải suy đoán: giá trị số của
repetition_penalty (1.2 ở họ, 1.15 ở app này) không phải nguyên nhân —
tăng giá trị này KHÔNG giải quyết được, kể cả nếu app này tăng lên nữa.

Thêm bằng chứng: issue #3515 ("Qwen3 0.6B loops with default settings",
tháng 5/2025 — "Android app, Qwen 0.6B loops 100 percent cases for me")
cho thấy hiện tượng Qwen-trên-MNN dễ lặp đã được báo cáo từ hơn 1 năm
trước, KHÔNG PHẢI mới xuất hiện gần đây. Và ở tầng chính bản thân model
Qwen (không riêng MNN): `QwenLM/Qwen3-VL` issue #1611 ("Infinite
repetition bug still exists") ghi rõ **"Increasing the repetition penalty
is not an acceptable solution because it breaks the transcription of
naturally repetitive text"** — xác nhận từ chính phía Qwen: tăng
repetition_penalty không phải cách chữa triệt để, có đánh đổi thật.

### Phát hiện 2 — bằng chứng CPU CŨNG lặp (đã có sẵn trong log trước) mâu thuẫn với giả thuyết mục BI ("lỗi riêng OpenCL 3.6.0")
Mục BI (2026-09-19) ghim MNN về tag 3.5.0 vì nghi 2 thay đổi OpenCL/int4
mới ở 3.6.0 (GEMM heuristic scheduling + int4 image1d_buffer_t) là thủ
phạm — giả thuyết CHƯA từng build/test lại để xác nhận (tự ghi rõ trong
mục đó). Log thật ở mục BQ cho thấy: lần chạy **CPU ép buộc** (không hề
đụng tới OpenCL/GEMM/int4-image1d_buffer_t) **CŨNG lặp** y hệt (thậm chí
nặng hơn — 1557 ký tự "24pay.biz"). CPU backend không chạy qua bất kỳ
kernel OpenCL nào → nếu lỗi CHỈ do 2 thay đổi OpenCL ở 3.6.0, CPU phải
KHÔNG lặp. Vậy bằng chứng THẬT (không phải suy đoán) đã có sẵn trong
chính log mục BQ nhưng chưa được đối chiếu với giả thuyết mục BI — nay
đối chiếu xong: **giả thuyết mục BI (chỉ OpenCL 3.6.0) KHÔNG giải thích
đủ hiện tượng đang thấy**, khớp đúng hướng issue #4891/#3515 (vấn đề nằm
ở tầng Qwen+sampler, xảy ra trên CẢ 2 backend, không riêng OpenCL).

**Không revert ghim 3.5.0** — giữ nguyên, vì 3.6.0 vẫn có 2 thay đổi
OpenCL/int4 thật (changelog xác nhận), có thể VẪN góp phần (không loại
trừ hẳn được, chỉ là "không đủ giải thích MỌI trường hợp lặp" chứ không
phải "chắc chắn vô can") — chỉ không còn xem đây là LỜI GIẢI DUY NHẤT.

### Phát hiện 3 — 1 giả thuyết cũ (mục BQ tự nêu) giờ có bằng chứng để hạ độ ưu tiên
Mục BQ tự hỏi: `set_config` gọi LẦN 2 lúc generate (chỉ gửi giá trị số,
không kèm `mixed_samplers`) có thể đã LÀM MẤT pipeline sampler đã thiết
lập lúc load hay không. Tra changelog chính thức: MNN có hàm
**`merge_and_clear`** xử lý gộp cấu hình LLM — tức cơ chế THẬT là GỘP
(merge), không phải THAY THẾ toàn bộ — đúng như suy đoán ban đầu (trước
mục BI) mà mục BQ đã bỏ qua. Có 1 lỗi THẬT từng tồn tại ở đúng hàm này
("LLM JSON Merge: Fixed recursive JSON merge issue in merge_and_clear
for jinja config") nhưng đã được vá ở bản **3.4.1** (phát hành 3/2026) —
TRƯỚC bản 3.5.0 app đang ghim — nên bản vá đó đã có sẵn trong 3.5.0, khả
năng gọi `set_config` lần 2 xoá mất `mixed_samplers` giờ CHƯA loại trừ
hẳn được (không có bằng chứng khẳng định merge có đúng cho phần cấu hình
sampler/penalty như cho phần jinja hay không — đây là 2 phần config khác
nhau trong cùng class), nhưng có cơ sở TỐT HƠN để hạ độ ưu tiên xuống
dưới giả thuyết Qwen3+MNN ở Phát hiện 1.

### Kết luận thật — không tô hồng
- **Nguyên nhân khả dĩ nhất, có bằng chứng THẬT nhất tính đến lúc này:**
  lỗi lặp/trả lời lạc đề khi dùng model kiến trúc Qwen3 trên MNN là lỗi
  THẬT, ĐANG MỞ, THUỘC VỀ chính MNN (hoặc sâu hơn, thuộc chính kiến trúc
  Qwen3 khi kết hợp 1 số cấu hình sampler nhất định) — KHÔNG phải lỗi
  trong cách app này truyền tham số, và KHÔNG có cách cấu hình
  (`repetition_penalty` cao hơn, thêm `presence_penalty`/`frequency_penalty`...)
  nào được xác nhận là chữa triệt để, vì chính người dùng MNN khác đã thử
  và vẫn lặp.
- **Không có fix/workaround chính thức nào từ MNN tính đến thời điểm tra
  cứu** (issue #4891 còn mở, không có bình luận). Vì vậy lớp phòng vệ
  tầng app (bộ dò lặp mục BQ, đã test qua biên dịch thật) KHÔNG còn là
  "giải pháp tạm trong lúc chưa tìm ra gốc rễ" — mà là hướng xử lý ĐÚNG
  và CẦN THIẾT cho một lỗi thượng nguồn hiện chưa có bản vá, không phải
  việc app có thể "tự sửa dứt điểm" bằng cách đổi cấu hình.
- Vẫn CHƯA build/test thật để xác nhận bộ dò mục BQ có đủ xử lý model
  Qwen3-8B remnant cụ thể của app hay không trên máy thật.
- Có thể cân nhắc: báo lại phát hiện "CPU cũng lặp, không riêng OpenCL"
  lên đúng issue #4891 (kèm model + config app đang dùng) — dữ liệu này
  có thể giúp ích cho chính nhóm MNN, chưa làm trong phiên này vì ngoài
  phạm vi sửa code.

## BS. Người dùng hỏi tiếp 3 việc: có phải riêng Alibaba/Qwen, bản MNN nào cũng lỗi hay chỉ mới nhất, có nên xét lại công nghệ MNN — tra cứu SÂU HƠN + tự bắt được suýt lặp lại đúng sai lầm cũ (2026-09-24)

### (1) Có phải "cùng 1 tập đoàn mà vẫn lỗi" — riêng Alibaba/Qwen?
Tra thêm: lỗi lặp xảy ra RỘNG hơn hẳn phạm vi Alibaba — diễn đàn HuggingFace
xác nhận **"Occurs in ALL Llama models (3:8B, 3:70B, 3.1, 3.2)"**, thử tăng
`repetition_penalty` lên 1.3 vẫn còn lặp, 1.1 thì lặp nhiều hơn. Lặp cũng
xảy ra với model Qwen chạy qua vLLM/harness KHÁC (không phải MNN) trong ít
nhất 2 nguồn khác đã tra được. Có hẳn nghiên cứu học thuật giải thích lặp
là "structural pathology" từ chính cơ chế self-attention + softmax (không
phải lỗi cài đặt riêng của 1 engine nào) — repetition_penalty dạng nhân
(chia/nhân theo dấu logit) còn bị chứng minh **phụ thuộc "gauge"**: cùng 1
giá trị 1.3 có thể đổi 58-96% token ở model này nhưng gần như không đổi gì
ở model khác, vì "điểm 0" của logit là tuỳ ý theo từng checkpoint. **Kết
luận: đây KHÔNG phải "ngay cả Alibaba cũng lỗi trên chính model Alibaba"
theo nghĩa hẹp/đáng xấu hổ — đây là 1 bài toán khó, CHƯA giải xong trên
toàn ngành**, MNN+Qwen3 chỉ là 1 trường hợp cụ thể đang có ticket mở.

Có 1 khác biệt kỹ thuật THẬT đáng chú ý: `llama.cpp` đã có sẵn **DRY
sampler** (Don't Repeat Yourself — phát hiện CẢ CHUỖI lặp, không chỉ token
đơn lẻ, coi là kỹ thuật chống lặp tân tiến hơn repetition_penalty cổ điển)
trong chuỗi sampler mặc định. Tra tài liệu MNN chính thức
(mnn-docs.readthedocs.io): MNN có `n_gram`/`ngram_factor` (phạt thêm cho
n-gram lặp dài) nhưng **KHÔNG có DRY** — đây là 1 khoảng cách công nghệ
THẬT giữa 2 engine, không phải suy đoán.

### (2) Bản MNN mới nhất hay tất cả đều lỗi?
Không xác nhận được "TẤT CẢ" (không có cách kiểm hết mọi bản), nhưng bằng
chứng trải dài đủ để bác bỏ "chỉ mới nhất": issue #3515 (Qwen3 0.6B lặp
100% trường hợp) đăng từ **5/2025**, issue #4891 (Qwen3-1.7B, cấu hình
giống hệt app) đăng **9/2026** — cách nhau hơn 1 NĂM, xuyên qua rất nhiều
bản phát hành MNN khác nhau trong khoảng đó. **Đây là loại lỗi DAI DẲNG,
không phải 1 bản gần đây mới gây ra** — nên riêng việc đổi bản MNN (lên
hoặc xuống) khó có khả năng tự nó giải quyết dứt điểm.

### (3) MNN "chỉ chạy được CPU" → có nên xét lại công nghệ?
**Chưa đúng ở khẳng định "chỉ chạy được CPU"** — tài liệu mục 2.2 (lý do
chọn MNN ban đầu) đã ghi rõ: benchmark THẬT đo trên chính máy Zenfone 8
của người dùng qua app "MNN Chat" gốc (Google Play, sản phẩm thật đã công
khai, không phải benchmark hãng công bố) cho kết quả OpenCL (GPU) **Decode
16.7 t/s** — nhanh hơn CPU (~1 t/s) tới 15-16 lần. Lần chạy OpenCL bất
thường trong log gần đây (173 giây/156 ký tự, cache tuning phồng 2048MB)
là 1 hiện tượng RIÊNG của phiên đó, CHƯA rõ nguyên nhân (đáng điều tra
riêng — mục BQ đã ghi), không phải bằng chứng "MNN không chạy được GPU"
như 1 kết luận chung.

**Nhưng câu hỏi xét lại công nghệ vẫn CHÍNH ĐÁNG, và tài liệu đã có sẵn
phần lớn dữ kiện cần** — tổng hợp lại thay vì lặp lại:
- Mục 5.52 (2026-07-31, đã xác nhận qua tài liệu CHÍNH THỨC Qualcomm):
  NPU máy này (Hexagon v68, Snapdragon 888) DƯỚI mức tối thiểu Qualcomm
  công bố cho LLM-trên-NPU (cần v73+) — **QNN đã bị loại, không phải do
  MNN, do chính phần cứng**, không đổi engine nào khác cứu được việc này.
- Mục 5.65 (2026-08-01, đã tra tài liệu chính thức `llama.cpp`
  `docs/backend/OPENCL.md`): Adreno 660 (GPU máy này) **KHÔNG nằm trong
  danh sách đã kiểm chứng** của llama.cpp (chỉ có Adreno 750/830 — đời
  8 Gen 3/8 Elite) — Vulkan trên Adreno được cộng đồng ghi "có thể chậm
  nếu driver chưa vá". **`llama.cpp` KHÔNG chắc chắn nhanh hơn trên ĐÚNG
  phần cứng này** — cùng vùng chưa kiểm chứng như MNN đang gặp phải.
- Mới tra thêm lần này: `llama.cpp` có DRY sampler (lợi thế công nghệ
  THẬT cho đúng loại lỗi đang gặp) — nhưng CHƯA có bằng chứng nào (cũ lẫn
  mới) khẳng định DRY thật sự tránh được lặp cho MỌI trường hợp (issue
  Qwen3-VL #1611 vẫn ghi lặp "still exists" dù nêu rõ tăng penalty không
  phải lời giải).

### Suýt lặp lại đúng sai lầm cũ — tự bắt được TRƯỚC khi đề xuất, không phải sau
Trước khi tra web, đã định đề xuất: tăng `ngram_factor` (1.0→cao hơn) làm
lever chưa dùng tới. Đọc lại kỹ `MnnBridge.kt` (không chỉ tin trí nhớ của
chính phiên này) mới thấy: **việc NÀY đã được thử THẬT** ở mục AY
(2026-09-16: `penalty_window=0`, `n_gram` 8→4, `ngram_factor` 1.0→1.3) và
**REVERT ở mục BA** (2026-09-17) sau khi đo bằng chính log thật trên máy:
chậm hơn **2.21 lần** mỗi token, lặp vẫn xảy ra Ở ĐÚNG cùng độ dài như
trước — tăng `ngram_factor` không hề ngăn được lặp, chỉ tốn thêm thời gian
tính mỗi token (và làm nút Huỷ phản hồi chậm hơn do khoảng cách giữa 2 lần
kiểm tra cờ huỷ giãn theo). Nếu không đọc lại đoạn này, tôi đã lặp lại
đúng thứ người dùng đang phàn nàn — "đoán mò tốn thời gian" — dù có tra
web hỗ trợ. Bài học: tra cứu phải gồm CẢ tài liệu dự án ĐÃ CÓ (đọc kỹ,
không chỉ nhớ đại khái), không chỉ web bên ngoài.

### 1 manh mối THẬT trong tài liệu chưa ai theo đuổi tiếp — có liên quan nhưng KHÔNG khớp hẳn sự cố hiện tại
Mục BE (2026-09-19) từng tìm ra 1 lỗi THẬT KHÁC, đã vá: `_buildFinalPrompt`
gộp `systemPrompt`+`userPrompt` làm 1 khối rồi nhét vào 1 turn "user" duy
nhất khi render Jinja — khiến model (bằng chứng: xảy ra giống hệt ở CẢ
Llama 8B lẫn Hunyuan 1.8B, hỏi "xin chào" nhưng model PARAPHRASE LẠI system
prompt, 1 bản còn dịch sang tiếng Hoa, rồi mới lặp "FFFF") coi khối văn bản
vai trò+Story Bible dài là thứ cần phản hồi thay vì nhận ra câu hỏi thật.
Mục BE tự ghi rõ: CHƯA xác nhận tách vai trò có giải quyết TRIỆT ĐỂ hiện
tượng lặp hay chỉ giảm bớt — "có thể là 2 hiện tượng liên quan nhưng không
hoàn toàn trùng nhau".

Đối chiếu với log sự cố "24pay.biz" đang bàn (mục BQ): dòng
`_tryRenderJinja: render THANH CONG... (mục BE: tach rieng 1 turn
system/user)` xác nhận bản vá mục BE ĐANG hoạt động cho đúng model này —
và prompt render cuối cùng (`<|im_start|>user|xin chào<|im_end|>|...`)
KHÔNG hề có turn "system" (vì `systemPrompt` rỗng ở đúng lần test đó,
không bật persona/Story Bible) — nghĩa là điều kiện gây lỗi mục BE (system
prompt dài lẫn vào) **KHÔNG hề có mặt** trong sự cố đang bàn, vậy mà lặp
vẫn xảy ra. Đây là bằng chứng khá chắc: sự cố "24pay.biz" là 1 hiện tượng
KHÁC, không phải cùng nguyên nhân với mục BE — càng củng cố hướng Phát
hiện 1 ở mục BR (Qwen3+MNN sampler, issue #4891) hơn là lỗi cấu trúc
prompt đã vá.

Cũng tra thêm: model đang dùng
(`allura-org-remnant-qwen3-8b-MNN-q4-chinh`) render Jinja THÀNH CÔNG (cần
có sẵn `jinja.chat_template` hợp lệ trong `llm_config.json`) — khác hẳn 2
model gây lỗi ở mục AX/BA (OccultAI-Morpheus-8B,
Orion-zhen-Qwen2.5-7B-Uncensored — nghi KHÔNG có `prompt_template` lẫn
`model_type`) — khớp với việc notebook convert model của người dùng
(`LocalNovel_Convert_Model_To_MNN.ipynb`) dùng đúng `llmexport.py` chính
thức, công cụ mục AX đã xác nhận thường xuất kèm `prompt_template`/
`chat_template` hợp lệ. Vậy model đang dùng KHÔNG rơi vào nhóm "thiếu
template" của mục AX — càng loại bớt hướng đó cho đúng sự cố lần này.

### Khuyến nghị thật — không né tránh câu hỏi nhưng không đề xuất viết lại engine chỉ vì 1 sự cố
KHÔNG đề xuất đổi hẳn sang `llama.cpp` ngay — 2 lý do đã có sẵn trong tài
liệu (mục 5.65: chưa kiểm chứng nhanh hơn trên ĐÚNG phần cứng này; đổi
engine là việc viết lại toàn bộ tầng native, rủi ro/chi phí rất lớn so với
1 sự cố lặp cụ thể) vẫn còn nguyên giá trị, cộng thêm: lợi thế DRY sampler
của llama.cpp KHÔNG có bằng chứng chắc chắn giải quyết dứt điểm (issue
Qwen3-VL #1611 vẫn ghi nhận lặp tồn tại dù dùng harness có DRY). Đây là
quyết định lớn, nên cân nhắc riêng, có chủ đích, KHÔNG lồng vào lúc đang
sửa 1 bug — sẽ hỏi lại rõ nếu người dùng muốn đi hướng này thật.

Việc THẬT nên làm tiếp, theo đúng thứ tự chi phí thấp → cao:
1. Đã làm (mục BQ): bộ dò lặp tầng app tự dừng sớm hơn — vẫn là lớp phòng
   vệ ĐÚNG cho 1 lỗi thượng nguồn chưa có bản vá.
2. Có thể thử — CHƯA làm, cần người dùng xác nhận có muốn thử không vì
   tốn thời gian đo trên máy thật: đổi SANG model KHÁC kiến trúc (không
   phải Qwen3) cho slot đang lỗi, xem lặp có hết theo model hay không —
   rẻ hơn hẳn đổi engine, và tách bạch được "lỗi do Qwen3" hay "lỗi do
   MNN nói chung" bằng 1 phép thử thật thay vì đọc thêm issue.
3. Có thể báo lên issue #4891 (đã nêu ở mục BR) — không tốn công sửa code,
   có thể nhận được hướng dẫn/bản vá thật từ chính nhóm MNN.

## BT. Người dùng hỏi tiếp: MNN Chat gốc có lặp không, bao nhiêu năm chưa sửa, GPU "phế" thì trái tôn chỉ số 1 (2026-09-24)

### (1) App "MNN Chat" gốc (chính Alibaba, benchmark THẬT dùng để chọn MNN ở mục 2.2) — CÓ bị bug này
Tra được review THẬT trên Google Play, đúng app
`com.alibaba.mnnllm.android.release`: **"Very fast. BUT buggy mess,
specially with qwen models. I tried feeding the model with a prompt
file... the model produces gibberish or repetitive [output]."** — xác
nhận trực tiếp: KHÔNG PHẢI riêng app này gặp lỗi, chính app gốc Alibaba
dùng làm bằng chứng benchmark cũng bị người dùng thật phản ánh đúng kiểu
lỗi này, đặc biệt với model Qwen. Cũng tìm thêm 1 dự án mã nguồn mở hoàn
toàn khác (`private-mind`, không liên quan MNN) gặp ĐÚNG hiện tượng
("Qwen 3... no repetition penalty configured... no loop guard") và chọn
ĐÚNG hướng xử lý giống mục BQ: viết bộ dò lặp hậu kiểm (`loopDetection.ts`)
thay vì trông cậy vào sampler — 1 dự án độc lập khác đi tới cùng kết luận.

### (2) "Bao nhiêu năm chưa sửa" — cần chỉnh lại khung thời gian cho đúng
Qwen3 (kiến trúc đang gây lỗi) mới phát hành khoảng giữa 2025 — tức mới
~1,5 năm tuổi tính tới nay, không phải "nhiều năm". Lặp vô tận là bài toán
CHƯA giải xong trên toàn ngành (xem mục BS: xảy ra cả ở Llama, cả ở Qwen
chạy ngoài MNN) — kể cả kỹ thuật DRY sampler của `llama.cpp` (coi là tân
tiến hơn) cũng KHÔNG có bằng chứng giải quyết dứt điểm. Không phải MNN bỏ
mặc lỗi nhiều năm — là cả ngành chưa giải xong 1 bài toán khó, MNN có 1
phần lỗi cụ thể (Qwen3) đang là ticket mở gần đây.

### (3)+(4) GPU "phế" → trái tôn chỉ số 1 — đúng, đây là điều KHÔNG được lơ đi, nhưng có 1 phát hiện làm thay đổi hẳn cách đọc bằng chứng
Tôn chỉ số 1 ghi rõ ở mục 1 tài liệu: **"model AI local bắt buộc phải
chạy được tối thiểu GPU... CPU-only vẫn bị coi là 'vứt'"** — đúng, không
né tránh.

Nhưng đối chiếu kỹ: dòng ĐẦU TIÊN của `debug_log.txt` gây ra sự cố đang
bàn ghi `MA_NGUON_BUILD=mucAV_2026-09-15` — tức APK đó được build TỪ BẢN
MÃ NGUỒN mục AV (15/9), còn bản GHIM MNN 3.5.0 chỉ được thêm ở **mục BI,
19/9 — SAU đó 4 ngày**. `build.yml` là workflow dán riêng trên GitHub
(không nằm trong file zip, không tự đổi theo mã nguồn app) — APK gây ra
log chậm OpenCL/lặp "24pay.biz" **RẤT CÓ THỂ đã build TRƯỚC KHI bản ghim
3.5.0 tồn tại**, cũng chưa hề có bản vá cấu trúc prompt (mục BE, 19/9) hay
bộ dò lặp cải thiện (mục BQ, 23/9) — tất cả các bản vá SAU 15/9 chưa hề
được build/chạy thử THẬT trên máy, dù đã có sẵn trong mã nguồn từ nhiều
ngày.

**Điều này nghĩa là gì — nói thẳng, không tô hồng theo hướng có lợi:**
KHÔNG có nghĩa là GPU "chắc chắn ổn" — chỉ có nghĩa là **bằng chứng OpenCL
chậm hiện có (173 giây/156 ký tự, cache 2048MB) đến từ 1 bản build CŨ,
CHƯA có bất kỳ bản vá nào của phiên làm việc này** — kết luận "GPU phế"
dựa trên dữ liệu đó cũng cùng loại rủi ro như việc tôi suýt đề xuất lại
`ngram_factor` ở mục BS: kết luận trên bằng chứng CHƯA đủ mới. Benchmark
GỐC (16.7 t/s, đo bằng app MNN Chat thật, KHÔNG qua tầng app này) vẫn là
bằng chứng THẬT duy nhất đo được TRÊN ĐÚNG máy này — chưa có bằng chứng
mới đủ mạnh để phủ nhận nó.

### Việc THẬT cần làm trước khi kết luận bất cứ điều gì về GPU
Build lại từ file zip MỚI NHẤT (đã gồm mục BI/BE/BQ) qua GitHub Actions,
chạy lại đúng phép thử "xin chào" trên backend OpenCL, so `MA_NGUON_BUILD`
đầu log để CHẮC CHẮN đang chạy bản mới — nếu vẫn chậm bất thường + cache
tuning phồng to y hệt, MỚI có bằng chứng THẬT để nói GPU đang có vấn đề
CHỨ KHÔNG PHẢI do build cũ, và MỚI cần bàn tiếp việc "quay lại tôn chỉ số
1" một cách nghiêm túc. Nếu tốc độ trở lại bình thường, đây từng chỉ là 1
lần build cũ/chưa vá — không phải bằng chứng chống lại chính công nghệ
MNN.

## BU. Log mới (2026-09-26) — lặp xảy ra ở CẢ 2 model, model Llama 3 lặp "FFFF" không bị bộ dò bắt; phát hiện mục BH tự mâu thuẫn với mục BQ (2026-09-26)

### Bằng chứng mới
Log mới cho thấy CẢ 2 model đều có vấn đề trong CÙNG 1 phiên: model 1
(`OccultAI-Morpheus-8B-v2`, prompt dùng ĐÚNG khuôn Llama 3
`<|begin_of_text|>...<|eot_id|>` — KHÔNG PHẢI Qwen3) lặp thành
`---\nFFFFFFFF...`, người dùng phải tự Huỷ sau **342 giây, chỉ 73 ký tự**
(~4,7 giây/ký tự — cực chậm, chưa rõ vì sao). Model 2
(`allura-org-remnant-qwen3-8b`) cũng được người dùng báo là lặp, log chi
tiết bị cắt trước đoạn hiển thị nội dung nên chưa đối chiếu được mẫu lặp
cụ thể.

Build tag đầu log vẫn ghi `mucAV_2026-09-15` — NHƯNG dòng log
`_tryRenderJinja...(mục BE: tach rieng 2 turn system/user)` xuất hiện,
chứng tỏ mã nguồn THẬT chạy trong bản build này đã có mục BE (19/9) — tức
chuỗi `MA_NGUON_BUILD` chỉ là 1 dòng chữ tĩnh CHƯA từng được cập nhật lại
qua nhiều phiên, không phản ánh đúng mã nguồn thật đang chạy. Đã sửa dứt
điểm trong phiên này (xem bên dưới) để tránh gây hiểu lầm lần sau.

### Model Llama 3 CŨNG lặp — càng củng cố "không riêng Qwen3/Alibaba"
`OccultAI-Morpheus-8B` dùng khuôn Llama 3 rõ ràng (không phải ChatML của
Qwen) — khớp thêm 1 bằng chứng nữa cho kết luận mục BS/BT: đây KHÔNG phải
lỗi riêng kiến trúc Qwen3, mà là hiện tượng ảnh hưởng nhiều kiến trúc
khác nhau qua chính pipeline MNN của app này.

### Lỗ hổng THẬT trong bộ dò lặp — ngưỡng 320 byte trở thành điểm mù khi sinh QUÁ CHẬM
`accumulated_.size() < 320` là ngưỡng override TRƯỚC KHI bất kỳ tiêu chí
(a)/(b)/(c) nào được chạy. Log xác nhận: tới lúc người dùng tự bấm Huỷ,
tổng tích luỹ mới **73 byte** — CHƯA BAO GIỜ chạm 320 — nên dù nội dung
lặp là "FFFFFF..." (đúng kiểu tiêu chí (a) — 1 ký tự chiếm áp đảo — sinh
ra để bắt), không tiêu chí nào được chạy. Ngưỡng 320 hợp lý cho (b)/(c)
(cần đủ dữ liệu phân biệt chu kỳ thật với trùng hợp) nhưng là điểm mù chết
người khi tốc độ sinh cực chậm — người dùng phải chờ TOÀN BỘ thời gian
sinh 320 byte đó (ở tốc độ ~4,7s/ký tự, tức OVER 25 phút) trước khi bộ dò
có cơ hội đầu tiên để chạy.

### Bản vá — thêm lớp kiểm tra SỚM, độc lập ngưỡng 320
Thêm `hasEarlyFlood()`/`_hasEarlyFlood()` (native + Dart) — chạy TRÊN
TOÀN BỘ văn bản đã tích luỹ, KHÔNG chờ ngưỡng 320, CHỈ bắt đúng 1 kiểu: 1
ký tự (UTF-8 thật) chiếm >90% (khắt khe hơn 85% của tiêu chí (a) gốc, bù
cho mẫu nhỏ hơn — trần tối thiểu 24 ký tự thay vì 60). Đã test qua biên
dịch thật (`g++ -std=c++17 -Wall -Wextra`), trích ĐÚNG hàm từ file đã
commit (không gõ tay lại) qua 4 tình huống: mô phỏng đúng "FFFF" trong
log (bắt được ở byte thứ 33, cách xa 320) — văn bản thường không lặp —
cụm từ lặp tự nhiên (không phải 1 ký tự) — cười "ha ha ha" tự nhiên — CẢ
4 đúng như kỳ vọng.

Với tốc độ ~4,7s/ký tự đã thấy, bắt ở byte 33 thay vì 73 chỉ rút ngắn thời
gian chờ phần nào (không phải tức thì) — bản thân tốc độ cực chậm lúc
model rơi vào trạng thái lặp là 1 hiện tượng RIÊNG, chưa giải thích được
(nghi vấn, CHƯA xác nhận: nếu `penalty_window=0` nghĩa là "quét lại TOÀN
BỘ lịch sử không giới hạn" mỗi token — càng sinh nhiều token lặp, chi phí
quét mỗi token sau đó càng tăng — có thể giải thích ĐỒNG THỜI cả lặp lẫn
chậm dần, nhưng đây là suy đoán CHƯA kiểm chứng, không có mã nguồn MNN
trong repo để xác minh trực tiếp).

### PHÁT HIỆN QUAN TRỌNG — mục BH ("XÁC NHẬN THẬT, không còn giả thuyết") tự mâu thuẫn với bằng chứng SAU ĐÓ ở mục BQ
Đọc lại mục BH (19/9) khi tìm hiểu tiếp câu hỏi người dùng — mục đó tự
nhận: người dùng chuyển "Ép CPU", thử lại, **"KHÔNG còn lặp ký tự ở BẤT
KỲ model nào đã thử"** — dùng ĐÚNG cụm "XÁC NHẬN THẬT (không còn là giả
thuyết)". Nhưng log mục BQ (23/9, 4 ngày sau) cho thấy: model Qwen3
remnant chạy **Ép CPU** (`backendPreference=2, backend: cpu`) **VẪN lặp
nặng** ("24pay.biz" lặp nhiều lần). Đây là 2 lần đo THẬT, cho kết quả
NGƯỢC NHAU trên cùng 1 điều kiện (Ép CPU) — mục BH đúng cho ĐÚNG model/
lúc đó (không nghi ngờ người dùng đo sai), nhưng bị mục BQ chứng minh
KHÔNG tổng quát được cho MỌI model như câu chữ "bất kỳ model nào" đã
khẳng định — lặp lại đúng khuôn mẫu "kết luận SỚM rồi bị bằng chứng SAU
phủ định 1 phần" đã xảy ra nhiều lần trong tài liệu này (mục AP bị AS,
mục AY bị BA). Không xoá/sửa mục BH (giữ nguyên làm lịch sử), chỉ ghi rõ
ở đây: **"Ép CPU luôn hết lặp" KHÔNG còn là kết luận đáng tin cậy** — có
thể đúng với 1 số model/tình huống (như mục BH), sai với 1 số khác (như
mục BQ) — tuỳ model cụ thể phản ứng khác nhau với chính engine/cấu hình
này, không có quy luật chung "cứ CPU là an toàn".

### Đã sửa thêm — build tag `main.dart` cập nhật lần đầu sau rất nhiều phiên
Cập nhật `MA_NGUON_BUILD` từ `mucAV_2026-09-15` lên `mucBU_2026-09-26`,
liệt kê tóm tắt mọi mục AW→BU — tránh lặp lại nhầm lẫn "build tag nói 1
đằng, log lại có dòng chứng tỏ mã nguồn mới hơn" như đã thấy ở chính log
đang phân tích trong mục này.

### Giới hạn thật — không giấu
- Chưa build/test thật (như mọi mục — môi trường soạn không có Flutter/
  Dart SDK).
- Chưa giải thích được vì sao ~4,7 giây/ký tự lúc rơi vào lặp — suy đoán
  `penalty_window=0` quét không giới hạn mới chỉ là giả thuyết, chưa kiểm
  chứng.
- Chưa có log chi tiết nội dung lặp của model 2 (Qwen3 remnant) trong lần
  này — chưa xác nhận được bộ dò câu (mục BQ) có bắt đúng mẫu lặp của nó
  lần này hay không, cần log đầy đủ hơn (không bị cắt) để xác nhận.
- "Ép CPU luôn an toàn" (mục BH) đã bị bằng chứng sau phủ định 1 phần —
  khuyến nghị trong `local_optimization_screen.dart` (thêm ở mục BH) nên
  được coi là "có thể giúp với 1 số model", không phải giải pháp chắc
  chắn — CHƯA sửa lại câu chữ mô tả trong màn hình đó ở phiên này (ngoài
  phạm vi, cần cân nhắc riêng cách diễn đạt lại cho đúng mức độ chắc chắn
  thật).

## BV. Log rebuild THẬT với mục BU — bộ dò sớm HOẠT ĐỘNG ĐÚNG, nhưng lộ ra bí ẩn mới: ~215 giây giống hệt nhau ở 2 kiến trúc khác hẳn nhau (2026-09-26)

### Xác nhận: build tag ĐÃ đúng, bộ dò sớm mục BU ĐÃ hoạt động thật
Log mới ghi đúng `MA_NGUON_BUILD=mucBU_2026-09-26` — xác nhận người dùng
đã rebuild với mã nguồn mới nhất. Cả 2 lần sinh đều tự dừng bởi CHÍNH bộ
dò native (`[CHAN DOAN LAP VO TAN]`), KHÔNG cần người dùng tự bấm Huỷ nữa
— model 1 (Llama 3) dừng ở 31 ký tự, model 2 (Qwen3) dừng ở 24 ký tự —
đúng thiết kế mục BU. Đây là XÁC NHẬN THẬT đầu tiên (qua log production
thật, không phải test biên dịch riêng) rằng bản vá mục BU có tác dụng.

### Phát hiện mới, đáng chú ý hơn cả bug lặp: ~215 giây GIỐNG HỆT NHAU ở 2 model hoàn toàn khác kiến trúc
- Model 1 (Llama 3, OccultAI-Morpheus-8B): STEADY=214373ms trước khi bộ
  dò bắt được, tích luỹ 31 ký tự.
- Model 2 (Qwen3, allura-org-remnant-qwen3-8b): STEADY=216918ms trước khi
  bộ dò bắt được, tích luỹ 24 ký tự (WALL=1979008ms — log tự phát hiện
  "RAT CO THE may da ngu GIUA CHUNG", chênh 1.762.090ms — nhưng STEADY,
  loại trừ thời gian ngủ, vẫn ~217 giây y hệt model 1).

2 model KHÁC HẲN kiến trúc, KHÁC checkpoint, hội tụ về ĐÚNG cùng 1 khoảng
thời gian tính toán THẬT (STEADY) trước khi sụp — quá trùng hợp để coi là
ngẫu nhiên. Điều này đổi hướng nghi vấn: có thể đây KHÔNG (chỉ) là lỗi
riêng của sampler/kiến trúc Qwen3 hay Llama3 — mà là 1 hiện tượng CHUNG,
xảy ra ở 1 mốc THỜI GIAN/TẢI TÍNH TOÁN gần như cố định, bất kể model nào —
gợi ý nguyên nhân có thể nằm ở tầng THIẾT BỊ/DRIVER (nhiệt độ, GPU tự hạ
xung sau 1 khoảng tải nặng liên tục) hơn là tầng model/sampler thuần tuý.

### Đối chiếu với baseline tốc độ ĐÃ ĐO THẬT trước đây (mục G) — chênh lệch 50-100 LẦN, không phải "model vốn nặng" như đã chấp nhận ở mục H
Mục G (28/8) đo STEADY=140ms cho 2 ký tự đầu (~70ms/ký tự) lúc model khoẻ
mạnh, trên đúng model 8B cùng lớp. Lần này: 214373ms/31 ký tự ≈ **6915
ms/ký tự** — chậm hơn baseline đã đo và đã được người dùng CHẤP NHẬN ở
mục H tới **~99 LẦN**. Mục H người dùng đồng ý "model vốn nặng, không cần
sửa tốc độ, đừng tự cắt CHỈ VÌ CHẬM" — đồng ý đó dựa trên baseline ~70-
140ms/ký tự, KHÔNG áp dụng cho mức chậm gấp ~100 lần đang thấy ở đây. Đây
là 2 hiện tượng khác nhau về BẢN CHẤT/độ lớn, không phải cùng 1 thứ đã
được chấp nhận trước đó.

### Đã kiểm tra: WakeLock đã có sẵn, khá kỹ — không phải nguyên nhân (ít nhất không phải nguyên nhân DUY NHẤT)
Rà `MnnBridge.kt`/`GenerationService.kt`: đã có hệ thống WakeLock
(`PARTIAL_WAKE_LOCK`) khá đầy đủ — giữ trực tiếp đồng bộ trước khi vào
coroutine (né race condition), cộng `GenerationService` tự làm mới mỗi 30
phút (trần 40 phút) — không phải thiếu sót đơn giản. Log lần 1 (không có
cảnh báo "may ngu") xác nhận: dù KHÔNG hề ngủ, thời gian tính toán THẬT
(STEADY) vẫn y hệt ~214 giây rồi sụp — nên WakeLock/máy ngủ giải thích
được phần chênh WALL vs STEADY ở lần 2, nhưng KHÔNG giải thích được hiện
tượng CỐT LÕI (chậm ~100 lần rồi sụp) ở cả 2 lần.

### Đã thêm — CHỈ đo, KHÔNG tự cắt (đúng tinh thần mục H)
Thêm log định kỳ mỗi ~5 giây trong `JniStreamingBuf::xsputn` (ghi số byte
đã tích luỹ + thời gian đã trôi qua kể từ lúc bắt đầu `generate()` này) —
KHÔNG throw, KHÔNG dừng gì, thuần quan sát. Mục đích: lần sau gặp lại hiện
tượng này, log sẽ cho thấy độ chậm tăng DẦN theo thời gian (khớp giả
thuyết `penalty_window=0` quét lại toàn bộ lịch sử không giới hạn, càng
sinh lâu càng chậm) hay sụp ĐỘT NGỘT tại 1 mốc cụ thể (khớp giả thuyết máy
nóng/GPU tự hạ xung) — hiện CHƯA có đủ dữ liệu để phân biệt 2 giả thuyết
này, cố tình không đoán thêm.

### Giới hạn thật — không giấu
- Chưa build/test thật (như mọi mục).
- Log định kỳ mới thêm CHƯA từng chạy thật — chưa biết định dạng log thực
  tế trông ra sao, có cần chỉnh gì không.
- Vẫn chưa có giả thuyết nào được xác nhận cho vì sao chậm ~100 lần —
  mục này chỉ thêm công cụ QUAN SÁT, không phải bản sửa nguyên nhân gốc.
- Chưa loại trừ được: liệu chính việc CHẠY LIÊN TỤC 2 model nặng ngay sau
  nhau trong CÙNG 1 phiên (~470+ giây tải OpenCL gần như liên tục, cộng cả
  bước load() ~17s mỗi lần) có phải là điều kiện CẦN để hiện tượng này xảy
  ra hay không — chưa có dữ liệu về việc chạy 1 MODEL DUY NHẤT, ngay sau
  khi mở app, có bị y hệt hay không.

## BW. Thêm cache vào `build.yml` — build LocalNovel chậm hơn hẳn 1 project khác của người dùng (2026-09-27)

### Bối cảnh — hiểu sai ban đầu, đã sửa
Người dùng gửi ảnh chụp build GitHub Actions của 1 project KHÁC
(`VideoEditorAPK`, 3m14s) kèm câu hỏi ngắn — ban đầu hiểu NHẦM đó là
project ĐANG gặp vấn đề cần sửa cảnh báo cache. Người dùng chỉnh lại
đúng: ảnh đó là VÍ DỤ TỐT (build nhanh nhờ có cache), câu hỏi thật là làm
sao để LocalNovel (build "vài chục phút") cũng nhanh được như vậy.

### Nguyên nhân THẬT, đọc thẳng `build.yml` — không đoán
`build.yml` của LocalNovel KHÔNG cache bất kỳ thứ gì — không Gradle,
không pub, không Flutter SDK. Quan trọng nhất: **mỗi lần chạy đều clone +
biên dịch LẠI TOÀN BỘ engine MNN (LLM+OpenCL+QNN) từ mã nguồn C++** — dù
bản MNN đã ghim cố định ở tag 3.5.0 (mục BI) không đổi giữa các lần build
(build nặng tới mức workflow phải tự thêm 12GB swap để tránh hết RAM).
Đây gần như chắc chắn là phần tốn thời gian nhất, trong khi phần THẬT SỰ
đổi giữa các lần build (suốt cả phiên làm việc này) chỉ là code Dart/
Kotlin — mã nguồn MNN không hề đụng tới.

### Đã sửa — 3 lớp cache
1. **Cache thư viện MNN đã build sẵn** (`MNN/project/android/build_64`,
   `actions/cache@v4`, khoá theo hash nội dung chính `build.yml` + version
   NDK) — nếu cờ CMake/bản MNN/QNN SDK không đổi (không đổi gì trong file
   này), TRÚNG cache thì BỎ QUA HẲN bước biên dịch C++ nặng nhất, dùng
   thẳng `.so` đã cache. Bước "Clone mã nguồn"/"Vá demo TTS"/"Tải QNN SDK"
   vẫn chạy bình thường mọi lần (chi phí nhỏ, và các bước sau cần cây mã
   nguồn MNN + QNN SDK có mặt) — CHỈ bước biên dịch CMake được đánh dấu
   `if:` để bỏ qua, không đụng tới các bước còn lại — an toàn hơn cố bỏ
   qua cả chuỗi nhiều bước liên tiếp.
2. **Cache SDK Flutter + gói pub** — bật `cache: true` / `pub-cache:
   true`, tham số CHÍNH THỨC của `subosito/flutter-action@v2` (đã tra
   cứu xác nhận qua tài liệu chính thức action này, không đoán).
3. **Cache thư viện Gradle** (`~/.gradle/caches`, `~/.gradle/wrapper`) —
   `flutter build apk` gọi Gradle bên trong, scaffold Flutter luôn tạo
   mới mỗi lần nên chưa từng tái dùng cache Gradle giữa các lần build.

### Giới hạn thật — không giấu
- **CHƯA xác nhận đường dẫn thật của `hashFiles('build.yml')`** — chỉ có
  nội dung file này ở dạng tải lên riêng, không thấy cây thư mục repo
  GitHub thật. Nếu file nằm ở đường dẫn khác (vd
  `.github/workflows/build.yml`), cần sửa lại chuỗi trong 2 dòng `key:`
  cho khớp — nếu sai đường dẫn, `hashFiles()` trả về rỗng: cache vẫn chạy
  được nhưng KHÔNG tự làm mới khi đổi cờ CMake/bản MNN/QNN SDK (rủi ro
  dùng nhầm cache cũ, không phải lỗi dừng build).
- Chưa build/test thật — cần chạy 2 lần liên tiếp (không đổi gì) để xác
  nhận lần 2 thật sự bắt cache (`cache-hit: true` trong log Actions) và
  rút ngắn thời gian build.
- Gói `jni` cố tình luôn tự nâng lên bản mới nhất (`--major-versions`) —
  không nằm trong khoá cache Gradle, nên phần cache đó không hoàn hảo
  (vẫn tái dùng được phần lớn dependency ổn định khác).
- Chưa đo được cache MNN giúp rút ngắn bao nhiêu phần trăm thời gian build
  thật — chỉ có cơ sở lý luận (bước build C++ đủ nặng để cần thêm swap),
  chưa có số liệu trước/sau thật.

## BX. Model đột nhiên không nạp được sau build đầu tiên có cache — nguyên nhân THẬT: NDK r30 (19 ngày tuổi), không phải bản vá cache (2026-09-27)

### Bằng chứng loại trừ bản vá cache
Ảnh chụp GitHub Actions xác nhận: build ra APK lỗi là **"Build APK #1"** —
LẦN ĐẦU TIÊN, DUY NHẤT từng chạy trong repo này (không có build nào
trước đó). Không thể có chuyện cache cũ/hỏng bị dùng lại — không có gì để
mà cache trước lần này. Bản vá cache (mục BW) bị loại trừ hoàn toàn khỏi
nghi vấn bằng bằng chứng trực tiếp, không phải suy luận.

### Nguyên nhân THẬT — tra được qua chính log GitHub Actions
Log bước "Cài NDK mới nhất có sẵn" của build #1 in ra: `Dùng NDK:
ndk;30.0.16248370` — tức **NDK r30**. Tra cứu xác nhận: r30 là bản LTS,
phát hành CHÍNH THỨC ngày **8/9/2026** — chỉ 19 ngày trước build #1 — mới
tới mức chính GitHub Actions còn có yêu cầu MỞ (issue #14722, chưa xong)
để thêm bản này vào runner image mặc định (nghĩa là workflow phải TỰ TẢI
r30 qua `sdkmanager`, không phải bản có sẵn). MNN 3.5.0 (đang ghim, mục
BI) phát hành khoảng 4/2026 — TRƯỚC KHI r30 tồn tại — nên chắc chắn chưa
từng được chính đội MNN build/test bằng toolchain r30 (LLVM/Clang mới
hơn hẳn, xem changelog r30: "Updated LLVM to clang-r574158").

### Đã sửa — ghim cố định NDK r29 thay vì "luôn lấy mới nhất"
Đổi bước "Cài NDK mới nhất có sẵn" (tự dò qua `sdkmanager --list`, không
kiểm soát được) thành ghim thẳng `ndk;29.0.14206865` (NDK r29, tra cứu
xác nhận số hiệu chính xác qua trang wiki chính thức
`github.com/android/ndk/wiki`) — đây là bản "mới nhất" trong SUỐT quãng
MNN 3.5.0 được phát triển/phát hành (r30 chỉ thay thế r29 từ 8/9/2026, rất
lâu sau khi 3.5.0 đã ra mắt) — nhiều khả năng đúng hoặc rất gần bản
toolchain chính đội MNN đã dùng. Vẫn đủ mới để có SVE2/KleidiAI (lý do
ban đầu bỏ NDK cũ) — r29 là bản chính sau r28, không phải bản cũ kỹ.

### Bị hỏi thẳng — đúng, đáng lẽ phải thấy trước, không phải sau khi lỗi
Người dùng chỉ ra đúng: dự án ĐÃ có bài học y hệt với chính MNN (mục BI —
"luôn lấy master mới nhất" từng bị nghi là nguyên nhân gây lặp ký tự,
phải đảo ngược ưu tiên sang ghim bản ổn định) — mà bước NDK vẫn giữ nguyên
kiểu "luôn lấy mới nhất" suốt từ đầu, không ai (kể cả tôi, dù đã đọc toàn
bộ `build.yml` VÀ mục BI nhiều lần trong chính phiên này) chủ động ghép 2
việc lại để cảnh báo trước — chỉ tìm ra SAU khi người dùng đã dính lỗi.
Đây là điểm cần rút kinh nghiệm thật: 1 lớp phòng vệ (ghim version) được
xác nhận có giá trị ở 1 chỗ trong dự án nên được RÀ LẠI có áp dụng đủ ở
MỌI chỗ tương tự hay chưa, thay vì chỉ áp đúng chỗ vừa bị phát hiện.

### Đã rà lại toàn bộ `build.yml` tìm các chỗ "luôn lấy mới nhất" khác — chỉ còn 1 chỗ, ĐÃ CÓ LÝ DO CHÍNH ĐÁNG, không sửa mù
Grep toàn file tìm "latest"/"mới nhất"/"--major-versions"/"upgrade": còn
đúng 1 chỗ khác — `flutter pub upgrade jni --major-versions` (bước "Nâng
jni lên bản mới nhất"). Đọc lại lịch sử ĐÃ ghi sẵn trong chính file (thêm
27/7): bản `jni` cũ (1.0.1, bị kéo vào gián tiếp) có lỗi THẬT đã xác nhận
(gọi hàm `kotlin()` không tương thích tổ hợp Gradle/Kotlin/AGP hiện tại)
— bản MỚI HƠN đã BỎ HẲN đoạn gây lỗi đó (xác nhận qua changelog chính
thức "Removed the dependency on kotlin_gradle_plugin"). Khác bản chất với
NDK: (a) có bằng chứng THẬT bản cũ bị lỗi + bản mới đã sửa, không phải
"đổi vì muốn tính năng mới" như NDK; (b) `jni` chỉ là gói Dart hỗ trợ
BUILD Gradle, không quyết định mã máy thật của chính engine AI như NDK —
rủi ro thấp hơn hẳn. KHÔNG sửa chỗ này — sửa mù có thể giẫm lại đúng lỗi
`kotlin()` mà quyết định "luôn lấy mới nhất" ở đây từng được đưa ra để
né.

Các phần khác (Flutter, AGP, Gradle, Kotlin, MNN, QNN SDK) đều đã ghim số
phiên bản cụ thể từ trước — không phát hiện thêm chỗ hở nào khác.

### Giới hạn thật — không giấu
- Đây là GIẢ THUYẾT có căn cứ mạnh (thời điểm khớp chính xác — r30 vừa
  phát hành 19 ngày trước, cơ chế hợp lý — toolchain mới hơn build ra mã
  máy khác), KHÔNG PHẢI đã xác nhận 100%. Cần chạy lại build với bản ghim
  NDK r29 và xác nhận model có nạp lại được hay không mới coi là XONG.
- Chưa build/test thật (như mọi mục — môi trường soạn không có Flutter/
  Dart SDK).
- Nếu build lại với NDK r29 mà VẪN lỗi nạp model: đây KHÔNG phải nguyên
  nhân (hoặc không phải nguyên nhân duy nhất) — cần quay lại tìm hướng
  khác, không lặp lại giả thuyết này.

## BY. Build #2 (NDK r29) THẤT BẠI ngay ở CI — do chính bộ kiểm tra tôi vừa thêm, không liên quan NDK (2026-09-27)

### Lỗi thật, tự gây ra
Build #2 (bản ghim NDK r29, mục BX) fail sau 9m26s, ngay ở bước "Xác nhận
THẬT libMNN.so/libllm.so...": tìm thấy `libMNN.so` hợp lệ (7199072 byte)
nhưng KHÔNG tìm thấy `libllm.so`/`libMNN_llm.so` riêng → bước tự viết ở
mục BW cho đây là lỗi, `exit 1`, dừng cả build — CHƯA HỀ chạm tới việc
đóng gói APK, nên chưa hề kiểm chứng được giả thuyết NDK r29 của mục BX.

### Đọc lại đúng `CMakeLists.txt` — bộ kiểm tra của tôi SAI, không phải build sai
`android_native/app/src/main/cpp/CMakeLists.txt` (dòng 48+58:
`if(MNN_LLM_LIB)`) xác nhận: file LLM RIÊNG là TÙY CHỌN — dự án TỰ đã
thiết kế để chấp nhận cả 2 khả năng (tách riêng `libllm.so` HOẶC gộp
thẳng vào `libMNN.so`), không coi thiếu file riêng là lỗi. Với cờ
`-DMNN_SEP_BUILD=OFF` đang dùng (rất có thể nghĩa là "không tách build
riêng"), khả năng cao LLM đã gộp thẳng vào `libMNN.so` — khớp với kích
thước 7.2MB tìm được (đủ lớn để chứa cả 2). Bộ kiểm tra ở mục BW viết
THÊM 1 yêu cầu khắt khe hơn chính CMakeLists.txt của dự án, mà không đọc
lại kỹ dòng `if(MNN_LLM_LIB)` trước khi viết — lỗi thật của tôi.

### Đã sửa
Đổi đoạn kiểm tra `libllm.so`/`libMNN_llm.so` từ `exit 1` (dừng build)
thành chỉ ghi log GHI CHÚ (không dừng gì) — khớp đúng mức độ "tuỳ chọn"
mà chính `CMakeLists.txt` đã thiết kế. Vẫn giữ nguyên yêu cầu bắt buộc
với `libMNN.so` (đúng, khớp `FATAL_ERROR` thật trong `CMakeLists.txt`).
Đã test lại qua bash thật (không chỉ đọc bằng mắt) cả 4 tình huống: thiếu
libMNN.so (fail đúng), libMNN.so rỗng (fail đúng), chỉ có libMNN.so đã
gộp LLM (PASS — đúng tình huống build #2, trước đây fail sai), có cả 2
file riêng (PASS) — cả 4 đúng như kỳ vọng.

### Giới hạn thật — không giấu
- Giả thuyết NDK r29 (mục BX) VẪN CHƯA được kiểm chứng thật — build #2
  chưa từng chạy tới bước đóng gói APK. Cần build #3 (với bản sửa ở mục
  này) để lần đầu tiên thật sự kiểm chứng được cả 2 giả thuyết cùng lúc.
- Đây là bằng chứng cụ thể cho thấy: thêm 1 lớp "an toàn" (bộ kiểm tra)
  mà không đọc kỹ code đã có sẵn (CMakeLists.txt) có thể tự tạo ra lỗi
  mới — không phải lý do để ngừng thêm lớp an toàn, mà là lý do để LUÔN
  đối chiếu với code thật đang có trước khi viết điều kiện fail cứng.

## BZ. NDK bị loại trừ hoàn toàn — nguyên nhân THẬT tìm được qua tra LẠI tài liệu dự án (mục 63, 2026-08-01), không phải code mới (2026-09-28)

### NDK r29 vs r30 — kết quả GIỐNG HỆT nhau, loại trừ hẳn giả thuyết mục BX
Xác nhận qua build #3 (NDK r29, CI thành công) — APK build #3 vẫn lỗi
`load()` trả `false` ở CẢ OpenCL lẫn CPU, CẢ 2 model, giống hệt build #1
(NDK r30). Vậy bản NDK không phải khác biệt thật — giả thuyết mục BX bị
bác bỏ bằng bằng chứng trực tiếp (không phải suy luận).

### Phát hiện thêm: repo `localai6969691/LocalNovel` là repo MỚI HOÀN TOÀN
Build #1 là lần build ĐẦU TIÊN trong repo này (27/9) — "phiên từng chạy
tốt" 26/9 mà tài liệu vẫn lấy làm mốc so sánh thực ra đến từ 1 repo/tài
khoản KHÁC hẳn (`localai696969-cell`, repo cũ từng build tới #142) —
CHƯA từng có build nào từ repo mới này chạy thành công trên máy thật.

### Bị hỏi thẳng, đúng trọng tâm: "trước kia đã từng bị bug này và đã fix, sao không đọc tài liệu kỹ thuật để tham khảo"
Đúng — thay vì tiếp tục đọc code C++ đoán mò, tra lại chính tài liệu dự
án trước: tìm thấy **mục 63 (2026-08-01)** đã ghi nhận CHÍNH XÁC triệu
chứng đang gặp lại — "lần `loadModel` ĐẦU TIÊN trong phiên thất bại hoàn
toàn (CẢ OpenCL lẫn CPU cùng trả `false`, không phải crash)" — nghi
storage ngoài (`/storage/emulated/0/Download/...`) chưa sẵn sàng ngay
lúc app vừa mở (mount trễ/quyền truy cập chưa cấp xong kịp) — và bằng
chứng THẬT: **lần thử THỨ HAI (35 giây sau, không sửa gì khác) đã load
bình thường**. Mục 63 tự ghi rõ việc cần làm: "nếu lặp lại, có thể cần
thêm bước thử lại tự động sau vài giây ở `ensureLoaded()`" — kiểm tra
`local_provider.dart` xác nhận: **việc này CHƯA TỪNG được làm** — dòng
`throw Exception('Không nạp được model...')` vẫn nổ ngay khi lần ĐẦU
TIÊN thất bại, khớp CHÍNH XÁC với thông báo lỗi "Lỗi sau 0s" trong ảnh
chụp màn hình của người dùng ("sau 0s" = không hề đợi/thử lại gì cả).

### Đã sửa
Thêm vòng lặp thử lại trong `ensureLoaded()` (`local_provider.dart`) —
nếu lần gọi `loadModel` ĐẦU TIÊN thất bại (native trả `success != true`
hoặc ném lỗi), đợi 3 giây rồi tự thử lại ĐÚNG 1 lần trước khi báo lỗi
cho người dùng — không lặp vô hạn (tránh treo UI nếu lỗi thật khác hẳn,
vd file model đã bị xoá/hỏng thật). Log rõ từng lần thử để đối chiếu sau.

### Giới hạn thật — không giấu
- Chưa build/test thật.
- Mục 63 chỉ ghi "vài giây", KHÔNG xác nhận 35 giây là mức TỐI THIỂU
  cần thiết hay chỉ là thời gian ngẫu nhiên người dùng thử lại lúc đó —
  đợi 3 giây CÓ THỂ chưa đủ, cần build thật để xác nhận.
- Đây là giả thuyết có căn cứ mạnh (đúng tài liệu dự án tự ghi lại, đúng
  triệu chứng khớp 100%), KHÔNG PHẢI đã xác nhận qua build thật lần này.
- Nếu vẫn lỗi sau khi thử lại: bằng chứng sẽ RÕ hơn nhiều (log sẽ cho
  thấy CẢ 2 lần thử đều fail, loại hẳn giả thuyết "storage chưa sẵn
  sàng", cần tìm hướng khác — không phải NDK, không phải cache, không
  phải build.yml, vì cả 3 đều đã bị loại trừ bằng bằng chứng thật).
- Bài học tự rút ra, ghi lại để không lặp lại: khi gặp lỗi CÓ VẺ mới,
  PHẢI tra lại toàn bộ tài liệu dự án (`grep` từ khoá triệu chứng cụ thể)
  TRƯỚC KHI đọc code/đoán nguyên nhân mới — dự án đã có sẵn hơn 6000 dòng
  lịch sử debug, rất nhiều khả năng đã gặp và ghi lại y hệt trước đó.

## CA. Build #4 fail ngay ở bước clone MNN — cache TRÚNG lần đầu (sau build #3 thành công) làm lộ ra lỗi thứ tự bước tôi tự gây ra (2026-09-29)

### Lỗi thật
Log build #4: `git clone --depth 1 --branch 3.5.0 ... MNN.git` báo `fatal:
destination path 'MNN' already exists and is not an empty directory` —
fail sau 59 giây, dừng ngay ở bước clone, chưa chạm gì khác.

### Nguyên nhân
Build #3 thành công → cache MNN được LƯU lần đầu (đúng thiết kế mục BW).
Build #4 là lần ĐẦU TIÊN cache đó được TRÚNG. Thứ tự bước TRƯỚC ĐÓ: khôi
phục cache (đặt file vào `MNN/project/android/build_64`) chạy TRƯỚC bước
clone — khôi phục cache vào 1 đường dẫn LỒNG NHAU buộc phải TỰ TẠO thư
mục cha `MNN/` làm chỗ chứa, dù cache chỉ thật sự lưu đúng thư mục con
`build_64`. Bước `git clone` chạy ngay sau đó cố tạo lại chính thư mục
`MNN/` vừa bị tạo sẵn → bị git từ chối thẳng.

### Đã sửa
Đổi thứ tự: **clone trước, khôi phục cache sau**. Lúc khôi phục cache
chạy, `MNN/project/android/` đã có sẵn từ clone (cây mã nguồn thật, sạch)
— khôi phục cache chỉ cần thêm đúng thư mục con `build_64` vào cây đã
có, không còn ai tranh chấp việc tạo thư mục `MNN/` nữa.

### Giới hạn thật — không giấu
- Chưa build/test thật — cần build #5 để xác nhận thứ tự mới hoạt động
  đúng (cache vẫn trúng, clone không còn xung đột, build engine vẫn được
  bỏ qua đúng như thiết kế mục BW).
- Bản vá thử lại 3 giây khi `loadModel` thất bại (mục BZ) VẪN CHƯA được
  kiểm chứng thật — build #4 chưa từng chạy tới bước đóng gói APK, nên
  chưa có cơ hội test giả thuyết mục 63. Cần build #5 thành công mới bắt
  đầu kiểm chứng được.

## CB. Log 2026-09-30 BÁC BỎ mục BZ; đọc lại toàn bộ chuỗi BX→CA; thêm công cụ chụp NGUYÊN NHÂN THẬT khi `load()` false (2026-10-01)

### Vì sao mục này tồn tại
Người dùng gửi ảnh + log sau build đầu tiên CÓ bản vá thử lại của mục BZ:
cả 2 model (`allura-org-remnant-qwen3-8b-MNN-q4-chinh`,
`OccultAI-Morpheus-8B-v2-MNN-q4-chinh`) vẫn không nạp được. Người dùng nhắc
đúng (lần thứ hai): "trước kia bị bug này và đã fix, những lần fix cuối cùng
không đọc tài liệu kỹ thuật mà fix mù dẫn tới nhiều vòng không xong". Mục này
ghi lại kết quả đọc lại tài liệu + đối chiếu log, theo đúng quy tắc mục 0.

### Mục BZ BỊ BÁC BỎ bằng log thật — và nó đã khớp nhầm với mục 63
- Log có `lần 1/2` VÀ `lần 2/2` (cách nhau 3 giây) cho cả 2 model, cả 2 lần đều
  `{success: false}` — chính xác kịch bản mà BZ tự ghi "nếu vẫn lỗi sau khi thử
  lại → loại hẳn giả thuyết storage chưa sẵn sàng".
- BZ tuyên bố triệu chứng "khớp 100%" với mục 63. Đối chiếu lại: log mục 63 có
  `khong tim thay config.json — thu muc RONG`. Log hiện tại thì ngược lại: đọc
  được `config.json` (502 byte), `llm.mnn` (1325976 / 2302392 byte),
  `llm.mnn.weight` (~4GB), `tokenizer.mtok` (4–5MB) đều TỒN TẠI, danh sách thư
  mục đủ 8 file. Chỉ giống ở bề mặt (`load()` false ở cả OpenCL lẫn CPU), khác
  hẳn ở chi tiết. Đây là 2 bug khác nhau — BZ chọn mục 63 vì giống bề mặt, không
  đối chiếu chi tiết log.
- BZ còn kết luận "không phải NDK, không phải cache, không phải build.yml". Thực
  ra CHỈ NDK (build #3 r29 vs #1 r30) và cache (build #1 chưa có cache) bị loại
  bằng bằng chứng. **build.yml KHÔNG hề bị loại** — không có bằng chứng nào cho
  phần đó.

### Những gì log 2026-09-30 CHỨNG MINH được (không còn là giả thuyết)
1. File/đường dẫn/quyền truy cập đều ổn; `createLLM()` trả về xong, không null.
2. `load()` trả false sau khoảng **20–70 ms** ở OpenCL và **16–27 ms** ở CPU.
   Mục BV ghi `load()` bình thường mất ~17 giây với chính các model này. Tức nó
   chết ở 1 cổng rất sớm, TRƯỚC khi đụng weights/GPU, và cổng đó KHÔNG phụ thuộc
   backend → không phải lỗi GPU/OpenCL, không phải thiếu RAM, không phải storage
   chậm.
3. Đúng 2 model này đã nạp được ngày 26/9 (mục BV) bằng APK từ repo CŨ
   (`localai696969-cell`). Model không đổi (cùng tên/kích thước) nên **model và
   notebook convert KHÔNG phải biến thay đổi** (người dùng chỉ ra đúng điểm này;
   đề xuất "convert lại model bằng MNN 3.5.0" của tôi trước đó là hướng SAI, bỏ).
   Thứ thay đổi là APK (repo mới, build mới).
4. NDK và cache đã bị loại → biến còn lại trong APK là **phiên bản MNN runtime**
   (và các khác biệt build.yml chưa kiểm tra).

### LỖ HỔNG GỐC của cả chuỗi debug: chưa từng có bản ghi MNN nào chạy tốt
- Toàn bộ spec KHÔNG ghi giá trị `MA_NGUON_MNN_THAT_DUNG` hay commit hash MNN của
  bất kỳ APK nào từng chạy tốt (đã grep). Mục BI ghim 3.5.0 vào build.yml ngày
  19/9, nhưng không ai xác nhận APK chạy tốt ngày 26/9 đã thực sự build với bản
  ghim đó hay chưa (build.yml được dán tay lên GitHub, không nằm trong zip).
- Và nguyên nhân sâu hơn: khi `Llm::load()` false, LÝ DO THẬT do MNN in ra logcat
  (MNN_ERROR, tag `MNNJNI`, vì build `-DMNN_USE_LOGCAT=true`). App không có adb,
  và KHÔNG có dòng code nào đọc logcat (đã grep). Nên mọi vòng sửa từ BX đến CA
  đều đoán quanh 1 hộp đen — đây là lý do "fix mù" lặp lại.

### Giả thuyết đang mạnh nhất (CHƯA XÁC NHẬN — không được coi là kết luận)
Runtime MNN 3.5.0 (ghim ở mục BI) từ chối đọc model ở bước cấu hình/tokenizer,
trong khi APK chạy tốt ngày 26/9 có thể đã build bằng MNN khác (master/3.6.x).
Bằng chứng ủng hộ: (a) khớp đúng thứ tự "biến còn lại" ở trên; (b) `config.json`
của model có các khóa sampler (`tfs_z`, `penalty_window`, `n_gram`...) KHÔNG do
app/notebook ghi (đã grep) → do `llmexport` bản master sinh ra; (c) phần xuất
`tokenizer.mtok` của master còn được sửa tới giữa 9/2026 (PR alibaba/MNN #4878).
Bằng chứng ĐI NGƯỢC (đã tra release notes): `tokenizer.mtok` đã có từ chính MNN
3.5.0 — nên KHÔNG thể kết luận đơn giản là "3.5.0 không hiểu mtok".
Cách bác bỏ nhanh: nếu log CI (bước "In thông tin commit/version MNN") của build
cũ chạy tốt cũng là 3.5.0 thì giả thuyết này chết, phải tìm khác biệt build.yml
khác (bản QNN SDK, jni, Flutter...).

### Bản vá (chỉ quan sát, KHÔNG đổi luồng nạp)
- File MỚI `LoadDiagnostics.kt`; chỉ thêm 2 lời gọi ở `MnnBridge.kt` (đánh dấu
  mốc logcat trước `nativeLoadModel`, và chụp sau khi `ok == false`).
- Khi `load()` false, ghi vào `native_debug.txt`: (1) dấu vân tay APK
  (lastUpdateTime) + máy; (2) kích thước `libMNN.so`/`libmnn_bridge.so` thật trong
  APK + có chứa chuỗi `mtok`/`tokenizer.txt`/`jinja` hay không (chỉ báo thô);
  (3) nội dung `config.json`, `llm_config.json`, `export_args.json` + 64 byte đầu
  `tokenizer.mtok` dạng hex/ASCII; (4) **logcat của chính app từ mốc `LOAD_BEGIN`
  tới giờ — chứa dòng lỗi MNN thật**, dòng `[LOGCAT] ...`.
- Chạy SAU khi đã trả kết quả cho Dart; mọi phần bọc try/catch riêng, không ném
  exception; không chạy khi nạp thành công.
- Build tag `main.dart` → `mucCB_2026-10-01`, đã gộp thêm mục BZ (trước đó code
  BZ có trong APK nhưng thiếu trong tag — vi phạm quy tắc 5).

### Giới hạn thật — không giấu
- **CHƯA biên dịch/test thật.** Môi trường soạn không có `kotlinc` và không có
  mạng; đã tự đọc lại cú pháp nhưng chưa có compiler xác nhận. Các mục BP/BY/CA
  từng hỏng build vì lỗi kiểu này — nếu build #N báo lỗi ở `LoadDiagnostics.kt`,
  đọc đúng dòng lỗi CI và sửa, không đoán.
- Nếu Android chặn `logcat` từ app trên máy này (hiếm), phần (4) sẽ ghi rõ "0 dòng
  sau mốc" — khi đó 3 phần còn lại vẫn có giá trị.
- Bản vá KHÔNG sửa được lỗi nạp model; nó chỉ làm lần build kế tiếp cho ra LÝ DO
  THẬT. Đừng thêm bất kỳ bản vá đoán nào (NDK/cache/retry/convert lại model) cho
  tới khi đọc được các dòng `[LOGCAT]` và `[CHAN DOAN LOAD FAIL]`.
- Việc người dùng làm song song, không cần build: mở log CI build cũ chạy tốt
  (repo `localai696969-cell`) và build mới, so dòng MNN commit/version.

## CC. Bản vá CB HOẠT ĐỘNG — lý do THẬT `load()` false đã lộ ra (2026-10-01) — [THÍ NGHIỆM GỠ GHIM MNN 3.5.0 TRONG MỤC NÀY ĐÃ BỊ THU HỒI, xem phần cuối mục]

### Kết quả mục CB (đã xác nhận bằng log production thật, build tag `mucCB_2026-10-01`)
Bản chụp chẩn đoán chạy đúng ngay lần đầu và lần đầu tiên trong lịch sử dự án đọc được logcat của MNN:
```
I MNNJNI : Invalidate buffer to create MNN Module
E MNNJNI : [Error]: Load module failed, please check model.
E MnnBridge: Slot 0: load() that bai voi CA OpenCL lan CPU
```
Giống hệt cho cả 2 model (Qwen3-8B và Llama-3 Morpheus-8B), cả OpenCL lẫn CPU.

### Ý nghĩa (đã tra, không đoán)
- "Invalidate buffer to create ..." trong MNN là thông báo khi **bước kiểm tra FlatBuffers (verify) buffer của file
  `.mnn` thất bại** (xem alibaba/MNN issue #116: tác giả debug thấy "buffer verifying process failed"). Ở đây
  buffer là nội dung `llm.mnn`. Cổng lỗi là **`Module::load` của đồ thị `llm.mnn`** — KHÔNG phải tokenizer,
  KHÔNG phải config, KHÔNG phải storage/quyền, KHÔNG phải GPU. (Nhận định mục CB trước đó "bước cấu hình/tokenizer"
  là SAI chỗ; cổng thật là đồ thị llm.mnn.)
- File đọc được đủ kích thước (Kotlin đọc config/llm_config/tokenizer bình thường), nên không phải thiếu quyền.
- Mục BZ (storage chưa sẵn sàng) bị bác bỏ lần thứ hai; có thể gỡ code retry nếu muốn (vô hại, nhưng vô dụng).

### Phát hiện PHỤ, độc lập, đã có bằng chứng trực tiếp: OpenCL bị Android chặn
```
E linker : library "/system/vendor/lib64/libOpenCL.so" ... needed or dlopened by ".../libMNN.so"
           is not accessible for the namespace: [name="clns-4" ...]
I MNNJNI : OpenCL init error, fallback ...
```
Android 12+ (app targetSdk >= 31) chỉ cho app nạp `libOpenCL.so` của vendor nếu manifest khai
`<uses-native-library android:name="libOpenCL.so" android:required="false" />`. `build.yml` (đoạn vá manifest,
~dòng 200-215) KHÔNG có thẻ này (đã grep `uses-native-library`/`libOpenCL`: không có). => Với APK này GPU OpenCL
KHÔNG BAO GIỜ khởi tạo được, dù model nạp tốt. Đây không phải nguyên nhân `load()` false (CPU cũng fail), nhưng
là lỗi thật cần sửa SAU khi model nạp được. CHƯA sửa ở mục này để giữ nguyên tắc "đúng 1 biến mỗi lần thử".
(Dòng thêm dự kiến: trong script Python vá manifest, nối thêm
`'<uses-native-library android:name=\"libOpenCL.so\" android:required=\"false\" />'` trước `</application>`.)

### Những gì CHƯA biết — không được coi là kết luận
- Người dùng xác nhận tài khoản GitHub cũ (`localai696969-cell`) bị khoá → KHÔNG còn log CI cũ để đối chiếu bản MNN
  của APK từng chạy tốt (kiểm tra "A" ở mục CB vô hiệu). Spec cũng không ghi bản MNN của APK đó (đã grep).
- Spec ghi: trước mục BI (19/9) `build.yml` clone master HEAD (dự phòng tag 3.6.0); từ BI ghim 3.5.0. Nhưng
  APK chạy tốt ngày 26/9 build bằng `build.yml` nào thì KHÔNG có bằng chứng (build.yml dán tay; mục BT nói
  APK 24/9 có thể build TRƯỚC khi ghim tồn tại). Mục BI vốn là giả thuyết về lỗi lặp OpenCL, sau đó bị mục BN/BQ làm
  yếu đi (CPU cũng lặp, lỗi OpenCL là dài hạn). Nếu APK 26/9 THỰC RA đã là 3.5.0 và nạp tốt, giả thuyết dưới đây SAI.
- `export_args.json` của cả 2 model có các khóa rất mới của llmexport (`dflash_path`, `fuse_qkv_proj`,
  `fuse_gate_up_proj`, `fuse_ln_proj`, `fuse_linear_attn_gate`) — bằng chứng đây là bản xuất gần đây (notebook mặc định
  `mnn_git_ref="master"`). Tra cứu về DFlash không đủ để kết luận khóa này mới hơn hay cũ hơn MNN 3.5.0 (04/2026) —
  KHÔNG dùng làm bằng chứng quyết định.

### Giả thuyết đang thử (CHƯA xác nhận): runtime pinned 3.5.0 cũ hơn công cụ đã xuất model
Thay đổi duy nhất lần này: `build.yml` gỡ ghim 3.5.0 → master HEAD (build lỗi thì lùi tag 3.6.0), tức quay về cấu hình trước
mục BI. Bản MNN thật dùng được in ở dòng `MA_NGUON_MNN_THAT_DUNG` + bước "In thông tin commit/version MNN" của CI.
Model KHÔNG phải đổi/convert lại — người dùng nêu đúng: model không đổi, chỉ APK đổi.
- Nếu sau build này model nạp được → xác nhận (và cần cân nhắc lại mục BI: nó đã làm hỏng việc nạp model).
- Nếu VẪN "Invalidate buffer" → giả thuyết version CHẾT. Khi đó dùng dữ liệu mới của mục CC trong log: 64 byte đầu
  của `llm.mnn` (hex/ASCII) để xem file có phải FlatBuffers hợp lệ không, và thử nạp 1 model chính thức cũ (xuất 2025)
  để tách "lỗi do model" khỏi "lỗi do bản build mới" mà KHÔNG cần build lại.

### Thay đổi mục CC
- `build.yml` (file dán tay trên GitHub, nằm ngoài zip): chỉ đổi đúng phần chọn bản MNN (clone master; fallback 3.6.0;
  nhãn `MA_NGUON_MNN_THAT_DUNG`). Đổi `build.yml` làm khóa cache đổi → build MNN lại từ đầu (chậm hơn, bình thường).
- `LoadDiagnostics.kt`: thêm `llm.mnn` vào danh sách file in 64 byte đầu.
- `main.dart`: build tag `mucCC_2026-10-01`.
- Chưa biên dịch/test thật phần mới (chỉ thêm 1 phần tử vào danh sách chuỗi có sẵn — rủi ro thấp; mục CB cùng file đã biên dịch và chạy đúng).

### THU HỒI (cùng ngày) — thí nghiệm "gỡ ghim 3.5.0" sai hướng, KHÔNG dùng
Sau khi tôi giao `build.yml` gỡ ghim, người dùng bổ sung thông tin: trước đây họ đã xác định bản MNN ảnh hưởng
tới lỗi lặp ký tự trên GPU (CPU không lỗi), rồi tìm và chạy bản MNN "chạy không lỗi trên cả GPU lẫn CPU" — tức
chính bản ghim 3.5.0 của mục BI; còn trước khi có lỗi lặp thì mỗi lần build đều lấy bản MNN mới nhất (master).
- Hệ quả 1: gỡ ghim = quay lại đúng cấu hình mà người dùng gắn với lỗi lặp GPU. Thí nghiệm đó rủi ro tái phát lỗi cũ
  và mâu thuẫn với lời người dùng → THU HỒI. `build.yml` giữ NGUYÊN ghim 3.5.0 (file trong outputs đã trả về
  đúng bản gốc của người dùng).
- Hệ quả 2: nhiều khả năng APK chạy tốt 26/9 CHÍNH LÀ MNN 3.5.0. Chú thích trong `build.yml` (mục BX) cũng khẳng định
  "cùng bản MNN 3.5.0" nhưng đó là SUY ĐOÁN không có log CI đi kèm; lời người dùng là bằng chứng đầu tiên theo hướng này.
  Câu "spec chưa từng ghi bản MNN của APK chạy tốt" ở mục CB chưa chính xác hoàn toàn (BX có khẳng định, chỉ là
  không có log chứng minh) — đã sửa nhận định ở đây.
- Hệ quả 3: nếu cùng MNN 3.5.0 và cùng model mà trước nạp được, nay "Invalidate buffer" → giả thuyết "3.5.0 cũ hơn
  công cụ xuất model" YẾU ĐI nhiều. Thủ phạm phải nằm ở phần KHÁC giữa 2 lần build: toolchain (NDK; bước NDK cũ tự dò
  "mới nhất" nên bản r29 hay r30 của APK 26/9 cũng KHÔNG biết — r29 và r30 đều đã thử và đều lỗi, nhưng chưa thử bản
  cũ hơn), cờ build, bản runner... hoặc chính file model đã đổi sau 26/9 (spec không lưu kích thước cũ để so).
  Tìm kiếm web không thấy báo cáo công khai nào gắn "Invalidate buffer" với NDK — NDK vẫn chỉ là nghi phạm, chưa chứng minh.

### Bước tiếp theo (KHÔNG cần build): tách "lỗi do model" khỏi "lỗi do bản build mới"
Nạp thử 1 model nhỏ CHÍNH THỨC xuất cũ (taobao-mnn, "Last updated" năm 2025, thư mục đủ llm.mnn/llm.mnn.weight/config.json/
llm_config.json/tokenizer.txt) trong APK hiện tại:
- Nạp được → runtime tốt; 2 model đang dùng mới là bên có vấn đề (xuất bằng llmexport master) → xuất lại 1 model với
  `mnn_git_ref="3.5.0"` để kiểm chứng; kiểm tra file model có bị đổi/copy lại sau 26/9 không.
- Cũng "Invalidate buffer" → lỗi nằm ở bản build mới (libMNN.so) → bisect đúng 1 biến mỗi lần, bắt đầu từ NDK.

### Đọc lại tài liệu theo yêu cầu người dùng (cùng ngày) — những gì thật sự có trong spec
Người dùng chỉ ra (đúng): 2 model này đã nạp được qua rất nhiều lần sinh chữ; yêu cầu đọc các bug gần nhất TRƯỚC lỗi nạp model.
1. **Lần trước cùng triệu chứng (2026-08-23, phiên 10-11, dòng ~1128-1180):** model 8B `load()` FALSE trong ~1ms.
   Nguyên nhân THẬT: người dùng đã đổi tên `llm_config.json` → `config.json` theo gợi ý của bên phân tích khác (file
   `config.json.arch` là `llm_config.json` gốc bị đặt sai tên). Sửa = KHÔNG phải thử lại/NDK/cache, mà là khôi phục đúng cặp
   `config.json` / `llm_config.json`. Tìm ra nhờ in nội dung config + liệt kê file. Log 2026-10-01 LOẠI TRỪ nguyên nhân này:
   `config.json` (502B, cấu hình sampler) và `llm_config.json` (có `model_type` + `jinja`) đúng vai trò, đủ 8 file.
2. **Lần nạp tốt gần nhất (26/9, mục BU/BV):** log mang đúng `MA_NGUON_BUILD=mucBU_2026-09-26` — CÙNG build tag với APK đang lỗi;
   `load()` ~17s mỗi lần và có OpenCL chạy (mục BV). BQ→BU chỉ đụng bộ dò lặp/provider/chat (theo tiêu đề mục), không đụng đường nạp.
   LƯU Ý: build tag là chuỗi tự ghi, KHÔNG chứng minh code y hệt (mục BZ có trong APK nhưng thiếu trong tag — đã sửa ở mục CB).
3. Sau 26/9 chỉ có: BW (cache trong build.yml, 27/9), chuyển sang repo/tài khoản GitHub mới (build #1 lỗi ngay), rồi BX→CA là các
   chỉnh `build.yml`/retry tôi làm SAU khi lỗi đã xuất hiện. => Không có bản vá ứng dụng nào trước lỗi tác động tới nạp model.
4. **Hai hồi quy độc lập cùng nằm trong APK mới:** (a) llm.mnn bị từ chối ("Invalidate buffer"), (b) OpenCL bị linker chặn
   (`libOpenCL.so` not accessible) trong khi 26/9 OpenCL chạy được và spec chưa từng ghi lỗi (b) trước đây. Cả hai trỏ vào PHÍA BUILD
   (thư viện native/đóng gói), không phải file model hay logic app.
5. **Rút lại các nhận định thiếu căn cứ của chính tôi:** (i) "2 model đang dùng là bên có vấn đề" — SAI, chúng đã nạp tốt nhiều lần;
   (ii) BX "NDK r30 là nguyên nhân THẬT" — không có bằng chứng; bước NDK cũ cũng tự chọn bản mới nhất (r30 từ 8/9) nên nhiều
   khả năng APK 26/9 cũng build bằng r30, và r29 cũng lỗi => NDK KHÔNG được ủng hộ bởi dữ kiện nào.
6. **Việc cần để có dữ liệu thật thay cho đoán:** mở và SO SÁNH trực tiếp APK cũ (chạy tốt) với APK mới: `libMNN.so` (kích thước,
   chuỗi trình biên dịch trong ELF `.comment`, chuỗi phiên bản MNN), manifest (targetSdk, `uses-native-library`), danh sách file.
   Cần người dùng cung cấp file APK cũ nếu còn (Download/Actions artifact/Telegram...) + APK mới.

## CD. Chẩn đoán phía RUNTIME/BUILD (bỏ chẩn đoán xoay quanh model) + sửa OpenCL bị linker chặn (2026-10-01)

### Yêu cầu của người dùng và căn cứ
- APK cũ không còn (tài khoản GitHub cũ bị khoá) → KHÔNG thể so sánh APK; model đã nạp tốt nhiều lần và nhiều model đều lỗi
  → loại bỏ mọi chẩn đoán/giả thuyết xoay quanh model (config/llm_config/export_args/tokenizer không còn được dump nữa).
- Tham khảo fix cũ trong spec cho cùng triệu chứng `load()` FALSE: mục 33/35 (29/7: đường dẫn config + thứ tự `config.json` vs
  `llm_config.json`), mục 37/39 (crash do nạp nặng, `use_mmap`), phiên 10-11 (23/8: do đổi nhầm tên `llm_config.json`→`config.json`).
  Cả 3 lần đều là lỗi cấu hình/đường dẫn file model và được tìm ra nhờ IN dữ liệu thật rồi mới sửa. Log 01/10 đã loại trừ cả 3:
  config đọc đúng, đủ file, MNN chạy tới tận bước verify buffer `llm.mnn`.

### Thứ tự sự kiện thật trong logcat (01/10) — chỗ duy nhất MNN báo lý do
`Invalidate buffer to create MNN Module` → `[Error]: Load module failed, please check model.` (cả OpenCL lẫn CPU).
Nghĩa (xem alibaba/MNN issue #116): bước verify FlatBuffers buffer `.mnn` thất bại.

### Self-test mới (chỉ chạy khi `load()` thất bại hoàn toàn; không đổi luồng nạp) — `runLoadSelfTest()` trong `mnn_bridge.cpp`
- **(A) thư viện tự kiểm tra:** `Variable::save` tạo 1 net tí hon (Input→Relu) rồi `Interpreter::createFromBuffer` đọc lại chính nó.
  * (A) THẤT BẠI => bộ verify trong libMNN.so của bản build này hỏng => lỗi phía BUILD (toolchain/cờ), không liên quan model.
  * (A) THÀNH CÔNG => thư viện verify tốt; chỉ buffer `llm.mnn` bị từ chối.
- **(B) cách đọc file:** native `fopen/fread` đọc `llm.mnn`: ftell, số byte đọc được, CRC32, 32 byte đầu/cuối, rồi `createFromBuffer`.
  Kotlin (`LoadDiagnostics.dumpModelFileReadCheck`) tính CRC32 bằng Java. CRC khác nhau => đường đọc native lỗi (quyền/FUSE);
  giống nhau => native thấy đúng byte Java thấy. (Đây là kiểm tra CÁCH ĐỌC, không phải nội dung/độ hợp lệ của model.)
- **(C) phiên bản:** `MNN_VERSION_*` trong header lúc biên dịch cầu nối vs `MNN::getVersion()` của libMNN.so ĐANG CHẠY (dlsym).
  Lệch nhau => cầu nối và libMNN.so không cùng 1 bản (nghi ABI).
- Kotlin thêm: kích thước + CRC32 + chuỗi `clang version`/`Linker:` trong ELF của `libMNN.so` và `libmnn_bridge.so` thật trong APK
  (cho biết NDK/trình biên dịch thật đã dựng ra APK, không cần đoán từ build.yml) + logcat từ mốc `LOAD_BEGIN` như mục CB.

### Cách đọc kết quả (cây quyết định, KHÔNG cần APK cũ)
1. `[CD] (A) ... NULL` => libMNN.so verify hỏng => bisect phía build (NDK/cờ CMake/phiên bản CMake & runner), 1 biến mỗi lần;
   đối chiếu `compiler=[...]` của libMNN.so với libmnn_bridge.so và với log CI (bước cấu hình CMake in "compiler identification").
2. `(A)` THÀNH CÔNG nhưng `(B)` NULL, CRC native == CRC Java => thư viện tốt, byte đúng, chỉ riêng llm.mnn bị bản MNN này từ chối.
   Khi đó mới quay lại câu hỏi định dạng/phiên bản (mâu thuẫn với lời người dùng về 3.5.0 → phải xem `(C)`).
3. CRC native != CRC Java => lỗi đường đọc native (quyền/FUSE/targetSdk), không phải MNN hay model.
4. `(C)` header != runtime => cầu nối biên dịch với header của bản MNN khác libMNN.so (xem lại cache BW và thư mục install).

### Sửa kèm theo — OpenCL (bằng chứng trực tiếp trong logcat, độc lập với lỗi nạp)
`linker: library "/system/vendor/lib64/libOpenCL.so" ... is not accessible for the namespace clns-4` → thêm vào Manifest
`<uses-native-library android:name="libOpenCL.so" android:required="false" />` (bước vá manifest trong `build.yml`, nằm trong
`<application>`). Đã mô phỏng chạy ĐÚNG 2 step vá manifest trên manifest mẫu: service, receiver và thẻ mới đều có, XML hợp lệ.
`required="false"` => máy không có thư viện vẫn cài/chạy bình thường. Thay đổi này không đụng đường CPU nên không làm nhiễu phép thử trên.

### Giới hạn thật — không giấu
- C++ chưa được biên dịch với MNN thật (sandbox không có NDK/MNN). Đã kiểm cú pháp bằng `g++ -fsyntax-only` với stub CHỮ KÝ API công
  khai tôi nhớ (`Variable::save`, `_Input`, `_Relu`, `Interpreter::createFromBuffer/destroy`); nếu header MNN thật khác chữ ký này, CI sẽ
  báo lỗi đúng dòng — sửa theo dòng lỗi, không đoán. `MNN_VERSION_*` và `dlsym` được bảo vệ bằng `#if defined`/kiểm null.
- Self-test chạy trên đường lỗi nên nếu nó tự crash thì handler crash của dự án sẽ ghi log; không ảnh hưởng nạp thành công.
- Sửa OpenCL KHÔNG hứa sửa được lỗi nạp model. Nó chỉ gỡ 1 hồi quy có bằng chứng và loại nhiễu khỏi log.

## CE. KẾT QUẢ self-test mục CD — NGUYÊN NHÂN THẬT: runtime 3.5.0 cũ hơn công cụ đã xuất model (3.6.1) (2026-10-01)

### Dữ liệu thật (log 2026-10-01 22:33, build tag `mucCD_2026-10-01`, model `allura-org-remnant-qwen3-8b-MNN-q4-chinh`)
- `(C)` MNN_VERSION trong header = **3.5.0**; `MNN::getVersion()` của libMNN.so đang chạy = **3.5.0** → cầu nối và thư viện CÙNG bản (loại giả thuyết lệch ABI).
- `(A)` `Variable::save` tạo net 288 byte rồi `createFromBuffer` đọc lại = **THÀNH CÔNG** → bộ verify FlatBuffers của libMNN.so HOẠT ĐỘNG; build không hỏng (loại giả thuyết NDK/toolchain làm hỏng verify).
- `(B)` `llm.mnn`: ftell = fread = 1325976 byte, **CRC32 native 879043cd == CRC32 Java 879043cd** → native đọc đúng từng byte (loại giả thuyết quyền/FUSE/đường đọc).
- `(B)` `createFromBuffer(llm.mnn)` = **NULL (verify từ chối)**.
- 32 byte CUỐI của llm.mnn: `0a 00 00 00 04 00 00 00 05 00 00 00 33 2e 36 2e 31 00 00 00 07 00 00 00 4d 4e 4e 54 65 73 74 00`
  = chuỗi FlatBuffers độ dài 5 `"3.6.1"` + chuỗi độ dài 7 `"MNNTest"`. Đây là siêu dữ liệu phiên bản do công cụ xuất ghi vào đồ thị
  => **model được xuất bằng MNN 3.6.1** (suy từ vị trí/định dạng chuỗi; rất khớp với việc notebook mặc định `mnn_git_ref="master"` lúc master là 3.6.1).
- Trình biên dịch thật (đọc từ ELF trong APK): cả `libMNN.so` (7199064 B, CRC32 95d9a5cf) và `libmnn_bridge.so` (255840 B, CRC32 76ce6d9e) do
  `clang version 21.0.0 (r563880c)` + `LLD 21.0.0` dựng ra, tức NDK r29, đúng như `build.yml` ghim.

### Kết luận (có bằng chứng, không còn là giả thuyết)
Runtime **3.5.0 từ chối** file `llm.mnn` do **3.6.1** xuất, dù thư viện và đường đọc đều tốt. MNN chỉ cam kết runtime MỚI đọc được model CŨ, không ngược lại.
Vì model đã nạp tốt nhiều lần ở APK cũ, **APK cũ chắc chắn dùng runtime >= 3.6.1** (master/3.6.x trước khi mục BI ghim) — NÓ KHÔNG THỂ LÀ 3.5.0.
Điều này **đảo lại** nhận định ở mục CC phần "THU HỒI": thí nghiệm gỡ ghim 3.5.0 đi ĐÚNG hướng; tôi đã thu hồi nó dựa trên trí nhớ "bản ghim 3.5.0 từng chạy tốt",
trong khi dữ liệu file cho thấy điều đó không thể đúng với các model này. Lời người dùng "model nạp được trước kia" lại là mảnh ghép đúng: nó khớp với runtime >= 3.6.1.
Hệ quả cho mục BI: giả thuyết "3.5.0 hết lỗi lặp trên GPU" CHƯA BAO GIỜ được kiểm chứng trên máy, vì 3.5.0 không nạp nổi các model này. Muốn thử giả thuyết đó
đúng cách phải xuất lại model bằng công cụ 3.5.0 (`mnn_git_ref="3.5.0"` trong notebook) rồi mới so.

### Quy tắc mới (bắt buộc ghi nhớ)
**Runtime trong APK phải CÙNG HOẶC MỚI HƠN công cụ xuất model.** Nếu ghim runtime ở bản X thì notebook convert cũng phải đặt `mnn_git_ref = X`.
Không bao giờ ghim runtime thấp hơn bản đã xuất các model hiện có. Phiên bản xuất nằm trong chính `llm.mnn` (chuỗi "x.y.z" gần cuối file).

### Sửa OpenCL — ĐÃ XÁC NHẬN hoạt động
Log mới KHÔNG còn dòng `linker ... libOpenCL.so ... not accessible for the namespace`, không còn `OpenCL init error, fallback`/`Can't Find type=3 backend`,
và xuất hiện `Update cache to ...mnn_cachefile.bin, size = 268` (runtime OpenCL khởi tạo xong, load() mất 252ms thay vì ~60ms). Thẻ
`<uses-native-library android:name="libOpenCL.so" android:required="false" />` trong `build.yml` có tác dụng thật.

### Thay đổi mục CE
- `build.yml`: bước clone `--branch 3.5.0` → `--branch 3.6.1` (+ nhãn `MA_NGUON_MNN_THAT_DUNG` thành `tag-3.6.1-...`). Khóa cache gồm `hashFiles('build.yml')` nên cache 3.5.0 cũ
  tự bị bỏ, MNN được build lại từ đầu bằng 3.6.1 (lần build này chậm hơn bình thường). Nhánh dự phòng khi build lỗi vẫn là master HEAD (như cũ).
- `main.dart`: build tag `mucCE_2026-10-01`. Giữ nguyên bộ chẩn đoán mục CB/CD (chỉ chạy khi load thất bại).

### Kỳ vọng và cách bác bỏ
- Kỳ vọng: model nạp lại được; CI in `MA_NGUON_MNN_THAT_DUNG=tag-3.6.1-ghim-on-dinh`; log không còn "Invalidate buffer".
- Nếu VẪN "Invalidate buffer" với `(C)` báo runtime = 3.6.1 và `(A)` thành công thì giả thuyết "lệch phiên bản" bị bác bỏ → khi đó phải so sánh cấu trúc `llm.mnn` với schema 3.6.1.
- Chưa xác nhận: model Morpheus (chỉ thấy đuôi llm.mnn của Qwen3; cả 2 cùng notebook/cùng triệu chứng nên khả năng cao cũng 3.6.1 — log kế tiếp sẽ cho biết).
- Cần theo dõi RIÊNG (không phải kết luận): lỗi lặp ký tự trên GPU (mục BR/BS/BT, MNN issue #4891) có thể quay lại vì runtime lên 3.6.1; ghi chú bên thứ ba cho biết 3.6.1
  từng có báo cáo logits bằng 0 ở đường CPU độ chính xác thấp trên 1 đồ thị khác (không đủ để suy ra cho model này).

## CF. Người dùng phản biện: "nạp được mà GPU vẫn rác thì vô nghĩa; sao không giải quyết dựa trên bản cũ?" — đối chiếu lại bằng chứng (2026-10-02)

### 1. 3.5.0 có ổn định trên GPU (không sinh ký tự rác) không? — KHÔNG CÓ BẰNG CHỨNG
- Mục BI tự ghi đây là GIẢ THUYẾT chưa build/test thật; mục BN ghi "không có gì đảm bảo GPU ổn định ngay cả ở 3.5.0" (OpenCL sai kết quả tái diễn nhiều lần
  trong lịch sử MNN: #1736/2021, #1003, #2907/2024, #4802, #4836).
- Giả thuyết 3.5.0 CHƯA TỪNG có thể được thử với các model hiện có, vì runtime 3.5.0 không đọc nổi model xuất bằng 3.6.1 (mục CE).
- Issue #4836 (bằng chứng chính của BH/BI) là **Windows 11 + Intel Iris Xe** trên master 2026-09-04 (người báo còn thử cả wheel 3.6.1 chính thức, kết quả chi tiết CHƯA đọc) —
  KHÔNG phải Android/Adreno và không nói gì về 3.5.0. Việc BH ví nó với Adreno 660 chỉ là suy đoán.
- BH ("Ép CPU hết lặp") đã bị BU/BQ làm yếu: CPU cũng lặp ở 1 số lần; app MNN Chat gốc của Alibaba cũng gặp (BT). Hai hiện tượng KHÁC NHAU cần tách:
  (a) GPU "ký tự rác đa ngôn ngữ" = lỗi kernel OpenCL; (b) lặp câu/ký tự = tầng Qwen/Llama + sampler (issue #4891, #3515), xảy ra cả CPU lẫn GPU, không phụ thuộc bản MNN.

### 2. Cảnh báo "GPU rác có thể quay lại ở 3.6.1" của mục CE cũng KHÔNG có căn cứ — đã hiệu chỉnh
- Ghi chú phát hành 3.6.1 (tháng 7/2026, ngày 22/7) có mục sửa "OpenCL maskless attention setArg overflow" — lỗi gây OUTPUT SAI trên **Adreno** (issue #4653),
  cùng họ GPU với máy này (Adreno 660). Đây là bằng chứng NGHIÊNG VỀ 3.6.1 hơn 3.5.0 cho Adreno, nhưng KHÔNG chứng minh LLM trên máy này hết rác.
- Mốc thời gian: người dùng nhớ GPU còn chạy bình thường "tháng trước" (tháng 8) với bản build lấy master HEAD — master tháng 8 ĐÃ chứa mọi thay đổi của 3.6.0 (6/2026)
  và 3.6.1 (7/2026). Nếu trí nhớ đúng thì giả thuyết BI ("2 thay đổi OpenCL của 3.6.0 gây rác") mâu thuẫn với chính mốc đó; cửa sổ hồi quy phải nằm SAU 3.6.1
  (commit master tháng 9). Lưu ý: dựa vào trí nhớ + suy luận, không có log phiên bản tháng 8.

### 3. Hướng "dựa trên bản cũ" (giữ runtime 3.5.0, xuất lại model bằng 3.5.0) — KHẢ THI, và rẻ để thử
- APK đang cài (mục CD) CHÍNH LÀ runtime 3.5.0 + sửa OpenCL (linker) => KHÔNG cần build CI. Chỉ cần xuất lại 1 model: notebook `Convert_Model_To_MNN`, ô cấu hình
  `mnn_git_ref = "3.5.0"` (ô đầu, mặc định "master"); notebook tự build lại MNNConvert theo đúng ref (cache Drive khoá theo ref, ~10-20 phút) rồi chạy `llmexport.py`
  với các tham số cũ (`--path --dst_path --export mnn --quant_bit --quant_block --embed_bit [--lm_quant_bit] [--hqq] --mnnconvert`). CHƯA kiểm tra llmexport tag 3.5.0 nhận đủ
  các tham số này; nếu lỗi tham số, đọc dòng lỗi rồi bỏ đúng tham số đó.
- Đây là CÁCH DUY NHẤT để kiểm chứng giả thuyết "3.5.0 ổn định trên GPU": runtime 3.5.0 + model xuất bằng 3.5.0, cùng prompt, so GPU (Tự động) với CPU (Ép CPU).
- Đối chứng song song: bản build 3.6.1 đã chuẩn bị (mục CE) + model hiện có => so GPU/CPU trên 3.6.1. Có 2 điểm dữ liệu rồi mới chọn bản, không chọn theo trí nhớ.

### 4. Quy tắc
Không chuyển/ghim phiên bản MNN theo giả thuyết nữa. Mỗi lần đổi phiên bản phải đi kèm phép thử GPU vs CPU cùng prompt trên máy thật, ghi cả hai kết quả vào spec.

## CG. Người dùng hỏi: "lỗi nạp model có phải do tham số model khác loại với MNN (Qwen 8B convert bằng tham số mặc định)?" + chỉnh notebook convert (2026-10-02)

### Trả lời: KHÔNG phải tham số quantize
- `export_args.json` của Qwen3-8B: `quant_bit=4, quant_block=128, hqq=true, embed_bit=16, lm_quant_bit=4` = tham số mặc định/thường dùng, hợp lệ với MNN.
  Các tham số này đổi cách lượng tử hoá TRỌNG SỐ (độ chính xác/kích thước), không quyết định file `llm.mnn` có qua bước verify FlatBuffers hay không.
- Dữ liệu thật (mục CD/CE): thư viện verify tốt; byte file đọc đúng; model nạp được nhiều lần ở APK cũ; nhiều model cùng lỗi. Cái duy nhất khác là
  **phiên bản MNN đã xuất** (`"3.6.1"` nằm ở cuối `llm.mnn`) so với **runtime trong APK** (3.5.0). Biến này không nằm trong các ô tham số quantize mà nằm ở ô
  `mnn_git_ref` (mặc định cũ `"master"`).

### Chỉnh notebook `LocalNovel_Convert_Model_To_MNN.ipynb` (4 cell đổi, còn lại giữ nguyên)
- Cell 4: `mnn_git_ref` mặc định `"3.5.0"` (trước: `"master"`). Thêm đọc phiên bản mã nguồn từ `MNNDefine.h` và **báo lỗi** nếu `mnn_git_ref` là dạng x.y.z mà
  `/content/MNN` đang là bản khác. Lý do: cell này CHỈ clone khi chưa có `/content/MNN`, và cell 5 dùng lại `MNNConvert` đã build trong phiên => đổi `mnn_git_ref` trong
  CÙNG phiên Colab sẽ im lặng KHÔNG có tác dụng (bẫy dễ dẫm: vẫn xuất bằng master). Cách tránh: `!rm -rf /content/MNN` hoặc Runtime -> Disconnect and delete runtime.
- Cell 5: in `requirements.txt` của llmexport (đã bỏ torch*) để thấy có ghim `transformers` không — rủi ro: notebook cài `transformers` MỚI NHẤT trong khi `llmexport` tag 3.5.0
  (04/2026) có thể cần bản cũ hơn; nếu llmexport lỗi liên quan `transformers`, ghim đúng bản trong `requirements.txt`.
- Cell 14: in phiên bản MNN đã xuất model (đọc chuỗi `x.y.z` ở 1 KB cuối `llm.mnn`) và nhắc quy tắc "runtime >= bản xuất". Đã thử regex trên 32 byte cuối THẬT của log: ra `3.6.1`.
- Cell 0: thay đoạn cảnh báo bằng QUY TẮC PHIÊN BẢN.
- Đã kiểm: JSON hợp lệ, cú pháp Python mọi code cell hợp lệ (bỏ qua lệnh `!` của Colab), 18 cell như gốc. CHƯA chạy thật trên Colab.

### Vì sao 3.5.0 là lựa chọn an toàn cho cả 2 hướng runtime
Runtime MỚI đọc được model CŨ (hướng MNN cam kết). Model xuất bằng 3.5.0 sẽ nạp được trên runtime 3.5.0 (APK đang cài) và dự kiến cả trên runtime 3.6.1 (build.yml mục CE).
=> CÙNG MỘT model dùng để so GPU vs CPU trên cả 2 runtime — phép so sánh sạch, không còn lẫn biến "model khác bản". (Dự kiến — chưa kiểm chứng việc 3.6.1 đọc model 3.5.0.)

### Rủi ro còn lại — không giấu
- `llmexport` tag 3.5.0 có thể không nhận đủ tham số notebook đang truyền, hoặc xung đột bản `transformers` — chỉ biết khi chạy. Dòng lỗi sẽ chỉ ra tham số/thư viện cụ thể.
- Định dạng `llm_config.json` của 3.5.0 có thể khác (khóa `jinja` vs `prompt_template`); app có cả 2 đường (mục AV `prompt_template`, mục BD Jinja) nhưng chưa kiểm với model xuất bằng 3.5.0.

## CH. Tra cứu kỹ theo yêu cầu người dùng: lỗi nạp model = cờ C4 của llmexport (không phải tham số quantize) + hiệu chỉnh nhận định GPU (2026-10-02)

### Bối cảnh
Người dùng yêu cầu tra cứu THẬT KỸ các vấn đề đang gặp (vì lịch sử lỗi sinh ký tự rác từng kéo dài do tra cứu không kỹ nên bỏ sót nguyên nhân từ MNN).
Nguồn đã đọc: tài liệu chính thức MNN-Doc (stable/transformers/llm.html), trang Releases (3.1.0 → 3.6.0), ghi chú phát hành 3.6.1 (đọc đủ),
issue #4836, #4802, #1736, wiki testing, FAQ. Ba lượt tìm riêng về "GPU sinh rác trên Snapdragon/Adreno với LLM của MNN" KHÔNG ra issue công khai nào khớp.

### Phát hiện chính (có nguồn chính thức)
1. **C4 fusion là NGUYÊN NHÂN lỗi nạp** (MNN-Doc, mục "C4 融合与引擎兼容性"): `llmexport.py` MẶC ĐỊNH bật Transformer C4 graph fusion; model xuất mặc định
   "phụ thuộc engine MNN mới hỗ trợ layout C4 RoPE/Attention, KHÔNG chạy được trên engine cũ"; dùng `--disable_transformer_c4` (llmexport) hoặc
   `--transformerFuseC4=0` (MNNConvert) để xuất model tương thích; **"engine mới vẫn tương thích model không-C4 cũ"**. `export_args.json` của cả 2 model có
   `"transformer_c4": true` (+ `fuse_qkv_proj`, `fuse_gate_up_proj`, `fuse_ln_proj`) => đúng model C4.
   => Nhận định mục CG ("không phải do tham số") CHỈ ĐÚNG với tham số QUANTIZE (`quant_bit/quant_block/hqq/embed_bit`); SAI nếu hiểu là mọi tham số: cờ C4 CHÍNH là tham số
   quyết định tương thích và nó bật mặc định. Đã đính chính với người dùng.
2. **Ghi chú 3.6.1** (tag commit `d407447`, phát hành 2026-07-23, đang là bản "Latest" ở thời điểm đọc 2026-10-01): "Transformer C4 graphs across backends" — thêm fused op
   (CPURoPE, SharedGather...), lần đầu bật C4 trên CPU/Metal/OpenCL/CUDA; benchmark của họ ghi rõ "model xuất lại bằng 3.6.1". => runtime TỐI THIỂU cho model C4 là 3.6.1, không phải 3.5.0/3.6.0.
3. **OpenCL + C4 còn non trước 3.6.1** (sửa trong 3.6.1): lỗi biên dịch kernel attention c4; tràn V-buffer khi tune GEMM + thiếu layout NC4HW4 ở prefill dài; tràn setArg của
   *maskless* attention gây OUTPUT SAI trên **Adreno** (issue #4653 — nhưng là **SD UNet**, đường maskless, KHÔNG phải attention nhân quả của LLM => KHÔNG đủ để kết luận cho LLM);
   ghi đè gpuMode của runtime dùng chung; ghi ngoài biên LinearAttention. => đường OpenCL của đồ thị C4 vừa được vá nhiều lỗi sai-kết-quả, đường không-C4 là đường cũ trưởng thành hơn.
4. **fp16 scale/bias khi `precision=low` trên OpenCL/Metal có từ 3.1.0** (2025) — KHÔNG phải thay đổi mới ở 3.6.0 => ghim 3.5.0 không né được nó. 3.6.0 thêm "lưu scale/zero-point fp16"
   và có mục "đồng bộ schema fp16 scale" (schema flatbuffer thay đổi giữa 3.5.0 và 3.6.x).
5. 3.5.0 đã có: tokenizer.mtok, jinja, sampler Pipeline có `penalty` (khớp config app). Cấu hình runtime của app KHỚP khuyến nghị tài liệu: `thread_num=68` cho OpenCL, `precision=low`,
   `memory=low`, `mixed_samplers` đưa `penalty` lên đầu.
6. #4836 (nguồn chính của BH/BI) là Windows 11 + Intel Iris Xe, master 2026-09-04 — không phải Android/Adreno.

### Hiệu chỉnh nhận định cũ
- Mục CF: "3.6.1 có sửa lỗi Adreno nên nghiêng về 3.6.1" — YẾU hơn tôi nói: bản sửa #4653 thuộc đường maskless/SD UNet.
- Giả thuyết giải thích lỗi GPU rác tháng 9 (CHƯA kiểm chứng, chỉ nhất quán với dữ kiện): lệch phiên bản giữa model C4 (xuất bằng master) và runtime APK (master HEAD lúc build hoặc dự phòng tag 3.6.0
  khi build master lỗi — đúng cơ chế dự phòng của build.yml cũ trước mục BI) làm kernel OpenCL diễn giải sai đồ thị C4 => ra rác trên GPU mà CPU vẫn đúng. Không có issue công khai xác nhận.
- Lỗi lặp (BR/BS/BT, #4891) là chuyện khác (sampler/Qwen), không liên quan C4.

### Ba đường (đã cân nhắc)
1. **Model không-C4 xuất bằng công cụ 3.5.0** (notebook mặc định `mnn_git_ref="3.5.0"`; bản 3.5.0 chưa có C4): nạp được trên APK ĐANG CÀI (3.5.0, không cần build CI) và theo tài liệu
   cả trên runtime mới sau này. Rủi ro: chưa kiểm `llmexport` tag 3.5.0 nhận đủ cờ (notebook giờ TỰ bỏ cờ không được hỗ trợ).
2. **Giữ model C4 hiện có, build runtime 3.6.1** (`build.yml` mục CE): không phải convert lại. Rủi ro: chuỗi "3.6.1" trong model do `master` ghi; nếu `master` lúc xuất đã đi trước tag 3.6.1
   (đổi cấu trúc C4) thì runtime tag 3.6.1 vẫn có thể từ chối; nếu GPU còn rác thì là kernel OpenCL-C4.
3. **Xuất bằng công cụ ≥3.6.1 kèm `--disable_transformer_c4`**: model không-C4 nhưng dùng schema 3.6.x => runtime 3.5.0 có thể vẫn từ chối vì schema (CHƯA chắc). Kém chắc hơn đường 1.
Khuyến nghị: đường 1 TRƯỚC (rẻ nhất, không build, tách được biến C4 và biến phiên bản), rồi mới đường 2 nếu cần.

### Thay đổi notebook (mục CH) — cell 0, 10, 12, 14
- Cell 10: ô mới `disable_transformer_c4 = True`. Cell 12: thêm cờ `--disable_transformer_c4`; chạy `llmexport.py -h` rồi TỰ BỎ các cờ tùy chọn mà bản đó không có
  (`--embed_bit`, `--lm_quant_bit`, `--hqq`, `--disable_transformer_c4`) kèm thông báo — tránh lỗi argparse khi dùng tag cũ. Cell 14: đọc `export_args.json` in "transformer_c4 = true/false".
- Cell 0: thêm quy tắc C4. Đã kiểm cú pháp mọi cell; thử logic lọc cờ trên lệnh mẫu (bỏ đúng cặp cờ+giá trị). CHƯA chạy thật trên Colab.

### Giới hạn của lượt tra cứu này
Không có issue công khai nào khớp "Adreno + LLM + rác" nên KHÔNG có bằng chứng ngoài về nguyên nhân GPU rác; mọi kết luận GPU ở trên là suy luận từ ghi chú phát hành. Bằng chứng thật chỉ có thể
đến từ phép thử GPU vs CPU cùng prompt trên máy (mục CF mục 4).

### Nguồn
mnn-docs.readthedocs.io/en/stable/transformers/llm.html; github.com/alibaba/MNN/releases/tag/3.6.1; github.com/alibaba/MNN/releases (3.1.0, 3.5.0, 3.6.0);
github.com/alibaba/MNN/issues/4836, #4802, #1736; github.com/alibaba/MNN/discussions/4662.

### CH-bổ sung (2026-10-02). Cache Drive của notebook cũ có dùng lại được không?
- Đường dẫn cache: `MyDrive/LocalNovel_MNNConvert_Cache/<slug(mnn_git_ref)>/mnn_build.tar.gz` — CHỈ chứa bản build `MNNConvert` (không chứa model nguồn hay model đầu ra).
- Notebook cũ mặc định `mnn_git_ref="master"` => cache nằm ở thư mục `master/`. Notebook mới mặc định `"3.5.0"` => tìm `3.5.0/` => CHƯA có => build mới (~10-20 phút) rồi lưu riêng. Hai cache độc lập.
- KHÔNG chép cache `master/` sang `3.5.0/`: MNNConvert của master ghi model theo định dạng master (phiên bản 3.6.1; tài liệu: MNNConvert cũng mặc định bật C4) — phá đúng mục đích.
- Cache `master/` vẫn dùng được nếu đặt `mnn_git_ref="master"` + `disable_transformer_c4=True`, nhưng binary trong cache cũ hơn `llmexport.py` vừa clone hôm nay (nhánh trôi theo thời gian);
  notebook giờ in ngày lưu cache và cảnh báo điều này. Đã thêm in danh sách cache hiện có + trạng thái cache cho ref đang chọn (cell 5). Đã kiểm cú pháp; chưa chạy thật trên Colab.

## CI. Log 2026-10-02: model UTENA-7B NẠP ĐƯỢC trên OpenCL (xác nhận giả thuyết C4) + nguyên nhân "ngáo" khi sinh chữ (2026-10-02)

### 1. Xác nhận bằng log thật (APK `mucCD` = runtime 3.5.0, OpenCL đã khởi tạo)
- Model `AI-B-UTENA-7B-NSFW-V2-MNN-q4-chinh` **NẠP THÀNH CÔNG**: `load() (OpenCL) = true`, mất 25013ms, backend opencl. Đây là lần ĐẦU nạp được model trên APK 3.5.0.
- So sánh với 2 model lỗi: `llm.mnn` chỉ 557656 B (vs 1325976 / 2302392), `llm_config.json` 162 B (vs 610 / 5187, không có `jinja`), `export_args.json` 1058 B (vs ~1250-1257).
  Hình dạng này khớp một model xuất bằng công cụ CŨ (trước C4/jinja). => Hỗ trợ mạnh giả thuyết mục CE/CH: **runtime 3.5.0 chạy được model xuất bằng công cụ cũ (không-C4)
  và KHÔNG chạy được model C4 xuất bằng master 3.6.1**. (Chưa tự đọc được chuỗi phiên bản trong llm.mnn của UTENA — log thành công không chạy self-test.)
- Thẻ model (Hugging Face): `UTENA-7B-NSFW-V2` là bản gộp mergekit SLERP trên kiến trúc **Mistral** (01/2024), **không có `tokenizer.chat_template`** (issue cộng đồng #2) và thẻ không ghi định dạng prompt.

### 2. Vì sao câu trả lời "ngáo" (đọc từ `[MUC BB - TOAN BO PROMPT DA GUI]` và dòng PROMPT CUOI)
Không phải GPU sinh rác — đầu ra là tiếng Việt mạch lạc, chỉ là CHÉP LẠI prompt. Hai nguyên nhân phía ỨNG DỤNG, đều thấy thẳng trong log:
1. **Lịch sử chat lẫn dòng lỗi.** `_buildRecentHistoryContext()` đưa NGUYÊN VĂN các lượt thất bại của lần trước (`Lỗi sau 3s: Exception: Không nạp được model...`) vào prompt như thể trợ lý đã nói.
2. **Nhánh ghép thô không có tín hiệu "đến lượt trợ lý".** UTENA không có `prompt_template`/`jinja` và `model_type` (mistral) không có trong bảng cố định (chỉ `qwen2`, `hunyuan`) => log
   `_resolvePromptStrategy: KHONG doc duoc gi phu hop, se ghep tho`. Prompt kết thúc bằng đúng "xin chào" không nhãn vai; model coi nó là tên người nói và viết tiếp `: xin chào`,
   rồi nhại cả lịch sử cho tới khi bộ dò lặp native dừng ở 578 byte.

### 3. Bản sửa (Dart; CHƯA biên dịch được — sandbox không có Dart SDK; đã kiểm cân bằng ngoặc)
- `chat_screen.dart`: `_isFailedAssistantReply()` + bỏ các lượt trợ lý bắt đầu bằng `Lỗi sau ` hoặc chứa `⚠️` khỏi lịch sử (khớp đúng 2 định dạng `_send()` ghi ra và dấu `⚠️ [Đã dừng...]` của bộ dò lặp).
- `local_provider.dart` (`_buildFinalPrompt`, CHỈ nhánh ghép thô): thêm đuôi `\n\nTrợ lý:` (cùng nhãn lịch sử chat đã dùng). Model có template đi các nhánh trên, không đổi. Hiệu quả CHƯA kiểm chứng.
- Build tag `mucCI_2026-10-02`.
- **Cách không cần build:** mở cuộc trò chuyện MỚI (lịch sử trống => hết nhiễm lỗi).

### 4. Còn tồn đọng — KHÔNG phải lỗi mới, KHÔNG sửa ở mục này
- **Chậm bất thường trên OpenCL:** `generate()` mất 482s tới byte đầu (prompt 1261 ký tự), rồi ~6 byte/s (~3 token/s). App MNN Chat gốc đạt 16.7 t/s trên cùng máy (mục BV). Đã ghi ở BN/BT:
  autotune kernel `TUNING_WIDE` (thread_num 68 = 64 buffer + 4 wide) khi gặp hình dạng mới; kết quả lưu ở `mnn_cachefile.bin`. Phép thử rẻ: gửi lại 1 prompt ngắn NGAY SAU lần này trong cùng phiên
  và xem thời gian tới byte đầu — nhanh hẳn => chỉ là autotune lần đầu; vẫn hàng phút => cần xét lại chế độ tuning.
- Template cho UTENA: thẻ model không nêu định dạng; muốn thử sớm không cần build, thêm khóa `"prompt_template"` có `%s` vào `llm_config.json` của model (app đã hỗ trợ), vd Mistral `[INST] %s [/INST]` — chỉ là THỬ, không có bằng chứng định dạng đúng.

## CJ. Log 2026-10-03 (UTENA-7B, GPU rồi CPU): máy ngủ sâu giữa chừng, cache OpenCL 4GB bị xoá mỗi phiên, so sánh CPU/GPU bằng số đo thật (2026-10-03)

### Bối cảnh
Người dùng báo: "càng ngày càng tệ, tính năng chạy ngầm hình như lỗi so với trước; trước kia tạo chương/chat ổn dù chậm, không lặp từ; CPU lại nhanh hơn GPU?". Đối chiếu log mới với spec (không đoán).

### 1. Máy NGỦ SÂU giữa lúc sinh (khớp lại mục F 27/8 và mục V/W 7/9)
- Lần 1 (GPU): `STEADY=258492ms, WALL=814568ms, CHENH LECH 556076ms` (~9,3 phút máy ngủ).
- Lần 3 (CPU): `STEADY=155962ms, WALL=2305596ms, CHENH LECH 2149634ms` (~35,8 phút máy ngủ). Dòng `[TIEN DO DINH KY]` tăng đều ~5s theo đồng hồ steady trong khi mốc thời gian thật nhảy hàng phút => cả tiến trình bị đóng băng, không riêng luồng sinh.
- Lần chạy 2/10 KHÔNG có chênh lệch (STEADY==WALL).
- Spec mục V (7/9) đã gặp ĐÚNG hiện tượng này; mục W (cùng ngày) ghi: sau khi người dùng bật **miễn tối ưu pin** (nút xanh trong màn "Tối ưu AI local"), chạy lại `STEADY==WALL, không chênh lệch`. Mã giữ máy thức (PARTIAL_WAKE_LOCK trực tiếp + GenerationService, manifest đủ `WAKE_LOCK`, `FOREGROUND_SERVICE*`, `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`) không đổi so với bản đã xác nhận.
- Giả thuyết nhất quán (CHƯA xác nhận): chuyển sang repo/tài khoản mới buộc cài lại app => cài đặt miễn tối ưu pin của app bị reset => Android lại cho máy ngủ. Cách kiểm: mở "Tối ưu AI local" xem trạng thái pin; Cài đặt Android > Ứng dụng > LocalNovel > Pin > Không hạn chế. Sau đó chạy lại: STEADY==WALL thì đúng.

### 2. CPU vs GPU (số đo thật từ log, đồng hồ STEADY — không tính thời gian ngủ)
| | GPU (OpenCL) | CPU (ép) |
|---|---|---|
| Thời gian tới byte đầu (prefill) | 218956ms (prompt 736 ký tự); 482839ms ngày 2/10 (1261 ký tự) | 48662ms (prompt 1026 ký tự) |
| Tốc độ sinh (decode) | ~11,2 byte/s (228B/20,3s) | ~8,4 byte/s (864B/103,4s) |
| Thời gian nạp model | 26,9s | ~150s (đổi backend phải nạp lại) |
- Prefill GPU chậm hơn CPU nhiều lần dù prompt GPU ngắn hơn; decode GPU chỉ nhỉnh ~1,3 lần. KHÔNG nghịch lý — mục BH (19/9) đã đo và giải thích: decode bị giới hạn băng thông bộ nhớ (CPU/GPU dùng chung LPDDR), MNN tối ưu tay NEON rất kỹ cho CPU, còn OpenCL trên Adreno 660 có lỗi tương thích (OpenCL sai kết quả — họ lỗi #4836 và các issue trước đó).
- Chất lượng (chỉ là chỉ báo, prompt khác nhau nên KHÔNG sạch): GPU ra câu vô nghĩa chép mảnh prompt ("Trong đời thời cứu chúa chung của người viết..." rồi lặp, bộ dò lặp dừng ở 332 ký tự); CPU ra tiếng Việt trôi chảy hơn. Nhất quán với BH (CPU không lặp, GPU lặp).
- **Cấu hình ổn định trước đây theo spec = "Ép CPU"** (BH: CPU hết lặp ký tự và còn nhanh hơn GPU).

### 3. Phát hiện mới trong app: cache autotuning OpenCL bị xoá sạch MỖI phiên
Log cuối phiên: `pruneOpenCLTuningCacheIfNeeded: tong dung luong cache opencl_tuning = 4097MB, vuot han muc 500MB — DA XOA "AI-B-UTENA-7B-NSFW-V2-MNN-q4-chinh" (4097MB)`.
Thư mục con của model gồm file autotuning rất nhỏ (`mnn_cachefile.bin`, 268 byte ở log CD) VÀ ~4GB do MNN ghi khi `use_mmap=true` + `tmp_path` (4097MB ≈ llm.mnn.weight 4,0GB + embeddings 0,26GB — suy ra từ kích thước, CHƯA liệt kê file để xác nhận). Hạn mức 500MB (thiết kế cho file nhỏ) luôn bị vượt => mỗi phiên xoá cả thư mục => mất luôn tuning cache => OpenCL dò lại kernel từ đầu ở prefill (khớp: 482s ngày 2/10 khi chưa có cache, 219s ngày 3/10 khi còn cache từ hôm trước, CPU không bị).
**Bản sửa (`mnn_bridge.cpp`)**: khi dọn chỉ xoá file LỚN (>= 32MB), GIỮ file nhỏ (tuning cache); nếu không có file lớn nào thì quay về xoá cả thư mục như cũ. Thêm log liệt kê file TRƯỚC khi xoá để kiểm chứng giả định "phần lớn dung lượng là file mmap". Đã biên dịch THẬT phần logic (POSIX thuần) bằng g++ và chạy thử trên thư mục giả: xoá 2 file lớn (90MB), giữ `mnn_cachefile.bin` + file nhỏ. CHƯA build APK; tác dụng lên tốc độ prefill GPU CHƯA kiểm chứng.

### 4. Nhánh ghép thô (UTENA, không template) — chỉnh tiếp mục CI
Log CPU: model tự bịa thêm các cặp `nghe rõ ko` / `Trợ lý: ...` giả (không dừng ở hết lượt). Nguyên nhân khớp prompt: lịch sử có nhãn `Người dùng:`/`Trợ lý:` nhưng lượt hiện tại đứng trơ trọi rồi tới `Trợ lý:`. Sửa `_buildFinalPrompt` nhánh ghép thô: gắn nhãn `Người dùng:` cho đúng lượt hiện tại. Chưa kiểm chứng. Chưa làm: chuỗi dừng (stop sequence) khi model sinh `Người dùng:` — ghi nhận.
Lịch sử chat bỏ lượt lỗi (mục CI) có tác dụng: prompt 03/10 sạch ("xin chào||Trợ lý:") và không còn chép dòng lỗi.

### 5. Việc cần làm theo thứ tự (KHÔNG cần build trước)
1. Màn "Tối ưu AI local": xác nhận miễn tối ưu pin đang BẬT (xanh); chọn "Ép CPU". Đây là cấu hình ổn định theo BH.
2. Nạp thử Qwen3-8B/Morpheus (chưa thử trong APK `mucCI`; log lần sau sẽ cho biết runtime nạp được hay không — nếu lỗi, self-test mục CD in phiên bản runtime).
3. Build APK mới (mục CJ) khi tiện: sửa dọn cache + nhãn lượt.

## CK. Log 2026-10-04 (UTENA, 3 lần nạp liên tiếp): lỗi do CHÍNH bản sửa CI gây ra + dữ liệu GPU/CPU mới + app chết vì rò RAM khi nạp lại (2026-10-04)

### 1. Lỗi do bản sửa mục CI (đã sửa — mục CK)
`PROMPT CUOI` log 04/10: `...Người dùng: xin chào||Người dùng: kiểu gì mà lặp từ vậy||Trợ lý:` — lịch sử CHỈ có dòng `Người dùng:`, không có lượt nào của trợ lý.
Nguyên nhân: mục CI bỏ mọi lượt trợ lý chứa `⚠️`; mà mọi câu trả lời ở các lần thử này đều bị bộ dò lặp cắt và gắn `⚠️ [Đã dừng...]`, nên bị lọc HẾT. Khuôn "toàn câu hỏi, không có đáp" khiến model nhại/bịa tiếp.
Sửa (`chat_screen.dart`): bỏ CẢ CẶP (lượt người dùng ngay trước câu trả lời thất bại + chính câu đó); giữ nguyên các cặp hỏi-đáp hoàn chỉnh. Đã mô phỏng logic bằng Python trên chuỗi đúng như log: lịch sử rỗng khi mọi lượt trước đều thất bại; giữ cặp tốt ở đầu. CHƯA biên dịch Dart.

### 2. Số đo (đồng hồ STEADY; không có chênh lệch WALL => máy KHÔNG ngủ ở cả 3 lần — khớp việc người dùng đã bật miễn tối ưu pin)
| lần | backend | nạp | tới byte đầu (prompt) | sinh | đầu ra |
|---|---|---|---|---|---|
| 1 | GPU (Tự động), tuning lạnh | 33,0s | 274s (752 ký tự) | ~5,2 B/s | `Bạn / Trường: Đông / Trường: Đông...` — thoái hoá, bị dừng ở 321 ký tự |
| 2 | GPU (ép), nạp lại | 11,4s | **61s** (1062 ký tự) | ~5,5 B/s | chép lại đoạn system prompt rồi lặp |
| 3 | CPU (ép), sau khi app khởi động lại | 27,3s | 62s (1152 ký tự) | ~4,8 B/s | tiếng Việt trôi chảy nhưng chép system prompt và bịa thêm `Người dùng:` |
- GPU lần 2 (tuning đã ấm) có prefill 61s ≈ CPU 62s: **khi tuning đã ấm GPU không nhanh hơn CPU** trên máy này; thời gian prefill 219–482s các lần trước là chi phí dò kernel lạnh. Decode GPU ≈ CPU.
- **GPU vẫn ra chữ vô nghĩa ở lần 1 trong khi CPU trôi chảy** với CÙNG model. UTENA xuất bằng công cụ cũ (export_args.json 1058 B, không có khóa C4; nạp được cả trên runtime 3.5.0) => **lỗi GPU rác KHÔNG do C4**. Giả thuyết mục CH ("C4 + OpenCL") KHÔNG được ủng hộ; bằng chứng khớp mục BH/issue #4836 (đường OpenCL trên Adreno 660). Không thể giải thích bằng dữ liệu hiện có vì sao trước đây GPU từng ra chữ.
- Dọn cache OpenCL (mục CJ) CÓ tác dụng: log liệt kê `1_0_0_0_{0..3}.opencl.weight = 1048576KB` (4 file x 1GiB = file trọng số OpenCL), `mnn_cachefile.bin = 3156KB` (tuning cache thật, lớn lên từ 268B), `0_0_0_0_sync.static`...; đã xoá 4096MB và GIỮ 3 file nhỏ. Lần nạp lại thứ 2 trong phiên chỉ mất 11,4s (vs 33,0s).

### 3. App chết khi nạp lại lần 3 — rò RAM theo từng lần nạp lại (đã ghi ở mục 23 spec, nay có số đo)
VmRSS TRƯỚC khi huỷ model cũ: lần nạp 1 = 233.768 kB; lần 2 = 4.284.028 kB; lần 3 = **8.025.880 kB** (huỷ model cũ chỉ giải phóng ~290.000 kB). Log kết thúc ngay sau `createLLM()` lần 3 rồi tiến trình mới khởi động (01:58:51) => bị hệ điều hành giết vì hết RAM, không phải crash trong code MNN. Mỗi lần ĐỔI backend/nạp lại cộng thêm ~4GB. CHƯA sửa (cần điều tra riêng nguồn rò: bộ nhớ trọng số OpenCL không trả sau `reset()`).
**Cách tránh hiện tại**: chỉ nạp 1 lần mỗi lần mở app; muốn đổi backend/model thì đóng hẳn app (vuốt khỏi recent) rồi mở lại.

### 4. Nhận định về cách kiểm thử (ghi lại để khỏi lặp lại sai lầm)
UTENA-7B là model KHÔNG có chat template (bản gộp Mistral 01/2024) nên mọi đầu ra của nó chủ yếu phản ánh việc app phải ghép prompt thô — KHÔNG đại diện cho Qwen3-8B/Morpheus (có `jinja`) mà người dùng thực sự dùng. Nền ổn định cũ (BH) là Qwen/Llama có template chạy "Ép CPU". Đã nhiều lần thử chỉ với UTENA vì 2 model chính không nạp được trên runtime 3.5.0; CHƯA có log nào của 2 model chính trên APK từ `build.yml` ghim 3.6.1.
Việc cần làm: mở app mới, "Ép CPU", nạp Qwen3-8B (một lần), hỏi 1 câu, gửi log.

### 5. Chưa làm (ghi nhận)
- Chuỗi dừng (stop sequence) cho nhánh ghép thô: model không biết dừng ở hết lượt nên tự bịa `Người dùng:`; hiện chỉ bộ dò lặp cắt.
- Nguồn rò RAM khi nạp lại (mục 3).

## CL. RÒ RAM KHI NẠP LẠI MODEL — lỗi nghiêm trọng, nay đã có bản sửa (2026-10-04)

### Người dùng phản ánh (đúng) và đính chính
- "Bug to như vậy sao không fix, bắt người dùng sống chung": đúng — mục CK mới chỉ ghi nhận và đưa cách né; mục này sửa. Hậu quả thật: tiến trình phình ~8GB làm hệ điều hành giết app và cả các app khác của máy.
- "Chỉ dùng đúng 1 model, sao log lòi ra 2 model": đúng — cả 3 lần nạp đều là CÙNG `AI-B-UTENA-7B-NSFW-V2` (đổi backend 0->1->2 làm app nạp lại). Dòng log `slot TRUOC DO DA CO model khac dang nap` do CHÍNH code sinh ra sai chữ: nó chỉ kiểm `hadPreviousModelInThisSlot` (slot đã có đối tượng Llm), không so tên model nên ghi "model khác" cả khi là model cũ nạp lại. Đã sửa câu chữ. Cũng nghĩa là rò RAM xảy ra ngay khi nạp lại CHÍNH model đó — không cần 2 model.

### Số đo (log 04/10): VmRSS trước khi huỷ model cũ
lần 1 = 233.768 kB; lần 2 = 4.284.028 kB; lần 3 = 8.025.880 kB. Mỗi `llmSlot.reset()` chỉ trả ~290.000 kB. Sau lần 3 tiến trình bị giết (log dừng ngay sau createLLM, tiến trình mới 01:58:51).

### Nguyên nhân nghi vấn (có căn cứ từ mã MNN, CHƯA kiểm chứng trên máy)
`Executor.cpp` của MNN: `Executor::getGlobalExecutor()` giữ `mRuntimeInfo` (runtime theo từng loại backend) suốt đời tiến trình; `Executor::gc(GCFlag flag = FULL)` là API công khai trả bộ nhớ đệm của các runtime đó (chữ ký xác nhận từ `Executor.hpp`). Huỷ `Llm` không huỷ runtime OpenCL dùng chung => vùng nhớ trọng số OpenCL (4 file `*.opencl.weight` x 1GiB, thấy ở log CJ) vẫn nằm trong bộ nhớ đệm của runtime.

### Bản sửa (`mnn_bridge.cpp`)
1. `releaseRuntimeCachesAndLog(where)`: gọi `MNN::Express::Executor::getGlobalExecutor()->gc(MNN::Express::Executor::FULL)` rồi ghi `VmRSS`, **`RssAnon`, `RssFile`** (trước/sau) và `MemAvailable` hệ thống. Gọi sau `llmSlot.reset()` ở: nạp lại, nhánh lỗi nạp, `nativeUnload`.
2. **Chốt chặn an toàn**: nếu sau gc app vẫn > 3GB VÀ RAM trống toàn máy < 3GB thì TỪ CHỐI nạp (trả false, log `[CL] TU CHOI NAP LAI ...`) thay vì để hệ điều hành giết app và các app khác. Người dùng đóng hẳn app rồi mở lại.
3. Sửa câu log sai "DA CO model khac".
- Đã biên dịch + chạy thật hàm đo (`/proc/self/status`: RssAnon/RssFile, `/proc/meminfo`: MemAvailable) với stub đúng chữ ký `Executor` của MNN: cú pháp OK, số đọc được hợp lý. CHƯA build APK; tác dụng của `gc` lên RAM CHƯA kiểm chứng.
- Cách đọc kết quả ở log kế tiếp: dòng `[CL] ...: Executor::gc(FULL) xong. VmRSS A -> B kB; RssAnon ...; RssFile ...`. B giảm ~4GB => đã sửa đúng. B không giảm mà RssFile cao => phần giữ lại là trang mmap có thể thu hồi (cần xét lại ngưỡng); RssAnon cao => rò thật ngoài runtime (cần tra tiếp).

## CM. Log 2026-10-04 (build mucCL): bản sửa CL KHÔNG có tác dụng; phát hiện APK vẫn là MNN 3.5.0 (2026-10-04)

### A. PHÁT HIỆN QUAN TRỌNG NHẤT — APK hiện cài vẫn là runtime 3.5.0, bản 3.6.1 chưa từng có hiệu lực
`libMNN.so` trong APK hôm nay: size=7199064, CRC32=95d9a5cf — **giống từng byte** với bản build 01/10 (mucCD) mà self-test đã báo `MNN::getVersion() = 3.5.0`. Bản build 3.6.1 không thể ra đúng cùng kích thước và CRC. Hệ quả: `build.yml` ghim 3.6.1 (mục CE) CHƯA được áp dụng trên GitHub của người dùng (repo vẫn giữ bản ghim 3.5.0 — bản gốc người dùng tải lên có `--branch 3.5.0`, bản tôi giao có `--branch 3.6.1`).
=> Qwen3-8B/Morpheus (model C4, xuất bằng 3.6.1) KHÔNG THỂ nạp trên APK này (mục CE/CH), nên mọi phép thử gần đây chỉ chạy được UTENA (không template). Đây là lý do "mọi bug vẫn như cũ". Việc kiểm tra: mở repo GitHub > file workflow build.yml > tìm `git clone ... --branch`; trong log CI tìm `MA_NGUON_MNN_THAT_DUNG=tag-3.6.1-ghim-on-dinh`. Lẽ ra tôi phải so CRC giữa các log từ sớm.

### B. Bản sửa mục CL bị log bác bỏ
Dòng `[CL]`: `Executor::gc(FULL) xong. VmRSS 3990664 -> 3990664 kB (giai phong 0 kB); RssAnon 171536 -> 171536 kB; RssFile 3817572 -> 3817572 kB`.
- `gc` KHÔNG giải phóng gì (giả thuyết "runtime toàn cục giữ bộ đệm" SAI) — đã bỏ lệnh gọi.
- Phần bộ nhớ app còn giữ sau khi huỷ model là **bộ nhớ ánh xạ từ file (RssFile ~3,8GB)**, không phải heap rò (RssAnon chỉ 0,17GB). Trang ánh xạ file là bộ nhớ hệ điều hành có thể thu hồi khi cần.
- Chốt chặn mục CL SAI THIẾT KẾ: (1) chặn theo VmRSS nên sẽ chặn nhầm khi phần giữ lại chỉ là trang file (hôm nay nạp tiếp vẫn chạy ổn, không bị giết); (2) bị chính cơ chế thử lại của Dart lách: lần thử lại thấy slot đã rỗng (`hadPreviousModelInThisSlot=false`) nên bỏ qua chốt chặn — log: lần 1 `TU CHOI NAP LAI`, 3 giây sau lần 2 nạp CPU thành công.
- Lần chết hôm qua (01:57) xảy ra sau 2 lần nạp OpenCL cộng dồn (RSS 8,0GB); hôm nay chỉ 1 OpenCL + 1 CPU thì sống. => nguy cơ giết app tương ứng với RssAnon/GPU anon cộng dồn, không phải RssFile.

### C. Sửa trong bản CM (chưa build)
- Bỏ `gc`. `releaseRuntimeCachesAndLog` nay ghi `VmRSS/RssAnon/RssFile/MemAvailable` + **top 6 vùng ánh xạ lớn nhất đọc từ `/proc/self/smaps`** (tên file + MB trong RAM + cờ "(deleted)"). Mục tiêu: biết ĐÚNG file nào còn bị ánh xạ sau khi huỷ model (4 file `*.opencl.weight` hay `llm.mnn.weight`), thay vì đoán tiếp. Đã biên dịch + chạy thật trong sandbox: nhận ra file ánh xạ 300MB, cờ `(deleted)` khi xoá file đang ánh xạ, và hết sau `munmap`.
- Chốt chặn nay chặn theo **RssAnon > 3GB VÀ MemAvailable < 3GB**, áp dụng cả lần thử lại (không phụ thuộc `hadPreviousModelInThisSlot`).
- Dart: thông báo "Không nạp được model" có gợi ý rõ + chỉ tới dòng `[CM]` trong native_debug.txt.

### D. Đánh giá trung thực các bản sửa gần đây (đối chiếu log)
- ĐÃ XÁC NHẬN hoạt động: OpenCL khởi tạo (CD); lịch sử chat sạch cặp thất bại (CK: `PROMPT CUOI` log 04/10 chỉ còn lượt hiện tại); giữ `mnn_cachefile.bin` khi dọn cache (CJ: file 3MB còn nguyên).
- KHÔNG có tác dụng: `gc` (CL); chốt chặn CL; giữ cache tuning KHÔNG rút ngắn thời gian tới byte đầu trên GPU (lần chạy đầu 286s, trước đó 274s); chưa giải thích được vì sao lần chạy thứ 2 TRONG CÙNG tiến trình trước đó chỉ mất 61s.
- CHƯA TỪNG kiểm thử: runtime 3.6.1 và 2 model chính (Qwen3-8B, Morpheus) — vì APK vẫn là 3.5.0.
- UTENA-7B không có chat template: vòng lặp `xin chào / Trợ lý: xin chào...` và `ăn nói ăn nói...` là hành vi của model với prompt ghép thô, không đại diện cho chất lượng app.
- Máy vẫn ngủ giữa chừng lúc 11:01 (CHENH LECH 105s) và 11:07 (82s) dù hôm 04/10 sáng không bị; chưa xác minh trạng thái miễn tối ưu pin.

## CN. Nhật ký xác minh trạng thái nguồn + phép thử GPU fp32 (2026-10-04)

### Phản hồi của người dùng (đúng) và đính chính
1. "Sao không làm log xác minh; tôi ĐÃ bật cài đặt pin trong app": đúng. Mục CM chỉ ghi "chưa xác minh" thay vì thêm nhật ký — lẽ ra phải thêm ngay từ mục CJ. Máy vẫn ngủ giữa chừng (log 04/10: STEADY 348s vs WALL 453s; 115s vs 197s) nghĩa là việc app báo "đã bật" KHÔNG đủ để đảm bảo, và cần số liệu thật thay vì suy đoán.
2. "OpenCL khởi tạo được thì có ích gì, trước đó vẫn khởi tạo được, vấn đề là chữ rác": đúng. Sửa thẻ `uses-native-library` (mục CD) chỉ đưa app về lại trạng thái TRƯỚC khi chuyển repo; nó KHÔNG giải quyết chữ rác. Không được coi là tiến bộ.

### Bản sửa
- **`PowerDiagnostics.kt` (mới) + `MnnBridge.kt`**: bao quanh `nativeGenerate()` bằng `PowerWatcher`. Ghi dòng `[PWR]` khi BẮT ĐẦU/KẾT THÚC và mỗi ~15s CHỈ khi trạng thái đổi hoặc máy vừa ngủ thêm > 3s. Mỗi dòng gồm: `ignoreBatteryOpt` (hệ thống có THẬT SỰ miễn tối ưu pin cho app không), `screenOn`, `doze` (isDeviceIdleMode), `powerSave`, `standbyBucket` (10 ACTIVE, 20 WORKING_SET, 30 FREQUENT, 40 RARE, 45 RESTRICTED), `thermal` (API 29+), `directWakeLockHeld`, và tổng thời gian máy NGỦ = `elapsedRealtime - uptimeMillis` (tăng thêm). CHỈ ĐỌC, không đổi cách giữ máy thức. Cân bằng ngoặc đã kiểm; CHƯA biên dịch Kotlin.
- **Cách đọc `[PWR]`**: `ignoreBatteryOpt=false` => nút xanh trong app không khớp hệ thống (cần Cài đặt Android > Ứng dụng > LocalNovel > Pin > Không hạn chế). `doze=true` trước khi ngủ => Doze bỏ qua wake lock của app chưa được miễn. `screenOn=false`, `doze=false` mà vẫn ngủ => trình quản lý nguồn của hãng (ASUS Mobile Manager/Power Master) đóng băng app: cần cho phép tự khởi động/chạy nền trong công cụ của hãng. `standbyBucket >= 40` => hạn chế nền của hệ thống.

### Phép thử 1 biến cho chữ rác trên GPU: `backendPreference = 4` ("Ép GPU fp32")
- Căn cứ (đã tra): tài liệu MNN — `precision` mặc định `"low"` = "cố dùng fp16"; `llm_bench -c`: 0 Normal, 1 High, 2 Low; `"high"` = fp32 trên GPU. fp16 tràn ở ~65.500 nên model có giá trị kích hoạt lớn CÓ THỂ ra NaN/chữ rác khi tính bằng fp16. Cấu hình hiện tại của app (`memory: low`) ĐÚNG với yêu cầu đã biết của MNN cho model int4 trên GPU (GPU chỉ hỗ trợ `memory: low` cho int4/int8; issue AAswordman/Operit #1239 trích lại cảnh báo của MNN).
- **KHÔNG có báo cáo công khai nào xác nhận giả thuyết fp16-tràn cho Adreno + LLM**; ba lượt tìm trước đó cũng không ra issue khớp. Đây là phép thử để có BẰNG CHỨNG, không phải bản sửa. Cách đọc: cùng 1 câu hỏi, cùng model, (a) "Ép GPU" (fp16) ra rác, (b) "Ép GPU fp32" ra bình thường => fp16 tràn là nguyên nhân (khi đó cân nhắc mặc định fp32 cho GPU, chậm hơn); (b) vẫn rác => KHÔNG phải fp16 tràn, hướng khác (kernel OpenCL/driver Adreno).
- Native: `buildOptimizedOpenCLConfig(rawPath, slot, highPrecision)` — `"precision": "high"` khi `backendPreference == 4`; nhánh OpenCL xử lý cả 4. Dart: màn "Tối ưu AI local" đổi `SegmentedButton` thành `Wrap` + `ChoiceChip` (5 lựa chọn không vừa 1 hàng) và thêm chú thích. Không có chỗ nào chặn giá trị 4 (đã kiểm Dart/Kotlin/DB).
- Giới hạn: fp32 trên GPU chậm hơn và tốn RAM hơn fp16; chưa biên dịch.

### Cách thực hiện phép thử (mỗi lần ĐÓNG HẲN app trước khi đổi chế độ, vì rò RAM mục CM chưa hết)
Mở app > "Ép GPU" > hỏi 1 câu ngắn cố định > ghi lại đầu ra. Tắt hẳn app. Lặp với "Ép GPU fp32 (thử nghiệm)" rồi "Ép CPU". Gửi `native_debug.txt` (có dòng `[PWR]` và `[CN]`).

## CO. Log 2026-10-05 (build mucCN): GPU fp32 CŨNG ra rác; nguồn gốc THẬT của việc app kéo chết các app khác = bộ nhớ GPU (KGSL) không được trả (2026-10-05)

### 1. Phép thử GPU fp32 (mục CN) — KẾT QUẢ: giả thuyết "fp16 tràn" KHÔNG được ủng hộ
Cùng model UTENA, cùng phiên (3 lần nạp):
| lần | backend | đầu ra |
|---|---|---|
| 1 | GPU ép (fp16) | ` truyện này cũng thần đang thêm thiếu vào phần bách khoa trước, chung chung của người viết, trả lời như một biên tập viên...` rồi lặp — chữ vô nghĩa, bị dừng ở 500 ký tự |
| 2 | **GPU fp32 (`precision: high`)** | `""""""""""""""""""""""""` — 24 dấu ngoặc kép lặp, bị dừng sau 73,9s |
| 3 | CPU ép | CHƯA chạy được: tiến trình bị hệ điều hành giết trong lúc nạp (xem mục 3) |
- fp32 (nơi tràn số fp16 không thể xảy ra) vẫn thoái hoá, còn tệ hơn (một token lặp mãi — dạng đầu ra điển hình của logit hỏng/NaN) => nguyên nhân KHÔNG phải độ chính xác fp16. Hạn chế: mỗi chế độ chỉ 1 mẫu, câu hỏi khác nhau ("xin chào" vs "trả lời"), model UTENA (không template) vốn dễ lặp; CPU lần 3 không hoàn tất nên chưa có đối chứng cùng phiên. Gợi ý nghi phạm còn lại: kernel OpenCL/dequant int4 của MNN 3.5.0 trên Adreno 660 (khớp BH/#4836), không kiểm chứng được ở đây.

### 2. Nhật ký `[PWR]` (mục CN) cho dữ liệu thật về việc máy ngủ
Mọi cờ "đúng": `ignoreBatteryOpt=true`, `doze=false`, `powerSave=false`, `standbyBucket=5` (EXEMPTED), `thermal=0`, `directWakeLockHeld=true`. NHƯNG trong lúc `screenOn=false` máy vẫn ngủ: +8449ms, +3706ms, +43018ms, +31433ms (tổng 86606ms, khớp WALL−STEADY của native). Khi `screenOn=true` (01:53:52) hết ngủ; lần 2 (`screenOn=true` suốt) ngủ 1ms.
=> Wake lock đang được giữ, không Doze, đã miễn pin mà CPU vẫn đóng băng khi TẮT MÀN HÌNH: đây là cơ chế quản lý nguồn của HÃNG (ASUS) đè lên wake lock, không phải thiếu cài đặt của Android chuẩn và không sửa được bằng code giữ máy thức hiện tại. Cần cài đặt phía ASUS (trình quản lý di động/nguồn: cho phép LocalNovel chạy nền/không hạn chế — tên mục tuỳ phiên bản). CHƯA thử.

### 3. Nguồn gốc THẬT của chuyện kéo chết cả các app khác (smaps sau khi huỷ model)
- Sau lần nạp lại 1: `/dev/kgsl-3d0` = **3628MB**; sau lần nạp lại 2: **7459MB** (RssAnon chỉ 175-220MB; RssFile 3,8GB -> 7,7GB). `MemAvailable` hệ thống: 2,03GB -> 1,30GB. Lần nạp thứ 3 (CPU ép) bị giết giữa chừng (log dừng ngay sau `createLLM`, tiến trình mới 02:02:45).
- `/dev/kgsl-3d0` là bộ nhớ của driver GPU Adreno (KGSL) ánh xạ vào tiến trình: bộ nhớ GPU dùng chung RAM, bị ghim, hệ điều hành không thu hồi như trang file thường. Mỗi lần nạp OpenCL giữ ~3,6GB và `llmSlot.reset()` KHÔNG trả => cộng dồn ~7,5GB => lmkd giết hàng loạt app khác rồi chính app này. CHƯA biết vì sao runtime OpenCL còn sống sau khi huỷ `Llm` (nghi: MNN lấy runtime từ Executor toàn cục dùng chung nên sống suốt tiến trình; `Executor::gc` đã đo = 0 kB).
- Sai sót của tôi: chốt chặn mục CM chặn theo RssAnon nên KHÔNG BAO GIỜ kích hoạt (RssAnon luôn ~0,2GB) — đo sai thước đo; đo smaps ở mục CM đã chỉ đúng thủ phạm nhưng chốt chặn không dùng nó.

### 4. Sửa trong bản CO (chưa build)
- **"Tự động" = CPU** (native: `backendPreference==0` => 2). Căn cứ: GPU ra chữ rác ở cả fp16 lẫn fp32; khi cache đã ấm chỉ ngang CPU về tốc độ (61s vs 62s, log 04/10); mỗi lần nạp giữ ~3,6GB bộ nhớ GPU không trả. GPU vẫn dùng được khi chọn rõ ("Ép GPU"/"Ép GPU fp32"). Không phụ thuộc giá trị đã lưu trong DB (mọi novel đang lưu 0 đều chạy CPU).
- **Chốt chặn theo bộ nhớ GPU thật**: `kgslMappedKb()` (cộng các vùng `/dev/kgsl*` trong smaps); nếu còn giữ > 2GB và `MemAvailable` < 3,5GB thì TỪ CHỐI nạp (cả lần thử lại). Với log 05/10, lần nạp lại thứ 2 (KGSL 3628MB, trống 2,0GB) sẽ bị chặn, không để lên 7,4GB. Đã biên dịch + chạy hàm đo trong sandbox (đọc smaps hoạt động; sandbox không có KGSL => 0).
- **Mỗi lần nạp ghi phiên bản MNN thật** (`[CO] runtime MNN dang chay = ...`) — hết cần suy từ CRC.
- Giao diện: nhãn "Tự động (hiện dùng CPU)", "Ép GPU (thử nghiệm)"; chú thích nêu rõ rủi ro GPU. Thông báo lỗi nạp: nhắc bộ nhớ GPU không tự trả, vuốt tắt hẳn app.

### 5. Chưa giải quyết / không giấu
- Lỗi chữ rác trên GPU CHƯA có lời giải (fp16 bị loại; còn nghi kernel OpenCL của 3.5.0 trên Adreno — chỉ có thể thử bằng runtime 3.6.1, vốn chưa hề được build vì `build.yml` 3.6.1 chưa có hiệu lực — xem mục CM; dòng `[CO]` ở log sau sẽ xác nhận phiên bản).
- Rò bộ nhớ GPU sau khi huỷ model CHƯA sửa tận gốc: chỉ NGĂN (mặc định CPU + chốt chặn). Trên bản APK ĐANG CÀI (mucCN) mặc định "Tự động" vẫn thử OpenCL => hãy CHỌN "Ép CPU" và đừng chọn chế độ GPU cho tới khi cài bản CO.
- Máy ngủ khi tắt màn hình: nguyên nhân phía hãng, chưa có biện pháp trong code.

## CP. Máy ngủ khi tắt màn hình: nút mở cài đặt nguồn ASUS trong app + nhật ký dịch vụ nền (2026-10-05)

> **[CẬP NHẬT 2026-10-08 — xem mục CQ]** Nút ASUS cứng ở mục này đã bị thay bằng bộ mở cài đặt theo hãng (`OemPowerSettings.kt`) vì là hardcode theo thiết bị; và kết luận "phía hãng" ở cuối mục chưa được kiểm bằng log (giả thuyết H2 chưa được đọc lại) — đừng coi là đã chứng minh.

### Câu hỏi của người dùng và trả lời trung thực
1. "Sao không làm thành nút gạt trong app như quản lý pin và truy cập tệp?": Với pin, Android có intent chuẩn xin miễn tối ưu pin; với "Truy cập mọi tệp", Android có trang cài đặt để mở thẳng — app chỉ MỞ ĐƯỢC trang đó, không tự bật được. Với trình quản lý nguồn của ASUS, KHÔNG có API chính thức nào để app (a) tự gạt công tắc, hay (b) ĐỌC trạng thái công tắc. Nên không thể làm công tắc thật có trạng thái xanh/đỏ cho mục ASUS; chỉ làm được nút MỞ THẲNG màn hình đó.
2. "Càng sửa càng tệ, tự tạo bug mới": đã kiểm bằng diff với zip gốc người dùng tải lên. `GenerationService.kt` trước mục CP KHÔNG đổi; mục CP chỉ thêm 4 dòng cờ chỉ-đọc (`isRunning`, `wakeLockHeldNow`). `MnnBridge.kt`: dòng duy nhất đổi có liên quan wake lock là 1 dòng LOG chỉ-đọc (`directWakeLock?.isHeld`); không dòng nào đổi chỗ khởi động/dừng dịch vụ hay xin/giữ wake lock. => Các bản sửa của tôi KHÔNG đụng cơ chế giữ máy thức. Điều tôi KHÔNG chứng minh được: vì sao trước đây tắt màn hình không ngủ (không có log [PWR] cũ để so; mục W 07/09 chỉ ghi STEADY==WALL sau khi bật miễn pin, không ghi rõ màn hình tắt hay sáng).

### Giả thuyết đang mở (chưa xác nhận) về việc ngủ khi tắt màn hình dù miễn pin + wake lock được giữ + không Doze
- H1: cài đặt nguồn RIÊNG của ASUS cho app bị reset khi cài lại (APK từ tài khoản mới có chữ ký khác nên phải gỡ cài lại; thiết lập theo ứng dụng của hãng mất theo). Khớp thời điểm lỗi xuất hiện lại sau khi chuyển repo. Không đọc được trạng thái để kiểm.
- H2: dịch vụ nền KHÔNG thật sự chạy foreground khi tắt màn hình (khi đó tiến trình bị coi là nền; wake lock `isHeld=true` vẫn có thể bị hệ thống vô hiệu hoá). CÓ THỂ kiểm bằng nhật ký mới.
- H3: chế độ hệ thống bỏ qua wake lock. Tài liệu Android: Doze bỏ qua wake lock của app chưa được miễn pin (log: `doze=false`, đã miễn pin); Low Power Standby bỏ qua wake lock của MỌI app kể cả app có dịch vụ nền (log mới ghi `lowPowerStandby`).

### Bản sửa mục CP (chưa build; chưa biên dịch Kotlin/Dart)
- **Nhật ký `[PWR]` thêm**: `svcRunning`, `svcWakeLockHeld` (cờ tĩnh trong `GenerationService`), `svcForegroundPerSystem` (hệ thống báo dịch vụ có `foreground` không, qua `ActivityManager.getRunningServices` — chỉ trả dịch vụ của chính app), `notifEnabled`, `notifActive`, `lowPowerStandby` (API 33+, bọc try/catch). Mục đích: phân biệt H2/H3 bằng số liệu thật ở lần chạy sau.
- **Kênh mới**: `getBackgroundStatus` (miễn pin, thông báo, dịch vụ chạy/foreground) và `openOemPowerSettings` — thử lần lượt `com.asus.mobilemanager/.powersaver.PowerSaverSettings`, `.autostart.AutoStartActivity`, `.MainActivity`; không mở được thì mở trang chi tiết ứng dụng của Android. Tên thành phần ASUS lấy từ danh sách do cộng đồng ghi lại, KHÔNG có tài liệu chính thức, CHƯA kiểm trên ROG Phone 5 (ROG UI có thể khác ZenUI).
- **Giao diện**: thẻ "Chạy nền khi tắt màn hình" trong "Tối ưu AI local": 2 dòng trạng thái xanh/cam (thông báo; dịch vụ foreground) + nút "Mở cài đặt nguồn của ASUS" + ghi chú nói rõ app không tự gạt được công tắc của hãng.
- Cân bằng ngoặc đã kiểm cho Kotlin/Dart; `FilledButton.tonalIcon` cần Flutter >= 3.7 (dự án ghim 3.44.7).

### Cách đọc nhật ký lần sau
`svcForegroundPerSystem=false` hoặc `svcRunning=false` lúc đang sinh => H2 (dịch vụ nền không chạy foreground — bug thật trong app cần sửa). Cả hai `true` mà vẫn "MAY VUA NGU" khi `screenOn=false` => H1/H3 (phía hãng/hệ thống). `lowPowerStandby=true` => H3.

## CQ. Phiên 2026-10-07/08 — đọc lại tài liệu trước khi làm: máy ngủ khi tắt màn hình (bỏ nút ASUS cứng + đóng lỗ hổng lease + chẩn đoán) và GPU rác (đánh giá lại + chốt chặn cache cũ + khảo sát llama.cpp)

### 1. Yêu cầu của người dùng
(a) Đọc kỹ tài liệu trước. (b) Lỗi "máy ngủ khi tắt màn hình" từng gặp, đã sửa và xác nhận bằng log, đã ghi chú. (c) Nút ASUS ở mục CP là hardcode — đổi máy hãng khác thì vô dụng. (d) Quan trọng hơn: GPU vẫn ra rác sau nhiều lượt; nếu do kiến trúc MNN hoặc MNN kén model thì phải đổi kiến trúc, không hardcode model. (e) Khảo sát llama.cpp làm backend thay thế và cách tích hợp JNI.

### 2. Đọc lại tài liệu cho thấy gì (kể cả chỗ tôi sai ở mục CP)
- Mục F (27/08): lỗi "ngủ sâu giữa chừng" có nguyên nhân thật (`pipelineDepth` rò rỉ → bỏ qua `acquireDirectWakeLock()`), đã sửa và **xác nhận bằng log** (ngủ 20,6 phút → ~40 giây). Người dùng nhớ đúng.
- Mục V (07/09): tái diễn 15 phút ở lệnh generate ĐẦU TIÊN của tiến trình (không phải rò rỉ) → khi đó kết luận "phía hãng ASUS" từ lập luận loại trừ, không từ log chỉ ra dịch vụ nền hay quyền.
- Mục CN/CO (05/10): `directWakeLockHeld=true`, miễn tối ưu pin, `doze=false`, `standbyBucket=5` mà vẫn ngủ khi `screenOn=false`.
- Mục CP của tôi: (1) hardcode 3 màn hình ASUS và ghi cứng chữ "ASUS" trên giao diện — người dùng chỉ ĐÚNG; (2) kết luận "cơ chế của hãng" trong khi giả thuyết H2 (tiến trình bị coi là nền, dịch vụ foreground không thật sự chạy foreground khi tắt màn hình) CHƯA được kiểm bằng log nào — dòng `[PWR]` mới của CP chưa từng được đọc lại. Tức là kết luận "phía hãng" đến sớm hơn bằng chứng.

### 3. Bản sửa (chưa biên dịch Kotlin/Dart/C++ — không có NDK/Flutter ở môi trường soạn)
**3.1 Bỏ hardcode ASUS** — `OemPowerSettings.kt` (mới). Hai bậc:
- Bậc 1 (chuẩn AOSP, mọi máy): mở "Thông tin ứng dụng" của chính app (`ACTION_APPLICATION_DETAILS_SETTINGS`) — có Pin và Thông báo.
- Bậc 2 (tuỳ hãng, cố gắng hết sức): bảng dữ liệu `hãng → danh sách (gói, lớp)`; chọn theo `Build.MANUFACTURER + BRAND` của máy ĐANG CHẠY; thử lần lượt, lỗi thì bỏ qua và rơi về bậc 1; không bao giờ ném exception. Thêm hãng = thêm 1 dòng.
- Giao diện (`local_optimization_screen.dart`): nhãn hãng lấy từ chính máy (`brand`), nút ghi "Thử mở cài đặt nguồn của <hãng>" nếu bảng có mục cho máy này (`hasOemEntry`), nếu không ghi "Mở cài đặt pin của ứng dụng".
- **Giới hạn thật**: Android KHÔNG có API chuẩn để mở/đọc/gạt màn hình quản lý nền của từng hãng, nên "giải pháp 100% tổng quát" không tồn tại. Tên thành phần trong bảng (ASUS, Xiaomi, Huawei, OPPO/Realme, vivo, OnePlus, Samsung, Nokia/HMD, HTC, LeEco) lấy từ danh sách do cộng đồng ghi lại, KHÔNG có tài liệu chính thức, KHÔNG kiểm được trên máy thật nào ở đây — có thể sai theo đời ROM. Bậc 1 là lưới an toàn duy nhất đảm bảo.

**3.2 Lỗ hổng THẬT cùng họ với mục F — "lease"** (`MnnBridge.kt`): trước đây `finally` của `generate()`/`loadModel()` làm `if (pipelineDepth == 0) { nhả wake lock; dừng dịch vụ }`. `pipelineDepth` chỉ đếm `beginPipeline/endPipeline` của Dart; khi nhiều lệnh chạy chồng (log thật từng có 2 lệnh generate đè nhau trên 1 slot), lệnh ngắn xong trước thấy depth==0 → nhả wake lock và dừng dịch vụ khi lệnh dài còn chạy. Sửa: mỗi lệnh giữ 1 lease (`beginLease/endLease`, có `leaseEpoch` để lệnh cũ bị huỷ không trừ nhầm bộ đếm mới); chỉ nhả khi `pipelineDepth == 0 && leaseCount == 0`; mọi start/stop dịch vụ nằm trong `synchronized(pipelineDepthLock)`; `performFullCancel` đặt lease về 0 và tăng epoch (lệnh treo vĩnh viễn không giữ dịch vụ mãi).
- **Không chứng minh được đây là nguyên nhân của lần ngủ ở CN/CO**: log đó có `directWakeLockHeld=true` suốt thời gian ngủ, nên lỗ hổng lease KHÔNG giải thích riêng sự kiện đó. Đóng lại vì là lỗ hổng thật trong code, không vì nó đã gây ra lỗi.

**3.3 Dịch vụ foreground** (`GenerationService.kt`): `startForeground` bọc try/catch, ghi `foregroundError`/`foregroundOkAtMs`, lỗi thì `stopSelf()` + `START_NOT_STICKY`. `start()`: nếu dịch vụ đã chạy thì chỉ cập nhật thông báo, KHÔNG gọi lại `startForegroundService` (Android 12+ cấm khởi động dịch vụ foreground từ nền — là 1 đường có thể làm dịch vụ chết lặng lẽ lúc tắt màn hình). `buildNotification/channelId/notificationId` chuyển vào companion để cập nhật thông báo mà không khởi động lại dịch vụ.

**3.4 Chẩn đoán để phân xử H2 vs hãng** (`PowerDiagnostics.kt`, dòng `[PWR]`, `getBackgroundStatus`): thêm `procImportance` (qua `ActivityManager.getMyMemoryState`; 100 = foreground, 125 = foreground service, 400 = cached), `svcFgError`, `svcFgAgeMs`, `leases=`.

### 4. Cách đọc nhật ký lần sau (khi `screenOn=false` lúc đang sinh)
| Quan sát | Nghĩa |
|---|---|
| `procImportance` ≥ 300 (nhất là 400) | Hệ thống coi tiến trình là nền/cached → dịch vụ foreground KHÔNG có tác dụng thật (H2); xem `svcFgError` |
| `svcFgError` khác rỗng | `startForeground` thất bại — đọc lỗi |
| `leases=0` trong lúc đang generate | Lỗi lease — báo ngay |
| `procImportance` = 125, không lỗi, `directWakeLockHeld=true` mà vẫn "MAY VUA NGU" | Nhiều khả năng cơ chế riêng của hãng/hệ thống (mục CP H1/H3); dùng nút mở cài đặt nguồn |
Chưa có dòng nào trong số này được đọc từ máy thật — mọi cột bên phải là cách đọc, không phải kết luận.

### 5. GPU rác — đánh giá lại
- Dữ kiện trong tài liệu (CO, BH, BU, BT): fp16 và fp32 đều rác; CPU đúng ở mọi model đã thử; ≥2 model đều rác; MNN issue #4836 cùng lớp lỗi "kernel OpenCL × driver"; MNN Chat gốc cũng có người dùng báo rác với Qwen. => **Không có bằng chứng "MNN kén model"**; hướng "đổi kiến trúc vì kén model" không có cơ sở. Cũng chưa có phép thử nào tách "lỗi engine MNN/driver Adreno 660" khỏi "lỗi cách app tích hợp".
- **Chốt chặn cache GPU cũ** (`mnn_bridge.cpp`: `modelDirFingerprint`, `guardStaleOpenCLWeightCache`, gọi trong `buildOptimizedOpenCLConfig`): đọc mã MNN 3.5.0 (`OpenCLBackend.cpp`) thấy với `use_mmap=true` + `tmp_path`, trọng số dạng GPU được ghi vào `*.opencl.weight` và dùng lại ở lần nạp sau, điều kiện hợp lệ duy nhất là kích thước mmap ghi trong file `sync` — KHÔNG kiểm model nào tạo ra. Notebook luôn xuất vào cùng tên thư mục `<slug>-MNN-q4-chinh`, nên xuất lại model hoặc 1 lần nạp bị kill giữa lúc ghi có thể để lại trọng số cũ/ghi dở. Bản vá: dấu vân tay (tên+kích thước+mtime mọi file trong thư mục model, FNV-1a) lưu ở `.ln_model_fingerprint`; khác/chưa có → xoá file ≥32MB trong thư mục cache của model rồi ghi dấu mới; giữ file nhỏ (cache dò kernel) theo quy tắc mục CJ. Mỗi lần nạp ghi dòng `[CQ]` (liệt kê file cache trước khi nạp, khớp/khác dấu).
- **Giới hạn thật**: đây là **giả thuyết đọc từ mã nguồn, CHƯA có log nào chứng minh nó đã xảy ra** (mục dọn cache có sẵn thường xoá file lớn mỗi phiên nên có thể không phải thủ phạm các lần rác trước). Không được ghi "đã sửa GPU".
- **Khảo sát llama.cpp**: xem `LocalNovel_LlamaCpp_Survey.md`. Kết luận chính: llama.cpp KHÔNG tự cứu GPU trên Adreno 660 (tài liệu họ: "A6x trong điện thoại nhiều khả năng không hỗ trợ"; Hexagon NPU chỉ v73+). Giá trị thật: hệ sinh thái GGUF, template do llama.cpp áp, sampler/DRY, tái dùng KV theo token. Đề xuất giữ MNN, thêm llama.cpp như engine thứ 2 chọn theo định dạng file; **3 phép thử trên điện thoại (A: MNN Chat gốc GPU vs CPU cùng model; B: llama.cpp Termux GPU vs CPU; C: tốc độ CPU) cần làm TRƯỚC khi viết code tích hợp**. Chưa viết mã llama.cpp nào.

### 6. Chưa giải quyết / không giấu
- Máy ngủ khi tắt màn hình: chưa biết nguyên nhân thật cho lần CN/CO; có chẩn đoán mới, cần log mới.
- GPU rác: chưa có lời giải; phép thử A là bước quyết định.
- Mọi thay đổi mục CQ chưa biên dịch.

---

## CR. Provider Google Gemini gọi thẳng API gốc (2026-10-07)

**Câu hỏi của người dùng**: "Ở dự án này có API model của Google không?" — **Trước mục này: không có provider riêng.** App có Anthropic, OpenAI-compatible, OpenRouter, GPU từ xa (Colab). Gemini dùng được qua endpoint "tương thích OpenAI" của Google bằng provider OpenAI-compatible (nhập base URL do Google công bố), nhưng không đặt được `safetySettings` và tham số lạ bị bỏ qua âm thầm.

**Đã làm**: `lib/services/providers/gemini_provider.dart` (mới) — `generateContent` và `streamGenerateContent?alt=sse`, khoá trong header `x-goog-api-key` (không để trong URL), `systemInstruction`, `generationConfig`, `safetySettings`=BLOCK_NONE cho 4 nhóm chỉnh được. Tên model do người dùng nhập (không hardcode danh sách). Thêm vào `settings_service.dart` (`_buildApiProviderFromEntry`, type `gemini`) và `settings_screen.dart` (mục "Google Gemini" + chú thích).
**Giới hạn thật (theo tài liệu Google)**: bảo vệ lõi (vd nội dung hại trẻ em) luôn chặn, không chỉnh được; với Gemini 2.5/3 ngưỡng mặc định đã là Off; model có "thinking" có thể dùng hết `maxOutputTokens` cho suy nghĩ và trả rỗng (provider báo lỗi rõ); gói miễn phí có giới hạn và điều khoản dữ liệu của Google. **Chưa build/test** (không có Dart SDK).

---

## CS. Web chat AI làm "model viết truyện" qua WebView (2026-10-07/08)

**Yêu cầu**: duyệt web, đăng nhập một web chat AI, dùng prompt/Story Bible/chức năng viết tiểu thuyết của app để yêu cầu web chat viết chương rồi lưu thành chương như bình thường.

**Thiết kế**: app đã gọi `AIProvider.generate*()` với system prompt + user prompt → `WebChatProvider` (loại provider mới `web_chat`) nhận 2 chuỗi đó và nhờ `WebChatSession` (singleton, 1 `WebViewController` dùng chung, cookie đăng nhập nằm trong WebView) dán vào ô chat, gửi, đợi, đọc trả lời, trả về như 1 model bình thường — luồng viết chương/lưu chương KHÔNG đổi.
- `web_chat_session.dart`: kênh JS `LNCh`; hỏi đáp chạy TUẦN TỰ; poll từ Dart (không dùng timer JS vì trang nền bị giãn timer); mỗi lần gọi mở cuộc trò chuyện MỚI; đọc trả lời bằng MÃ tham chiếu (nonce) — lấy phần chữ sau mã trong tin của mình rồi cắt phần giao diện thừa (Copy, "You said"…); xong khi chữ ổn định (3s nếu thấy nút dừng, 9s nếu không).
- `web_chat_js.dart` (sinh từ `ln_webchat.js`): dò ô nhập (ô soạn thấp nhất/rộng nhất), nút gửi (nhãn send/gửi… gần ô nhập; không có thì Enter), nút dừng; chọn phần tử bằng cách chạm ("Dạy app"); selector đã dạy lưu RIÊNG từng provider (SharedPreferences), ưu tiên hơn dò tự động.
- `web_chat_host.dart`: WebView luôn là 1 widget + `GlobalKey` (không bị nạp lại); 3 trạng thái: rảnh = 1×1; đang chạy = phủ kín nhưng NẰM DƯỚI giao diện app (trang có kích thước thật); mở cho người dùng = trên cùng có thanh công cụ. Nằm TRÊN Navigator nên không dùng Dialog/Popup/Tooltip.
- Cài đặt: loại "Web chat AI" với nút chọn nhanh (ChatGPT, Gemini, Claude) và ô URL "cuộc trò chuyện mới"; nút biểu tượng trình duyệt cạnh provider để đăng nhập/dạy. `pubspec.yaml`: `webview_flutter ^4.10.0`; `build.yml` bản sửa thêm quyền INTERNET nếu thiếu (bước cũ tên "quyền Internet" không thực sự thêm).

**Đã kiểm**: phần JS chạy trong Chromium thật (Playwright) trên 3 trang chat GIẢ do tôi dựng (kiểu ChatGPT contenteditable + nút gửi; kiểu Gemini textarea + Enter; trang có nút gửi không nhãn chỉ hiện sau khi gõ) — chỉ chứng minh logic.
**Giới hạn thật (không giấu)**:
1. CHƯA chạy trên trang thật nào và chưa biên dịch Dart. Giao diện thật có thể khác; khi đó dùng "Dạy app".
2. Chưa biết khi TẮT MÀN HÌNH WebView có chạy tiếp không (trình duyệt có thể ngưng vẽ/giãn timer).
3. Điều khoản dịch vụ của nhiều trang cấm tự động hoá giao diện web → tài khoản có thể bị hạn chế. Gói miễn phí có hạn mức tin nhắn; app chỉ phát hiện qua chữ báo lỗi.
4. Google thường chặn "Tiếp tục với Google" trong trình duyệt nhúng; popup đăng nhập không được hỗ trợ — dùng email/mật khẩu nếu trang cho.
5. temperature/top_p/max tokens KHÔNG áp dụng được. Không có stream thật (trả 1 khối khi ổn định).

---

## CT. "Model thư ký" + "AI tự dạy" cho Web chat (2026-10-08)

**Câu hỏi của người dùng**: dùng API model ít tham số làm thư ký trò chuyện/trích xuất, còn web chat AI tham số lớn chỉ để viết — làm được không? Và có thể nhờ API model "dạy app chỗ nhập/gửi/đọc" không?

**Trả lời**: làm được, đã làm cả hai (chưa biên dịch/chưa chạy máy thật).

**A. Model thư ký** — vì sao: sau MỖI chương app tự tóm tắt chương + nén "cốt truyện đã diễn ra" (2 lượt), chat/trích Bible/kiểm tra nhất quán mỗi việc 1 lượt; nếu model chính là Web chat AI (chậm, có hạn mức tin nhắn) thì các việc phụ này ăn hết hạn mức và chậm gấp 3.
- `SettingsService.secretaryProvider(novelId)`: đọc id API provider đã chọn (SharedPreferences, riêng từng truyện); chưa chọn hoặc không sẵn sàng (thiếu khoá/URL, đã bị xoá) → quay về `currentProvider` và ghi log — **hành vi cũ giữ nguyên với người dùng cũ**.
- Việc dùng thư ký: chat trò chuyện, trích Story Bible (chat + tài liệu), tóm tắt chương + cốt truyện tích luỹ (cả luồng tạo hàng loạt: `memoryProvider` truyền xuống `ChapterBatchService`), kiểm tra nhất quán, phân tích văn phong, tóm tắt sự kiện timeline. Việc dùng model chính: viết tiếp, đắp thịt, áp dụng sửa, tạo chương hàng loạt (phần sinh chương), gợi ý dàn ý.
- Giao diện: thẻ "Model thư ký (việc phụ)" trong Cài đặt (menu chọn API provider; "Dùng chung model chính"), kèm cảnh báo nếu chọn Web chat làm thư ký.
- **Đánh đổi**: nội dung truyện (đoạn văn, Story Bible) đi tới nhà cung cấp của thư ký; thư ký là model nhỏ nên trích xuất/tóm tắt có thể kém model lớn; khoá/hạn mức khác với model chính. Người dùng tự quyết định chọn hay không.

**B. "AI tự dạy"** (nút trong bảng "Dạy app / kiểm tra" của trình duyệt nhúng):
1. JS liệt kê ứng viên có MÃ (ô gõ `i0…`; nút sát ô nhập `b0…` kèm cờ `fresh` = nút MỚI hiện/bật sau khi gõ chữ). Model thư ký chỉ chọn MÃ, không tự viết selector → không bịa được selector không tồn tại; lỗi/sai mã → luật dự phòng (ứng viên đầu / nút `fresh` đầu).
2. App gõ thử "ping", lấy danh sách nút, rồi xin selector (`LN.commit`).
3. **Chạy thử thật**: tải lại trang, dán 1 câu hỏi, gửi, đọc trả lời bằng đúng đường dùng khi viết truyện. Thất bại → HOÀN LẠI cấu hình cũ, báo lý do.
4. Vùng trả lời: không dùng AI — tìm đoạn chữ vừa nhận trên trang rồi lấy khối bao quanh (`LN.locateReply`); không định vị được thì vẫn dùng cách dò theo mã tham chiếu.
- Chặn dùng nhầm: thư ký phải là API thật — nếu là Web chat AI (vòng lặp tự gọi mình) hoặc model local thì báo lỗi rõ.
- **Đã kiểm trong Chromium** trên 3 trang giả (kể cả trang có 2 nút biểu tượng không nhãn + nút gửi chỉ hiện sau khi gõ + ô tìm kiếm/nút chat cũ ở thanh bên làm mồi nhử). Đã sửa 2 lỗi do chính phép thử phát hiện: (i) cờ `fresh` dựa vào vị trí nên nút micro bị đẩy lệch khi nút gửi hiện ra bị tính nhầm là "mới" → đổi sang chữ ký theo nhãn/lớp + danh tính phần tử; (ii) `locateReply` chọn nhầm thẻ `<script>` vì mã nguồn trang chứa đúng đoạn chữ → bỏ qua script/style/phần tử ẩn và yêu cầu khối cuối nhìn thấy được.
- **Giới hạn thật**: (a) tốn đúng 1 tin nhắn thật của tài khoản web chat để chạy thử; (b) nhãn các nút sát ô nhập + placeholder của ô gõ được gửi cho model thư ký (không gửi nội dung cuộc trò chuyện, nhưng là chữ lấy từ trang); (c) chưa thử trên trang thật nào, chưa biên dịch Dart; (d) nút DỪNG không được dạy tự động (app đợi lâu hơn để chắc đã xong); (e) lời chọn của model chỉ là gợi ý — bằng chứng thật là bước chạy thử.

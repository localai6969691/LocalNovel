# Khảo sát llama.cpp làm backend thay thế/bổ sung cho MNN — và cách tích hợp qua JNI (2026-10-08)

Phạm vi: trả lời đúng câu hỏi của người dùng — "GPU ra rác mãi: nếu do kiến trúc MNN thì đổi kiến trúc; không hardcode model; khảo sát llama.cpp + JNI".
Đọc kèm: `LocalNovel_Architecture_Spec.md` mục BH, BT, CE, CI, CN, CO (bằng chứng GPU) và mục CQ (bản vá chống cache GPU cũ, chưa chứng minh).

---------------------------------------------------------------------------------------------------

## 0. Kết luận (đọc phần này nếu chỉ có 1 phút)

1. **llama.cpp KHÔNG tự cứu được GPU trên máy test (Zenfone 8 / Snapdragon 888 / Adreno 660).** Chính tài liệu của họ nói: OpenCL kiểm chứng trên Adreno 750/810/830/840; "GPU A6x **trong điện thoại** nhiều khả năng KHÔNG được hỗ trợ vì driver và compiler quá cũ". Hexagon NPU của họ chỉ có kernel cho HTP v73/v75/v79/v81 (Snapdragon 888 là v68 — điểm này là hiểu biết của tôi, không nằm trong tài liệu llama.cpp). Vulkan có sẵn nhưng độ tin cậy trên Adreno 6xx là chưa biết.
2. Vì vậy **đổi sang llama.cpp không phải là "bản sửa GPU"**. Nếu tôn chỉ số 1 ("tối thiểu phải chạy GPU") vẫn giữ, việc quyết định cần số liệu từ 3 phép thử rẻ ở mục 6 TRƯỚC khi viết 1 dòng code tích hợp.
3. Giá trị thật của llama.cpp với dự án này (kể cả khi GPU không dùng được): (a) hệ sinh thái GGUF — tải model có sẵn từ Hugging Face, không phải tự convert qua `llmexport` rồi dính lỗi "runtime phải ≥ phiên bản xuất" (mục CE) hay cờ C4 (mục CH); (b) khuôn mẫu chat (Jinja) nằm TRONG file GGUF và do llama.cpp áp — không hardcode theo model; (c) sampler đầy đủ (DRY, min-p, penalty theo cửa sổ); (d) tái dùng KV theo **so khớp token thật** (đúng theo cách làm mà MNN `reuse_kv` đã sai ở mục 65 — không thể lệch vì so sánh trực tiếp mảng token); (e) CPU tốt, được kiểm thử rộng, dùng được ngay không cần GPU.
4. Cái giá: thêm 1 thư viện native (~vài chục nghìn dòng C++ phải biên dịch trong CI), API đổi nhanh (cả `llama_decode` lẫn `llama_process` cùng tồn tại ở bản 2026-10-07 → **bắt buộc ghim phiên bản**), phải port bộ dò lặp native hiện nằm trong `mnn_bridge.cpp`, và Snapdragon 888 (Armv8.2, không i8mm/SVE — hiểu biết của tôi) không hưởng được các kernel CPU mới nhất.
5. Đề xuất: **giữ MNN làm engine mặc định, thêm llama.cpp như engine thứ 2 chọn theo định dạng file (`.gguf` → llama.cpp, thư mục có `llm_config.json` → MNN)**. Không thay thế, vì thay thế bỏ mất đường GPU/QNN của MNN trên máy mới hơn (Adreno 7xx/8xx nơi cả hai đều có thể chạy).

---------------------------------------------------------------------------------------------------

## 1. Bằng chứng GPU hiện có (để biết mình đang giải bài toán nào)

| Dữ kiện (nguồn trong spec) | Ý nghĩa |
|---|---|
| GPU fp16 ra chữ rác; GPU **fp32** (`precision: high`) cũng rác, còn tệ hơn (mục CO) | Loại giả thuyết "tràn số fp16" |
| CPU ra đúng ở mọi model đã thử (mục BH) | Trọng số/model/template không hỏng; lỗi nằm ở đường OpenCL |
| Lỗi nhiều model (UTENA 7B và model khác — mục BU) | Không phải "kén 1 model" |
| MNN issue #4836: OpenCL ra rác không báo lỗi trên Intel Iris Xe, CPU và Vulkan cùng máy đều đúng (mục BH) | Cùng lớp lỗi "kernel OpenCL × driver cụ thể" |
| App MNN Chat gốc cũng có người dùng báo "gibberish" với Qwen (mục BT) | Không riêng tầng app này |
| Benchmark gốc 16,7 t/s đo bằng MNN Chat **trên đúng máy này** (mục BT) | Chưa rõ đầu ra lúc đó có đúng không, và chạy backend nào — **đây là mắt xích còn thiếu** |
| Mục CQ (bản vá mới): cache OpenCL `*.opencl.weight` được dùng lại không kiểm danh tính model | **Giả thuyết CHƯA chứng minh**: cache của model khác/phiên bản khác có thể gây rác |

Chưa có phép thử nào tách được "lỗi engine MNN" khỏi "lỗi do cách app tích hợp" (cấu hình, cache, template). Phép thử A ở mục 6 làm đúng việc đó.

---------------------------------------------------------------------------------------------------

## 2. llama.cpp trên Snapdragon 888 — từng đường chạy

(Phiên bản tham chiếu: tag `v0.6.0` = commit `d81235049384534c167caea52b85a694f6103d14`, 2026-10-05, là bản Termux đang đóng gói; mới hơn có `b11493` = `847f447c310a3784d623a953e6f0bb07f04c0f27`, 2026-10-08.)

| Đường | Tình trạng theo tài liệu/mã nguồn | Với máy test |
|---|---|---|
| CPU (NEON/dotprod; i8mm, SME2, KleidiAI cho CPU mới) | Chọn biến thể lúc chạy nếu build `GGML_CPU_ALL_VARIANTS=ON` + `GGML_BACKEND_DL=ON` | Chạy được. Kryo 680 (X1 + A78 + A55) là Armv8.2 có dotprod, **không** i8mm/SVE (hiểu biết của tôi) → rơi vào biến thể dotprod |
| OpenCL (Adreno) | `docs/backend/OPENCL.md`: kiểm chứng A750, A810, A830, A840, X1-85, X2-90; "A6x trong điện thoại nhiều khả năng không hỗ trợ" | **Không được hỗ trợ chính thức.** Có thể thử, đừng hứa |
| Vulkan | Có (`GGML_VULKAN`); Termux đóng gói riêng `llama-cpp-backend-vulkan` | Chưa biết; độ ổn định trên Adreno 6xx không có bằng chứng trong nguồn tôi đọc |
| Hexagon NPU | `docs/backend/snapdragon/README.md`: chỉ có `libggml-htp-v73/v75/v79/v81` | Không (Snapdragon 888 = v68, hiểu biết của tôi) |

Hệ quả: với llama.cpp, "GPU trên máy này" = thử OpenCL/Vulkan như **thí nghiệm**, mặc định CPU. Điều này chính là hành vi mà mục CO đã chọn cho MNN ("Tự động = CPU").

---------------------------------------------------------------------------------------------------

## 3. Kiến trúc tích hợp đề xuất (không hardcode model/thiết bị)

### 3.1 Chọn engine theo định dạng file, không theo tên model
- `.gguf` (1 file) → engine llama.cpp. Thư mục có `llm_config.json`/`config.json` → engine MNN. Quy tắc nằm ở 1 hàm duy nhất (`engineFor(path)`), không có bảng tên model.
- Màn "Thêm model local" hiện đang ghi "engine hiện tại (MNN) không dùng trực tiếp file .gguf" (`settings_screen.dart`) → sửa khi engine thứ 2 chạy được: cho phép chọn file `.gguf`.

### 3.2 Giữ nguyên bề mặt hiện có để chạm ít code nhất
App hiện có chuỗi: Dart `LocalLlamaProvider` → MethodChannel `com.localnovel/mnn_method` → `MnnBridge.kt` (khoá/lease/dịch vụ nền/PowerWatcher) → JNI `MnnNative` → `mnn_bridge.cpp` (theo `slot`). Toàn bộ phần **khoá theo slot, sở hữu object bằng shared_ptr, lease giữ máy thức, dịch vụ foreground, huỷ, theo dõi treo** (mục L, F, V, CP, CQ) nằm ở Kotlin và **không phụ thuộc engine** → tái dùng nguyên.
Chỉ thêm 1 lớp mỏng trong Kotlin:

```kotlin
interface NativeEngine {            // trùng với các hàm MnnNative hiện có
    fun loadModel(slot: Int, path: String, backendPreference: Int): Boolean
    fun generate(slot: Int, prompt: String, configJson: String, cb: TokenCallback)
    fun unload(slot: Int)
    fun isLoaded(slot: Int): Boolean
    fun activeBackend(slot: Int): String
    fun requestCancel(slot: Int)
    fun isGenerating(slot: Int): Boolean
    fun needsFullReload(slot: Int): Boolean
    fun slotStalledMs(slot: Int): Long
}
object MnnEngine : NativeEngine { /* gọi MnnNative.* như cũ */ }
object LlamaEngine : NativeEngine { /* gọi LlamaNative.* mới */ }
```
`MnnBridge.kt` chọn engine theo đường dẫn lúc `loadModel` và nhớ engine theo `slot`. Dart gần như không đổi (thêm trường `engine` hiển thị ở nhật ký).

### 3.3 Thư viện native thứ 2: `libllama_bridge.so`
- JNI class `com.localnovel.mnnbridge.LlamaNative`, hàm `nativeLlama*` — cùng chữ ký ý nghĩa với `MnnNative` (slot, load, generate, unload, cancel…).
- Trạng thái theo slot (tương tự `g_slots` của MNN): `llama_model*`, `llama_context*`, chuỗi sampler, `std::vector<llama_token> cached_tokens`, cờ huỷ nguyên tử, mốc thời gian token cuối (cho `slotStalledMs`).
- **Khởi tạo 1 lần**: `llama_log_set(...)` (đẩy log vào `native_debug.txt` như MNN), `ggml_backend_load_all_from_path(nativeLibDir)`, `llama_backend_init()` — đúng như ví dụ chính thức `examples/llama.android`.
- **Nạp model**: `llama_model_load_from_file(path, params)`; tham số `n_gpu_layers` = 0 mặc định (CPU), >0 chỉ khi người dùng chọn "thử GPU" (thí nghiệm). `llama_init_from_model` với `n_ctx` do người dùng/ngân sách RAM quyết (ví dụ chặn bằng `llama_model_n_ctx_train`), `n_batch/n_ubatch` ≈ 512, số luồng = số nhân lớn (ví dụ chính thức dùng `clamp(nproc−2, 2, 4)`).
- **Sinh chữ**: vòng lặp `common_sampler_sample → common_sampler_accept → llama_decode` (hoặc `llama_process` ở bản mới — chọn 1 hàm theo bản đã ghim và kiểm khi build), dừng ở `llama_vocab_is_eog`, gom byte tới khi đủ UTF-8 rồi mới gửi `onToken` (ví dụ chính thức có `is_valid_utf8` — **bắt buộc**, cùng lớp lỗi với mục Z).
- **Huỷ thật**: cờ nguyên tử kiểm giữa các token + `llama_set_abort_callback` để ngắt cả khi đang prefill dài.

### 3.4 Khuôn mẫu chat — để llama.cpp áp, không hardcode
- Hiện app dựng prompt bằng Jinja ở Dart từ `llm_config.json` của model MNN (mục AV, BD, BE). Với GGUF, template nằm trong metadata (`tokenizer.chat_template`).
- Phương án khuyến nghị: Dart gửi **danh sách message** (`system`, `user` — đúng 2 phần mà `AIProvider.generate` đang có) dưới dạng JSON; native gọi `common_chat_templates_init(model, "")` rồi `common_chat_templates_apply(...)` để ra chuỗi prompt. Không cần bảng template theo tên model. Nếu `common_chat_templates_was_explicit` trả false (model thiếu template) → rơi về ghép chữ thô và **ghi cảnh báo vào log** (không đoán).
- Chi tiết BOS/special-token khi tokenize: sao chép đúng logic của `tools/server` hoặc `examples/main` ở bản đã ghim; đừng tự suy.

### 3.5 Tái dùng KV theo token (thay cho `reuse_kv` của MNN)
App luôn dựng lại TOÀN BỘ prompt (Story Bible + ngữ cảnh) mỗi lượt → phần đầu rất dài và giống nhau. Cách làm:

```
tokens = tokenize(prompt)
lcp    = độ dài tiền tố chung giữa tokens và cached_tokens   // so từng token
lcp    = min(lcp, tokens.size() - 1)                          // luôn để lại >= 1 token để có logit
nếu lcp < cached_tokens.size():
    ok = llama_memory_seq_rm(mem, 0, lcp, -1)                 // cắt phần đuôi cũ
    nếu !ok (model hồi quy/không cắt được từng phần): llama_memory_clear(mem, true); lcp = 0
decode(tokens[lcp:]) theo lô n_batch; cached_tokens = tokens[:lcp] + tokens[lcp:]
sau khi sinh xong: cached_tokens += các token đã sinh
```
Vì so khớp token thật nên **không thể** xảy ra kiểu lệch KV "8888888" đã gặp ở mục 65 (nguyên nhân khi đó: KV có phần model tự sinh, còn prompt mới thì không). Giới hạn: lợi ích chỉ có khi phần đầu prompt giống hệt giữa 2 lượt (Story Bible đổi giữa chừng → mất lợi ích từ điểm đổi trở đi). Hàm `llama_memory_can_shift` / giá trị trả về của `seq_rm` quyết định có cắt từng phần được không.

### 3.6 Sampler
`generationConfigJson` hiện có (temperature, top_p, top_k, repetition_penalty, …) ánh xạ sang `common_params_sampling`: `temp`, `top_p`, `top_k`, `min_p`, `penalty_repeat`, `penalty_last_n`, và **`dry_multiplier/dry_base/dry_allowed_length/dry_penalty_last_n`** (đã xác minh các tên trường này tồn tại ở `common/common.h` bản 2026-10-07). Thêm vào màn "Cài đặt sinh chữ" 1 mục DRY (mặc định tắt). Lưu ý đã ghi ở mục BT: DRY **không** có bằng chứng giải quyết dứt điểm lặp vô tận → vẫn cần bộ dò lặp hậu kiểm.

### 3.7 Port bộ dò lặp
Bộ dò lặp (mục Z, BK, BQ, BU) nằm trong `mnn_bridge.cpp`. Tách phần thuần logic (nhận chuỗi UTF-8 đang sinh, trả "dừng/không") ra `loop_guard.h` dùng chung 2 engine — việc cơ học nhưng phải chạy lại các test cũ. Không tách thì engine mới không có chốt chặn.

### 3.8 Build (CI)
- `build.yml` thêm bước **clone llama.cpp ở commit ghim** (đề xuất tag `v0.6.0` = `d812350…`; cùng bản với gói Termux dùng cho phép thử mục 6 → kết quả Termux dự đoán sát hành vi trong app).
- CMake cho `llama_bridge` (cờ lấy từ `examples/llama.android/lib/build.gradle.kts`, đã đọc): `-DBUILD_SHARED_LIBS=ON -DGGML_BACKEND_DL=ON -DGGML_CPU_ALL_VARIANTS=ON -DGGML_NATIVE=OFF -DGGML_LLAMAFILE=OFF -DLLAMA_BUILD_APP=OFF -DLLAMA_BUILD_COMMON=ON -DLLAMA_OPENSSL=OFF`; arm64: `GGML_CPU_KLEIDIAI=ON`, `GGML_OPENMP=ON` (ví dụ chính thức đặt vậy). OpenCL/Vulkan: chỉ bật khi làm thí nghiệm GPU (`-DGGML_OPENCL=ON`/`-DGGML_VULKAN=ON`, tạo thêm `libggml-opencl.so`/`libggml-vulkan.so` nạp động).
- **Backend nạp động đòi file `.so` nằm thật trong thư mục thư viện của app** → manifest cần `android:extractNativeLibs="true"` (ví dụ chính thức có đặt). Đã grep `android_native/` và `build.yml`: dự án hiện KHÔNG đặt thuộc tính này, nên phải thêm bước vá manifest trong `build.yml`; `ggml_backend_load_all_from_path(nativeLibDir)` sẽ không thấy backend nếu thư viện chỉ nằm trong APK.
- Hai thư viện cùng dùng `libc++_shared`; `build.yml` hiện không đặt `MNN_OPENMP` (grep không thấy) nên nguy cơ đụng `libomp.so` có vẻ thấp — chưa kiểm khi đóng gói thật.
- Vì không biên dịch được ở môi trường soạn (không có NDK/Flutter), **bước CI đầu tiên chỉ nên biên dịch + chạy 1 bài tự kiểm** (nạp model nhỏ, sinh 20 token, ghi `[LL]` vào nhật ký) — theo đúng cách các mục CB–CE đã làm với MNN.

---------------------------------------------------------------------------------------------------

## 4. Việc phải làm (ước lượng thô, theo thứ tự)

| Giai đoạn | Nội dung | Tiêu chí xong |
|---|---|---|
| P0 | 3 phép thử ở mục 6 (không code) | Có số liệu: GPU llama.cpp đúng/sai; CPU llama.cpp so MNN CPU |
| P1 | `NativeEngine` + `LlamaNative` CPU-only, nạp/sinh/huỷ/unload; tự kiểm ở CI | Log `[LL]` thấy sinh chữ đúng tiếng Việt từ 1 GGUF nhỏ |
| P2 | Template qua `common_chat_templates_apply`, UTF-8, `loop_guard.h`, ánh xạ sampler + DRY | Chạy lại đúng các phép thử lặp cũ (mục BQ/BU) không tệ hơn MNN |
| P3 | Tái dùng KV theo token | Lượt thứ 2 cùng Story Bible: thời gian prefill giảm rõ trong log |
| P4 (tuỳ chọn) | Thí nghiệm GPU: `n_gpu_layers>0` với OpenCL/Vulkan, **có đối chiếu đầu ra với CPU** (cùng seed, so 32 token đầu) | Quyết định bật/cấm theo SoC bằng **phép kiểm đối chiếu lúc chạy**, không theo tên máy |

Chốt an toàn tổng quát cho GPU (tránh hardcode theo máy): trước khi cho 1 backend GPU chạy thật, native tự chạy 1 prompt cố định ngắn trên **cả CPU lẫn GPU** với cùng hạt giống, so lệch (token đầu / logit); lệch quá ngưỡng → tự cấm GPU cho cặp (máy, model) đó và ghi lý do. Cách này giải đúng lớp lỗi "OpenCL ra rác không báo lỗi" (MNN #4836) mà không cần danh sách thiết bị.

---------------------------------------------------------------------------------------------------

## 5. Rủi ro và điều CHƯA biết (không giấu)

1. Chưa biên dịch/chạy gì ở môi trường soạn; mọi thứ ở mục 3 là thiết kế đã đối chiếu với mã nguồn chính thức, chưa phải code chạy được.
2. Không biết llama.cpp OpenCL/Vulkan có cho đầu ra đúng trên Adreno 660 hay không — chỉ phép thử Termux mới trả lời được.
3. Tốc độ CPU llama.cpp trên Snapdragon 888 so với MNN CPU: không có số liệu trong tay; không ước lượng từ trí nhớ.
4. API đổi nhanh (bản 2026-10-07 có cả `llama_decode` lẫn `llama_process`); JNI phải viết theo bản ghim và kiểm lúc build.
5. Nếu phép thử A cho thấy MNN Chat gốc chạy GPU **đúng** với cùng model thì lỗi nằm ở cách app tích hợp/cấu hình MNN (cache, template, tham số) — khi đó đổi engine là sai hướng, và mục CQ cùng các thiết lập mục CD–CO mới là nơi cần đào.
6. Tuân thủ giấy phép: llama.cpp là MIT; GGUF của từng model có giấy phép riêng.

---------------------------------------------------------------------------------------------------

## 6. Ba phép thử quyết định (làm trên điện thoại, không cần build app)

**Phép thử A — MNN Chat gốc, cùng model, GPU vs CPU.** Mở app MNN Chat (Alibaba), nạp đúng thư mục model đang bị rác, chọn backend OpenCL, hỏi 1 câu ngắn cố định ("Xin chào, hãy giới thiệu ngắn về bạn."), chép đầu ra; lặp với CPU. Kết quả:
- GPU rác ở MNN Chat gốc → lỗi ở engine MNN/driver (hướng B); đổi engine mới có ý nghĩa.
- GPU đúng ở MNN Chat gốc → lỗi ở cách app tích hợp (hướng C); **đừng đổi engine**, đào cấu hình/cache/template của app (mục CQ).

**Phép thử B — llama.cpp trong Termux, cùng họ model (GGUF).** Cài `pkg install llama-cpp llama-cpp-backend-opencl llama-cpp-backend-vulkan` (gói Termux build backend nạp động, như `build.sh` của họ). Chạy `llama-cli --list-devices` xem GPU có được nhận không; rồi chạy cùng 1 câu với `-ngl 0` (CPU) và `-ngl 99` (GPU), so đầu ra. (Tên cờ có thể đổi theo bản; xem `llama-cli --help`.) GGUF lấy từ Hugging Face hoặc tự tạo bằng `convert_hf_to_gguf.py` + `llama-quantize` trên Colab.
- GPU đúng ở llama.cpp mà sai ở MNN → có lý do thật để đưa engine thứ 2 vào.
- GPU sai ở cả hai → driver Adreno 660 là gốc rễ; "GPU bắt buộc" không đạt được trên máy này bằng bất kỳ engine nào (cần xét lại tôn chỉ số 1 cho dòng Adreno 6xx).

**Phép thử C — tốc độ CPU.** `llama-bench -m model.gguf -ngl 0` (đọc `pp` và `tg` t/s) so với số của MNN CPU trên cùng cỡ model/lượng tử hoá. Chỉ khi llama.cpp CPU không tệ hơn MNN CPU thì "engine thứ 2 chạy CPU" mới đáng làm vì lý do hiệu năng; còn lại giá trị nằm ở hệ sinh thái GGUF/template/sampler/KV.

Gửi kết quả (đầu ra chữ + t/s) là đủ để chọn nhánh ở mục 0.5.

---------------------------------------------------------------------------------------------------

## Nguồn đã đọc (mã nguồn/tài liệu thật, không phải trí nhớ)
- llama.cpp (clone 2026-10-07): `docs/backend/OPENCL.md`, `docs/backend/snapdragon/README.md`, `docs/android.md`, `examples/llama.android/lib/src/main/cpp/{ai_chat.cpp,CMakeLists.txt}`, `examples/llama.android/lib/build.gradle.kts`, `examples/llama.android/app/src/main/AndroidManifest.xml`, `include/llama.h`, `common/common.h`, `common/chat.h`.
- Termux packages: `packages/llama-cpp/build.sh` (phiên bản 0.6.0, `GGML_BACKEND_DL`, `GGML_VULKAN`, `GGML_OPENCL`).
- Dự án: `LocalNovel_Architecture_Spec.md` (mục BH, BT, BU, CE, CH, CN, CO, CP), `MnnNative.kt`, `mnn_bridge.cpp`, `MnnBridge.kt`.
- Tags: `git ls-remote --tags https://github.com/ggml-org/llama.cpp` (v0.6.0, b11493).

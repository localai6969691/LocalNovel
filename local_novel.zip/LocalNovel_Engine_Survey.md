# Khảo sát engine LLM thứ hai — đối chiếu với YÊU CẦU GỐC của dự án

Ngày: 2026-10-10. Phạm vi: Android arm64, máy test Zenfone 8 (Snapdragon 888, **Adreno 660**, Hexagon v68, 16GB, Android 13).
Điều kiện đã chốt với bạn: **giữ MNN**, engine thứ hai chỉ là lựa chọn thêm vào, không bắt buộc là llama.cpp.
Bổ sung cho `LocalNovel_LlamaCpp_Survey.md` (bản đó chỉ khảo sát riêng llama.cpp; bản này so sánh nhiều engine).

> Cách đọc mức tin cậy: **[MÃ]** = mình đọc thẳng mã nguồn/tài liệu trong bản clone (có đường dẫn) · **[BÁO CÁO]** = người khác báo cáo trên GitHub, mình/tác tử đọc nhưng chưa tái hiện · **[SUY LUẬN]** = mình suy ra, không có nguồn trực tiếp · **[CHƯA BIẾT]** = không tìm được bằng chứng. Mình KHÔNG gộp các loại này lại.

---

## 0. Kết luận trước (đọc phần này nếu chỉ có 1 phút)

1. **Không engine nào — kể cả MNN — có bằng chứng "chạy ĐÚNG trên GPU Adreno 660".** Mình không tìm thấy báo cáo nào, tốt hoặc xấu, cho đúng GPU này ở bất kỳ engine nào. Chọn engine bằng cách đọc tài liệu **không** thể đảm bảo "không dính lỗi như MNN".
2. **Lỗi "GPU Adreno ra chữ rác" không riêng MNN.** Có báo cáo cùng loại ở llama.cpp (Vulkan, Adreno 740), LiteRT-LM (OpenCL, Adreno 750), ExecuTorch (Vulkan, Adreno 840/S25), MediaPipe (GPU, S23 Ultra…) — xem bảng ở mục 4. Điểm chung: **đường tính toán GPU của Adreno (driver + compiler) là bãi mìn**, bất kể engine nào.
3. Vì vậy cách để khỏi "xây và debug xong lại công cốc" là **THỬ TRƯỚC KHI XÂY**: chạy bản dựng sẵn của từng engine trên đúng máy của bạn, 1 prompt cố định + 1 prompt dài, so GPU với CPU. Không tốn dòng code nào. Xem mục 5.
4. Về khả năng tích hợp (không tính GPU), **llama.cpp vẫn là ứng viên engine thứ hai tốt nhất** (nạp thẳng file GGUF không cần chuyển đổi, sampler/template/KV đầy đủ, dự án rất sống). Nhưng riêng GPU Adreno 6xx đời điện thoại thì **tài liệu chính thức của llama.cpp tự nói "likely not supported"** cho đường OpenCL; đường Vulkan chưa có bằng chứng cho 660.
5. **Phép thử rẻ nhất, và không bỏ phí công MNN: backend Vulkan của chính MNN.** Mình đã đọc mã MNN 3.6.1 (đúng bản CI của bạn đang ghim): MNN có Vulkan riêng cho LLM (Attention + KV cache + conv int4/int8, có đường riêng cho Adreno). Bản build hiện tại KHÔNG bật nó. Bản giao lần này đã thêm: cờ build + 2 nút "Thử Vulkan" + log đọc khả năng Vulkan thật của máy. Mặc định của app **không đổi**.
6. Các engine còn lại: MLC-LLM, LiteRT-LM, ExecuTorch vướng ở "model do người dùng tự chuyển" hoặc thiếu tính năng runtime (mục 3); ONNX Runtime GenAI, mllm, ncnn, QNN/Genie bị loại (mục 3).

Thứ tự đề xuất: **T0 (MNN Vulkan, trong app) → T1 (llama.cpp trong Termux, không code) → T2/T3 (Google AI Edge Gallery, MLC Chat, không code) → chỉ xây engine nào qua phép thử.**

---

## 1. Thước đo lấy từ tài liệu kỹ thuật của dự án

| Mã | Yêu cầu | Nguồn trong spec |
|---|---|---|
| R1 | Model local chạy trên **GPU** (ít nhất) trên Adreno 660 và cho **chữ ĐÚNG**; CPU-only là "vứt" (tôn chỉ yêu cầu số 1) | mục 1, 2.x |
| R2 | Nhúng được vào Flutter qua Platform Channel + Kotlin/JNI (không `dart:ffi`); build hoàn toàn bằng GitHub Actions, không cần PC | mục 2, 3 |
| R3 | **Model do người dùng tự cấp**, không hardcode theo model; chuyển đổi bằng Colab | mục 2.2, 3 |
| R4 | Tính năng runtime: stream từng token, hủy thật, tái dùng KV/prefix, sampler (temp/top_p/top_k/repetition), chat template đọc từ model, UTF-8 đúng, prompt dài 8k+ (Story Bible) | mục 65, AV/AQ/BD/BE |
| R5 | Dự án còn sống, có người sửa lỗi (khỏi bị bỏ rơi như các wrapper Dart cũ) | mục 2.2 |
| R6 | 7–8B q4 trên 16GB, 2 slot độc lập, nạp/gỡ nhiều lần không rò bộ nhớ GPU (MNN OpenCL từng giữ ~3,6GB mỗi lần nạp, mục CO) | mục CO |

NPU đã loại bằng phần cứng, không phải bằng engine: Hexagon v68 < v73 mà Qualcomm Genie/AI Hub yêu cầu (spec mục 5.52). Không engine nào cứu được chuyện này.

---

## 2. Bảng chấm (PASS / PARTIAL / FAIL / ?)

`?` = không có bằng chứng, **không phải** "chắc là được".

| Engine | R1 GPU đúng trên 660 | R2 nhúng + build CI | R3 model tự cấp | R4 runtime | R5 sống | R6 7–8B/16GB/2 slot |
|---|---|---|---|---|---|---|
| **MNN (hiện tại), OpenCL** | **FAIL** (log của bạn: rác ở fp16 và fp32) | PASS (đã làm) | PARTIAL (phải chuyển trong Colab) | PASS (đã làm) | PASS | PARTIAL (rò KGSL ~3,6GB/lần nạp) |
| **MNN, Vulkan** (phép thử T0) | **?** | PASS (đổi cờ build) | như trên | như trên | PASS | **?** |
| **llama.cpp** (CPU/Vulkan/OpenCL) | **?** (OpenCL: tài liệu nói A6x điện thoại "likely not supported"; Vulkan: **?**) | PARTIAL (phải viết cầu JNI; có sẵn ví dụ Android chính thức) | **PASS** (GGUF nạp thẳng, không chuyển) | **PASS** (sampler, DRY, template, KV, cancel) | **PASS** | PARTIAL (CPU quen thuộc; GPU **?**) |
| **MLC-LLM** | **?** (không có bằng chứng 6xx) | PARTIAL (build nặng, không có CI Android upstream) | **FAIL** bản gốc (mỗi model 1 thư viện biên dịch sẵn nhúng trong app) | PARTIAL (thiếu top_k/min_p/DRY, template là preset) | PARTIAL (nhóm nhỏ, APK cuối 2024-09) | **?** |
| **LiteRT-LM (Google)** | **?** + rủi ro danh sách thiết bị (mục 3.3) | PASS (AAR Kotlin ổn định) | PARTIAL (cần ≥32GB RAM host để chuyển, chỉ từ HF bf16) | PARTIAL (thiếu min_p, hủy làm hỏng phiên) | PASS | **?** (chưa có tiền lệ 7–8B) |
| **ExecuTorch (Vulkan)** | **?** | PARTIAL | PARTIAL (danh sách model cố định; 8B cần ≥32GB RAM host — tự tính) | **FAIL-ish** (chỉ temperature; không top_p/top_k/repetition/template) | PASS | **?** (chỉ có bằng chứng 1B/3B) |
| **ONNX Runtime GenAI** | **FAIL** (không có đường GPU cho Android ngoài QNN/NPU) | PARTIAL | PARTIAL | ? | PASS | ? |
| **mllm** | **FAIL/?** (OpenCL còn TODO cho Adreno; NPU cần v73+) | PARTIAL | FAIL (model theo danh sách) | ? | PARTIAL | ? |
| **ncnn** | — (không phải runtime LLM: ví dụ chỉ có CV/whisper/TTS) | — | — | — | PASS | — |
| **QNN/Genie** | **FAIL** (phần cứng v68) | — | — | — | — | — |

---

## 3. Chi tiết từng engine (có bằng chứng)

### 3.1 MNN Vulkan — phép thử rẻ nhất (mình đã đọc mã nguồn thật)

- **CI của bạn ghim MNN 3.6.1**, không phải 3.5.0: `build.yml:427` (`git clone --depth 1 --branch 3.6.1`), mục CE. Các bình luận cũ trong build.yml vẫn ghi "3.5.0" — chỉ là bình luận cũ. **[MÃ]**
- LLM engine của MNN nhận `backend_type: "vulkan"`: `transformers/llm/engine/src/llm.cpp:48` và `:340` (đặt `shapeMutable=false` cho opencl/vulkan/npu). **[MÃ, bản 3.6.1]**
- Kernel Attention + KV cache cho Vulkan (có biến thể fp16, prefill/decode riêng): `source/backend/vulkan/buffer/execution/VulkanAttention.cpp`. **[MÃ]**
- Conv có đường lượng tử int4/int8 và **đường riêng cho Adreno** (cooperative matrix nếu máy khai báo đủ, nếu không rơi về `VulkanConv1x1General`): `buffer/execution/VulkanConvolution.cpp:569–613`. **[MÃ]**
- **Bẫy cấu hình:** các file trên nằm trong `buffer/`. CMake mặc định `MNN_VULKAN_IMAGE=ON` lại biên dịch thư mục `image/` (không có Attention) — `source/backend/vulkan/CMakeLists.txt:1–6`. Muốn LLM chạy được phải build `-DMNN_VULKAN=true -DMNN_VULKAN_IMAGE=false`. **[MÃ]**
- Shader đã biên dịch sẵn nằm trong repo (`buffer/compiler/AllShader.cpp`, ~9MB, có shader attention) nên **không cần glslc/Vulkan SDK** khi build; `libvulkan.so` được dlopen lúc chạy (không thêm phụ thuộc link). **[MÃ]**
- Chế độ GPU của Vulkan chỉ nhận cờ 1/2/4 (+0x200) — `runtime/VulkanRuntime.cpp:116–121`; vì thế config Vulkan dùng `thread_num: 4`, **không** dùng 68 như OpenCL. **[MÃ]**
- Bằng chứng gián tiếp ủng hộ thử: issue MNN #4836 (Intel Iris Xe) báo OpenCL ra rác trong khi **CPU và Vulkan trên cùng máy đều đúng** (spec mục BH). Đây **không** phải Adreno — chỉ là gợi ý rằng đường Vulkan có thể độc lập với lỗi OpenCL. **[BÁO CÁO]**
- Bằng chứng ngược: issue MNN #2907 (2024) có người báo OpenCL và Vulkan đều **chậm hơn CPU** (spec mục BN). **[BÁO CÁO]**
- **Chưa biết:** Vulkan của MNN có đúng trên Adreno 660 không; Adreno 660 có khai báo `VK_KHR_16bit_storage` / `shaderFloat16` / subgroup arithmetic đủ để các shader này chạy không (**[CHƯA BIẾT]** — log `[CU-VK]` mới thêm sẽ trả lời); có lùi âm thầm từng toán tử về CPU không.
- Lý do đây là phép thử TỐT NHẤT để làm trước: giữ nguyên toàn bộ công sức MNN, đổi 1 cờ build + 1 nhánh cấu hình; nếu hỏng thì không mất gì, nếu đúng thì giải quyết R1 mà không phải đổi engine.

### 3.2 llama.cpp (khảo sát chi tiết ở `LocalNovel_LlamaCpp_Survey.md`)

- OpenCL: tài liệu chính thức chỉ liệt kê đã kiểm chứng Adreno 750/810/830/840/X1-85/X2-90; nguyên văn: *"A6x GPUs in phones are likely not supported due to the outdated driver and compiler"* và flash-attention *"does not work on A6xx GPUs found in phones with old drivers and compilers"* (`docs/backend/OPENCL.md`, đã lấy lại từ GitHub master hôm nay). **[MÃ/TÀI LIỆU]**
- Vulkan: máy phải có `storageBuffer16BitAccess` mới được dùng (`ggml/src/ggml-vulkan/ggml-vulkan.cpp:16243–16254`). Đường cooperative matrix cho Adreno chỉ bật khi máy có CẢ `VK_KHR_cooperative_matrix` và `VK_QCOM_cooperative_matrix_conversion` (`:130–145`, `:16257–16271`) — **[SUY LUẬN]** Adreno 660 đời 2021 nhiều khả năng thiếu các extension này nên sẽ đi đường shader thường; log `[CU-VK]` sẽ cho biết thật. **[MÃ + SUY LUẬN]**
- Có báo cáo Vulkan Adreno **ra rác**: issue #20603 — Adreno 740, trên nhánh rebase Qwen3.5 ra gibberish (CPU đúng); trên master đúng nhưng 6–10 tok/s, **chậm hơn CPU**; không có lời giải. **[BÁO CÁO]**
- Không tìm được kết quả Adreno 6xx nào đáng tin trong discussion hiệu năng Vulkan (#10879) hay các bài hướng dẫn (có 1 gist ghi rõ "NOT YET TESTED", không có số liệu). **[CHƯA BIẾT]**
- Điểm mạnh thật (không liên quan GPU): nạp GGUF thẳng — hợp R3 nhất; sampler/DRY/template/KV đầy đủ; dự án cực sống.

### 3.3 LiteRT-LM (Google) — kết quả của tác tử khảo sát, mình chưa tự mở từng issue

- Hướng chính thức mới của Google: MediaPipe LLM Inference đã `@deprecated` ("Migrate to LiteRT LM"), ai-edge-torch đổi tên thành litert-torch. API Kotlin ổn định (`Engine/Conversation/Session`), AAR trên Google Maven. **[MÃ]**
- GPU = OpenCL (ML Drift), WebGPU chỉ là dự phòng khi không có OpenCL (`litert/litert/runtime/accelerators/gpu/ml_drift_gpu_accelerator.cc:177–190`). Cần khai báo `libOpenCL.so` trong manifest. **[MÃ]** → **[SUY LUẬN]** nếu gốc rễ lỗi của MNN là driver/compiler OpenCL của Adreno 660 thì đường này chung rủi ro.
- **Rủi ro mới:** commit 57bddb9 (2026-10-07) thêm kiểm tra *danh sách tương thích thiết bị* cho GPU (`gpu_registry.cc:51–66`); tác tử giải mã `mldrift_compatibility.bin` thấy Adreno 660 chỉ có vài model máy cụ thể, **không có ASUS**. LiteRT-LM ghim LiteRT ở 2026-09-25 (`litertlm/WORKSPACE:6`), trước commit này. → phải **ghim phiên bản**, bản mới có thể chặn GPU trên Zenfone 8. **[MÃ, giải mã nhị phân chưa tự kiểm lại]**
- Báo cáo lỗi GPU (đều Adreno 7xx, không có 6xx): #3012 (Adreno 750, prompt ~2k token, chữ hỏng, CPU sạch), #3577 (OpenCL Adreno, int4 + Hadamard sai kể cả fp32, `wi8` đúng), #3867 (SIGSEGV WebGPU Adreno 750); MediaPipe #5414/#5534/#5553 (GPU lặp token). **[BÁO CÁO]**
- **R3 nặng:** `litert-torch export_hf` đọc HF bf16, **cần ≥32GB RAM** (`litert_torch/generative/README.md`), từ chối rope dynamic/longrope và checkpoint đã lượng tử (`export_lib.py:98–135`); không dùng được GGUF/AWQ; chưa có tiền lệ 7–8B (model lớn nhất trong allowlist Gallery là E4B 3,66GB). Colab miễn phí không đủ. **[MÃ]**
- **R4:** sampler chỉ topK/topP/temperature/seed (`Config.kt:295`), phạt lặp truyền theo từng lần gửi, không min_p; hủy (`cancelProcess`) làm hỏng phiên, phải tạo lại và prefill lại (`runtime/engine/engine.h:262–268`). **[MÃ]**

### 3.4 MLC-LLM — kết quả của tác tử, bản clone HEAD 8978ea9 (2026-10-07)

- GPU qua OpenCL do TVM sinh kernel (`JSONFFIEngine.java` ghim `Device.opencl()`); `q4f16_*` cần `cl_khr_fp16`. Không có bằng chứng nào cho Adreno 660/640/SD888; chỉ có Adreno 730/740/750 và không nguồn nào kiểm tra độ đúng của chữ. **[MÃ + BÁO CÁO]**
- **R3 là điểm chết:** đường chính thức nhúng *mỗi model một thư viện biên dịch sẵn* (`libmodel_android.a`) vào `libtvm4j_runtime_packed.so`; app mẫu từ chối thư viện lạ (`AppViewModel.kt:169–171`). Có đường `dlopen` `.so` bất kỳ ở C++ (`function_table.cc:106–130`) nhưng wrapper Kotlin không dùng và chưa ai thử trên Android 13. **[MÃ]**
- Layout `_1` làm treo UI 20–50 giây ở lần prefill đầu trên Adreno (docs "Known issues" + bài Callstack), phải dùng `_0`. **[TÀI LIỆU]**
- Thiếu top_k/min_p/DRY; `repetition_penalty` có trong `GenerationConfig` nhưng không nối vào đường JSON-FFI; template là preset chọn lúc `gen_config` (không đọc từ tokenizer); `abort` có ở C++ nhưng chưa lộ ra Kotlin. **[MÃ]**
- Sức sống: `android/` chỉ còn commit giữ cho build được (cuối 2026-04-21), APK dựng sẵn mới nhất 2024-09-26, tag stable v0.20.0 (2026-07-07). **[MÃ]**

### 3.5 ExecuTorch — kết quả của tác tử, `version.txt` 1.6.0

- Vulkan chạy LLM end-to-end có bằng chứng **chỉ cho Llama 3.2 1B/3B** (tutorial dùng Galaxy S24 ~52 tok/s); tài liệu ghi Vulkan cho export LLM là *"experimental and limited"* (`docs/source/llm/export-llm.md:147`). **[MÃ]**
- Báo cáo lỗi Adreno đời mới: #22327 (Adreno 840, `nn.Linear` fp32 sai ~23% lượt ở M lớn), #21938 (conv2d không xác định), PR #23350 (S25: driver bỏ qua workgroup xen kẽ ở reduction → sai kết quả; đã merge 2026-10-02). **[BÁO CÁO]**
- R4 yếu: `LlmGenerationConfig` chỉ có temperature; `top_p` cứng 0,9; không top_k/repetition; không template trong runner. **[MÃ]**
- Danh sách model cố định (`llm_config.py:34–53`, Qwen chỉ tới `qwen3_4b`); export phải fp32 nên 8B cần ~32GB RAM host (**[SUY LUẬN]** 8e9×4B, chưa đo). **[MÃ + SUY LUẬN]**

### 3.6 Các engine bị loại và lý do

- **ONNX Runtime GenAI:** README liệt kê tăng tốc phần cứng gồm CPU/CUDA/DirectML/TRT-RTX/OpenVINO/QNN/WebGPU/AMD — không có đường GPU riêng cho Android; QNN là NPU (v68 bị loại). WebGPU trên Android **[CHƯA BIẾT]**. (`ort/README.md:21–23`) **[MÃ]**
- **mllm:** README ghi "Arm CPU, OpenCL GPU, QNN NPU, Ascend" (`README.md:80`) nhưng nhánh OpenCL cho Adreno còn `TODO` (`mllm/backends/opencl/runtime/OpenCLLoader.hpp:20–21`), bảng model chỉ có CPU và Hexagon NPU (SM8650), máy test là Snapdragon 8 Elite. **[MÃ]**
- **ncnn:** thư mục `examples/` chỉ có CV/whisper/TTS (piper), không có ví dụ LLM — không phải runtime LLM đã kiểm chứng. (Các nhánh fork cộng đồng: **[CHƯA BIẾT]**) **[MÃ]**
- **QNN/Genie:** loại bằng phần cứng (mục 1).
- **Dự án nhỏ lẻ "adreno-llms"** (a8nova): OpenCL thuần nhắm Adreno 6xx, nhưng 1 tác giả, 17 sao, test chính trên Adreno 620, model ≤0,5B được tinh chỉnh kernel theo từng hình dạng model ("kích thước khác có thể chạy kém hoặc lỗi") — **trái nguyên tắc "không hardcode model"**; chỉ có giá trị tham khảo rằng OpenCL thuần trên 6xx *có thể* cho kết quả đúng. **[BÁO CÁO]**
- **WebLLM/WebGPU trong WebView:** chưa khảo sát đủ để chấm. Một dấu hiệu bất lợi: giới hạn binding 128MiB của WebGPU từng gây output rác (llamadart#553, theo tác tử). **[CHƯA BIẾT / BÁO CÁO]**

---

## 4. Mẫu lỗi chung: GPU Adreno ra kết quả sai ở NHIỀU engine

| Engine | Backend | GPU | Triệu chứng | Nguồn / mức tin |
|---|---|---|---|---|
| MNN 3.5.0 | OpenCL | Adreno 660 (máy bạn) | chữ rác ở fp16 VÀ fp32; CPU đúng | log của bạn, spec CN/CO — **bằng chứng mạnh nhất** |
| llama.cpp | Vulkan | Adreno 740 | gibberish (nhánh rebase); master đúng nhưng chậm hơn CPU | issue #20603 — [BÁO CÁO] |
| LiteRT-LM | OpenCL | Adreno 750 | chữ hỏng ở prompt ~2k token | #3012 — [BÁO CÁO, qua tác tử] |
| LiteRT-LM | OpenCL | Adreno (int4 + Hadamard) | sai kể cả fp32 | #3577 — [BÁO CÁO, qua tác tử] |
| ExecuTorch | Vulkan | Adreno 840 / S25 | `nn.Linear` sai ~23% lượt; reduction sai | #22327, PR #23350 — [BÁO CÁO, qua tác tử] |
| MediaPipe | GPU | S23 Ultra… | lặp token | #5414/#5534/#5553 — [BÁO CÁO, qua tác tử] |

Ý nghĩa: (a) lỗi của bạn **không chứng minh MNN là "phế vật"** — cùng loại lỗi xuất hiện ở engine do Google/Meta/ggml-org bảo trì, trên cả Adreno đời mới; (b) ngược lại cũng không có lý do tin engine khác "sẽ chạy đúng" trên 660; (c) lỗi hay lộ ở **prompt dài** (#3012) — đúng kiểu prompt Story Bible của app, nên phép thử phải có prompt dài.

Gốc rễ lỗi trên máy bạn vẫn **chưa chứng minh** (engine, driver, hay cách tích hợp; spec mục CQ chỉ là giả thuyết cache). Phép thử T0 (Vulkan, cùng engine, cùng model, cùng cách tích hợp) phân biệt được một phần: nếu Vulkan của MNN đúng thì lỗi nằm ở đường OpenCL chứ không ở cách tích hợp hay file model.

---

## 5. Phép thử quyết định (làm trên điện thoại, theo thứ tự rẻ → đắt)

**Quy tắc chung cho mọi phép thử** (để so sánh công bằng):
- Cùng một họ model, Q4, cùng 1 prompt ngắn cố định (vd "Đếm từ 1 đến 20 bằng tiếng Việt, mỗi số một dòng") + 1 prompt dài ~2.000 token (dán một đoạn Story Bible thật rồi hỏi 1 câu về nội dung nó).
- Nhiệt độ 0 (hoặc thấp nhất cho phép), chạy GPU rồi CPU với cùng cài đặt, ghi lại cả hai.
- **ĐẠT** = ngắn: chữ mạch lạc, không lặp, không ký tự đa ngôn ngữ vô nghĩa (fp16 lệch vài token so với CPU là bình thường); dài: trả lời bám nội dung đoạn đã dán. **TRƯỢT** = bất kỳ chuỗi rác/lặp nào → engine đó chết với R1 trên máy này, **không xây**.
- Chỉ khi ĐẠT mới đo tốc độ prefill/decode và RAM/bộ nhớ GPU.

| # | Phép thử | Cần code? | Trả lời câu hỏi gì |
|---|---|---|---|
| **T0** | Trong chính app: chọn "Thử Vulkan fp32" rồi "Thử Vulkan (fp16)" ở Tối ưu AI local; nạp đúng model đã gây rác; xem `native_debug.txt` (dòng `[CU-VK]`) | Có (đã thêm sẵn ở bản này; cần build 1 lần) | MNN Vulkan có đúng trên 660 không; máy khai báo gì |
| **T1** | Termux: cài `llama-cpp` + backend Vulkan (và OpenCL) từ kho Termux (tên gói chính xác: kiểm tra bằng `pkg search llama`); chạy `llama-cli -m <gguf> -ngl 99 --temp 0 …` rồi `-ngl 0`. | Không | llama.cpp Vulkan/OpenCL có đúng trên 660 không |
| **T2** | App **Google AI Edge Gallery**: chạy Qwen2.5-1.5B và Gemma3-1B ở GPU rồi CPU; thử thêm prompt tiếng Việt dài | Không | LiteRT-LM GPU có đúng và có bị danh sách thiết bị chặn không |
| **T3** | **MLC Chat** APK 2024-09-26 (binary-mlc-llm-libs): model hậu tố `_0` | Không | MLC trên Adreno 660 có đúng không (chỉ chứng minh R1, không chứng minh R3) |

Lưu ý: T2/T3 chỉ chứng minh R1; nếu qua vẫn còn R3 (chuyển model tự cấp) là chướng ngại lớn như mục 3.3/3.4.

---

## 6. Quyết định kiến trúc đề xuất

1. **Giữ MNN** (đã chốt). Không gỡ gì.
2. Thêm **giao diện engine trừu tượng** (`NativeEngine`, chọn engine theo định dạng file: thư mục MNN vs `.gguf`) như đã thiết kế ở `LocalNovel_LlamaCpp_Survey.md` mục 3 — thiết kế này **không phụ thuộc** engine thứ hai là ai, nên không bị "công cốc" dù T0–T3 kết quả thế nào.
3. **Chưa xây cầu cho engine thứ hai** cho tới khi T0/T1 có kết quả:
   - Nếu **T1 Vulkan/OpenCL đúng**: xây llama.cpp ưu tiên cao (vừa giải R1 vừa giải R3).
   - Nếu **T0 đúng, T1 sai**: ở lại MNN + Vulkan, llama.cpp chỉ còn giá trị "chạy GGUF khỏi chuyển đổi" (CPU), ưu tiên thấp hơn — do bạn quyết.
   - Nếu **cả hai sai**: theo bằng chứng hiện có không engine nào cứu được R1 trên Adreno 660; còn các hướng đã có trong app (GPU từ xa qua Colab, API/Gemini, web chat, model thư ký) hoặc máy đời mới hơn (llama.cpp OpenCL có tài liệu xác nhận cho Adreno 750+).
4. Quy tắc từ bài học này (đề xuất ghi vào spec): **mọi engine mới phải có "bằng chứng đúng trên GPU của máy test" TRƯỚC khi viết cầu JNI** — vì các engine trước đây được chọn theo benchmark tốc độ (MNN Chat 129,8/16,7 token/s) mà không ai kiểm chữ có đúng không.

---

## 6b. Nếu chấp nhận quay lại CPU: tốc độ CPU của MNN so với engine khác (bổ sung 2026-10-10)

Câu hỏi của bạn: "CPU của MNN không chỉ đúng mà còn nhanh hơn GPU; vậy so với engine khác thì sao?"

**1. Trí nhớ của bạn khớp spec — nhưng số đo cho thấy "nhanh hơn" chỉ ở mức vừa phải.**
- Spec mục BH (19/9): bạn tự đổi sang "Ép CPU" → hết lặp chữ và "CPU còn nhanh hơn GPU". Đó là quan sát định tính của bạn.
- Số đo trong log (đồng hồ STEADY, UTENA-7B, mục CJ/CK; mỗi ô chỉ 1 mẫu, prompt khác nhau nên KHÔNG sạch):

| | GPU OpenCL | CPU (ép) |
|---|---|---|
| Prefill (tới byte đầu) | 219 s (736 ký tự) / 483 s (1261 ký tự) khi tuning lạnh; **61 s** (1062 ký tự) khi tuning đã ấm | 49 s (1026 ký tự) / 62 s (1152 ký tự) |
| Decode | ~11,2 và ~5,5 byte/s | ~8,4 và ~4,8 byte/s |

  → CPU nhanh hơn rõ ở prefill so với GPU **lạnh** (4–8 lần); khi GPU đã ấm thì ngang nhau; decode GPU nhỉnh hơn một chút (2 mẫu). Tức "CPU ≈ GPU, GPU chỉ thua nặng khi dò kernel lạnh" — không phải "CPU hơn hẳn". Lý do dễ hiểu (spec BH): decode bị giới hạn băng thông RAM dùng chung, GPU không có lợi thế.
- Đơn vị là byte/s chứ không phải token/s, nên **chưa có con số token/s thật của MNN CPU trên máy này**. Bản build này thêm log `[CU-SPEED] backend=... prefill ~X tok/s, decode ~Y tok/s` (mnn_bridge.cpp) để có số thật ở lần chạy tới. Lưu ý: `prompt_len` có thể gồm cả token đã nằm trong KV cache nên số prefill chỉ mang tính chỉ báo.
- "CPU ~1 token/s" ghi trong spec (dòng ~76) là của các engine cũ bọc bằng Dart, không phải MNN. Tiền đề "GPU phải nhanh hơn CPU rất nhiều mới đáng dùng" vì thế yếu hơn lúc đặt tôn chỉ ban đầu — cái GPU còn mua được là prefill nhanh cho prompt dài (Story Bible) *nếu* chạy đúng, và nhẹ nhiệt hơn (chưa đo).

**2. MNN CPU so với engine khác — bằng chứng có được, nói thẳng mức tin cậy.**
- Duy nhất có số liệu: bài báo của chính nhóm MNN (arXiv 2506.10443, đọc qua trang tổng hợp, mình KHÔNG mở được bản gốc vì bị chặn): trên Xiaomi 14 (Snapdragon 8 Gen 3), CPU 4 luồng, MNN-LLM nhanh hơn llama.cpp tới ~8,6× ở prefill và ~2,0–2,3× ở decode (ví dụ Qwen2-7B prompt 64 token: 13,0 so với 6,4 tok/s); nhanh hơn fastllm tới ~8,9× ở decode.
- Lý do KHÔNG nên tin con số đó là số trên máy bạn: (a) tác giả là nhóm MNN; (b) SoC 8 Gen 3 có i8mm/dotprod mới, còn Snapdragon 888 (Kryo 680, Armv8.2) có dotprod nhưng — theo hiểu biết của mình, chưa kiểm — không có i8mm, nên phần lợi thế kernel int8 có thể nhỏ hơn; (c) bài không nêu rõ cấu hình lượng tử hoá hai bên; (d) bản llama.cpp trong bài đã cũ. Ngoài ra "decode nhanh gấp đôi" nghe lạ vì decode bị giới hạn băng thông: hoặc llama.cpp trong bài chạy chưa tối ưu (số luồng, định dạng lượng tử), hoặc hai bên đọc số byte trọng số khác nhau. Nên coi 2× là *giới hạn trên*, đừng dùng làm kỳ vọng.
- **Không tìm được số đo độc lập nào so MNN với llama.cpp trên Snapdragon 888** (và mình không có số llama.cpp CPU đã kiểm chứng cho máy này). Các engine khác (MLC-LLM, LiteRT-LM, ExecuTorch, ORT GenAI…) không có số CPU đáng tin cho 7–8B trên SoC này — phần lớn đường nhanh của chúng là GPU/NPU, mà đó lại chính là chỗ Adreno 660 có vấn đề.
- Suy luận (không phải số đo): decode CPU của mọi engine đều chạm cùng một trần băng thông RAM (cùng ~4 GB trọng số 7B Q4 phải đọc cho mỗi token), nên chênh lệch giữa các engine CPU sẽ lộ ra chủ yếu ở **prefill** (bị giới hạn tính toán, phụ thuộc kernel dotprod). Đó cũng là chỗ MNN tuyên bố hơn.

**3. Kết luận thực dụng.** Không có lý do bằng chứng để chuyển engine chỉ vì tốc độ CPU; cũng không có bằng chứng ngược lại. Cách trả lời chắc chắn nhất là đo cạnh nhau cùng máy, cùng họ model, cùng lượng tử hoá:
1. MNN: chạy app với "Ép CPU", đọc `[CU-SPEED]` trong log (prompt ngắn + prompt ~2.000 token).
2. llama.cpp: Termux, `llama-bench -m <GGUF Q4 cùng họ model> -t 4 -ngl 0` (chỉ CPU; tên gói/bản build trong Termux cần kiểm bằng `pkg search llama`; bật `termux-wake-lock`; theo dõi nhiệt độ vì máy sẽ throttle). So pp (prefill) và tg (decode).
3. Cùng họ model nghĩa là cùng kích thước và gần cùng bits/weight; nếu không so sánh sẽ lệch.
Nếu llama.cpp CPU không hơn MNN CPU rõ rệt thì **ở lại MNN-CPU** là lựa chọn rẻ nhất, vì giữ nguyên mọi thứ đã xây.

**4. Một manh mối cho R3 (chưa kiểm chứng).** Tài liệu MNN 3.6.1 (`docs/transformers/llm.md`, khoảng dòng 311–326) liệt kê `transformers/llm/export/gguf2mnn.py` (GGUF → MNN) và `safetensors2mnn.py`. Nếu chạy được, người dùng có thể nạp model GGUF phổ biến mà không cần bản xuất MNN riêng. Mình chưa chạy thử; cần thử trên Colab trước khi tin.

---

## 7. Những điều mình KHÔNG kiểm chứng được (nói thẳng)

- Không có engine nào được chạy thật trên Adreno 660 trong khảo sát này — mọi chấm điểm R1 đều là "chưa biết", không phải đã đo.
- Mã Dart/Kotlin chưa biên dịch được ở đây; riêng `mnn_bridge.cpp` đã qua kiểm tra cú pháp bằng clang với header MNN 3.6.1 + JNI thật, và `vulkan_probe.cpp` biên dịch sạch với `-Wall -Wextra` (có và không có header Vulkan) và chạy được đường lỗi (không có driver). **Đường đọc thông tin GPU thật chưa chạy** (máy này không có driver Vulkan).
- Chưa build MNN 3.6.1 với `-DMNN_VULKAN=true -DMNN_VULKAN_IMAGE=false` trên NDK r29 — build.yml có đường lùi tự build lại không Vulkan nếu lỗi.
- Báo cáo của tác tử về MLC-LLM, LiteRT-LM, ExecuTorch: mình đã đọc kỹ nhưng chưa tự mở từng issue/commit; giải mã `mldrift_compatibility.bin` chưa tự kiểm lại. Trang tìm kiếm issue GitHub bị chặn nên có thể còn báo cáo Adreno 6xx mà không tìm thấy.
- Adreno 660 khai báo những extension Vulkan nào: **[CHƯA BIẾT]** (log `[CU-VK]` sẽ cho biết).
- Tốc độ CPU của llama.cpp/MNN (token/s) trên Snapdragon 888 cho 7–8B: không có số đo trong khảo sát này; chỉ có số byte/s trong log của bạn và số của nhóm MNN trên SoC khác (mục 6b).

---

## Nguồn chính

- Mã nguồn đã đọc (bản clone trong phiên): MNN 3.6.1 (`d407447`) và 3.5.0 (`c35f14f`); llama.cpp `005a1e1` (2026-10-07); MLC-LLM `8978ea9`; LiteRT / LiteRT-LM / MediaPipe / litert-torch (2026-10-08); ExecuTorch 1.6.0 (`d5cb595`); ONNX Runtime GenAI `45e972d`; ncnn `c4b34c5`; mllm `1d3c3d8`.
- llama.cpp OpenCL doc: https://github.com/ggml-org/llama.cpp/blob/master/docs/backend/OPENCL.md
- llama.cpp issue #20603 (Vulkan, Adreno 740): https://github.com/ggml-org/llama.cpp/issues/20603
- ExecuTorch issue #14507 (Vulkan build, glslc): https://github.com/pytorch/executorch/issues/14507
- LiteRT-LM tổng quan: https://developers.google.com/edge/litert-lm/overview
- Callstack, hồ sơ OpenCL của MLC-LLM trên Android: https://www.callstack.com/blog/profiling-mlc-llms-opencl-backend-on-android-performance-insights
- a8nova/adreno-llms: https://github.com/a8nova/adreno-llms
- arXiv 2410.03613 (so sánh MLC vs llama.cpp trên điện thoại): https://arxiv.org/html/2410.03613v1
- arXiv 2506.10443 (MNN-LLM, số CPU/GPU trên Snapdragon 8 Gen 3 — đọc qua trang tổng hợp, chưa mở bản gốc): https://arxiv.org/abs/2506.10443
- MNN docs LLM (gguf2mnn.py / safetensors2mnn.py): https://github.com/alibaba/MNN/blob/master/docs/transformers/llm.md
